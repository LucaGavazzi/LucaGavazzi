( function () {
	var toggle = document.querySelector( '.bh-menu-toggle' );
	var nav = document.getElementById( 'bh-nav' );
	if ( ! toggle || ! nav ) {
		return;
	}
	toggle.addEventListener( 'click', function () {
		var open = nav.classList.toggle( 'is-open' );
		toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
	} );
	nav.addEventListener( 'click', function ( e ) {
		if ( e.target.tagName === 'A' ) {
			nav.classList.remove( 'is-open' );
			toggle.setAttribute( 'aria-expanded', 'false' );
		}
	} );
} )();
