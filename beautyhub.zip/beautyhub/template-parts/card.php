<?php
/**
 * Card articolo/trattamento.
 *
 * @package BeautyHub
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'bh-card' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'beautyhub-card' ); ?></a>
	<?php endif; ?>
	<div class="bh-card__body">
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<div class="bh-card__meta"><?php echo esc_html( get_the_date() ); ?></div>
		<?php the_excerpt(); ?>
	</div>
</article>
