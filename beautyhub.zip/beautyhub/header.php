<?php
/**
 * Header del tema.
 *
 * @package BeautyHub
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#bh-main"><?php esc_html_e( 'Vai al contenuto', 'beautyhub' ); ?></a>

<?php if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'header' ) ) : ?>
<header class="bh-header">
	<div class="bh-container bh-header__inner">
		<div class="bh-brand">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a class="bh-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?><span>.</span></a>
			<?php endif; ?>
		</div>

		<nav class="bh-nav" id="bh-nav" aria-label="<?php esc_attr_e( 'Menu principale', 'beautyhub' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'depth'          => 1,
					'fallback_cb'    => 'beautyhub_fallback_menu',
				)
			);
			?>
		</nav>

		<div class="bh-header__actions">
			<a class="bh-btn" href="<?php echo esc_url( beautyhub_booking_url() ); ?>">
				<?php echo esc_html( get_theme_mod( 'beautyhub_book_label' ) ? get_theme_mod( 'beautyhub_book_label' ) : __( 'Prenota', 'beautyhub' ) ); ?>
			</a>
			<button class="bh-menu-toggle" aria-controls="bh-nav" aria-expanded="false">
				<span class="screen-reader-text"><?php esc_html_e( 'Apri menu', 'beautyhub' ); ?></span>
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
			</button>
		</div>
	</div>
</header>
<?php endif; ?>

<main id="bh-main" class="bh-main">
