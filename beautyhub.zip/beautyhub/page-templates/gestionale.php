<?php
/**
 * Template Name: BeautyHub – Gestionale (senza header e footer)
 * Template Post Type: page
 *
 * Pagina a schermo intero per la dashboard dello staff (tablet alla reception).
 *
 * @package BeautyHub
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'bh-app-body' ); ?>>
<?php
wp_body_open();
while ( have_posts() ) :
	the_post();
	the_content();
endwhile;
wp_footer();
?>
</body>
</html>
