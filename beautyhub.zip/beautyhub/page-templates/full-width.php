<?php
/**
 * Template Name: BeautyHub – Larghezza piena (Elementor)
 * Template Post Type: page, post
 *
 * Header e footer del tema, contenuto a tutta larghezza senza titolo:
 * ideale per pagine costruite con Elementor.
 *
 * @package BeautyHub
 */

get_header();
while ( have_posts() ) :
	the_post();
	the_content();
endwhile;
get_footer();
