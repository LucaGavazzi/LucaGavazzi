<?php
/**
 * Template articolo singolo / trattamento singolo.
 *
 * @package BeautyHub
 */

get_header();

if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) :
	while ( have_posts() ) :
		the_post();
		?>
		<section class="bh-page-hero">
			<div class="bh-container">
				<?php the_title( '<h1>', '</h1>' ); ?>
				<?php if ( 'post' === get_post_type() ) : ?>
					<p><?php echo esc_html( get_the_date() ); ?></p>
				<?php endif; ?>
			</div>
		</section>
		<div class="bh-content">
			<div class="bh-container">
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="entry-content"><figure class="alignwide"><?php the_post_thumbnail( 'large' ); ?></figure></div>
				<?php endif; ?>
				<div class="entry-content">
					<?php
					the_content();
					wp_link_pages();
					?>
				</div>
				<?php
				if ( comments_open() || get_comments_number() ) {
					echo '<div class="entry-content">';
					comments_template();
					echo '</div>';
				}
				?>
			</div>
		</div>
		<?php
	endwhile;
endif;

get_footer();
