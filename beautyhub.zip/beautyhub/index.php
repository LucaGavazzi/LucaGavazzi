<?php
/**
 * Template principale (archivi, blog, ricerca).
 *
 * @package BeautyHub
 */

get_header();

if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'archive' ) ) :
	?>
	<section class="bh-page-hero">
		<div class="bh-container">
			<h1>
				<?php
				if ( is_home() && ! is_front_page() ) {
					single_post_title();
				} elseif ( is_search() ) {
					/* translators: %s: termine cercato */
					printf( esc_html__( 'Risultati per “%s”', 'beautyhub' ), esc_html( get_search_query() ) );
				} elseif ( is_archive() ) {
					the_archive_title();
				} else {
					esc_html_e( 'Novità e consigli', 'beautyhub' );
				}
				?>
			</h1>
			<?php the_archive_description( '<p>', '</p>' ); ?>
		</div>
	</section>

	<div class="bh-content">
		<div class="bh-container">
			<?php if ( have_posts() ) : ?>
				<div class="bh-cards">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/card' );
					endwhile;
					?>
				</div>
				<?php beautyhub_pagination(); ?>
			<?php else : ?>
				<p><?php esc_html_e( 'Nessun contenuto trovato.', 'beautyhub' ); ?></p>
				<?php get_search_form(); ?>
			<?php endif; ?>
		</div>
	</div>
	<?php
endif;

get_footer();
