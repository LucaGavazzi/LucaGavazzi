<?php
/**
 * Template pagina.
 *
 * @package BeautyHub
 */

get_header();

if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) :
	while ( have_posts() ) :
		the_post();
		$beautyhub_elementor = did_action( 'elementor/loaded' ) && \Elementor\Plugin::$instance->documents->get( get_the_ID() ) && \Elementor\Plugin::$instance->documents->get( get_the_ID() )->is_built_with_elementor();
		?>
		<?php if ( ! $beautyhub_elementor && ! is_front_page() ) : ?>
			<section class="bh-page-hero">
				<div class="bh-container"><?php the_title( '<h1>', '</h1>' ); ?></div>
			</section>
		<?php endif; ?>
		<div class="bh-content">
			<div class="<?php echo $beautyhub_elementor ? '' : 'bh-container'; ?>">
				<div class="entry-content">
					<?php
					the_content();
					wp_link_pages();
					?>
				</div>
			</div>
		</div>
		<?php
	endwhile;
endif;

get_footer();
