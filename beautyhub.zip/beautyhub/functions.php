<?php
/**
 * BeautyHub – funzioni del tema.
 *
 * @package BeautyHub
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BEAUTYHUB_THEME_VERSION', '1.0.0' );

/**
 * Supporti del tema.
 */
function beautyhub_setup() {
	load_theme_textdomain( 'beautyhub', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 112,
			'width'       => 320,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_theme_support(
		'editor-color-palette',
		array(
			array( 'name' => __( 'Salvia', 'beautyhub' ), 'slug' => 'salvia', 'color' => '#7d8c6f' ),
			array( 'name' => __( 'Salvia scuro', 'beautyhub' ), 'slug' => 'salvia-dark', 'color' => '#5e6b52' ),
			array( 'name' => __( 'Sabbia', 'beautyhub' ), 'slug' => 'sabbia', 'color' => '#e8dfd0' ),
			array( 'name' => __( 'Crema', 'beautyhub' ), 'slug' => 'crema', 'color' => '#f8f4ed' ),
			array( 'name' => __( 'Terracotta', 'beautyhub' ), 'slug' => 'terracotta', 'color' => '#b9805f' ),
			array( 'name' => __( 'Testo', 'beautyhub' ), 'slug' => 'testo', 'color' => '#3b3a36' ),
		)
	);

	register_nav_menus(
		array(
			'primary' => __( 'Menu principale', 'beautyhub' ),
			'footer'  => __( 'Menu footer', 'beautyhub' ),
		)
	);

	add_image_size( 'beautyhub-card', 720, 480, true );
}
add_action( 'after_setup_theme', 'beautyhub_setup' );

/**
 * Larghezza contenuti.
 */
function beautyhub_content_width() {
	$GLOBALS['content_width'] = 1180;
}
add_action( 'after_setup_theme', 'beautyhub_content_width', 0 );

/**
 * Font e stili.
 */
function beautyhub_assets() {
	wp_enqueue_style(
		'beautyhub-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Jost:wght@300;400;500&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'beautyhub-style', get_stylesheet_uri(), array( 'beautyhub-fonts' ), BEAUTYHUB_THEME_VERSION );
	wp_enqueue_script( 'beautyhub-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), BEAUTYHUB_THEME_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'beautyhub_assets' );

/**
 * Aree widget del footer.
 */
function beautyhub_widgets_init() {
	for ( $i = 1; $i <= 3; $i++ ) {
		register_sidebar(
			array(
				/* translators: %d: numero colonna */
				'name'          => sprintf( __( 'Footer colonna %d', 'beautyhub' ), $i ),
				'id'            => 'footer-' . $i,
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h4 class="widget-title">',
				'after_title'   => '</h4>',
			)
		);
	}
}
add_action( 'widgets_init', 'beautyhub_widgets_init' );

/**
 * Elementor: supporto alle location del Theme Builder (Elementor Pro)
 * e impostazioni predefinite per colori e font globali.
 */
function beautyhub_register_elementor_locations( $elementor_theme_manager ) {
	$elementor_theme_manager->register_all_core_location();
}
add_action( 'elementor/theme/register_locations', 'beautyhub_register_elementor_locations' );

/**
 * Personalizzatore: dati del centro mostrati in header/footer.
 */
function beautyhub_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'beautyhub_center',
		array(
			'title'    => __( 'Dati del centro', 'beautyhub' ),
			'priority' => 30,
		)
	);

	$fields = array(
		'beautyhub_phone'      => __( 'Telefono', 'beautyhub' ),
		'beautyhub_whatsapp'   => __( 'WhatsApp (solo numeri, con prefisso 39)', 'beautyhub' ),
		'beautyhub_address'    => __( 'Indirizzo', 'beautyhub' ),
		'beautyhub_email'      => __( 'Email', 'beautyhub' ),
		'beautyhub_hours'      => __( 'Orari (testo libero)', 'beautyhub' ),
		'beautyhub_vat'        => __( 'Partita IVA', 'beautyhub' ),
		'beautyhub_book_label' => __( 'Testo pulsante prenotazione', 'beautyhub' ),
		'beautyhub_book_url'   => __( 'Link pulsante prenotazione', 'beautyhub' ),
	);

	foreach ( $fields as $id => $label ) {
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => '',
				'sanitize_callback' => ( 'beautyhub_book_url' === $id ) ? 'esc_url_raw' : 'sanitize_text_field',
			)
		);
		$wp_customize->add_control(
			$id,
			array(
				'label'   => $label,
				'section' => 'beautyhub_center',
				'type'    => 'text',
			)
		);
	}
}
add_action( 'customize_register', 'beautyhub_customize_register' );

/**
 * Restituisce l'URL della pagina di prenotazione.
 */
function beautyhub_booking_url() {
	$url = get_theme_mod( 'beautyhub_book_url' );
	if ( $url ) {
		return $url;
	}
	$page_id = (int) get_option( 'beautyhub_page_booking' );
	return $page_id ? get_permalink( $page_id ) : home_url( '/prenota/' );
}

/**
 * Menu di riserva se non è stato assegnato un menu principale.
 */
function beautyhub_fallback_menu() {
	echo '<ul>';
	echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'beautyhub' ) . '</a></li>';
	foreach ( array( 'beautyhub_page_treatments' => __( 'Trattamenti', 'beautyhub' ), 'beautyhub_page_team' => __( 'Team', 'beautyhub' ), 'beautyhub_page_client' => __( 'Area clienti', 'beautyhub' ) ) as $opt => $label ) {
		$id = (int) get_option( $opt );
		if ( $id ) {
			echo '<li><a href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html( $label ) . '</a></li>';
		}
	}
	echo '</ul>';
}

/**
 * Avviso se il plugin BeautyHub Core non è attivo.
 */
function beautyhub_core_notice() {
	if ( defined( 'BHC_VERSION' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p>' . esc_html__( 'Il tema BeautyHub funziona al meglio con il plugin "BeautyHub Core" (gestionale, agenda e prenotazioni). Installalo e attivalo da Plugin › Aggiungi nuovo › Carica plugin.', 'beautyhub' ) . '</p></div>';
}
add_action( 'admin_notices', 'beautyhub_core_notice' );

/**
 * Paginazione semplice.
 */
function beautyhub_pagination() {
	$links = paginate_links( array( 'type' => 'plain', 'prev_text' => '&larr;', 'next_text' => '&rarr;' ) );
	if ( $links ) {
		echo '<nav class="bh-pagination" aria-label="' . esc_attr__( 'Paginazione', 'beautyhub' ) . '">' . wp_kses_post( $links ) . '</nav>';
	}
}
