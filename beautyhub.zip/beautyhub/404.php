<?php
/**
 * Pagina non trovata.
 *
 * @package BeautyHub
 */

get_header();
?>
<section class="bh-404 bh-container">
	<div class="bh-404__code">404</div>
	<h1><?php esc_html_e( 'Questa pagina si è presa una pausa relax', 'beautyhub' ); ?></h1>
	<p><?php esc_html_e( 'Il contenuto che cerchi non esiste o è stato spostato.', 'beautyhub' ); ?></p>
	<p>
		<a class="bh-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Torna alla home', 'beautyhub' ); ?></a>
		<a class="bh-btn bh-btn--outline" href="<?php echo esc_url( beautyhub_booking_url() ); ?>"><?php esc_html_e( 'Prenota', 'beautyhub' ); ?></a>
	</p>
</section>
<?php
get_footer();
