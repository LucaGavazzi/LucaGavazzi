<?php
/**
 * Footer del tema.
 *
 * @package BeautyHub
 */
?>
</main>

<?php if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) : ?>
<footer class="bh-footer">
	<div class="bh-container">
		<div class="bh-footer__grid">
			<div>
				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
					<?php dynamic_sidebar( 'footer-1' ); ?>
				<?php else : ?>
					<h4><?php bloginfo( 'name' ); ?></h4>
					<p><?php bloginfo( 'description' ); ?></p>
					<p><a class="bh-btn bh-btn--accent" href="<?php echo esc_url( beautyhub_booking_url() ); ?>"><?php esc_html_e( 'Prenota un trattamento', 'beautyhub' ); ?></a></p>
				<?php endif; ?>
			</div>
			<div>
				<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
					<?php dynamic_sidebar( 'footer-2' ); ?>
				<?php else : ?>
					<h4><?php esc_html_e( 'Contatti', 'beautyhub' ); ?></h4>
					<ul>
						<?php if ( get_theme_mod( 'beautyhub_address' ) ) : ?>
							<li><?php echo esc_html( get_theme_mod( 'beautyhub_address' ) ); ?></li>
						<?php endif; ?>
						<?php if ( get_theme_mod( 'beautyhub_phone' ) ) : ?>
							<li><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', get_theme_mod( 'beautyhub_phone' ) ) ); ?>"><?php echo esc_html( get_theme_mod( 'beautyhub_phone' ) ); ?></a></li>
						<?php endif; ?>
						<?php if ( get_theme_mod( 'beautyhub_whatsapp' ) ) : ?>
							<li><a href="https://wa.me/<?php echo esc_attr( preg_replace( '/\D/', '', get_theme_mod( 'beautyhub_whatsapp' ) ) ); ?>" target="_blank" rel="noopener">WhatsApp</a></li>
						<?php endif; ?>
						<?php if ( get_theme_mod( 'beautyhub_email' ) ) : ?>
							<li><a href="mailto:<?php echo esc_attr( antispambot( get_theme_mod( 'beautyhub_email' ) ) ); ?>"><?php echo esc_html( antispambot( get_theme_mod( 'beautyhub_email' ) ) ); ?></a></li>
						<?php endif; ?>
					</ul>
				<?php endif; ?>
			</div>
			<div>
				<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
					<?php dynamic_sidebar( 'footer-3' ); ?>
				<?php else : ?>
					<h4><?php esc_html_e( 'Orari', 'beautyhub' ); ?></h4>
					<p><?php echo esc_html( get_theme_mod( 'beautyhub_hours' ) ? get_theme_mod( 'beautyhub_hours' ) : __( 'Mar–Sab 9:00–19:00', 'beautyhub' ) ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<div class="bh-footer__bottom">
			<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?><?php echo get_theme_mod( 'beautyhub_vat' ) ? ' – P.IVA ' . esc_html( get_theme_mod( 'beautyhub_vat' ) ) : ''; ?></span>
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'footer',
					'container'      => false,
					'depth'          => 1,
					'fallback_cb'    => false,
					'menu_class'     => 'bh-footer__menu',
				)
			);
			?>
		</div>
	</div>
</footer>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
