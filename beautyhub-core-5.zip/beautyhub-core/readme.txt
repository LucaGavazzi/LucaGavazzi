=== BeautyHub Core ===
Versione: 1.0.0 – Richiede WordPress 6.2+, PHP 7.4+. Consigliati: tema BeautyHub + Elementor.

Gestionale per centri estetici: clienti, trattamenti, cabine, agenda (una colonna per cabina),
personale (operatrici, receptionist, manager) con scheda completa, prenotazioni online,
promemoria email, incassi, report. Widget Elementor e shortcode inclusi.

== Installazione ==
1. Aspetto › Temi › Aggiungi › Carica tema: beautyhub.zip, poi Attiva.
2. Plugin › Aggiungi nuovo › Carica plugin: beautyhub-core.zip, poi Attiva.
   All'attivazione vengono creati: tabelle, ruoli, pagine (Home, Prenota, Trattamenti,
   Area clienti, Gestionale, Gestisci prenotazione) e dati di esempio (9 trattamenti, 3 cabine).
3. Gestionale › Impostazioni (solo amministratore): dati del centro, orari, chiusure, prenotazioni,
   notifiche e ruoli e permessi.
4. Gestionale › Trattamenti: crea e modifica i trattamenti dalla scheda (foto, categoria, descrizione,
   durata, prezzo, operatrici, cabine). Sostituisci i dati di esempio. Le cabine (nome, colore,
   trattamenti possibili) si creano dal gestionale, sezione "Cabine", o da BeautyHub › Cabine.
5. Gestionale › Operatrici: inserisci il personale con la scheda completa e, dalla scheda
   (Note e accesso), crea l'accesso al gestionale: la persona riceve l'email per la password.
6. Imposta i permalink su "Nome articolo" (Impostazioni › Permalink).
7. Per promemoria puntuali configura un vero cron sul server che chiami wp-cron.php ogni 15 minuti
   e un plugin SMTP per l'invio affidabile delle email.

== Ruoli ==
Titolare centro: tutto (impostazioni, report, eliminazioni, trattamenti, cabine).
Manager centro: come il titolare dal gestionale (agenda, cabine, personale, report), senza bacheca WordPress.
Reception: agenda, clienti e incassi; NON vede l'anamnesi.
Operatrice: vede l'agenda di tutte le cabine, segna Arrivata/Completato, aggiorna note e
scheda estetica, vede l'anamnesi.
Cliente: area clienti con appuntamenti futuri e passati.

== Shortcode ==
[bh_booking treatment="ID" staff="ID cabina" title="..."]  Prenotazione online in 3 passaggi (cabina assegnata in automatico)
[bh_treatments layout="list|cards" category="slug" price="yes" book="yes"]  Listino
[bh_cabins]  Cabine con i trattamenti possibili
[bh_client_area]  Area clienti con login
[bh_dashboard]  Gestionale staff (usa il modello pagina "BeautyHub – Gestionale")
[bh_manage_booking]  Pagina raggiunta dal link "Gestisci o annulla" nelle email

In Elementor gli stessi elementi sono nella categoria di widget "BeautyHub".

== Note ==
- Lo scontrino fiscale va emesso con registratore telematico o servizio certificato:
  il modulo incassi registra i pagamenti ma non sostituisce il registratore.
- Privacy: esportazione e cancellazione dati tramite Strumenti › Esporta/Cancella dati personali.
- I dati restano nel database anche disattivando il plugin.

== Operatrici e personale (modello PeopleHub) ==
Scheda con: anagrafica e codice fiscale, contatti e contatto di emergenza, contratto (tipo, livello,
ore, assunzione/fine, IBAN), competenze (trattamenti), documenti con scadenza, corsi e attestati,
orari settimanali, note e accesso al gestionale. Avvisi automatici per documenti, corsi e contratti
in scadenza nei 30 giorni. Stampa / PDF della scheda. Visibile solo a Titolare e Manager.
Stato "Cessato" o "Sospeso" = l'accesso al gestionale viene disattivato automaticamente.

== Operatrici negli appuntamenti ==
Ogni trattamento indica quante operatrici servono contemporaneamente (1 o 2) e chi può eseguirlo
(gestionale › Trattamenti, oppure BeautyHub › Trattamenti nel pannello, oppure Competenze nella scheda
della persona). Nell'appuntamento si scelgono le operatrici tra quelle abilitate: il gestionale indica chi
è disponibile e chi no (fuori turno o già occupata, con l'orario). Con 2 operatrici l'appuntamento non si
salva finché non sono indicate entrambe. Le prenotazioni online mostrano solo gli orari in cui ci sono
cabina libera e operatrici sufficienti, e le assegnano in automatico (la meno impegnata della giornata).
Se nel centro non è registrata nessuna operatrice, il controllo resta disattivato.

== Categorie dei trattamenti ==
Gestionale › Trattamenti › menu "Tutte le categorie" › "+ Nuova categoria…": nome e descrizione.
Scegliendo una categoria nel menu, la sua descrizione si apre in cima all'elenco (pulsante "Modifica
categoria"). Con "Tutte le categorie" la descrizione si apre dal titolo di ogni gruppo. La descrizione
compare anche nel listino pubblico [bh_treatments]. Una categoria si può eliminare solo se è vuota.

== Magazzino: prodotti, fornitori, fatture ==
Gestionale › Prodotti: codice EAN (con controllo della cifra di verifica; si può usare un lettore di
codici a barre nel campo di ricerca), codice interno (automatico PR00001… se vuoto), codice del
fornitore, prezzo di acquisto (netto IVA), prezzo di vendita (IVA inclusa) con margine e ricarico calcolati,
aliquota IVA, fornitore, tipo (rivendita / consumo in cabina), quantità a stock, scorta minima e quantità
di riordino. Movimenti: carico, vendita, consumo, reso, scarico e inventario, con lo storico completo.
"Lista riordino": prodotti sotto scorta raggruppati per fornitore, con stampa dell'ordine ed email pronta.
Gestionale › Fornitori: anagrafica (con controllo della partita IVA), codice SDI e PEC, contatti e referente,
IBAN, termini di pagamento, ordine minimo, tempi di consegna; prodotti e fatture del fornitore.
Gestionale › Fatture: fatture dei fornitori con righe prodotto, sconti, IVA per riga, spese di trasporto
e totali calcolati; scadenza proposta dai termini di pagamento; stato da pagare / pagata / scaduta.
Registrandole si caricano i prodotti a magazzino (modificando o eliminando la fattura il carico viene
stornato) e, se richiesto, si aggiorna il prezzo di acquisto. Le fatture registrate qui servono per la
gestione interna: non sostituiscono la conservazione delle fatture elettroniche ricevute dallo SDI.

== Ruoli e permessi (Impostazioni, solo amministratore) ==
La voce Impostazioni è visibile e modificabile solo dall'amministratore del sito (anche la pagina
BeautyHub nel pannello WordPress). In "Ruoli e permessi" una tabella permette di decidere, per Titolare,
Manager, Receptionist e Operatrice, cosa possono vedere e fare: agenda (vedere, creare/modificare,
segnare arrivo/completato, eliminare, incassi), clienti (vedere, modificare, note e scheda estetica,
anamnesi, eliminare), centro (cabine, trattamenti, personale, report) e magazzino (prodotti, fornitori,
fatture). Il menu del gestionale mostra a ognuno solo le sezioni consentite e il server blocca le
operazioni non permesse. L'amministratore ha sempre accesso a tutto. "Ripristina i permessi predefiniti"
riporta la configurazione iniziale.

== Famiglie, categorie, stampa stock e inventario ==
Prodotti › "Famiglie e categorie": la famiglia è il gruppo principale (es. Viso), le categorie la
suddividono (es. Creme, Sieri). Ogni prodotto ha famiglia, categoria e ubicazione; l'elenco prodotti
si filtra per famiglia e categoria.
Prodotti › "Stampa stock": foglio di conta stampabile per famiglia/categoria/tipo/ubicazione, raggruppato
per famiglia, ubicazione o fornitore, con colonne vuote "Contato" e "Differenza", valori al costo opzionali
e spazio firme.
Gestionale › Inventario: "Nuovo inventario" crea la scheda (completa o parziale) fotografando le giacenze.
Nella scheda si conta digitando le quantità o con il lettore di codici a barre (ogni scansione +1), con
salvataggio automatico, differenze in quantità e valore, note per riga, filtri "da contare" e "con
differenze", stampa della scheda. "Chiudi e aggiorna giacenze" allinea il magazzino con movimenti
"Inventario" (i movimenti avvenuti durante la conta, come le vendite, vengono considerati).

== Inventario per zone (pistola barcode) ==
Nella creazione dell'inventario si indica il numero di zone (es. 4) e, se si vuole, il nome di ognuna
(Reception, Scaffale A, Cabine…). Nella scheda inventario ogni zona ha la sua scheda con letture, pezzi
e stato. Aprendo una zona il cursore resta nel campo di lettura: si spara il codice EAN con la pistola
(che funziona come tastiera e invia Invio), compare il prodotto, si digita la quantità e si preme Invio.
Opzioni: "Quantità 1 automatica" (ogni lettura registra 1 pezzo senza chiedere la quantità) e segnale
acustico (un bip se la lettura è riuscita, due bip gravi se il codice non è riconosciuto). Le letture si
possono correggere o eliminare; un prodotto non presente nella scheda viene aggiunto in automatico.
Il contato di ogni prodotto è la somma delle zone (nella scheda si vede il dettaglio Z1, Z2…).
"Zona completata" blocca nuove letture (si può riaprire). Si può aggiungere una zona in corso d'opera,
assegnarla a un operatore e stampare le letture di ogni zona. Alla chiusura il gestionale avvisa delle
zone non completate.

== Card: gift card, fedeltà, carte trattamenti ==

Nuova voce "Card" nel gestionale (permesso "Gestire le card"). Tutte le card sono nominali (intestate a una cliente), hanno un codice identificativo (GC26-00001, FD26-…, PK26-…) e un codice EAN-13 stampabile.

* Gift card: valore libero, scaricabile anche in parte e in più volte, ricaricabile; chi la regala e dedica; scadenza.
* Carta fedeltà: punti accreditati in automatico a ogni incasso della cliente (regole in "Regole fedeltà": punti per €, valore del punto, soglia minima); i punti si usano come sconto.
* Carta trattamenti: si caricano pacchetti di sedute scontati, dal "Listino pacchetti" o personalizzati; il valore della seduta è il prezzo pagato ripartito. Le sedute si scalano dall'appuntamento.
* EAN: generato in automatico nella fascia ad uso interno (prefisso 29), oppure personalizzato (digitato o letto con il lettore, es. card prestampate): viene verificata la cifra di controllo e che non sia già usato da altre card o prodotti.
* Ricerca e lettore barcode: nel campo di ricerca, Invio con codice o EAN apre la scheda della card.
* Nell'incasso dell'appuntamento: scala una seduta dalla carta trattamenti, paga (anche in parte) con la gift card, usa i punti fedeltà come sconto.
* Scheda card: operazioni, storico movimenti con storno dell'ultimo movimento, dati, stampa in formato carta di credito.
* Scheda cliente: nuova scheda "Card" con tutte le card intestate.

== Cassa ==

Nuova voce "Cassa" (permesso "Usare la cassa", attivo per Titolare, Manager e Reception).

* Cliente: cercala, oppure scegli un appuntamento in "Da incassare" (gli appuntamenti di oggi con nome, trattamento, ora e operatrici).
* Scontrino: appuntamenti, trattamenti senza appuntamento, prodotti da rivendita (a tessere, per famiglia o con il lettore di codici a barre), gift card nuove o ricariche, pacchetti di sedute (nuova carta o carica su carta esistente), carta fedeltà.
* Card: spunta «Usa seduta» sulla riga del trattamento; scala la gift card (anche in parte e anche di un'altra persona, leggendola con il lettore); usa i punti fedeltà come sconto; i punti dell'acquisto si caricano in automatico sulla carta fedeltà, più eventuali punti bonus.
* Prezzi e sconti modificabili per riga (importo o percentuale).
* Pagamento: contanti, carta o misto. Tastierino numerico a video (funziona anche la tastiera del PC), tasti banconote 5/10/20/50/100 e «Importo esatto», calcolo del resto.
* Alla conferma: scarico del magazzino, appuntamenti segnati come completati, incassi registrati nei Report, scontrino di cortesia stampabile (80 mm).
* Vendite e chiusura cassa: totale contanti e carta del giorno, gift card usate, sconti, sedute, elenco scontrini con ristampa, stampa della chiusura.
* Lo scontrino della cassa è un documento non fiscale: lo scontrino fiscale va emesso con il registratore telematico.

== Messaggi: promemoria WhatsApp, scontrino e buoni sconto ==

Nuova voce "Messaggi" (permesso "Messaggi e promemoria", attivo per Titolare, Manager e Reception).

* Promemoria: elenco degli appuntamenti di domani (o di un altro giorno) con il messaggio già compilato. «Apri WhatsApp» apre WhatsApp / WhatsApp Web con il testo pronto e segna il promemoria come inviato.
* Messaggio promemoria: testo base con i campi {nome}, {cognome}, {data}, {ora}, {trattamento}, {operatrice}, {cabina}, {centro}, {telefono}, {link}; anteprima stile WhatsApp; prefisso internazionale; stati degli appuntamenti da ricordare.
* Invio automatico (facoltativo): con WhatsApp Business Cloud API di Meta (token, ID numero, modello approvato con variabili {{1}} nome, {{2}} data, {{3}} ora, {{4}} trattamento, {{5}} centro). Ogni giorno all'ora scelta partono i promemoria del giorno dopo. Le credenziali le imposta solo l'amministratore.
* Scontrino: messaggio stampato in fondo allo scontrino.
* Buono sconto: % o € sul prossimo acquisto, validità in giorni, spesa minima, emissione automatica sopra una soglia o scelta in cassa scontrino per scontrino. Il buono ha codice e EAN stampati sullo scontrino; in cassa si legge con il lettore e si usa una sola volta. Elenco dei buoni emessi con annullamento.

== Codice fiscale automatico ==

Nelle schede Clienti, Operatrici e Fornitori il codice fiscale viene controllato mentre lo si scrive.
* Da codice fiscale: estrae e compila data di nascita, sesso e luogo di nascita (comuni italiani, anche soppressi, e stati esteri), gestisce l'omocodia e avvisa se nome o cognome non corrispondono.
* Calcolo: con nome, cognome, sesso, data e luogo di nascita il pulsante «Calcola» genera il codice fiscale.
* Elenco dei codici catastali: assets/data/comuni-cf.json, dati tratti dal progetto CodiceFiscaleJS (github.com/lucavandro/CodiceFiscaleJS), licenza CC BY-SA 4.0; fonte originaria ISTAT / Agenzia delle Entrate.

== Email al personale (Operatrici › Note e accesso) ==

«Crea accesso e invia email» invia un'email in italiano con nome utente e link per impostare la password (valido 24 ore).
Se il server del sito non riesce a inviarla, il gestionale mostra il motivo e il link da copiare o inviare su WhatsApp.
Per un invio affidabile delle email del sito (accessi, conferme e promemoria delle prenotazioni) installare un plugin SMTP, ad esempio «WP Mail SMTP», collegato alla casella email del centro.

== Schede cliente: anamnesi viso, anamnesi estetica, massaggi, laser ==

Nella scheda cliente, nuova scheda «Schede» (visibile solo con il permesso «Vedere e modificare l'anamnesi»).
* Modelli ricalcati sulle schede cartacee del centro: Scheda anamnesi viso (2 pagine con mappa viso), Scheda anamnesi estetica (7 pagine: dati e abitudini, salute, analisi viso, analisi corpo e misure, registro trattamenti, mappa viso, mappa corpo), Scheda cliente massaggi (condizioni Sì/No e registro massaggi), Scheda cliente laser (check-up, registro sedute; aggiunta una breve verifica delle controindicazioni).
* Compilazione dal personale oppure «Tablet»: la cliente compila a schermo intero solo le parti che la riguardano, poi conferma, dà il consenso e firma con il dito.
* Dopo la firma le risposte della cliente sono bloccate; restano modificabili analisi, mappe e registri dell'operatore. «Nuova compilazione» per aggiornarle.
* Mappe: si segnano le zone 1-6 (o ✕ da evitare) toccando le sagome.
* Stampa: compilata (con firma) o in bianco da far compilare a penna, impaginata in A4 come le schede originali.
* Le schede vengono cancellate insieme alla cliente (diritto all'oblio).
* I modelli si possono modificare dal codice con il filtro «bhc_form_templates».

== Candidati e colloqui (Operatrici e personale) ==

In «Operatrici e personale» tre schede: Personale, Candidati, Colloqui (permesso «Gestire il personale»). Modelli ispirati a PeopleHub, adattati al centro estetico.
* Colloquio di selezione e assunzione: il candidato compila sul tablet (dati, qualifiche nel settore estetico, corsi, esperienze, trattamenti che sa eseguire, disponibilità, stipendio richiesto), legge l'informativa e firma; la selezionatrice aggiunge valutazione (stelle 1-5, prova pratica) e proposta di assunzione (ruolo, mansione, contratto, livello, data, ore, stipendio proposto) con la sua firma.
* Esito: «Assumi» crea la scheda del nuovo personale con i dati del colloquio (anagrafica, ruolo, mansione, contratto, livello, data di assunzione, ore, corsi; note con valutazione, stipendio proposto e competenze). «Non assunto» archivia la candidatura (si può riaprire).
* Valutazione periodica, Fine periodo di prova (con esito), Colloquio di uscita: dalla scheda della persona (scheda «Colloqui») o dalla sezione Colloqui; il dipendente aggiunge le sue osservazioni anche sul tablet. Dal colloquio di uscita «Chiudi il rapporto» segna la persona come cessata alla data dell'ultimo giorno e disattiva l'accesso.
* Tutti i colloqui si stampano compilati o vuoti.
* L'informativa per i candidati è un testo generico: va verificata con il consulente privacy. Le schede non chiedono stato civile, figli o salute.

== Orari e presenze (timbrature) ==

Una sola icona «Orari e presenze» (orologio), con permesso dedicato «Orari e presenze» (predefinito per titolare e manager). Ispirata a PeopleHub. Cinque schede:
* Orari settimana: griglia del personale con l'orario di ogni giorno e il totale ore confrontato con il contratto. Clic su una casella: ferie, permesso/ROL (anche a ore), malattia e infortunio (con n. di protocollo), riposo, formazione, altra assenza, cambio turno; anche su più giorni o per tutto il personale (chiusura del centro). Clic sul nome: orario di base (lo stesso della scheda personale). Stampa A4 orizzontale.
* Timbrature e cartellino: chi è in servizio adesso, riepilogo mensile (ore previste, lavorate, saldo sulle giornate concluse, assenze, anomalie), foglio presenze giorno per giorno con timbrature manuali (segnate con *) ed eliminazione (resta nello storico), cartellino stampabile con firme, esportazione CSV per il consulente.
* Anomalie: entrata in ritardo, rientro dalla pausa in ritardo, uscita anticipata o oltre l'orario, timbratura mancante, assenza non registrata, timbratura in giorno non lavorativo. Si giustificano (motivo e note), si respingono o si riaprono. Il controllo parte dalla prima timbratura di ogni persona, con tolleranza impostabile.
* Ferie e permessi: per anno, spettanti (con residuo anno precedente e proporzione ai mesi di servizio), godute, programmate, residuo; giorni di malattia.
* Timbratrice e PIN: si attiva un link segreto (con QR) da aprire sul tablet della sede; si timbra entrata/uscita con un PIN personale di 4-6 cifre (salvato solo come impronta cifrata, mostrato una volta). Dopo 8 PIN errati il tablet si blocca per 10 minuti. Il link si rigenera in qualsiasi momento.
* Il QR code è generato con la libreria «QR Code Generator» di Kazuhiko Arase (assets/vendor/qrcode.js, licenza MIT).
