<?php
/**
 * Plugin Name: BeautyHub Core
 * Plugin URI:  https://example.com/beautyhub
 * Description: Gestionale per centri estetici: clienti, trattamenti, operatrici, agenda, prenotazioni online, promemoria email, incassi e dashboard. Con widget Elementor.
 * Version:     1.12.0
 * Author:      L. Gavazzi
 * Text Domain: beautyhub-core
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * License:     GPLv2 or later
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BHC_VERSION', '1.12.0' );
define( 'BHC_DB_VERSION', '1.12.0' );
define( 'BHC_FILE', __FILE__ );
define( 'BHC_DIR', plugin_dir_path( __FILE__ ) );
define( 'BHC_URL', plugin_dir_url( __FILE__ ) );

require_once BHC_DIR . 'includes/helpers.php';
require_once BHC_DIR . 'includes/class-bhc-availability.php';
require_once BHC_DIR . 'includes/class-bhc-install.php';
require_once BHC_DIR . 'includes/class-bhc-permissions.php';
require_once BHC_DIR . 'includes/class-bhc-roles.php';
require_once BHC_DIR . 'includes/class-bhc-post-types.php';
require_once BHC_DIR . 'includes/class-bhc-settings.php';
require_once BHC_DIR . 'includes/class-bhc-repository.php';
require_once BHC_DIR . 'includes/class-bhc-emails.php';
require_once BHC_DIR . 'includes/class-bhc-rest.php';
require_once BHC_DIR . 'includes/class-bhc-shortcodes.php';
require_once BHC_DIR . 'includes/class-bhc-privacy.php';
require_once BHC_DIR . 'includes/class-bhc-people.php';
require_once BHC_DIR . 'includes/class-bhc-operators.php';
require_once BHC_DIR . 'includes/class-bhc-treatments-api.php';
require_once BHC_DIR . 'includes/class-bhc-inventory.php';
require_once BHC_DIR . 'includes/class-bhc-stock.php';
require_once BHC_DIR . 'includes/class-bhc-zones.php';
require_once BHC_DIR . 'includes/class-bhc-cards.php';
require_once BHC_DIR . 'includes/class-bhc-pos.php';
require_once BHC_DIR . 'includes/class-bhc-messages.php';
require_once BHC_DIR . 'includes/class-bhc-forms.php';
require_once BHC_DIR . 'includes/class-bhc-hr.php';
require_once BHC_DIR . 'includes/class-bhc-timeclock.php';
require_once BHC_DIR . 'includes/class-bhc-admin.php';

register_activation_hook( __FILE__, array( 'BHC_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'BHC_Install', 'deactivate' ) );

add_action(
	'plugins_loaded',
	function () {
		load_plugin_textdomain( 'beautyhub-core', false, dirname( plugin_basename( BHC_FILE ) ) . '/languages' );

		add_action( 'init', array( 'BHC_Install', 'maybe_upgrade' ), 5 );
		BHC_Post_Types::init();
		BHC_Settings::init();
		BHC_Emails::init();
		BHC_REST::init();
		BHC_Shortcodes::init();
		BHC_Privacy::init();
		BHC_People::init();
		BHC_Operators::init();
		BHC_Treatments_API::init();
		BHC_Inventory::init();
		BHC_Stock::init();
		BHC_Zones::init();
		BHC_Cards::init();
		BHC_POS::init();
		BHC_Messages::init();
		BHC_Forms::init();
		BHC_HR::init();
		BHC_Timeclock::init();
		BHC_Permissions::init();
		BHC_Admin::init();
	}
);

// Widget Elementor (caricati solo se Elementor è attivo).
add_action(
	'elementor/widgets/register',
	function ( $widgets_manager ) {
		require_once BHC_DIR . 'includes/class-bhc-elementor.php';
		BHC_Elementor::register( $widgets_manager );
	}
);
add_action(
	'elementor/elements/categories_registered',
	function ( $elements_manager ) {
		$elements_manager->add_category(
			'beautyhub',
			array(
				'title' => 'BeautyHub',
				'icon'  => 'fa fa-spa',
			)
		);
	}
);
