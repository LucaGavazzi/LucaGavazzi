<?php
/**
 * Orari e timbrature (ispirato a PeopleHub):
 * - orario settimanale di ogni persona (scheda personale › Orari) e variazioni giornaliere
 *   (ferie, permessi, malattia, infortunio, riposo, cambio turno, formazione);
 * - timbratrice per il tablet della sede (link segreto + PIN personale), timbrature manuali;
 * - confronto con l'orario: ritardi, uscite anticipate, timbrature mancanti, assenze non registrate;
 * - riepilogo mensile, foglio presenze/cartellino, ferie e permessi.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Timeclock {

	const OPT = 'bhc_timeclock';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'kiosk_page' ), 1 );
	}

	public static function types() {
		return array(
			'ferie'      => array( 'Ferie', '#5f8fb4', 'absence' ),
			'permesso'   => array( 'Permesso / ROL', '#8a6fa8', 'absence' ),
			'malattia'   => array( 'Malattia', '#c0574a', 'absence' ),
			'infortunio' => array( 'Infortunio', '#b0735a', 'absence' ),
			'riposo'     => array( 'Riposo / recupero', '#9a958a', 'absence' ),
			'altro'      => array( 'Altra assenza', '#7a776f', 'absence' ),
			'formazione' => array( 'Formazione / corso', '#c49a3a', 'work' ),
			'turno'      => array( 'Cambio turno', '#7d8c6f', 'shift' ),
		);
	}

	public static function anomaly_labels() {
		return array(
			'late_in'    => 'Entrata in ritardo',
			'late_back'  => 'Rientro dalla pausa in ritardo',
			'early_out'  => 'Uscita anticipata',
			'overtime'   => 'Uscita oltre l\'orario',
			'missing'    => 'Timbratura mancante',
			'absent'     => 'Assenza non registrata',
			'nonworking' => 'Timbratura in un giorno non lavorativo',
		);
	}

	public static function reasons() {
		return array( 'Straordinario autorizzato', 'Recupero ore', 'Permesso concordato', 'Visita medica', 'Ritardo mezzi / traffico', 'Dimenticanza timbratura', 'Errore di timbratura', 'Cambio turno concordato', 'Formazione esterna', 'Altro' );
	}

	public static function settings() {
		$s = wp_parse_args(
			get_option( self::OPT, array() ),
			array(
				'enabled'   => 0,
				'token'     => '',
				'tolerance' => 10,
				'vac_days'  => 26,
				'rol_hours' => 72,
			)
		);
		$s['tolerance'] = (int) $s['tolerance'];
		return $s;
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'shift_changes' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			day date NOT NULL,
			type varchar(20) NOT NULL DEFAULT 'ferie',
			ranges varchar(120) NOT NULL DEFAULT '',
			note varchar(255) NOT NULL DEFAULT '',
			protocol varchar(60) NOT NULL DEFAULT '',
			group_id varchar(20) NOT NULL DEFAULT '',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY person_day (person_id,day)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'punches' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			punched_at datetime NOT NULL,
			kind varchar(5) NOT NULL DEFAULT 'in',
			source varchar(10) NOT NULL DEFAULT 'tablet',
			note varchar(255) NOT NULL DEFAULT '',
			deleted tinyint(1) NOT NULL DEFAULT 0,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY person_time (person_id,punched_at)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'punch_notes' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			day date NOT NULL,
			code varchar(20) NOT NULL DEFAULT '',
			reason varchar(120) NOT NULL DEFAULT '',
			note varchar(255) NOT NULL DEFAULT '',
			status varchar(15) NOT NULL DEFAULT 'approvata',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY person_day (person_id,day)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'leave_balances' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			year smallint(5) unsigned NOT NULL DEFAULT 0,
			vac_prev decimal(6,2) NOT NULL DEFAULT 0,
			vac_days decimal(6,2) DEFAULT NULL,
			rol_prev decimal(7,2) NOT NULL DEFAULT 0,
			rol_hours decimal(7,2) DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY person_year (person_id,year)
			) {$c};"
		);
	}

	/* ==================================================================
	 * Calcolo della giornata
	 * ================================================================ */

	private static function mins( $ranges ) {
		$t = 0;
		foreach ( $ranges as $r ) {
			$t += $r[1] - $r[0];
		}
		return $t;
	}

	private static function overlap( $ranges, $a, $b ) {
		$t = 0;
		foreach ( $ranges as $r ) {
			$t += max( 0, min( $r[1], $b ) - max( $r[0], $a ) );
		}
		return $t;
	}

	private static function fmt_ranges( $ranges ) {
		return implode(
			', ',
			array_map(
				function ( $r ) {
					return sprintf( '%02d:%02d-%02d:%02d', intdiv( $r[0], 60 ), $r[0] % 60, intdiv( $r[1], 60 ), $r[1] % 60 );
				},
				$ranges
			)
		);
	}

	/** Persone che timbrano (attive o con rapporto nel periodo). */
	public static function people( $from = '', $to = '' ) {
		$out = array();
		foreach ( BHC_People::search( '', '', '' ) as $p ) {
			if ( 'cessato' === $p['status'] && ( ! $p['end_date'] || ( $from && $p['end_date'] < $from ) ) ) {
				continue;
			}
			if ( $to && $p['hire_date'] && $p['hire_date'] > $to ) {
				continue;
			}
			$out[] = $p;
		}
		return $out;
	}

	/** Carica variazioni, timbrature e giustificativi di un periodo (per non interrogare il db giorno per giorno). */
	private static function load( array $person_ids, $from, $to ) {
		global $wpdb;
		$data = array( 'changes' => array(), 'punches' => array(), 'notes' => array(), 'first' => array() );
		if ( ! $person_ids ) {
			return $data;
		}
		$in = implode( ',', array_map( 'intval', $person_ids ) );
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'shift_changes' ) . " WHERE person_id IN ({$in}) AND day >= %s AND day <= %s ORDER BY id", $from, $to ), ARRAY_A ) as $r ) { // phpcs:ignore
			$data['changes'][ $r['person_id'] ][ $r['day'] ][] = $r;
		}
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'punches' ) . " WHERE deleted = 0 AND person_id IN ({$in}) AND punched_at >= %s AND punched_at <= %s ORDER BY punched_at, id", $from . ' 00:00:00', $to . ' 23:59:59' ), ARRAY_A ) as $r ) { // phpcs:ignore
			$data['punches'][ $r['person_id'] ][ substr( $r['punched_at'], 0, 10 ) ][] = $r;
		}
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'punch_notes' ) . " WHERE person_id IN ({$in}) AND day >= %s AND day <= %s ORDER BY id", $from, $to ), ARRAY_A ) as $r ) { // phpcs:ignore
			$data['notes'][ $r['person_id'] ][ $r['day'] ][ $r['code'] ] = $r;
		}
		foreach ( $wpdb->get_results( "SELECT person_id, MIN(punched_at) f FROM " . bhc_table( 'punches' ) . " WHERE deleted = 0 AND person_id IN ({$in}) GROUP BY person_id", ARRAY_A ) as $r ) { // phpcs:ignore
			$data['first'][ $r['person_id'] ] = substr( $r['f'], 0, 10 );
		}
		return $data;
	}

	/**
	 * Situazione di una persona in un giorno.
	 */
	public static function day( array $p, $date, array $ctx ) {
		$s        = self::settings();
		$tol      = $s['tolerance'];
		$types    = self::types();
		$today    = current_time( 'Y-m-d' );
		$now_min  = (int) current_time( 'G' ) * 60 + (int) current_time( 'i' );
		$employed = ! ( $p['hire_date'] && $date < $p['hire_date'] ) && ! ( $p['end_date'] && $date > $p['end_date'] );
		$base     = $employed ? bhc_parse_ranges( $p['schedule'][ (int) gmdate( 'N', strtotime( $date ) ) ] ?? ( $p['schedule'][ (string) gmdate( 'N', strtotime( $date ) ) ] ?? '' ) ) : array();
		$sched    = $base;
		$changes  = $ctx['changes'][ $p['id'] ][ $date ] ?? array();
		$abs      = array();
		$work_ext = 0;
		$shift    = false;
		foreach ( $changes as $c ) {
			if ( 'turno' === $c['type'] ) {
				$sched = bhc_parse_ranges( $c['ranges'] );
				$shift = true;
			}
		}
		$expected_sched = self::mins( $sched );
		$expected       = $expected_sched;
		$full_absence   = false;
		foreach ( $changes as $c ) {
			$kind = $types[ $c['type'] ][2] ?? 'absence';
			if ( 'shift' === $kind ) {
				continue;
			}
			$rg = bhc_parse_ranges( $c['ranges'] );
			if ( 'work' === $kind ) {
				$work_ext += $rg ? self::mins( $rg ) : $expected_sched;
				continue;
			}
			if ( ! $rg ) {
				$m            = $expected_sched;
				$full_absence = true;
			} else {
				$m = 0;
				foreach ( $rg as $r ) {
					$m += self::overlap( $sched, $r[0], $r[1] );
				}
			}
			$abs[]     = array( 'id' => (int) $c['id'], 'type' => $c['type'], 'label' => $types[ $c['type'] ][0] ?? $c['type'], 'color' => $types[ $c['type'] ][1] ?? '#999', 'minutes' => $m, 'full' => ! $rg, 'ranges' => $c['ranges'], 'note' => $c['note'], 'protocol' => $c['protocol'] );
			$expected -= $m;
		}
		$expected = max( 0, $expected );

		// Coppie entrata / uscita.
		$punches = $ctx['punches'][ $p['id'] ][ $date ] ?? array();
		$pairs   = array();
		$open    = null;
		$missing = false;
		$worked  = 0;
		foreach ( $punches as $pu ) {
			$m = (int) substr( $pu['punched_at'], 11, 2 ) * 60 + (int) substr( $pu['punched_at'], 14, 2 );
			$x = array( 'id' => (int) $pu['id'], 'min' => $m, 'time' => substr( $pu['punched_at'], 11, 5 ), 'manual' => 'manual' === $pu['source'], 'note' => $pu['note'] );
			if ( 'in' === $pu['kind'] ) {
				if ( $open ) {
					$pairs[] = array( $open, null );
					$missing = true;
				}
				$open = $x;
			} else {
				if ( $open ) {
					$pairs[] = array( $open, $x );
					$worked += max( 0, $x['min'] - $open['min'] );
					$open    = null;
				} else {
					$pairs[] = array( null, $x );
					$missing = true;
				}
			}
		}
		$inside = false;
		if ( $open ) {
			if ( $date === $today ) {
				$inside  = true;
				$worked += max( 0, $now_min - $open['min'] );
			} else {
				$missing = true;
			}
			$pairs[] = array( $open, null );
		}
		$worked += $work_ext;

		// Anomalie (dal giorno della prima timbratura della persona, fino a oggi).
		$an    = array();
		$first = $ctx['first'][ $p['id'] ] ?? null;
		if ( $first && $date >= $first && $date <= $today && $employed ) {
			$ins  = array_values( array_filter( $punches, function ( $x ) {
				return 'in' === $x['kind'];
			} ) );
			$outs = array_values( array_filter( $punches, function ( $x ) {
				return 'out' === $x['kind'];
			} ) );
			$tm   = function ( $x ) {
				return (int) substr( $x['punched_at'], 11, 2 ) * 60 + (int) substr( $x['punched_at'], 14, 2 );
			};
			$work_ranges = $sched;
			// Le assenze a ore spostano gli orari attesi (es. permesso 9-11 → entrata attesa alle 11).
			foreach ( $abs as $a ) {
				if ( $a['full'] ) {
					$work_ranges = array();
				}
			}
			if ( $punches && ! $expected_sched && ! $shift && ! $work_ext ) {
				$an[] = array( 'code' => 'nonworking', 'detail' => '' );
			}
			if ( ! $punches && $expected > 0 && ! $full_absence && ! $work_ext && ( $date < $today || ( $work_ranges && $now_min > $work_ranges[0][0] + $tol ) ) ) {
				$an[] = array( 'code' => 'absent', 'detail' => 'previsto ' . self::fmt_ranges( $sched ) );
			}
			if ( $missing ) {
				$an[] = array( 'code' => 'missing', 'detail' => '' );
			}
			if ( $work_ranges && $ins ) {
				$start = $work_ranges[0][0];
				foreach ( $abs as $a ) {
					foreach ( bhc_parse_ranges( $a['ranges'] ) as $r ) {
						if ( $r[0] <= $start && $r[1] > $start ) {
							$start = $r[1];
						}
					}
				}
				$fi = $tm( $ins[0] );
				if ( $fi > $start + $tol ) {
					$an[] = array( 'code' => 'late_in', 'detail' => 'entrata ' . $ins[0]['punched_at'] . ' prevista ' . sprintf( '%02d:%02d', intdiv( $start, 60 ), $start % 60 ), 'minutes' => $fi - $start );
				}
				if ( count( $work_ranges ) > 1 && isset( $ins[1] ) ) {
					$st2 = $work_ranges[1][0];
					$si  = $tm( $ins[1] );
					if ( $si > $st2 + $tol ) {
						$an[] = array( 'code' => 'late_back', 'detail' => 'rientro ' . substr( $ins[1]['punched_at'], 11, 5 ), 'minutes' => $si - $st2 );
					}
				}
			}
			if ( $work_ranges && $outs && ( $date < $today || ! $inside ) && ! $open ) {
				$end = $work_ranges[ count( $work_ranges ) - 1 ][1];
				foreach ( $abs as $a ) {
					foreach ( bhc_parse_ranges( $a['ranges'] ) as $r ) {
						if ( $r[1] >= $end && $r[0] < $end ) {
							$end = $r[0];
						}
					}
				}
				$lo = $tm( $outs[ count( $outs ) - 1 ] );
				if ( $lo < $end - $tol ) {
					$an[] = array( 'code' => 'early_out', 'detail' => 'uscita ' . substr( $outs[ count( $outs ) - 1 ]['punched_at'], 11, 5 ), 'minutes' => $end - $lo );
				} elseif ( $lo > $end + $tol ) {
					$an[] = array( 'code' => 'overtime', 'detail' => 'uscita ' . substr( $outs[ count( $outs ) - 1 ]['punched_at'], 11, 5 ), 'minutes' => $lo - $end );
				}
			}
			foreach ( $an as &$x ) {
				$x['label'] = self::anomaly_labels()[ $x['code'] ];
				$n          = $ctx['notes'][ $p['id'] ][ $date ][ $x['code'] ] ?? null;
				$x['note']  = $n ? array( 'id' => (int) $n['id'], 'reason' => $n['reason'], 'note' => $n['note'], 'status' => $n['status'] ) : null;
				$x['open']  = ! $n || 'respinta' === $n['status'];
			}
			unset( $x );
		}

		return array(
			'date'       => $date,
			'employed'   => $employed,
			'base'       => self::fmt_ranges( $base ),
			'sched'      => self::fmt_ranges( $sched ),
			'shift'      => $shift,
			'sched_min'  => $expected_sched,
			'expected'   => $expected,
			'worked'     => $worked,
			'absences'   => $abs,
			'work_ext'   => $work_ext,
			'pairs'      => $pairs,
			'inside'     => $inside,
			'anomalies'  => $an,
			'changes'    => array_map(
				function ( $c ) use ( $types ) {
					return array( 'id' => (int) $c['id'], 'type' => $c['type'], 'label' => $types[ $c['type'] ][0] ?? $c['type'], 'color' => $types[ $c['type'] ][1] ?? '#999', 'ranges' => $c['ranges'], 'note' => $c['note'], 'protocol' => $c['protocol'] );
				},
				$changes
			),
		);
	}

	private static function dates( $from, $to ) {
		$out = array();
		for ( $t = strtotime( $from . ' 12:00:00' ); $t <= strtotime( $to . ' 12:00:00' ); $t += DAY_IN_SECONDS ) {
			$out[] = gmdate( 'Y-m-d', $t );
		}
		return $out;
	}

	private static function slim( $p ) {
		return array( 'id' => $p['id'], 'name' => trim( $p['first_name'] . ' ' . $p['last_name'] ), 'first_name' => $p['first_name'], 'last_name' => $p['last_name'], 'role' => $p['role'], 'job_title' => $p['job_title'], 'color' => $p['color'], 'status' => $p['status'], 'has_pin' => ! empty( $p['has_pin'] ), 'weekly_hours' => $p['weekly_hours'], 'schedule' => $p['schedule'] );
	}

	/** Settimana di tutto il personale. */
	public static function week( $date ) {
		$ts    = strtotime( $date . ' 12:00:00' );
		$mon   = gmdate( 'Y-m-d', $ts - ( (int) gmdate( 'N', $ts ) - 1 ) * DAY_IN_SECONDS );
		$sun   = gmdate( 'Y-m-d', strtotime( $mon . ' +6 days' ) );
		$ppl   = array_values( array_filter( self::people( $mon, $sun ), function ( $p ) {
			return 'cessato' !== $p['status'] || $p['end_date'];
		} ) );
		$ctx   = self::load( wp_list_pluck( $ppl, 'id' ), $mon, $sun );
		$rows  = array();
		foreach ( $ppl as $p ) {
			$days = array();
			$tot  = 0;
			foreach ( self::dates( $mon, $sun ) as $d ) {
				$x      = self::day( $p, $d, $ctx );
				$tot   += $x['expected'];
				$days[] = array( 'date' => $d, 'sched' => $x['sched'], 'shift' => $x['shift'], 'expected' => $x['expected'], 'changes' => $x['changes'], 'absences' => $x['absences'], 'employed' => $x['employed'] );
			}
			$rows[] = array( 'person' => self::slim( $p ), 'days' => $days, 'total' => $tot );
		}
		return array( 'from' => $mon, 'to' => $sun, 'rows' => $rows );
	}

	/** Riepilogo del mese (e dettaglio giornaliero se $person). */
	public static function month( $ym, $person = 0 ) {
		$from  = $ym . '-01';
		$to    = gmdate( 'Y-m-t', strtotime( $from ) );
		$ppl   = self::people( $from, $to );
		if ( $person ) {
			$ppl = array_values( array_filter( $ppl, function ( $p ) use ( $person ) {
				return $p['id'] === (int) $person;
			} ) );
		}
		$ctx   = self::load( wp_list_pluck( $ppl, 'id' ), $from, $to );
		$today = current_time( 'Y-m-d' );
		$rows  = array();
		foreach ( $ppl as $p ) {
			$first = $ctx['first'][ $p['id'] ] ?? null;
			$sum  = array( 'tracking' => (bool) $first, 'expected' => 0, 'worked' => 0, 'expected_to_date' => 0, 'worked_to_date' => 0, 'anomalies' => 0, 'open' => 0, 'absences' => array() );
			$days = array();
			foreach ( self::dates( $from, $to ) as $d ) {
				$x                = self::day( $p, $d, $ctx );
				$sum['expected'] += $x['expected'];
				if ( $d < $today && $first && $d >= $first ) {
					// Il saldo si calcola sulle giornate concluse (oggi è ancora in corso).
					$sum['expected_to_date'] += $x['expected'];
					$sum['worked_to_date']   += $x['worked'];
				}
				$sum['worked']    += $x['worked'];
				$sum['anomalies'] += count( $x['anomalies'] );
				foreach ( $x['anomalies'] as $a ) {
					$sum['open'] += $a['open'] ? 1 : 0;
				}
				foreach ( $x['absences'] as $a ) {
					if ( ! isset( $sum['absences'][ $a['type'] ] ) ) {
						$sum['absences'][ $a['type'] ] = array( 'label' => $a['label'], 'days' => 0, 'minutes' => 0 );
					}
					$sum['absences'][ $a['type'] ]['minutes'] += $a['minutes'];
					$sum['absences'][ $a['type'] ]['days']    += $a['full'] ? 1 : 0;
				}
				if ( $person ) {
					$days[] = $x;
				}
			}
			$sum['diff'] = $sum['worked_to_date'] - $sum['expected_to_date'];
			$row         = array( 'person' => self::slim( $p ), 'sum' => $sum );
			if ( $person ) {
				$row['days'] = $days;
			}
			$rows[] = $row;
		}
		return array( 'month' => $ym, 'from' => $from, 'to' => $to, 'rows' => $rows, 'present' => self::present() );
	}

	/** Chi è dentro adesso. */
	public static function present() {
		global $wpdb;
		$today = current_time( 'Y-m-d' );
		$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT person_id, kind, punched_at FROM ' . bhc_table( 'punches' ) . ' WHERE deleted = 0 AND punched_at >= %s ORDER BY punched_at, id', $today . ' 00:00:00' ), ARRAY_A ); // phpcs:ignore
		$last  = array();
		foreach ( $rows as $r ) {
			$last[ $r['person_id'] ] = $r;
		}
		$out = array();
		foreach ( $last as $pid => $r ) {
			if ( 'in' === $r['kind'] ) {
				$p     = BHC_People::get( $pid );
				$out[] = array( 'id' => (int) $pid, 'name' => $p ? trim( $p['first_name'] . ' ' . $p['last_name'] ) : '', 'since' => substr( $r['punched_at'], 11, 5 ), 'color' => $p ? $p['color'] : '#999' );
			}
		}
		return $out;
	}

	/** Anomalie di un periodo. */
	public static function anomalies( $from, $to, $status = 'open' ) {
		$ppl = self::people( $from, $to );
		$ctx = self::load( wp_list_pluck( $ppl, 'id' ), $from, $to );
		$out = array();
		foreach ( $ppl as $p ) {
			foreach ( self::dates( $from, min( $to, current_time( 'Y-m-d' ) ) ) as $d ) {
				$x = self::day( $p, $d, $ctx );
				foreach ( $x['anomalies'] as $a ) {
					if ( 'open' === $status && ! $a['open'] ) {
						continue;
					}
					if ( 'done' === $status && $a['open'] ) {
						continue;
					}
					$a['date']   = $d;
					$a['person'] = array( 'id' => $p['id'], 'name' => trim( $p['first_name'] . ' ' . $p['last_name'] ), 'color' => $p['color'] );
					$a['pairs']  = array_map(
						function ( $pr ) {
							return ( $pr[0] ? $pr[0]['time'] : '??:??' ) . '–' . ( $pr[1] ? $pr[1]['time'] : '??:??' );
						},
						$x['pairs']
					);
					$a['sched']  = $x['sched'];
					$out[]       = $a;
				}
			}
		}
		usort(
			$out,
			function ( $a, $b ) {
				return strcmp( $b['date'], $a['date'] );
			}
		);
		return $out;
	}

	/* ==================================================================
	 * Ferie e permessi
	 * ================================================================ */

	public static function leaves( $year ) {
		global $wpdb;
		$s     = self::settings();
		$from  = $year . '-01-01';
		$to    = $year . '-12-31';
		$today = current_time( 'Y-m-d' );
		$ppl   = self::people( $from, $to );
		$ctx   = self::load( wp_list_pluck( $ppl, 'id' ), $from, $to );
		$bal   = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'leave_balances' ) . ' WHERE year = %d', $year ), ARRAY_A ) as $b ) { // phpcs:ignore
			$bal[ $b['person_id'] ] = $b;
		}
		$rows = array();
		foreach ( $ppl as $p ) {
			$b   = $bal[ $p['id'] ] ?? array();
			$r   = array(
				'person'    => self::slim( $p ),
				'vac_prev'  => (float) ( $b['vac_prev'] ?? 0 ),
				'vac_days'  => isset( $b['vac_days'] ) && null !== $b['vac_days'] ? (float) $b['vac_days'] : (float) $s['vac_days'],
				'rol_prev'  => (float) ( $b['rol_prev'] ?? 0 ),
				'rol_hours' => isset( $b['rol_hours'] ) && null !== $b['rol_hours'] ? (float) $b['rol_hours'] : (float) $s['rol_hours'],
				'vac_used'  => 0,
				'vac_plan'  => 0,
				'rol_used'  => 0,
				'rol_plan'  => 0,
				'sick'      => 0,
				'injury'    => 0,
			);
			// Ferie in proporzione ai mesi di servizio nell'anno (assunzione / cessazione).
			$start = max( $from, $p['hire_date'] ? $p['hire_date'] : $from );
			$end   = min( $to, $p['end_date'] ? $p['end_date'] : $to );
			if ( $start > $from || $end < $to ) {
				$months         = max( 0, ( strtotime( $end ) - strtotime( $start ) ) / ( 30.4375 * DAY_IN_SECONDS ) );
				$r['vac_days']  = round( $r['vac_days'] * min( 12, round( $months ) ) / 12, 2 );
				$r['rol_hours'] = round( $r['rol_hours'] * min( 12, round( $months ) ) / 12, 2 );
			}
			foreach ( $ctx['changes'][ $p['id'] ] ?? array() as $d => $list ) {
				$x = self::day( $p, $d, $ctx );
				foreach ( $x['absences'] as $a ) {
					$future = $d > $today;
					if ( 'ferie' === $a['type'] && $x['sched_min'] > 0 ) {
						$v = $a['full'] ? 1 : ( $x['sched_min'] ? round( $a['minutes'] / $x['sched_min'], 2 ) : 0 );
						$r[ $future ? 'vac_plan' : 'vac_used' ] += $v;
					} elseif ( 'permesso' === $a['type'] ) {
						$r[ $future ? 'rol_plan' : 'rol_used' ] += round( $a['minutes'] / 60, 2 );
					} elseif ( 'malattia' === $a['type'] ) {
						$r['sick']++;
					} elseif ( 'infortunio' === $a['type'] ) {
						$r['injury']++;
					}
				}
			}
			$r['vac_left'] = round( $r['vac_prev'] + $r['vac_days'] - $r['vac_used'] - $r['vac_plan'], 2 );
			$r['rol_left'] = round( $r['rol_prev'] + $r['rol_hours'] - $r['rol_used'] - $r['rol_plan'], 2 );
			$rows[]        = $r;
		}
		return array( 'year' => (int) $year, 'rows' => $rows );
	}

	/* ==================================================================
	 * Scritture
	 * ================================================================ */

	public static function add_changes( array $d ) {
		global $wpdb;
		$types = self::types();
		$type  = sanitize_key( $d['type'] ?? '' );
		if ( ! isset( $types[ $type ] ) ) {
			return new WP_Error( 'type', __( 'Tipo non valido.', 'beautyhub-core' ) );
		}
		$from = (string) ( $d['from'] ?? '' );
		$to   = (string) ( $d['to'] ?? $from );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) || $to < $from ) {
			return new WP_Error( 'date', __( 'Date non valide.', 'beautyhub-core' ) );
		}
		if ( count( self::dates( $from, $to ) ) > 370 ) {
			return new WP_Error( 'date', __( 'Periodo troppo lungo.', 'beautyhub-core' ) );
		}
		$ranges = trim( sanitize_text_field( (string) ( $d['ranges'] ?? '' ) ) );
		if ( $ranges && ! bhc_parse_ranges( $ranges ) ) {
			return new WP_Error( 'ranges', __( 'Orario non valido: usa il formato 09:00-13:00, 14:00-18:00.', 'beautyhub-core' ) );
		}
		$ids = array();
		if ( ! empty( $d['all'] ) ) {
			$ids = wp_list_pluck( array_filter( self::people( $from, $to ), function ( $p ) {
				return 'attivo' === $p['status'];
			} ), 'id' );
		} else {
			$ids = array( absint( $d['person_id'] ?? 0 ) );
		}
		$ppl = array();
		foreach ( $ids as $id ) {
			$p = BHC_People::get( $id );
			if ( $p ) {
				$ppl[] = $p;
			}
		}
		if ( ! $ppl ) {
			return new WP_Error( 'person', __( 'Scegli la persona.', 'beautyhub-core' ) );
		}
		$group = wp_generate_password( 10, false );
		$n     = 0;
		$skip  = 0;
		foreach ( $ppl as $p ) {
			foreach ( self::dates( $from, $to ) as $day ) {
				$base = bhc_parse_ranges( $p['schedule'][ (int) gmdate( 'N', strtotime( $day ) ) ] ?? '' );
				// Ferie e permessi solo nei giorni lavorativi; malattia e infortunio a giorni di calendario.
				if ( in_array( $type, array( 'ferie', 'permesso', 'riposo', 'formazione', 'altro' ), true ) && ! $base && $from !== $to ) {
					$skip++;
					continue;
				}
				if ( 'malattia' === $type || 'infortunio' === $type ) {
					// La malattia sospende le ferie già inserite.
					$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . bhc_table( 'shift_changes' ) . " WHERE person_id = %d AND day = %s AND type IN ('ferie','permesso')", $p['id'], $day ) ); // phpcs:ignore
				}
				if ( 'turno' === $type ) {
					$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . bhc_table( 'shift_changes' ) . " WHERE person_id = %d AND day = %s AND type = 'turno'", $p['id'], $day ) ); // phpcs:ignore
				}
				$wpdb->insert(
					bhc_table( 'shift_changes' ),
					array(
						'person_id'  => $p['id'],
						'day'        => $day,
						'type'       => $type,
						'ranges'     => $ranges,
						'note'       => sanitize_text_field( (string) ( $d['note'] ?? '' ) ),
						'protocol'   => sanitize_text_field( (string) ( $d['protocol'] ?? '' ) ),
						'group_id'   => $group,
						'created_by' => get_current_user_id(),
						'created_at' => current_time( 'mysql' ),
					)
				);
				$n++;
			}
		}
		return array( 'added' => $n, 'skipped' => $skip );
	}

	public static function add_punch( $person_id, $datetime, $kind, $source, $note = '' ) {
		global $wpdb;
		$wpdb->insert(
			bhc_table( 'punches' ),
			array(
				'person_id'  => (int) $person_id,
				'punched_at' => $datetime,
				'kind'       => 'out' === $kind ? 'out' : 'in',
				'source'     => $source,
				'note'       => sanitize_text_field( $note ),
				'created_by' => get_current_user_id(),
				'created_at' => current_time( 'mysql' ),
			)
		);
		return (int) $wpdb->insert_id;
	}

	/** Prossima timbratura suggerita: entrata se fuori, uscita se dentro. */
	public static function next_kind( $person_id ) {
		global $wpdb;
		$last = $wpdb->get_row( $wpdb->prepare( 'SELECT kind, punched_at FROM ' . bhc_table( 'punches' ) . ' WHERE deleted = 0 AND person_id = %d AND punched_at >= %s ORDER BY punched_at DESC, id DESC LIMIT 1', $person_id, current_time( 'Y-m-d' ) . ' 00:00:00' ), ARRAY_A ); // phpcs:ignore
		return array( $last && 'in' === $last['kind'] ? 'out' : 'in', $last ? substr( $last['punched_at'], 11, 5 ) : '' );
	}

	/* ==================================================================
	 * PIN
	 * ================================================================ */

	public static function pin_hash( $pin ) {
		return hash_hmac( 'sha256', 'bh-pin|' . $pin, wp_salt( 'auth' ) );
	}

	public static function find_by_pin( $pin ) {
		global $wpdb;
		if ( ! preg_match( '/^\d{4,6}$/', (string) $pin ) ) {
			return null;
		}
		$id = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'people' ) . " WHERE pin_hash = %s AND status = 'attivo' LIMIT 1", self::pin_hash( $pin ) ) ); // phpcs:ignore
		return $id ? BHC_People::get( $id ) : null;
	}

	public static function set_pin( $person_id, $pin = '' ) {
		global $wpdb;
		$pin = preg_replace( '/\D/', '', (string) $pin );
		if ( '' === $pin ) {
			for ( $i = 0; $i < 50; $i++ ) {
				$try = (string) wp_rand( 1000, 9999 );
				if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'people' ) . ' WHERE pin_hash = %s', self::pin_hash( $try ) ) ) ) { // phpcs:ignore
					$pin = $try;
					break;
				}
			}
		}
		if ( ! preg_match( '/^\d{4,6}$/', $pin ) ) {
			return new WP_Error( 'pin', __( 'Il PIN deve avere da 4 a 6 cifre.', 'beautyhub-core' ) );
		}
		$other = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'people' ) . ' WHERE pin_hash = %s AND id <> %d', self::pin_hash( $pin ), $person_id ) ); // phpcs:ignore
		if ( $other ) {
			return new WP_Error( 'pin', __( 'PIN già usato da un\'altra persona: scegline un altro.', 'beautyhub-core' ) );
		}
		$wpdb->update( bhc_table( 'people' ), array( 'pin_hash' => self::pin_hash( $pin ) ), array( 'id' => (int) $person_id ) );
		return $pin;
	}

	/* ==================================================================
	 * Timbratrice pubblica (tablet della sede)
	 * ================================================================ */

	private static function kiosk_ok( $token ) {
		$s = self::settings();
		return $s['enabled'] && $s['token'] && is_string( $token ) && hash_equals( $s['token'], $token );
	}

	public static function kiosk_url() {
		$s = self::settings();
		return $s['token'] ? add_query_arg( 'bh_timbra', $s['token'], home_url( '/' ) ) : '';
	}

	private static function throttle() {
		$ip  = preg_replace( '/[^0-9a-f:.]/i', '', (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) ); // phpcs:ignore
		$key = 'bhc_pinfail_' . md5( $ip );
		return array( $key, (int) get_transient( $key ) );
	}

	public static function rest_kiosk_check( WP_REST_Request $r ) {
		if ( ! self::kiosk_ok( (string) $r->get_param( 'token' ) ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Timbratrice non attiva.', 'beautyhub-core' ) ), 403 );
		}
		list( $key, $fails ) = self::throttle();
		if ( $fails >= 8 ) {
			return new WP_REST_Response( array( 'message' => __( 'Troppi tentativi: riprova tra qualche minuto.', 'beautyhub-core' ) ), 429 );
		}
		$p = self::find_by_pin( (string) $r->get_param( 'pin' ) );
		if ( ! $p ) {
			set_transient( $key, $fails + 1, 10 * MINUTE_IN_SECONDS );
			return new WP_REST_Response( array( 'message' => __( 'PIN non riconosciuto.', 'beautyhub-core' ) ), 400 );
		}
		delete_transient( $key );
		list( $next, $last ) = self::next_kind( $p['id'] );
		$kind = (string) $r->get_param( 'kind' );
		if ( in_array( $kind, array( 'in', 'out' ), true ) ) {
			self::add_punch( $p['id'], current_time( 'mysql' ), $kind, 'tablet' );
			$ctx = self::load( array( $p['id'] ), current_time( 'Y-m-d' ), current_time( 'Y-m-d' ) );
			$day = self::day( $p, current_time( 'Y-m-d' ), $ctx );
			return array(
				'ok'        => true,
				'name'      => $p['first_name'],
				'kind'      => $kind,
				'time'      => current_time( 'H:i' ),
				'sched'     => $day['sched'],
				'anomalies' => array_values( array_map( function ( $a ) {
					return $a['label'];
				}, array_filter( $day['anomalies'], function ( $a ) {
					return in_array( $a['code'], array( 'late_in', 'late_back', 'early_out', 'nonworking' ), true );
				} ) ) ),
			);
		}
		return array( 'name' => $p['first_name'], 'next' => $next, 'last' => $last, 'now' => current_time( 'H:i' ) );
	}

	/** Pagina a schermo intero della timbratrice: /?bh_timbra=TOKEN */
	public static function kiosk_page() {
		if ( ! isset( $_GET['bh_timbra'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET['bh_timbra'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		$ok     = self::kiosk_ok( $token );
		$center = esc_html( bhc_get_option( 'center_name' ) );
		$api    = esc_url_raw( rest_url( BHC_REST::NS . '/public/clock' ) );
		echo '<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><meta name="robots" content="noindex,nofollow"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="theme-color" content="#3f4838"><title>Timbratrice – ' . $center . '</title>';
		echo '<style>
*{box-sizing:border-box}html,body{margin:0;height:100%;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:#f5f3ef;color:#2b2a27;-webkit-user-select:none;user-select:none}
.w{min-height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;gap:18px}
.c{font-size:13px;letter-spacing:.14em;text-transform:uppercase;color:#7a776f}
.t{font-size:64px;font-weight:700;font-variant-numeric:tabular-nums;line-height:1}
.d{color:#7a776f;margin-top:-10px}
.pin{display:flex;gap:14px;height:22px}.pin i{width:18px;height:18px;border-radius:50%;border:2px solid #7d8c6f}.pin i.on{background:#7d8c6f}
.k{display:grid;grid-template-columns:repeat(3,92px);gap:12px}
.k button{height:76px;border-radius:16px;border:1px solid #ddd6c8;background:#fff;font-size:30px;font-weight:600;color:#2b2a27;box-shadow:0 1px 2px rgba(0,0,0,.05)}
.k button:active{background:#e6ebdf}.k .f{font-size:16px;color:#7a776f;background:#f1ece3}
.m{min-height:26px;font-size:17px;text-align:center}.m.e{color:#b55448}
.who{font-size:30px;font-weight:700}.btns{display:flex;gap:16px}
.btns button{width:190px;height:110px;border-radius:18px;border:0;font-size:24px;font-weight:700;color:#fff;opacity:.45}
.btns .in{background:#5e7a4b}.btns .out{background:#a2563f}.btns .sug{opacity:1;box-shadow:0 0 0 4px rgba(0,0,0,.08)}
.ok{font-size:84px;color:#5e7a4b;line-height:1}.small{color:#7a776f}.warn{background:#fbeee2;color:#8a4f22;padding:10px 14px;border-radius:10px}
.back{background:none;border:0;color:#7a776f;font-size:16px;text-decoration:underline}
</style></head><body><div class="w" id="app">';
		if ( ! $ok ) {
			echo '<div class="c">' . $center . '</div><h2>Timbratrice non attiva</h2><p class="small">Chiedi alla responsabile di attivarla dal gestionale (Orari › Timbratrice).</p></div></body></html>';
			exit;
		}
		echo '</div><script>
(function(){var API=' . wp_json_encode( $api ) . ',TOKEN=' . wp_json_encode( $token ) . ',CENTER=' . wp_json_encode( bhc_get_option( 'center_name' ) ) . ';
var app=document.getElementById("app"),pin="",timer=null;
function pad(n){return(n<10?"0":"")+n}
function clock(){var d=new Date();return pad(d.getHours())+":"+pad(d.getMinutes())}
function dateStr(){return new Date().toLocaleDateString("it-IT",{weekday:"long",day:"numeric",month:"long"})}
function post(body){body.token=TOKEN;return fetch(API,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}).then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.message||"Errore");return j})})}
function home(msg,err){pin="";clearTimeout(timer);
app.innerHTML="<div class=c>"+esc(CENTER)+"</div><div class=t id=t>"+clock()+"</div><div class=d>"+dateStr()+"</div><div class=pin id=pin></div><div class=\"m"+(err?" e":"")+"\" id=m>"+(msg||"Digita il tuo PIN")+"</div><div class=k>"+[1,2,3,4,5,6,7,8,9].map(function(n){return"<button data-k="+n+">"+n+"</button>"}).join("")+"<button class=f data-k=C>C</button><button data-k=0>0</button><button class=f data-k=OK>OK</button></div>";
dots();app.querySelectorAll("[data-k]").forEach(function(b){b.onclick=function(){key(b.dataset.k)}})}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c]})}
function dots(){var p=document.getElementById("pin");if(p)p.innerHTML=[0,1,2,3,4,5].slice(0,Math.max(4,pin.length)).map(function(i){return"<i class=\""+(i<pin.length?"on":"")+"\"></i>"}).join("")}
function key(k){if(k==="C"){pin="";dots();return}if(k==="OK"){if(pin.length>=4)check();return}if(pin.length<6){pin+=k;dots();if(pin.length===6)check()}}
document.addEventListener("keydown",function(e){if(/^[0-9]$/.test(e.key))key(e.key);else if(e.key==="Enter")key("OK");else if(e.key==="Backspace"){pin=pin.slice(0,-1);dots()}});
function check(){var m=document.getElementById("m");m.textContent="Verifica…";post({pin:pin}).then(choose).catch(function(e){home(e.message,true)})}
function choose(d){clearTimeout(timer);app.innerHTML="<div class=who>Ciao "+esc(d.name)+"</div><div class=small>"+(d.last?"Ultima timbratura alle "+esc(d.last):"Nessuna timbratura oggi")+"</div><div class=btns><button class=\"in"+(d.next==="in"?" sug":"")+"\" data-p=in>Entrata</button><button class=\"out"+(d.next==="out"?" sug":"")+"\" data-p=out>Uscita</button></div><button class=back data-x>Annulla</button>";
app.querySelectorAll("[data-p]").forEach(function(b){b.onclick=function(){punch(b.dataset.p)}});app.querySelector("[data-x]").onclick=function(){home()};timer=setTimeout(home,20000)}
function punch(kind){var p=pin;post({pin:p,kind:kind}).then(function(d){app.innerHTML="<div class=ok>✓</div><div class=who>"+(kind==="in"?"Buon lavoro":"A presto")+", "+esc(d.name)+"</div><div class=t style=\"font-size:44px\">"+(kind==="in"?"Entrata ":"Uscita ")+esc(d.time)+"</div>"+(d.sched?"<div class=small>Orario di oggi: "+esc(d.sched)+"</div>":"")+(d.anomalies&&d.anomalies.length?"<div class=warn>"+d.anomalies.map(esc).join("<br>")+" – avvisa la responsabile</div>":"");timer=setTimeout(home,5000)}).catch(function(e){home(e.message,true)})}
setInterval(function(){var t=document.getElementById("t");if(t)t.textContent=clock()},5000);home();})();
</script></body></html>';
		exit;
	}

	/* ==================================================================
	 * REST
	 * ================================================================ */

	public static function routes() {
		$ns   = BHC_REST::NS;
		$perm = BHC_Permissions::cb( array( 'timeclock' ) );
		register_rest_route( $ns, '/public/clock', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_kiosk_check' ), 'permission_callback' => '__return_true' ) );
		$r = function ( $path, $method, $cb ) use ( $ns, $perm ) {
			register_rest_route( $ns, '/tc/' . $path, array( 'methods' => $method, 'callback' => array( __CLASS__, $cb ), 'permission_callback' => $perm ) );
		};
		$r( 'meta', 'GET', 'rest_meta' );
		$r( 'week', 'GET', 'rest_week' );
		$r( 'month', 'GET', 'rest_month' );
		$r( 'changes', 'POST', 'rest_add_changes' );
		$r( 'changes/(?P<id>\d+)', 'DELETE', 'rest_del_change' );
		$r( 'punches', 'POST', 'rest_add_punch' );
		$r( 'punches/(?P<id>\d+)', 'DELETE', 'rest_del_punch' );
		$r( 'anomalies', 'GET', 'rest_anomalies' );
		$r( 'anomalies', 'POST', 'rest_justify' );
		$r( 'leaves', 'GET', 'rest_leaves' );
		$r( 'leaves/(?P<id>\d+)', 'PUT', 'rest_save_leave' );
		$r( 'settings', 'PUT', 'rest_save_settings' );
		$r( 'pin/(?P<id>\d+)', 'POST', 'rest_pin' );
		$r( 'pin/(?P<id>\d+)', 'DELETE', 'rest_pin_del' );
		$r( 'schedule/(?P<id>\d+)', 'PUT', 'rest_schedule' );
	}

	private static function err( $e, $status = 400 ) {
		return new WP_REST_Response( array( 'message' => is_wp_error( $e ) ? $e->get_error_message() : $e ), $status );
	}

	public static function rest_meta() {
		$s = self::settings();
		$t = array();
		foreach ( self::types() as $k => $v ) {
			$t[ $k ] = array( 'label' => $v[0], 'color' => $v[1], 'kind' => $v[2] );
		}
		return array(
			'types'     => $t,
			'anomalies' => self::anomaly_labels(),
			'reasons'   => self::reasons(),
			'settings'  => array( 'enabled' => (int) $s['enabled'], 'tolerance' => $s['tolerance'], 'vac_days' => (float) $s['vac_days'], 'rol_hours' => (float) $s['rol_hours'], 'url' => $s['enabled'] ? self::kiosk_url() : '' ),
			'people'    => array_map( array( __CLASS__, 'slim' ), self::people( current_time( 'Y-m-d' ), current_time( 'Y-m-d' ) ) ),
			'today'     => current_time( 'Y-m-d' ),
		);
	}

	private static function dparam( WP_REST_Request $r, $k = 'date' ) {
		$d = (string) $r->get_param( $k );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ? $d : current_time( 'Y-m-d' );
	}

	public static function rest_week( WP_REST_Request $r ) {
		return self::week( self::dparam( $r ) );
	}

	public static function rest_month( WP_REST_Request $r ) {
		$m = (string) $r->get_param( 'month' );
		return self::month( preg_match( '/^\d{4}-\d{2}$/', $m ) ? $m : current_time( 'Y-m' ), absint( $r->get_param( 'person' ) ) );
	}

	public static function rest_add_changes( WP_REST_Request $r ) {
		$res = self::add_changes( (array) $r->get_json_params() );
		return is_wp_error( $res ) ? self::err( $res ) : $res;
	}

	public static function rest_del_change( WP_REST_Request $r ) {
		global $wpdb;
		$t   = bhc_table( 'shift_changes' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", (int) $r['id'] ), ARRAY_A ); // phpcs:ignore
		if ( $row && $r->get_param( 'group' ) && $row['group_id'] ) {
			$wpdb->delete( $t, array( 'group_id' => $row['group_id'], 'person_id' => $row['person_id'] ) );
		} else {
			$wpdb->delete( $t, array( 'id' => (int) $r['id'] ) );
		}
		return array( 'ok' => true );
	}

	public static function rest_add_punch( WP_REST_Request $r ) {
		$pid  = absint( $r->get_param( 'person_id' ) );
		$date = self::dparam( $r );
		$time = (string) $r->get_param( 'time' );
		if ( ! BHC_People::get( $pid ) || ! preg_match( '/^\d{2}:\d{2}$/', $time ) ) {
			return self::err( __( 'Persona o orario non validi.', 'beautyhub-core' ) );
		}
		if ( $date . ' ' . $time > current_time( 'Y-m-d H:i' ) ) {
			return self::err( __( 'Non puoi inserire una timbratura nel futuro.', 'beautyhub-core' ) );
		}
		$id = self::add_punch( $pid, $date . ' ' . $time . ':00', (string) $r->get_param( 'kind' ), 'manual', (string) $r->get_param( 'note' ) );
		return array( 'id' => $id );
	}

	public static function rest_del_punch( WP_REST_Request $r ) {
		global $wpdb;
		$wpdb->update( bhc_table( 'punches' ), array( 'deleted' => 1, 'note' => 'Eliminata da ' . wp_get_current_user()->display_name . ' il ' . current_time( 'd/m/Y H:i' ) ), array( 'id' => (int) $r['id'] ) );
		return array( 'ok' => true );
	}

	public static function rest_anomalies( WP_REST_Request $r ) {
		$m    = (string) $r->get_param( 'month' );
		$m    = preg_match( '/^\d{4}-\d{2}$/', $m ) ? $m : current_time( 'Y-m' );
		$from = $m . '-01';
		return array( 'items' => self::anomalies( $from, gmdate( 'Y-m-t', strtotime( $from ) ), sanitize_key( (string) $r->get_param( 'status' ) ) ) );
	}

	public static function rest_justify( WP_REST_Request $r ) {
		global $wpdb;
		$pid  = absint( $r->get_param( 'person_id' ) );
		$day  = self::dparam( $r, 'day' );
		$code = sanitize_key( (string) $r->get_param( 'code' ) );
		if ( ! isset( self::anomaly_labels()[ $code ] ) ) {
			return self::err( __( 'Anomalia non valida.', 'beautyhub-core' ) );
		}
		$t = bhc_table( 'punch_notes' );
		$wpdb->delete( $t, array( 'person_id' => $pid, 'day' => $day, 'code' => $code ) );
		$st = (string) $r->get_param( 'status' );
		if ( 'reopen' !== $st ) {
			$wpdb->insert(
				$t,
				array(
					'person_id'  => $pid,
					'day'        => $day,
					'code'       => $code,
					'reason'     => sanitize_text_field( (string) $r->get_param( 'reason' ) ),
					'note'       => sanitize_text_field( (string) $r->get_param( 'note' ) ),
					'status'     => 'respinta' === $st ? 'respinta' : 'approvata',
					'created_by' => get_current_user_id(),
					'created_at' => current_time( 'mysql' ),
				)
			);
		}
		return array( 'ok' => true );
	}

	public static function rest_leaves( WP_REST_Request $r ) {
		$y = absint( $r->get_param( 'year' ) );
		return self::leaves( $y >= 2000 && $y <= 2100 ? $y : (int) current_time( 'Y' ) );
	}

	public static function rest_save_leave( WP_REST_Request $r ) {
		global $wpdb;
		$pid  = (int) $r['id'];
		$year = absint( $r->get_param( 'year' ) );
		$t    = bhc_table( 'leave_balances' );
		$row  = array(
			'person_id' => $pid,
			'year'      => $year,
			'vac_prev'  => (float) str_replace( ',', '.', (string) $r->get_param( 'vac_prev' ) ),
			'vac_days'  => '' === (string) $r->get_param( 'vac_days' ) ? null : (float) str_replace( ',', '.', (string) $r->get_param( 'vac_days' ) ),
			'rol_prev'  => (float) str_replace( ',', '.', (string) $r->get_param( 'rol_prev' ) ),
			'rol_hours' => '' === (string) $r->get_param( 'rol_hours' ) ? null : (float) str_replace( ',', '.', (string) $r->get_param( 'rol_hours' ) ),
		);
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE person_id = %d AND year = %d", $pid, $year ) ); // phpcs:ignore
		if ( $id ) {
			$wpdb->update( $t, $row, array( 'id' => $id ) );
		} else {
			$wpdb->insert( $t, $row );
		}
		return array( 'ok' => true );
	}

	public static function rest_save_settings( WP_REST_Request $r ) {
		$s = self::settings();
		if ( null !== $r->get_param( 'enabled' ) ) {
			$s['enabled'] = $r->get_param( 'enabled' ) ? 1 : 0;
			if ( $s['enabled'] && ! $s['token'] ) {
				$s['token'] = wp_generate_password( 32, false, false );
			}
		}
		if ( $r->get_param( 'new_token' ) ) {
			$s['token'] = wp_generate_password( 32, false, false );
		}
		foreach ( array( 'tolerance', 'vac_days', 'rol_hours' ) as $k ) {
			if ( null !== $r->get_param( $k ) ) {
				$s[ $k ] = max( 0, (float) str_replace( ',', '.', (string) $r->get_param( $k ) ) );
			}
		}
		$s['tolerance'] = (int) $s['tolerance'];
		update_option( self::OPT, $s, false );
		return self::rest_meta();
	}

	public static function rest_pin( WP_REST_Request $r ) {
		if ( ! BHC_People::get( (int) $r['id'] ) ) {
			return self::err( __( 'Persona non trovata.', 'beautyhub-core' ), 404 );
		}
		$pin = self::set_pin( (int) $r['id'], (string) $r->get_param( 'pin' ) );
		return is_wp_error( $pin ) ? self::err( $pin ) : array( 'pin' => $pin );
	}

	/** Orario settimanale di base (lo stesso della scheda personale › Orari). */
	public static function rest_schedule( WP_REST_Request $r ) {
		if ( ! BHC_People::get( (int) $r['id'] ) ) {
			return self::err( __( 'Persona non trovata.', 'beautyhub-core' ), 404 );
		}
		$sched = (array) $r->get_param( 'schedule' );
		foreach ( $sched as $k => $v ) {
			if ( '' !== trim( (string) $v ) && ! bhc_parse_ranges( (string) $v ) ) {
				return self::err( sprintf( __( 'Orario di %s non valido: usa il formato 09:00-13:00, 14:00-18:00.', 'beautyhub-core' ), bhc_weekdays()[ (int) $k ] ?? $k ) );
			}
		}
		$data = array( 'schedule' => $sched );
		if ( null !== $r->get_param( 'weekly_hours' ) ) {
			$data['weekly_hours'] = $r->get_param( 'weekly_hours' );
		}
		BHC_People::save( $data, (int) $r['id'] );
		return array( 'ok' => true );
	}

	public static function rest_pin_del( WP_REST_Request $r ) {
		global $wpdb;
		$wpdb->update( bhc_table( 'people' ), array( 'pin_hash' => '' ), array( 'id' => (int) $r['id'] ) );
		return array( 'ok' => true );
	}
}
