<?php
/**
 * Funzioni di utilità.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Nome tabella con prefisso.
 *
 * @param string $name clients|appointments|payments.
 */
function bhc_table( $name ) {
	global $wpdb;
	return $wpdb->prefix . 'bh_' . $name;
}

/**
 * Legge un'impostazione del plugin.
 */
function bhc_get_option( $key, $default = null ) {
	$opts = get_option( 'bhc_settings', array() );
	if ( is_array( $opts ) && array_key_exists( $key, $opts ) ) {
		return $opts[ $key ];
	}
	$defaults = BHC_Settings::defaults();
	return isset( $defaults[ $key ] ) ? $defaults[ $key ] : $default;
}

/**
 * Converte "HH:MM" in minuti dalla mezzanotte.
 */
function bhc_time_to_min( $time ) {
	if ( ! is_string( $time ) || ! preg_match( '/^(\d{1,2}):(\d{2})/', $time, $m ) ) {
		return null;
	}
	return (int) $m[1] * 60 + (int) $m[2];
}

/**
 * Converte minuti in "HH:MM".
 */
function bhc_min_to_time( $min ) {
	$min = max( 0, (int) $min );
	return sprintf( '%02d:%02d', floor( $min / 60 ), $min % 60 );
}

/**
 * Stati appuntamento con etichetta.
 */
function bhc_statuses() {
	return array(
		'booked'    => __( 'Prenotato', 'beautyhub-core' ),
		'confirmed' => __( 'Confermato', 'beautyhub-core' ),
		'arrived'   => __( 'Arrivata', 'beautyhub-core' ),
		'done'      => __( 'Completato', 'beautyhub-core' ),
		'noshow'    => __( 'No-show', 'beautyhub-core' ),
		'cancelled' => __( 'Annullato', 'beautyhub-core' ),
	);
}

/**
 * Metodi di pagamento.
 */
function bhc_payment_methods() {
	return array(
		'cash'     => __( 'Contanti', 'beautyhub-core' ),
		'card'     => __( 'Carta / POS', 'beautyhub-core' ),
		'transfer' => __( 'Bonifico', 'beautyhub-core' ),
		'giftcard' => __( 'Gift card', 'beautyhub-core' ),
		'other'    => __( 'Altro', 'beautyhub-core' ),
	);
}

/**
 * L'utente corrente fa parte dello staff?
 */
function bhc_is_staff() {
	return BHC_Permissions::is_staff();
}

/**
 * Formatta prezzo in euro.
 */
function bhc_price( $value ) {
	return '€ ' . number_format_i18n( (float) $value, 2 );
}

/**
 * Restituisce i dati di un trattamento in forma di array.
 */
function bhc_treatment_data( $post ) {
	$post = get_post( $post );
	if ( ! $post || 'bh_treatment' !== $post->post_type ) {
		return null;
	}
	$cats = wp_get_post_terms( $post->ID, 'bh_treatment_cat', array( 'fields' => 'names' ) );
	return array(
		'id'          => $post->ID,
		'name'        => get_the_title( $post ),
		'description' => wp_strip_all_tags( get_the_excerpt( $post ) ),
		'duration'    => (int) get_post_meta( $post->ID, '_bh_duration', true ),
		'buffer'      => (int) get_post_meta( $post->ID, '_bh_buffer', true ),
		'price'       => (float) get_post_meta( $post->ID, '_bh_price', true ),
		'online'      => '0' !== get_post_meta( $post->ID, '_bh_online', true ),
		'staff_needed' => 2 === (int) get_post_meta( $post->ID, '_bh_staff_needed', true ) ? 2 : 1,
		'category'    => is_wp_error( $cats ) || empty( $cats ) ? '' : $cats[0],
		'image'       => get_the_post_thumbnail_url( $post, 'medium_large' ),
	);
}

/**
 * Restituisce i dati di un'operatrice.
 */
function bhc_staff_data( $post ) {
	$post = get_post( $post );
	if ( ! $post || 'bh_staff' !== $post->post_type ) {
		return null;
	}
	$treatments = get_post_meta( $post->ID, '_bh_treatments', true );
	$hours      = get_post_meta( $post->ID, '_bh_hours', true );
	return array(
		'id'         => $post->ID,
		'name'       => get_the_title( $post ),
		'role'       => (string) get_post_meta( $post->ID, '_bh_role', true ),
		'color'      => (string) get_post_meta( $post->ID, '_bh_color', true ) ?: '#7d8c6f',
		'user_id'    => (int) get_post_meta( $post->ID, '_bh_user_id', true ),
		'treatments' => is_array( $treatments ) ? array_map( 'intval', $treatments ) : array(),
		'hours'      => is_array( $hours ) ? $hours : array(),
		'bio'        => wp_strip_all_tags( get_the_excerpt( $post ) ),
		'image'      => get_the_post_thumbnail_url( $post, 'medium' ),
	);
}

/**
 * Elenco trattamenti pubblicati.
 */
function bhc_get_treatments( $only_online = false ) {
	$posts = get_posts(
		array(
			'post_type'   => 'bh_treatment',
			'post_status' => 'publish',
			'numberposts' => -1,
			'orderby'     => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		)
	);
	$out = array();
	foreach ( $posts as $p ) {
		$t = bhc_treatment_data( $p );
		if ( $only_online && ! $t['online'] ) {
			continue;
		}
		$out[] = $t;
	}
	return $out;
}

/**
 * Elenco operatrici pubblicate.
 */
function bhc_get_staff() {
	$posts = get_posts(
		array(
			'post_type'   => 'bh_staff',
			'post_status' => 'publish',
			'numberposts' => -1,
			'orderby'     => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		)
	);
	return array_map( 'bhc_staff_data', $posts );
}

/**
 * Giorni della settimana (chiave = numero ISO 1..7).
 */
function bhc_weekdays() {
	return array(
		1 => __( 'Lunedì', 'beautyhub-core' ),
		2 => __( 'Martedì', 'beautyhub-core' ),
		3 => __( 'Mercoledì', 'beautyhub-core' ),
		4 => __( 'Giovedì', 'beautyhub-core' ),
		5 => __( 'Venerdì', 'beautyhub-core' ),
		6 => __( 'Sabato', 'beautyhub-core' ),
		7 => __( 'Domenica', 'beautyhub-core' ),
	);
}

/**
 * Normalizza una stringa orari "09:00-13:00, 14:00-19:00" in intervalli di minuti.
 *
 * @return array<int, array{0:int,1:int}>
 */
function bhc_parse_ranges( $str ) {
	$out = array();
	foreach ( preg_split( '/[,;]+/', (string) $str ) as $part ) {
		if ( preg_match( '/(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})/', $part, $m ) ) {
			$a = bhc_time_to_min( $m[1] );
			$b = bhc_time_to_min( $m[2] );
			if ( null !== $a && null !== $b && $b > $a ) {
				$out[] = array( $a, $b );
			}
		}
	}
	return $out;
}
