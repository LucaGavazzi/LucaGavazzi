<?php
/**
 * Scheda trattamento dal gestionale: crea, modifica ed elimina i trattamenti
 * con tutti i dati (categoria, descrizione, foto, tempi, prezzo, operatrici, cabine).
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Treatments_API {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		$ns = BHC_REST::NS;
		register_rest_route(
			$ns,
			'/treatments',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_items' ), 'permission_callback' => BHC_Permissions::cb( array( 'treatments' ) ) ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'create' ), 'permission_callback' => BHC_Permissions::cb( array( 'treatments' ) ) ),
			)
		);
		register_rest_route(
			$ns,
			'/treatments/(?P<id>\d+)',
			array(
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'update' ), 'permission_callback' => BHC_Permissions::cb( array( 'treatments' ) ) ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete' ), 'permission_callback' => BHC_Permissions::cb( array( 'treatments' ) ) ),
			)
		);
		register_rest_route(
			$ns,
			'/categories',
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'create_category' ), 'permission_callback' => BHC_Permissions::cb( array( 'treatments' ) ) )
		);
		register_rest_route(
			$ns,
			'/categories/(?P<id>\d+)',
			array(
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'update_category' ), 'permission_callback' => BHC_Permissions::cb( array( 'treatments' ) ) ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete_category' ), 'permission_callback' => BHC_Permissions::cb( array( 'treatments' ) ) ),
			)
		);
		register_rest_route( $ns, '/treatments/(?P<id>\d+)/image', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'upload_image' ), 'permission_callback' => BHC_Permissions::cb( array( 'treatments' ) ) ) );
	}

	/** Dati completi per la scheda. */
	public static function item( $id ) {
		$t = bhc_treatment_data( $id );
		if ( ! $t ) {
			return null;
		}
		$post             = get_post( $id );
		$t['full_description'] = wp_strip_all_tags( $post->post_content );
		$t['description']      = $post->post_excerpt ? $post->post_excerpt : wp_trim_words( $t['full_description'], 30 );
		$t['people']           = BHC_Operators::treatment_people( $id );
		$t['cabins']           = self::cabins_for( $id );
		$t['image_id']         = (int) get_post_thumbnail_id( $id );
		$t['thumb']            = get_the_post_thumbnail_url( $id, 'thumbnail' );
		$t['order']            = (int) $post->menu_order;
		return $t;
	}

	/** Cabine in cui si può eseguire il trattamento. */
	public static function cabins_for( $treatment_id ) {
		$out = array();
		foreach ( bhc_get_staff() as $c ) {
			if ( empty( $c['treatments'] ) || in_array( (int) $treatment_id, $c['treatments'], true ) ) {
				$out[] = (int) $c['id'];
			}
		}
		return $out;
	}

	/**
	 * Aggiorna le cabine abilitate. Una cabina "tutti i trattamenti" che viene
	 * esclusa passa all'elenco esplicito di tutti gli altri trattamenti.
	 */
	public static function set_cabins( $treatment_id, array $cabin_ids ) {
		$tid  = (int) $treatment_id;
		$want = array_map( 'intval', $cabin_ids );
		$all  = wp_list_pluck( bhc_get_treatments(), 'id' );
		foreach ( bhc_get_staff() as $c ) {
			$should = in_array( (int) $c['id'], $want, true );
			if ( empty( $c['treatments'] ) ) {
				if ( ! $should ) {
					BHC_Repository::save_cabin_meta( $c['id'], array( 'treatments' => array_values( array_diff( $all, array( $tid ) ) ) ) );
				}
				continue;
			}
			$has = in_array( $tid, $c['treatments'], true );
			if ( $has === $should ) {
				continue;
			}
			$list = $should ? array_merge( $c['treatments'], array( $tid ) ) : array_values( array_diff( $c['treatments'], array( $tid ) ) );
			if ( ! $list ) {
				// Non lasciare mai una cabina senza trattamenti (vorrebbe dire "tutti").
				continue;
			}
			BHC_Repository::save_cabin_meta( $c['id'], array( 'treatments' => $list ) );
		}
	}

	public static function list_items() {
		$items = array();
		foreach ( get_posts( array( 'post_type' => 'bh_treatment', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ) ) ) as $p ) {
			$items[] = self::item( $p->ID );
		}
		$people = array();
		foreach ( BHC_People::search( '', '', 'attivo' ) as $p ) {
			$people[] = array( 'id' => $p['id'], 'name' => trim( $p['first_name'] . ' ' . $p['last_name'] ), 'role' => $p['role'], 'color' => $p['color'] );
		}
		$cabins = array();
		foreach ( bhc_get_staff() as $c ) {
			$cabins[] = array( 'id' => $c['id'], 'name' => $c['name'], 'color' => $c['color'] );
		}
		$info = self::categories();
		return array( 'items' => $items, 'people' => $people, 'cabins' => $cabins, 'categories' => wp_list_pluck( $info, 'name' ), 'category_info' => $info );
	}

	/**
	 * Applica i campi della scheda al trattamento.
	 */
	private static function apply( $id, WP_REST_Request $r ) {
		$post = array( 'ID' => $id );
		if ( null !== $r->get_param( 'name' ) ) {
			$post['post_title'] = sanitize_text_field( (string) $r->get_param( 'name' ) );
		}
		if ( null !== $r->get_param( 'description' ) ) {
			$post['post_excerpt'] = sanitize_textarea_field( (string) $r->get_param( 'description' ) );
		}
		if ( null !== $r->get_param( 'full_description' ) ) {
			$post['post_content'] = sanitize_textarea_field( (string) $r->get_param( 'full_description' ) );
		}
		if ( null !== $r->get_param( 'order' ) ) {
			$post['menu_order'] = (int) $r->get_param( 'order' );
		}
		if ( count( $post ) > 1 ) {
			wp_update_post( $post );
		}

		if ( null !== $r->get_param( 'category' ) ) {
			$cat = sanitize_text_field( (string) $r->get_param( 'category' ) );
			if ( '' === $cat ) {
				wp_set_object_terms( $id, array(), 'bh_treatment_cat' );
			} else {
				$term = term_exists( $cat, 'bh_treatment_cat' );
				if ( ! $term ) {
					$term = wp_insert_term( $cat, 'bh_treatment_cat' );
				}
				if ( ! is_wp_error( $term ) ) {
					wp_set_object_terms( $id, array( (int) $term['term_id'] ), 'bh_treatment_cat' );
				}
			}
		}
		if ( null !== $r->get_param( 'duration' ) ) {
			update_post_meta( $id, '_bh_duration', max( 5, absint( $r->get_param( 'duration' ) ) ) );
		}
		if ( null !== $r->get_param( 'buffer' ) ) {
			update_post_meta( $id, '_bh_buffer', absint( $r->get_param( 'buffer' ) ) );
		}
		if ( null !== $r->get_param( 'price' ) ) {
			update_post_meta( $id, '_bh_price', max( 0, round( (float) str_replace( ',', '.', (string) $r->get_param( 'price' ) ), 2 ) ) );
		}
		if ( null !== $r->get_param( 'online' ) ) {
			update_post_meta( $id, '_bh_online', $r->get_param( 'online' ) ? '1' : '0' );
		}
		if ( null !== $r->get_param( 'staff_needed' ) ) {
			update_post_meta( $id, '_bh_staff_needed', 2 === (int) $r->get_param( 'staff_needed' ) ? 2 : 1 );
		}
		if ( is_array( $r->get_param( 'people' ) ) ) {
			BHC_Operators::set_treatment_people( $id, $r->get_param( 'people' ) );
		}
		if ( is_array( $r->get_param( 'cabins' ) ) ) {
			self::set_cabins( $id, $r->get_param( 'cabins' ) );
		}
		if ( null !== $r->get_param( 'image_id' ) ) {
			$img = absint( $r->get_param( 'image_id' ) );
			if ( $img && wp_attachment_is_image( $img ) ) {
				set_post_thumbnail( $id, $img );
			} elseif ( ! $img ) {
				delete_post_thumbnail( $id );
			}
		}
	}

	private static function validate( WP_REST_Request $r, $creating ) {
		$name = trim( (string) $r->get_param( 'name' ) );
		if ( ( $creating || null !== $r->get_param( 'name' ) ) && '' === $name ) {
			return new WP_Error( 'name', __( 'Inserisci il nome del trattamento.', 'beautyhub-core' ) );
		}
		if ( $creating && ! absint( $r->get_param( 'duration' ) ) ) {
			return new WP_Error( 'duration', __( 'Indica la durata del trattamento.', 'beautyhub-core' ) );
		}
		if ( 2 === (int) $r->get_param( 'staff_needed' ) && is_array( $r->get_param( 'people' ) ) && 1 === count( $r->get_param( 'people' ) ) ) {
			return new WP_Error( 'people', __( 'Servono 2 operatrici: abilitane almeno due, oppure nessuna (tutte).', 'beautyhub-core' ) );
		}
		if ( is_array( $r->get_param( 'cabins' ) ) && ! $r->get_param( 'cabins' ) && bhc_get_staff() ) {
			return new WP_Error( 'cabins', __( 'Scegli almeno una cabina in cui eseguire il trattamento.', 'beautyhub-core' ) );
		}
		return true;
	}

	/* ------------------------------------------------------------------
	 * Categorie
	 * ---------------------------------------------------------------- */

	public static function categories() {
		$out   = array();
		$terms = get_terms( array( 'taxonomy' => 'bh_treatment_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$out[] = array(
					'id'          => (int) $term->term_id,
					'name'        => $term->name,
					'description' => $term->description,
					'count'       => (int) $term->count,
				);
			}
		}
		return $out;
	}

	private static function category_out( $term_id ) {
		foreach ( self::categories() as $c ) {
			if ( $c['id'] === (int) $term_id ) {
				return $c;
			}
		}
		return null;
	}

	public static function create_category( WP_REST_Request $r ) {
		$name = sanitize_text_field( (string) $r->get_param( 'name' ) );
		if ( '' === $name ) {
			return self::err( new WP_Error( 'name', __( 'Inserisci il nome della categoria.', 'beautyhub-core' ) ) );
		}
		if ( term_exists( $name, 'bh_treatment_cat' ) ) {
			return self::err( new WP_Error( 'exists', __( 'Esiste già una categoria con questo nome.', 'beautyhub-core' ) ) );
		}
		$t = wp_insert_term( $name, 'bh_treatment_cat', array( 'description' => sanitize_textarea_field( (string) $r->get_param( 'description' ) ) ) );
		return is_wp_error( $t ) ? self::err( $t ) : self::category_out( $t['term_id'] );
	}

	public static function update_category( WP_REST_Request $r ) {
		$id   = (int) $r['id'];
		$term = get_term( $id, 'bh_treatment_cat' );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Categoria non trovata.', 'beautyhub-core' ) ), 404 );
		}
		$args = array();
		if ( null !== $r->get_param( 'name' ) ) {
			$name = sanitize_text_field( (string) $r->get_param( 'name' ) );
			if ( '' === $name ) {
				return self::err( new WP_Error( 'name', __( 'Inserisci il nome della categoria.', 'beautyhub-core' ) ) );
			}
			$other = term_exists( $name, 'bh_treatment_cat' );
			if ( $other && (int) $other['term_id'] !== $id ) {
				return self::err( new WP_Error( 'exists', __( 'Esiste già una categoria con questo nome.', 'beautyhub-core' ) ) );
			}
			$args['name'] = $name;
		}
		if ( null !== $r->get_param( 'description' ) ) {
			$args['description'] = sanitize_textarea_field( (string) $r->get_param( 'description' ) );
		}
		$res = wp_update_term( $id, 'bh_treatment_cat', $args );
		return is_wp_error( $res ) ? self::err( $res ) : self::category_out( $id );
	}

	public static function delete_category( WP_REST_Request $r ) {
		$id   = (int) $r['id'];
		$term = get_term( $id, 'bh_treatment_cat' );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Categoria non trovata.', 'beautyhub-core' ) ), 404 );
		}
		if ( $term->count > 0 ) {
			/* translators: %d: numero trattamenti */
			return self::err( new WP_Error( 'not_empty', sprintf( _n( 'La categoria contiene %d trattamento: spostalo in un\'altra categoria prima di eliminarla.', 'La categoria contiene %d trattamenti: spostali in un\'altra categoria prima di eliminarla.', $term->count, 'beautyhub-core' ), $term->count ) ), 409 );
		}
		wp_delete_term( $id, 'bh_treatment_cat' );
		return array( 'ok' => true );
	}

	private static function err( WP_Error $e, $status = 400 ) {
		return new WP_REST_Response( array( 'message' => $e->get_error_message(), 'code' => $e->get_error_code() ), $status );
	}

	public static function create( WP_REST_Request $r ) {
		$v = self::validate( $r, true );
		if ( is_wp_error( $v ) ) {
			return self::err( $v );
		}
		$id = wp_insert_post(
			array(
				'post_type'   => 'bh_treatment',
				'post_status' => 'publish',
				'post_title'  => sanitize_text_field( (string) $r->get_param( 'name' ) ),
				'menu_order'  => count( bhc_get_treatments() ),
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			return self::err( $id );
		}
		// Valori predefiniti, poi i campi inviati.
		update_post_meta( $id, '_bh_online', '1' );
		update_post_meta( $id, '_bh_staff_needed', 1 );
		update_post_meta( $id, '_bh_buffer', 10 );
		self::apply( $id, $r );
		return self::item( $id );
	}

	public static function update( WP_REST_Request $r ) {
		$id = (int) $r['id'];
		if ( ! bhc_treatment_data( $id ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Trattamento non trovato.', 'beautyhub-core' ) ), 404 );
		}
		$v = self::validate( $r, false );
		if ( is_wp_error( $v ) ) {
			return self::err( $v );
		}
		self::apply( $id, $r );
		return self::item( $id );
	}

	/**
	 * Elimina (cestino). Lo storico degli appuntamenti conserva il nome.
	 */
	public static function delete( WP_REST_Request $r ) {
		global $wpdb;
		$id = (int) $r['id'];
		if ( ! bhc_treatment_data( $id ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Trattamento non trovato.', 'beautyhub-core' ) ), 404 );
		}
		$future = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . bhc_table( 'appointments' ) . " WHERE treatment_id = %d AND start_at >= %s AND status NOT IN ('cancelled','noshow')", $id, current_time( 'mysql' ) ) ); // phpcs:ignore
		if ( $future ) {
			/* translators: %d: numero appuntamenti */
			return new WP_REST_Response( array( 'message' => sprintf( _n( 'C\'è %d appuntamento futuro con questo trattamento: disattiva la prenotazione online invece di eliminarlo.', 'Ci sono %d appuntamenti futuri con questo trattamento: disattiva la prenotazione online invece di eliminarlo.', $future, 'beautyhub-core' ), $future ), 'code' => 'has_future' ), 409 );
		}
		wp_trash_post( $id );
		return array( 'ok' => true );
	}

	/**
	 * Carica la foto del trattamento (multipart, campo "file").
	 */
	public static function upload_image( WP_REST_Request $r ) {
		$id = (int) $r['id'];
		if ( ! bhc_treatment_data( $id ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Trattamento non trovato.', 'beautyhub-core' ) ), 404 );
		}
		$files = $r->get_file_params();
		if ( empty( $files['file'] ) || ! empty( $files['file']['error'] ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Nessun file ricevuto.', 'beautyhub-core' ) ), 400 );
		}
		$type = wp_check_filetype_and_ext( $files['file']['tmp_name'], $files['file']['name'] );
		if ( ! in_array( $type['type'], array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Carica un\'immagine JPG, PNG o WebP.', 'beautyhub-core' ) ), 400 );
		}
		if ( $files['file']['size'] > 8 * MB_IN_BYTES ) {
			return new WP_REST_Response( array( 'message' => __( 'L\'immagine supera 8 MB.', 'beautyhub-core' ) ), 400 );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$_FILES['bhc_image'] = $files['file'];
		$att = media_handle_upload( 'bhc_image', $id );
		if ( is_wp_error( $att ) ) {
			return self::err( $att );
		}
		set_post_thumbnail( $id, $att );
		return self::item( $id );
	}
}
