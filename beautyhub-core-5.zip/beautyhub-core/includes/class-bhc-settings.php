<?php
/**
 * Impostazioni del centro.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Settings {

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_filter(
			'option_page_capability_bhc_settings_group',
			function () {
				return 'manage_options';
			}
		);
	}

	public static function defaults() {
		return array(
			'center_name'     => get_bloginfo( 'name' ),
			'center_email'    => get_option( 'admin_email' ),
			'center_phone'    => '',
			'hours_1'         => '',
			'hours_2'         => '09:00-19:00',
			'hours_3'         => '09:00-19:00',
			'hours_4'         => '09:00-19:00',
			'hours_5'         => '09:00-19:00',
			'hours_6'         => '09:00-17:00',
			'hours_7'         => '',
			'closures'        => '',
			'slot_step'       => 15,
			'lead_hours'      => 2,
			'max_days'        => 60,
			'cancel_hours'    => 24,
			'auto_confirm'    => 0,
			'reminder_hours'  => 24,
			'notify_staff'    => 1,
			'privacy_url'     => get_privacy_policy_url(),
			'booking_note'    => __( 'Riceverai una email di conferma. Puoi annullare o spostare l\'appuntamento fino a 24 ore prima.', 'beautyhub-core' ),
		);
	}

	public static function register() {
		register_setting(
			'bhc_settings_group',
			'bhc_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);
	}

	public static function sanitize( $input ) {
		$input = is_array( $input ) ? $input : array();
		$out   = array();
		foreach ( self::defaults() as $key => $default ) {
			$val = $input[ $key ] ?? '';
			if ( is_int( $default ) ) {
				$out[ $key ] = absint( $val );
			} elseif ( 'center_email' === $key ) {
				$out[ $key ] = sanitize_email( $val );
			} elseif ( 'privacy_url' === $key ) {
				$out[ $key ] = esc_url_raw( $val );
			} elseif ( in_array( $key, array( 'closures', 'booking_note' ), true ) ) {
				$out[ $key ] = sanitize_textarea_field( $val );
			} else {
				$out[ $key ] = sanitize_text_field( $val );
			}
		}
		$out['slot_step'] = in_array( $out['slot_step'], array( 5, 10, 15, 20, 30, 60 ), true ) ? $out['slot_step'] : 15;
		return $out;
	}

	/**
	 * Date di chiusura come array Y-m-d.
	 */
	public static function closures() {
		$out = array();
		foreach ( preg_split( '/[\s,;]+/', (string) bhc_get_option( 'closures', '' ) ) as $d ) {
			$d = trim( $d );
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) {
				$out[] = $d;
			} elseif ( preg_match( '#^(\d{1,2})/(\d{1,2})/(\d{4})$#', $d, $m ) ) {
				$out[] = sprintf( '%04d-%02d-%02d', $m[3], $m[2], $m[1] );
			}
		}
		return $out;
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o = wp_parse_args( get_option( 'bhc_settings', array() ), self::defaults() );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Impostazioni BeautyHub', 'beautyhub-core' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'bhc_settings_group' ); ?>
				<h2><?php esc_html_e( 'Dati del centro', 'beautyhub-core' ); ?></h2>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Nome centro', 'beautyhub-core' ); ?></th><td><input class="regular-text" name="bhc_settings[center_name]" value="<?php echo esc_attr( $o['center_name'] ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Email per notifiche', 'beautyhub-core' ); ?></th><td><input class="regular-text" type="email" name="bhc_settings[center_email]" value="<?php echo esc_attr( $o['center_email'] ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Telefono', 'beautyhub-core' ); ?></th><td><input class="regular-text" name="bhc_settings[center_phone]" value="<?php echo esc_attr( $o['center_phone'] ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Link informativa privacy', 'beautyhub-core' ); ?></th><td><input class="regular-text" type="url" name="bhc_settings[privacy_url]" value="<?php echo esc_attr( $o['privacy_url'] ); ?>"></td></tr>
				</table>

				<h2><?php esc_html_e( 'Orari di apertura', 'beautyhub-core' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Formato: 09:00-13:00, 14:00-19:00. Vuoto = chiuso.', 'beautyhub-core' ); ?></p>
				<table class="form-table">
					<?php foreach ( bhc_weekdays() as $n => $label ) : ?>
						<tr><th><?php echo esc_html( $label ); ?></th><td><input class="regular-text" name="bhc_settings[hours_<?php echo esc_attr( $n ); ?>]" value="<?php echo esc_attr( $o[ 'hours_' . $n ] ); ?>" placeholder="<?php esc_attr_e( 'chiuso', 'beautyhub-core' ); ?>"></td></tr>
					<?php endforeach; ?>
					<tr><th><?php esc_html_e( 'Giorni di chiusura', 'beautyhub-core' ); ?></th><td><textarea class="large-text" rows="3" name="bhc_settings[closures]" placeholder="25/12/2026, 26/12/2026, 2027-01-01"><?php echo esc_textarea( $o['closures'] ); ?></textarea></td></tr>
				</table>

				<h2><?php esc_html_e( 'Prenotazioni online', 'beautyhub-core' ); ?></h2>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Intervallo griglia (min)', 'beautyhub-core' ); ?></th><td>
						<select name="bhc_settings[slot_step]">
							<?php foreach ( array( 5, 10, 15, 20, 30, 60 ) as $s ) : ?>
								<option value="<?php echo esc_attr( $s ); ?>" <?php selected( (int) $o['slot_step'], $s ); ?>><?php echo esc_html( $s ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th><?php esc_html_e( 'Preavviso minimo (ore)', 'beautyhub-core' ); ?></th><td><input type="number" min="0" name="bhc_settings[lead_hours]" value="<?php echo esc_attr( $o['lead_hours'] ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Prenotabile fino a (giorni)', 'beautyhub-core' ); ?></th><td><input type="number" min="1" name="bhc_settings[max_days]" value="<?php echo esc_attr( $o['max_days'] ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Annullamento gratuito fino a (ore prima)', 'beautyhub-core' ); ?></th><td><input type="number" min="0" name="bhc_settings[cancel_hours]" value="<?php echo esc_attr( $o['cancel_hours'] ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Conferma automatica', 'beautyhub-core' ); ?></th><td><label><input type="checkbox" name="bhc_settings[auto_confirm]" value="1" <?php checked( (int) $o['auto_confirm'], 1 ); ?>> <?php esc_html_e( 'Le prenotazioni online sono subito confermate', 'beautyhub-core' ); ?></label></td></tr>
					<tr><th><?php esc_html_e( 'Nota mostrata nel form', 'beautyhub-core' ); ?></th><td><textarea class="large-text" rows="2" name="bhc_settings[booking_note]"><?php echo esc_textarea( $o['booking_note'] ); ?></textarea></td></tr>
				</table>

				<h2><?php esc_html_e( 'Notifiche', 'beautyhub-core' ); ?></h2>
				<table class="form-table">
					<tr><th><?php esc_html_e( 'Promemoria email (ore prima)', 'beautyhub-core' ); ?></th><td><input type="number" min="0" name="bhc_settings[reminder_hours]" value="<?php echo esc_attr( $o['reminder_hours'] ); ?>"> <span class="description"><?php esc_html_e( '0 = disattivato', 'beautyhub-core' ); ?></span></td></tr>
					<tr><th><?php esc_html_e( 'Avvisa il centro', 'beautyhub-core' ); ?></th><td><label><input type="checkbox" name="bhc_settings[notify_staff]" value="1" <?php checked( (int) $o['notify_staff'], 1 ); ?>> <?php esc_html_e( 'Email al centro per ogni prenotazione o annullamento online', 'beautyhub-core' ); ?></label></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
