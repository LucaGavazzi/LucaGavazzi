<?php
/**
 * Widget Elementor (categoria "BeautyHub").
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base comune: ogni widget rende uno shortcode con i parametri scelti.
 */
abstract class BHC_Elementor_Widget extends \Elementor\Widget_Base {

	public function get_categories() {
		return array( 'beautyhub' );
	}

	public function get_style_depends() {
		return array( 'bhc' );
	}

	protected function treatment_options() {
		$out = array( '' => __( '— nessuno —', 'beautyhub-core' ) );
		foreach ( bhc_get_treatments() as $t ) {
			$out[ $t['id'] ] = $t['name'];
		}
		return $out;
	}

	protected function staff_options() {
		$out = array( '' => __( 'Tutte', 'beautyhub-core' ) );
		foreach ( bhc_get_staff() as $s ) {
			$out[ $s['id'] ] = $s['name'];
		}
		return $out;
	}

	protected function category_options() {
		$out   = array( '' => __( 'Tutte', 'beautyhub-core' ) );
		$terms = get_terms( array( 'taxonomy' => 'bh_treatment_cat', 'hide_empty' => false ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[ $t->slug ] = $t->name;
			}
		}
		return $out;
	}

	protected function color_controls( $selector_prefix = '{{WRAPPER}} .bhc' ) {
		$this->start_controls_section( 'style', array( 'label' => __( 'Colori', 'beautyhub-core' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'c_primary', array( 'label' => __( 'Colore principale', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( $selector_prefix => '--c-primary: {{VALUE}}; --c-primary-dark: {{VALUE}};' ) ) );
		$this->add_control( 'c_accent', array( 'label' => __( 'Colore accento', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( $selector_prefix => '--c-accent: {{VALUE}};' ) ) );
		$this->add_control( 'c_text', array( 'label' => __( 'Colore testo', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( $selector_prefix => '--c-text: {{VALUE}};' ) ) );
		$this->add_control( 'c_card', array( 'label' => __( 'Sfondo schede', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( $selector_prefix => '--c-card: {{VALUE}};' ) ) );
		$this->end_controls_section();
	}
}

class BHC_Widget_Booking extends BHC_Elementor_Widget {
	public function get_name() {
		return 'bhc_booking';
	}
	public function get_title() {
		return __( 'Prenotazione online', 'beautyhub-core' );
	}
	public function get_icon() {
		return 'eicon-calendar';
	}
	public function get_script_depends() {
		return array( 'bhc-booking' );
	}
	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => __( 'Impostazioni', 'beautyhub-core' ) ) );
		$this->add_control( 'title', array( 'label' => __( 'Titolo', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __( 'Prenota il tuo trattamento', 'beautyhub-core' ) ) );
		$this->add_control( 'treatment', array( 'label' => __( 'Trattamento preselezionato', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::SELECT, 'options' => $this->treatment_options(), 'default' => '' ) );
		$this->add_control( 'staff', array( 'label' => __( 'Solo in cabina', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::SELECT, 'options' => $this->staff_options(), 'default' => '' ) );
		$this->end_controls_section();
		$this->color_controls();
	}
	protected function render() {
		$s = $this->get_settings_for_display();
		echo do_shortcode( sprintf( '[bh_booking title="%s" treatment="%d" staff="%d"]', esc_attr( $s['title'] ), absint( $s['treatment'] ), absint( $s['staff'] ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

class BHC_Widget_Treatments extends BHC_Elementor_Widget {
	public function get_name() {
		return 'bhc_treatments';
	}
	public function get_title() {
		return __( 'Listino trattamenti', 'beautyhub-core' );
	}
	public function get_icon() {
		return 'eicon-price-list';
	}
	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => __( 'Impostazioni', 'beautyhub-core' ) ) );
		$this->add_control( 'category', array( 'label' => __( 'Categoria', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::SELECT, 'options' => $this->category_options(), 'default' => '' ) );
		$this->add_control(
			'layout',
			array(
				'label'   => __( 'Layout', 'beautyhub-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( 'list' => __( 'Listino', 'beautyhub-core' ), 'cards' => __( 'Schede con foto', 'beautyhub-core' ) ),
				'default' => 'list',
			)
		);
		$this->add_control( 'price', array( 'label' => __( 'Mostra prezzi', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->add_control( 'book', array( 'label' => __( 'Link "Prenota"', 'beautyhub-core' ), 'type' => \Elementor\Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->end_controls_section();
		$this->color_controls();
	}
	protected function render() {
		$s = $this->get_settings_for_display();
		echo do_shortcode( sprintf( '[bh_treatments category="%s" layout="%s" price="%s" book="%s"]', esc_attr( $s['category'] ), esc_attr( $s['layout'] ), 'yes' === $s['price'] ? 'yes' : 'no', 'yes' === $s['book'] ? 'yes' : 'no' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

class BHC_Widget_Team extends BHC_Elementor_Widget {
	public function get_name() {
		return 'bhc_cabins';
	}
	public function get_title() {
		return __( 'Cabine e trattamenti', 'beautyhub-core' );
	}
	public function get_icon() {
		return 'eicon-door';
	}
	protected function register_controls() {
		$this->color_controls();
	}
	protected function render() {
		echo do_shortcode( '[bh_cabins]' ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

class BHC_Widget_Client_Area extends BHC_Elementor_Widget {
	public function get_name() {
		return 'bhc_client_area';
	}
	public function get_title() {
		return __( 'Area clienti', 'beautyhub-core' );
	}
	public function get_icon() {
		return 'eicon-lock-user';
	}
	protected function register_controls() {
		$this->color_controls();
	}
	protected function render() {
		echo do_shortcode( '[bh_client_area]' ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

class BHC_Widget_Dashboard extends BHC_Elementor_Widget {
	public function get_name() {
		return 'bhc_dashboard';
	}
	public function get_title() {
		return __( 'Gestionale staff', 'beautyhub-core' );
	}
	public function get_icon() {
		return 'eicon-dashboard';
	}
	public function get_script_depends() {
		return array( 'bhc-dashboard' );
	}
	protected function register_controls() {
		$this->start_controls_section( 'content', array( 'label' => __( 'Info', 'beautyhub-core' ) ) );
		$this->add_control(
			'note',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => esc_html__( 'Mostra agenda, clienti e report allo staff che ha effettuato l\'accesso. Consigliato il modello di pagina "BeautyHub – Gestionale".', 'beautyhub-core' ),
			)
		);
		$this->end_controls_section();
	}
	protected function render() {
		if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			echo '<div class="bhc"><div class="bhc-box">' . esc_html__( 'Qui verrà mostrato il gestionale dello staff.', 'beautyhub-core' ) . '</div></div>';
			return;
		}
		echo do_shortcode( '[bh_dashboard]' ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

class BHC_Elementor {
	public static function register( $widgets_manager ) {
		$widgets_manager->register( new BHC_Widget_Booking() );
		$widgets_manager->register( new BHC_Widget_Treatments() );
		$widgets_manager->register( new BHC_Widget_Team() );
		$widgets_manager->register( new BHC_Widget_Client_Area() );
		$widgets_manager->register( new BHC_Widget_Dashboard() );
	}
}
