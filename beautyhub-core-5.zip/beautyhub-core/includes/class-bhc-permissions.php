<?php
/**
 * Permessi configurabili per ruolo.
 *
 * Ogni funzione del gestionale corrisponde a una capability WordPress "bh_p_<chiave>".
 * L'amministratore del sito ha sempre tutti i permessi e lui solo può modificarli
 * (Impostazioni › Ruoli e permessi).
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Permissions {

	const OPTION = 'bhc_role_perms';

	/** Ruoli configurabili, in ordine di visualizzazione. */
	public static function roles() {
		return array(
			'bh_owner'     => __( 'Titolare', 'beautyhub-core' ),
			'bh_manager'   => __( 'Manager', 'beautyhub-core' ),
			'bh_reception' => __( 'Receptionist', 'beautyhub-core' ),
			'bh_operator'  => __( 'Operatrice', 'beautyhub-core' ),
		);
	}

	/** Elenco permessi: chiave => [gruppo, etichetta, descrizione]. */
	public static function all() {
		return array(
			'agenda_view'    => array( __( 'Agenda', 'beautyhub-core' ), __( 'Vedere l\'agenda', 'beautyhub-core' ), __( 'Accesso al gestionale e all\'agenda di tutte le cabine.', 'beautyhub-core' ) ),
			'agenda_edit'    => array( __( 'Agenda', 'beautyhub-core' ), __( 'Creare e modificare appuntamenti', 'beautyhub-core' ), __( 'Nuovi appuntamenti, spostamenti, conferme e annullamenti.', 'beautyhub-core' ) ),
			'agenda_status'  => array( __( 'Agenda', 'beautyhub-core' ), __( 'Segnare arrivo e trattamento completato', 'beautyhub-core' ), __( 'Per chi lavora in cabina ma non gestisce le prenotazioni.', 'beautyhub-core' ) ),
			'appt_delete'    => array( __( 'Agenda', 'beautyhub-core' ), __( 'Eliminare appuntamenti', 'beautyhub-core' ), __( 'Cancellazione definitiva (di norma basta "Annullato").', 'beautyhub-core' ) ),
			'payments'       => array( __( 'Agenda', 'beautyhub-core' ), __( 'Registrare incassi', 'beautyhub-core' ), __( 'Incasso degli appuntamenti e totale incassato del giorno.', 'beautyhub-core' ) ),
			'clients_view'   => array( __( 'Clienti', 'beautyhub-core' ), __( 'Vedere le clienti', 'beautyhub-core' ), __( 'Elenco e schede cliente con lo storico.', 'beautyhub-core' ) ),
			'clients_edit'   => array( __( 'Clienti', 'beautyhub-core' ), __( 'Inserire e modificare le clienti', 'beautyhub-core' ), __( 'Anagrafica, contatti, consensi.', 'beautyhub-core' ) ),
			'clients_notes'  => array( __( 'Clienti', 'beautyhub-core' ), __( 'Aggiornare note e scheda estetica', 'beautyhub-core' ), __( 'Tipo di pelle, fototipo e note, senza toccare l\'anagrafica.', 'beautyhub-core' ) ),
			'health'         => array( __( 'Clienti', 'beautyhub-core' ), __( 'Vedere e modificare l\'anamnesi', 'beautyhub-core' ), __( 'Dati sanitari: allergie, controindicazioni. Da dare solo a chi esegue i trattamenti.', 'beautyhub-core' ) ),
			'clients_delete' => array( __( 'Clienti', 'beautyhub-core' ), __( 'Eliminare le clienti', 'beautyhub-core' ), '' ),
			'cabins'         => array( __( 'Centro', 'beautyhub-core' ), __( 'Gestire le cabine', 'beautyhub-core' ), __( 'Creare, modificare ed eliminare cabine.', 'beautyhub-core' ) ),
			'treatments'     => array( __( 'Centro', 'beautyhub-core' ), __( 'Gestire trattamenti e categorie', 'beautyhub-core' ), __( 'Listino, prezzi, durate, operatrici e cabine abilitate.', 'beautyhub-core' ) ),
			'people'         => array( __( 'Centro', 'beautyhub-core' ), __( 'Gestire il personale', 'beautyhub-core' ), __( 'Schede Operatrici con dati personali, contratti e accessi.', 'beautyhub-core' ) ),
			'reports'        => array( __( 'Centro', 'beautyhub-core' ), __( 'Vedere i report', 'beautyhub-core' ), __( 'Incassi, occupazione cabine, trattamenti più richiesti.', 'beautyhub-core' ) ),
			'timeclock'      => array( __( 'Centro', 'beautyhub-core' ), __( 'Orari e presenze', 'beautyhub-core' ), __( 'Orari, ferie e permessi, timbrature, anomalie e cartellino del personale, PIN della timbratrice.', 'beautyhub-core' ) ),
			'messages'       => array( __( 'Centro', 'beautyhub-core' ), __( 'Messaggi e promemoria', 'beautyhub-core' ), __( 'Promemoria WhatsApp alle clienti, testo del promemoria, messaggio e buono sconto dello scontrino.', 'beautyhub-core' ) ),
			'pos'            => array( __( 'Centro', 'beautyhub-core' ), __( 'Usare la cassa', 'beautyhub-core' ), __( 'Incassare trattamenti, vendere prodotti e card, scalare sedute, gift card e punti dalla cassa; chiusura giornaliera.', 'beautyhub-core' ) ),
			'cards'          => array( __( 'Centro', 'beautyhub-core' ), __( 'Gestire le card', 'beautyhub-core' ), __( 'Emettere e ricaricare gift card, carte fedeltà e carte trattamenti; listino pacchetti. Chi registra gli incassi può comunque scalarle sugli appuntamenti.', 'beautyhub-core' ) ),
			'products'       => array( __( 'Magazzino', 'beautyhub-core' ), __( 'Prodotti e magazzino', 'beautyhub-core' ), __( 'Schede prodotto, giacenze, movimenti, lista riordino.', 'beautyhub-core' ) ),
			'suppliers'      => array( __( 'Magazzino', 'beautyhub-core' ), __( 'Fornitori', 'beautyhub-core' ), __( 'Anagrafiche e condizioni dei fornitori.', 'beautyhub-core' ) ),
			'invoices'       => array( __( 'Magazzino', 'beautyhub-core' ), __( 'Fatture fornitori', 'beautyhub-core' ), __( 'Registrazione fatture, pagamenti e carico a magazzino.', 'beautyhub-core' ) ),
		);
	}

	public static function defaults() {
		$all = array_keys( self::all() );
		return array(
			'bh_owner'     => $all,
			'bh_manager'   => $all,
			'bh_reception' => array( 'agenda_view', 'agenda_edit', 'agenda_status', 'payments', 'clients_view', 'clients_edit', 'clients_notes', 'cards', 'pos', 'messages' ),
			'bh_operator'  => array( 'agenda_view', 'agenda_status', 'clients_view', 'clients_notes', 'health' ),
		);
	}

	/** Permessi salvati (con i predefiniti per i ruoli mai configurati). */
	public static function get() {
		$saved = get_option( self::OPTION, array() );
		$out   = array();
		$keys  = array_keys( self::all() );
		foreach ( self::defaults() as $role => $def ) {
			$out[ $role ] = isset( $saved[ $role ] ) && is_array( $saved[ $role ] ) ? array_values( array_intersect( $saved[ $role ], $keys ) ) : $def;
		}
		return $out;
	}

	/**
	 * Salva e applica i permessi ai ruoli WordPress.
	 */
	public static function save( array $input ) {
		$keys  = array_keys( self::all() );
		$clean = array();
		foreach ( array_keys( self::roles() ) as $role ) {
			$list           = isset( $input[ $role ] ) && is_array( $input[ $role ] ) ? $input[ $role ] : array();
			$list           = array_values( array_unique( array_intersect( array_map( 'sanitize_key', $list ), $keys ) ) );
			// Chi modifica l'agenda deve poterla vedere; idem per le clienti.
			if ( array_intersect( $list, array( 'agenda_edit', 'agenda_status', 'appt_delete', 'payments' ) ) && ! in_array( 'agenda_view', $list, true ) ) {
				$list[] = 'agenda_view';
			}
			if ( array_intersect( $list, array( 'clients_edit', 'clients_notes', 'clients_delete', 'health' ) ) && ! in_array( 'clients_view', $list, true ) ) {
				$list[] = 'clients_view';
			}
			$clean[ $role ] = $list;
		}
		update_option( self::OPTION, $clean, false );
		self::apply();
		return self::get();
	}

	/** Allinea le capability dei ruoli all'opzione salvata. */
	public static function apply() {
		$perms = self::get();
		foreach ( array_keys( self::all() ) as $key ) {
			$cap   = 'bh_p_' . $key;
			$admin = get_role( 'administrator' );
			if ( $admin ) {
				$admin->add_cap( $cap );
			}
			foreach ( $perms as $role_name => $list ) {
				$role = get_role( $role_name );
				if ( ! $role ) {
					continue;
				}
				if ( in_array( $key, $list, true ) ) {
					$role->add_cap( $cap );
				} else {
					$role->remove_cap( $cap );
				}
			}
		}
	}

	/* ------------------------------------------------------------------
	 * Controlli
	 * ---------------------------------------------------------------- */

	/** L'utente corrente ha il permesso? (l'amministratore sempre). */
	public static function can( $perm, $user = null ) {
		if ( $user instanceof WP_User ) {
			return $user->has_cap( 'manage_options' ) || $user->has_cap( 'bh_p_' . $perm );
		}
		return current_user_can( 'manage_options' ) || current_user_can( 'bh_p_' . $perm );
	}

	/** Almeno uno dei permessi indicati. */
	public static function any( array $perms, $user = null ) {
		foreach ( $perms as $p ) {
			if ( self::can( $p, $user ) ) {
				return true;
			}
		}
		return false;
	}

	/** Fa parte dello staff (ha almeno un permesso del gestionale). */
	public static function is_staff( $user = null ) {
		return self::any( array_keys( self::all() ), $user );
	}

	/** Callback per register_rest_route. */
	public static function cb( $perms ) {
		$perms = (array) $perms;
		return function () use ( $perms ) {
			return BHC_Permissions::any( $perms );
		};
	}

	/** Mappa dei permessi dell'utente corrente (per il gestionale). */
	public static function current_map() {
		$out = array();
		foreach ( array_keys( self::all() ) as $k ) {
			$out[ $k ] = self::can( $k );
		}
		return $out;
	}

	/* ------------------------------------------------------------------
	 * Impostazioni (solo amministratore)
	 * ---------------------------------------------------------------- */

	public static function is_admin() {
		return current_user_can( 'manage_options' );
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		$ns = BHC_REST::NS;
		register_rest_route(
			$ns,
			'/settings',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_get' ), 'permission_callback' => array( __CLASS__, 'is_admin' ) ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_save' ), 'permission_callback' => array( __CLASS__, 'is_admin' ) ),
			)
		);
	}

	public static function rest_get() {
		$groups = array();
		foreach ( self::all() as $k => $p ) {
			$groups[ $p[0] ][] = array( 'key' => $k, 'label' => $p[1], 'desc' => $p[2] );
		}
		$users = array();
		foreach ( array_keys( self::roles() ) as $role ) {
			$users[ $role ] = count( get_users( array( 'role' => $role, 'fields' => 'ID' ) ) );
		}
		return array(
			'settings'    => wp_parse_args( get_option( 'bhc_settings', array() ), BHC_Settings::defaults() ),
			'roles'       => self::roles(),
			'groups'      => $groups,
			'perms'       => self::get(),
			'defaults'    => self::defaults(),
			'users'       => $users,
			'weekdays'    => bhc_weekdays(),
		);
	}

	public static function rest_save( WP_REST_Request $r ) {
		if ( is_array( $r->get_param( 'settings' ) ) ) {
			$current = wp_parse_args( get_option( 'bhc_settings', array() ), BHC_Settings::defaults() );
			update_option( 'bhc_settings', BHC_Settings::sanitize( array_merge( $current, $r->get_param( 'settings' ) ) ) );
		}
		if ( is_array( $r->get_param( 'perms' ) ) ) {
			self::save( $r->get_param( 'perms' ) );
		}
		return self::rest_get();
	}
}

/** Scorciatoia. */
function bhc_can( $perm ) {
	return BHC_Permissions::can( $perm );
}
