<?php
/**
 * Famiglie e categorie dei prodotti, inventari (scheda di conta) e rettifiche.
 *
 * Gerarchia: Famiglia (es. Viso) › Categoria (es. Creme) › Prodotto.
 * Inventario: si crea una scheda con le giacenze teoriche dei prodotti scelti,
 * si inseriscono le quantità contate (anche con lettore barcode) e alla chiusura
 * le giacenze vengono allineate con movimenti di tipo "inventario".
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Stock {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/* ==================================================================
	 * Tabelle
	 * ================================================================ */

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c  = $wpdb->get_charset_collate();
		$fa = bhc_table( 'product_families' );
		$ca = bhc_table( 'product_categories' );
		$in = bhc_table( 'inventories' );
		$il = bhc_table( 'inventory_lines' );

		dbDelta(
			"CREATE TABLE {$fa} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(120) NOT NULL DEFAULT '',
			description text,
			color varchar(10) NOT NULL DEFAULT '#7d8c6f',
			position smallint(5) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY name (name)
			) {$c};"
		);
		dbDelta(
			"CREATE TABLE {$ca} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			family_id bigint(20) unsigned NOT NULL DEFAULT 0,
			name varchar(120) NOT NULL DEFAULT '',
			description text,
			position smallint(5) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY family_id (family_id)
			) {$c};"
		);
		dbDelta(
			"CREATE TABLE {$in} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			title varchar(190) NOT NULL DEFAULT '',
			date date NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'bozza',
			family_id bigint(20) unsigned NOT NULL DEFAULT 0,
			category_id bigint(20) unsigned NOT NULL DEFAULT 0,
			product_type varchar(20) NOT NULL DEFAULT '',
			location varchar(120) NOT NULL DEFAULT '',
			notes text,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			closed_by bigint(20) unsigned NOT NULL DEFAULT 0,
			closed_at datetime DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY date (date)
			) {$c};"
		);
		dbDelta(
			"CREATE TABLE {$il} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			inventory_id bigint(20) unsigned NOT NULL DEFAULT 0,
			product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			expected decimal(10,2) NOT NULL DEFAULT 0,
			counted decimal(10,2) DEFAULT NULL,
			stock_at_close decimal(10,2) DEFAULT NULL,
			cost_price decimal(10,2) NOT NULL DEFAULT 0,
			note varchar(255) NOT NULL DEFAULT '',
			counted_by bigint(20) unsigned NOT NULL DEFAULT 0,
			counted_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY inventory_id (inventory_id),
			KEY product_id (product_id)
			) {$c};"
		);
	}

	/**
	 * Converte le vecchie categorie di testo dei prodotti nella nuova struttura.
	 */
	public static function migrate_text_categories() {
		global $wpdb;
		$pr   = bhc_table( 'products' );
		$rows = $wpdb->get_results( "SELECT id, category FROM {$pr} WHERE category <> '' AND category_id = 0", ARRAY_A ); // phpcs:ignore
		if ( ! $rows ) {
			return;
		}
		$family = self::find_or_create_family( __( 'Generale', 'beautyhub-core' ) );
		foreach ( $rows as $r ) {
			$cat = self::find_or_create_category( $family, $r['category'] );
			$wpdb->update( $pr, array( 'family_id' => $family, 'category_id' => $cat ), array( 'id' => (int) $r['id'] ) );
		}
	}

	private static function find_or_create_family( $name ) {
		global $wpdb;
		$t  = bhc_table( 'product_families' );
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE name = %s", $name ) ); // phpcs:ignore
		if ( ! $id ) {
			$wpdb->insert( $t, array( 'name' => $name, 'position' => 99 ) );
			$id = (int) $wpdb->insert_id;
		}
		return $id;
	}

	private static function find_or_create_category( $family_id, $name ) {
		global $wpdb;
		$t  = bhc_table( 'product_categories' );
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE family_id = %d AND name = %s", $family_id, $name ) ); // phpcs:ignore
		if ( ! $id ) {
			$wpdb->insert( $t, array( 'family_id' => $family_id, 'name' => $name ) );
			$id = (int) $wpdb->insert_id;
		}
		return $id;
	}

	/* ==================================================================
	 * Famiglie e categorie
	 * ================================================================ */

	/** Albero completo con conteggi. */
	public static function tree() {
		global $wpdb;
		$fa = bhc_table( 'product_families' );
		$ca = bhc_table( 'product_categories' );
		$pr = bhc_table( 'products' );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$families = $wpdb->get_results( "SELECT * FROM {$fa} ORDER BY position, name", ARRAY_A );
		$cats     = $wpdb->get_results( "SELECT * FROM {$ca} ORDER BY position, name", ARRAY_A );
		$fcount   = $wpdb->get_results( "SELECT family_id, COUNT(*) n FROM {$pr} WHERE active = 1 GROUP BY family_id", OBJECT_K );
		$ccount   = $wpdb->get_results( "SELECT category_id, COUNT(*) n FROM {$pr} WHERE active = 1 GROUP BY category_id", OBJECT_K );
		// phpcs:enable
		$out = array();
		foreach ( $families as $f ) {
			$f['id']         = (int) $f['id'];
			$f['position']   = (int) $f['position'];
			$f['products']   = isset( $fcount[ $f['id'] ] ) ? (int) $fcount[ $f['id'] ]->n : 0;
			$f['categories'] = array();
			$out[ $f['id'] ] = $f;
		}
		foreach ( $cats as $c ) {
			$fid = (int) $c['family_id'];
			if ( ! isset( $out[ $fid ] ) ) {
				continue;
			}
			$out[ $fid ]['categories'][] = array(
				'id'          => (int) $c['id'],
				'family_id'   => $fid,
				'name'        => $c['name'],
				'description' => (string) $c['description'],
				'products'    => isset( $ccount[ $c['id'] ] ) ? (int) $ccount[ $c['id'] ]->n : 0,
			);
		}
		return array_values( $out );
	}

	/** Nomi di famiglia e categoria per id (cache per richiesta). */
	public static function names() {
		static $cache = null;
		if ( null === $cache ) {
			global $wpdb;
			$cache = array( 'f' => array(), 'c' => array() );
			foreach ( $wpdb->get_results( 'SELECT id, name FROM ' . bhc_table( 'product_families' ), ARRAY_A ) as $r ) { // phpcs:ignore
				$cache['f'][ (int) $r['id'] ] = $r['name'];
			}
			foreach ( $wpdb->get_results( 'SELECT id, name FROM ' . bhc_table( 'product_categories' ), ARRAY_A ) as $r ) { // phpcs:ignore
				$cache['c'][ (int) $r['id'] ] = $r['name'];
			}
		}
		return $cache;
	}

	/** Verifica la coppia famiglia/categoria; restituisce [famiglia, categoria]. */
	public static function normalize_pair( $family_id, $category_id ) {
		global $wpdb;
		$family_id   = absint( $family_id );
		$category_id = absint( $category_id );
		if ( $category_id ) {
			$fid = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT family_id FROM ' . bhc_table( 'product_categories' ) . ' WHERE id = %d', $category_id ) ); // phpcs:ignore
			if ( ! $fid ) {
				return array( $family_id, 0 );
			}
			return array( $fid, $category_id );
		}
		if ( $family_id && ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'product_families' ) . ' WHERE id = %d', $family_id ) ) ) { // phpcs:ignore
			$family_id = 0;
		}
		return array( $family_id, 0 );
	}

	/* ==================================================================
	 * Inventari
	 * ================================================================ */

	private static function inv_out( $row ) {
		global $wpdb;
		foreach ( array( 'id', 'family_id', 'category_id', 'created_by', 'closed_by' ) as $k ) {
			$row[ $k ] = (int) $row[ $k ];
		}
		$l     = bhc_table( 'inventory_lines' );
		$stats = $wpdb->get_row( // phpcs:ignore
			$wpdb->prepare(
				"SELECT COUNT(*) items, SUM(CASE WHEN counted IS NOT NULL THEN 1 ELSE 0 END) counted_items,
				SUM(CASE WHEN counted IS NOT NULL AND counted <> expected THEN 1 ELSE 0 END) diff_items,
				SUM(CASE WHEN counted IS NOT NULL THEN (counted - expected) * cost_price ELSE 0 END) diff_value,
				SUM(CASE WHEN counted IS NOT NULL THEN counted * cost_price ELSE 0 END) counted_value,
				SUM(expected * cost_price) expected_value
				FROM {$l} WHERE inventory_id = %d", // phpcs:ignore
				$row['id']
			),
			ARRAY_A
		);
		$row['items']          = (int) $stats['items'];
		$row['counted_items']  = (int) $stats['counted_items'];
		$row['diff_items']     = (int) $stats['diff_items'];
		$row['diff_value']     = round( (float) $stats['diff_value'], 2 );
		$row['counted_value']  = round( (float) $stats['counted_value'], 2 );
		$row['expected_value'] = round( (float) $stats['expected_value'], 2 );
		$names                 = self::names();
		$scope                 = array();
		if ( $row['family_id'] ) {
			$scope[] = $names['f'][ $row['family_id'] ] ?? '';
		}
		if ( $row['category_id'] ) {
			$scope[] = $names['c'][ $row['category_id'] ] ?? '';
		}
		if ( $row['product_type'] ) {
			$scope[] = 'consumo' === $row['product_type'] ? __( 'Consumo in cabina', 'beautyhub-core' ) : __( 'Rivendita', 'beautyhub-core' );
		}
		if ( $row['location'] ) {
			$scope[] = $row['location'];
		}
		$row['scope'] = $scope ? implode( ' › ', array_filter( $scope ) ) : __( 'Tutti i prodotti', 'beautyhub-core' );
		$u            = $row['created_by'] ? get_userdata( $row['created_by'] ) : null;
		$row['author'] = $u ? $u->display_name : '';
		return $row;
	}

	public static function list_inventories() {
		global $wpdb;
		$t = bhc_table( 'inventories' );
		return array_map( array( __CLASS__, 'inv_out' ), $wpdb->get_results( "SELECT * FROM {$t} ORDER BY date DESC, id DESC LIMIT 200", ARRAY_A ) ); // phpcs:ignore
	}

	public static function get_inventory( $id ) {
		global $wpdb;
		$t   = bhc_table( 'inventories' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $row ) {
			return null;
		}
		$row   = self::inv_out( $row );
		$l     = bhc_table( 'inventory_lines' );
		$p     = bhc_table( 'products' );
		$lines = $wpdb->get_results( // phpcs:ignore
			$wpdb->prepare(
				"SELECT l.*, p.name, p.ean, p.sku, p.unit, p.location, p.family_id, p.category_id, p.stock AS current_stock, p.type
				FROM {$l} l LEFT JOIN {$p} p ON p.id = l.product_id WHERE l.inventory_id = %d ORDER BY p.name", // phpcs:ignore
				$id
			),
			ARRAY_A
		);
		$names     = self::names();
		$row['zones']     = BHC_Zones::zones( $id );
		$row['has_zones'] = (bool) $row['zones'];
		$by_zone          = $row['has_zones'] ? BHC_Zones::breakdown( $id ) : array();
		foreach ( $lines as &$ln ) {
			foreach ( array( 'id', 'product_id', 'family_id', 'category_id' ) as $k ) {
				$ln[ $k ] = (int) $ln[ $k ];
			}
			foreach ( array( 'expected', 'cost_price', 'current_stock' ) as $k ) {
				$ln[ $k ] = (float) $ln[ $k ];
			}
			$ln['counted']        = null === $ln['counted'] ? null : (float) $ln['counted'];
			$ln['stock_at_close'] = null === $ln['stock_at_close'] ? null : (float) $ln['stock_at_close'];
			$ln['family']         = $names['f'][ $ln['family_id'] ] ?? '';
			$ln['category']       = $names['c'][ $ln['category_id'] ] ?? '';
			// Movimenti avvenuti dopo la creazione della scheda (vendite, carichi…).
			$ln['moved_since'] = 'bozza' === $row['status'] ? round( $ln['current_stock'] - $ln['expected'], 2 ) : 0;
			$ln['by_zone']     = isset( $by_zone[ $ln['product_id'] ] ) ? $by_zone[ $ln['product_id'] ] : new stdClass();
		}
		$row['lines'] = $lines;
		return $row;
	}

	/**
	 * Crea la scheda inventario fotografando le giacenze dei prodotti nel perimetro scelto.
	 */
	public static function create_inventory( array $d ) {
		global $wpdb;
		list( $fid, $cid ) = self::normalize_pair( $d['family_id'] ?? 0, $d['category_id'] ?? 0 );
		$type              = in_array( $d['product_type'] ?? '', array( 'rivendita', 'consumo' ), true ) ? $d['product_type'] : '';
		$location          = sanitize_text_field( $d['location'] ?? '' );
		$date              = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d['date'] ?? '' ) ? $d['date'] : current_time( 'Y-m-d' );
		$title             = sanitize_text_field( $d['title'] ?? '' );
		if ( '' === $title ) {
			/* translators: %s: data */
			$title = sprintf( __( 'Inventario del %s', 'beautyhub-core' ), date_i18n( 'd/m/Y', strtotime( $date ) ) );
		}

		$p     = bhc_table( 'products' );
		$where = array( 'active = 1' );
		$args  = array();
		if ( $cid ) {
			$where[] = 'category_id = %d';
			$args[]  = $cid;
		} elseif ( $fid ) {
			$where[] = 'family_id = %d';
			$args[]  = $fid;
		}
		if ( $type ) {
			$where[] = 'type = %s';
			$args[]  = $type;
		}
		if ( $location ) {
			$where[] = 'location = %s';
			$args[]  = $location;
		}
		$sql      = "SELECT id, stock, cost_price FROM {$p} WHERE " . implode( ' AND ', $where );
		$products = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		if ( ! $products ) {
			return new WP_Error( 'empty', __( 'Nessun prodotto attivo corrisponde ai filtri scelti.', 'beautyhub-core' ) );
		}
		$open = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . bhc_table( 'inventories' ) . " WHERE status = 'bozza'" ); // phpcs:ignore

		$now = current_time( 'mysql' );
		$wpdb->insert(
			bhc_table( 'inventories' ),
			array(
				'title'        => $title,
				'date'         => $date,
				'status'       => 'bozza',
				'family_id'    => $fid,
				'category_id'  => $cid,
				'product_type' => $type,
				'location'     => $location,
				'notes'        => sanitize_textarea_field( $d['notes'] ?? '' ),
				'created_by'   => get_current_user_id(),
				'created_at'   => $now,
				'updated_at'   => $now,
			)
		);
		$id = (int) $wpdb->insert_id;
		foreach ( $products as $pr ) {
			$wpdb->insert(
				bhc_table( 'inventory_lines' ),
				array(
					'inventory_id' => $id,
					'product_id'   => (int) $pr['id'],
					'expected'     => (float) $pr['stock'],
					'cost_price'   => (float) $pr['cost_price'],
				)
			);
		}
		BHC_Zones::create_for( $id, (int) ( $d['zones'] ?? 0 ), isset( $d['zone_names'] ) && is_array( $d['zone_names'] ) ? $d['zone_names'] : array() );
		return array( 'id' => $id, 'other_open' => $open );
	}

	/**
	 * Salva le quantità contate (solo righe inviate). counted = null per "non contato".
	 */
	public static function save_counts( $id, array $lines ) {
		global $wpdb;
		$inv = self::get_inventory( $id );
		if ( ! $inv ) {
			return new WP_Error( 'not_found', __( 'Inventario non trovato.', 'beautyhub-core' ) );
		}
		if ( 'bozza' !== $inv['status'] ) {
			return new WP_Error( 'closed', __( 'L\'inventario è chiuso e non si può più modificare.', 'beautyhub-core' ) );
		}
		$t         = bhc_table( 'inventory_lines' );
		$has_zones = BHC_Zones::has_zones( $id );
		foreach ( $lines as $l ) {
			$pid = absint( $l['product_id'] ?? 0 );
			if ( ! $pid ) {
				continue;
			}
			if ( $has_zones ) {
				// Con le zone la quantità è la somma delle letture: qui si salva solo la nota.
				$wpdb->update( $t, array( 'note' => sanitize_text_field( $l['note'] ?? '' ) ), array( 'inventory_id' => (int) $id, 'product_id' => $pid ) );
				continue;
			}
			$exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE inventory_id = %d AND product_id = %d", $id, $pid ) ); // phpcs:ignore
			$counted = ( ! isset( $l['counted'] ) || '' === $l['counted'] || null === $l['counted'] ) ? null : max( 0, round( (float) str_replace( ',', '.', (string) $l['counted'] ), 2 ) );
			$data    = array(
				'counted'    => $counted,
				'note'       => sanitize_text_field( $l['note'] ?? '' ),
				'counted_by' => get_current_user_id(),
				'counted_at' => null === $counted ? null : current_time( 'mysql' ),
			);
			if ( $exists ) {
				$wpdb->update( $t, $data, array( 'id' => $exists ) );
			} else {
				// Prodotto trovato durante la conta ma fuori dalla scheda: lo aggiunge.
				$p = BHC_Inventory::get_product( $pid );
				if ( $p ) {
					$wpdb->insert( $t, $data + array( 'inventory_id' => $id, 'product_id' => $pid, 'expected' => $p['stock'], 'cost_price' => $p['cost_price'] ) );
				}
			}
		}
		$wpdb->update( bhc_table( 'inventories' ), array( 'updated_at' => current_time( 'mysql' ) ), array( 'id' => (int) $id ) );
		return true;
	}

	/**
	 * Chiude l'inventario: per ogni prodotto contato porta la giacenza al valore contato
	 * (tenendo conto dei movimenti avvenuti nel frattempo, se richiesto).
	 *
	 * @param string $uncounted  keep = lascia invariati i non contati | zero = azzera i non contati.
	 * @param bool   $keep_moves true = somma i movimenti avvenuti dopo la creazione della scheda.
	 */
	public static function close_inventory( $id, $uncounted = 'keep', $keep_moves = true ) {
		global $wpdb;
		$inv = self::get_inventory( $id );
		if ( ! $inv ) {
			return new WP_Error( 'not_found', __( 'Inventario non trovato.', 'beautyhub-core' ) );
		}
		if ( 'bozza' !== $inv['status'] ) {
			return new WP_Error( 'closed', __( 'L\'inventario è già chiuso.', 'beautyhub-core' ) );
		}
		if ( ! $inv['counted_items'] && 'zero' !== $uncounted ) {
			return new WP_Error( 'nothing', __( 'Non è stata contata nessuna quantità.', 'beautyhub-core' ) );
		}
		$t     = bhc_table( 'inventory_lines' );
		/* translators: %d: numero inventario */
		$label = sprintf( __( 'Inventario n. %d', 'beautyhub-core' ), $id );
		foreach ( $inv['lines'] as $l ) {
			$counted = $l['counted'];
			if ( null === $counted ) {
				if ( 'zero' !== $uncounted ) {
					continue;
				}
				$counted = 0;
			}
			$target = $keep_moves ? $counted + $l['moved_since'] : $counted;
			$delta  = round( $target - $l['current_stock'], 2 );
			if ( abs( $delta ) > 0.0001 ) {
				BHC_Inventory::move( $l['product_id'], $delta, 'inventario', 0, $label . ( $l['note'] ? ' – ' . $l['note'] : '' ) );
			}
			$wpdb->update( $t, array( 'stock_at_close' => $l['current_stock'], 'counted' => $counted ), array( 'id' => $l['id'] ) );
		}
		$wpdb->update(
			bhc_table( 'inventories' ),
			array(
				'status'     => 'chiuso',
				'closed_by'  => get_current_user_id(),
				'closed_at'  => current_time( 'mysql' ),
				'updated_at' => current_time( 'mysql' ),
			),
			array( 'id' => (int) $id )
		);
		return self::get_inventory( $id );
	}

	/* ==================================================================
	 * REST
	 * ================================================================ */

	private static function err( WP_Error $e, $status = 400 ) {
		return new WP_REST_Response( array( 'code' => $e->get_error_code(), 'message' => $e->get_error_message() ), $status );
	}

	public static function routes() {
		$ns    = BHC_REST::NS;
		$read  = BHC_Permissions::cb( array( 'products', 'invoices' ) );
		$write = BHC_Permissions::cb( array( 'products' ) );
		$id    = '(?P<id>\d+)';

		register_rest_route( $ns, '/product-tree', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_tree' ), 'permission_callback' => $read ) );
		register_rest_route( $ns, '/product-families', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_save_family' ), 'permission_callback' => $write ) );
		register_rest_route(
			$ns,
			'/product-families/' . $id,
			array(
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_save_family' ), 'permission_callback' => $write ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete_family' ), 'permission_callback' => $write ),
			)
		);
		register_rest_route( $ns, '/product-categories', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_save_category' ), 'permission_callback' => $write ) );
		register_rest_route(
			$ns,
			'/product-categories/' . $id,
			array(
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_save_category' ), 'permission_callback' => $write ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete_category' ), 'permission_callback' => $write ),
			)
		);

		register_rest_route(
			$ns,
			'/inventories',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_list_inv' ), 'permission_callback' => $write ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_create_inv' ), 'permission_callback' => $write ),
			)
		);
		register_rest_route(
			$ns,
			'/inventories/' . $id,
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_get_inv' ), 'permission_callback' => $write ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_save_inv' ), 'permission_callback' => $write ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete_inv' ), 'permission_callback' => $write ),
			)
		);
		register_rest_route( $ns, '/inventories/' . $id . '/close', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_close_inv' ), 'permission_callback' => $write ) );
	}

	public static function rest_tree() {
		$locations = array();
		global $wpdb;
		foreach ( $wpdb->get_col( 'SELECT DISTINCT location FROM ' . bhc_table( 'products' ) . " WHERE location <> '' AND active = 1 ORDER BY location" ) as $l ) { // phpcs:ignore
			$locations[] = $l;
		}
		return array( 'families' => self::tree(), 'locations' => $locations );
	}

	public static function rest_save_family( WP_REST_Request $r ) {
		global $wpdb;
		$t    = bhc_table( 'product_families' );
		$id   = isset( $r['id'] ) ? (int) $r['id'] : 0;
		$name = trim( sanitize_text_field( (string) $r->get_param( 'name' ) ) );
		if ( '' === $name ) {
			return self::err( new WP_Error( 'name', __( 'Inserisci il nome della famiglia.', 'beautyhub-core' ) ) );
		}
		$dup = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE name = %s AND id <> %d", $name, $id ) ); // phpcs:ignore
		if ( $dup ) {
			return self::err( new WP_Error( 'dup', __( 'Esiste già una famiglia con questo nome.', 'beautyhub-core' ) ) );
		}
		$row = array(
			'name'        => $name,
			'description' => sanitize_textarea_field( (string) $r->get_param( 'description' ) ),
			'color'       => sanitize_hex_color( (string) $r->get_param( 'color' ) ) ?: '#7d8c6f',
		);
		if ( $id ) {
			$wpdb->update( $t, $row, array( 'id' => $id ) );
		} else {
			$row['position'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ); // phpcs:ignore
			$wpdb->insert( $t, $row );
		}
		return self::rest_tree();
	}

	public static function rest_delete_family( WP_REST_Request $r ) {
		global $wpdb;
		$id = (int) $r['id'];
		$n  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . bhc_table( 'products' ) . ' WHERE family_id = %d AND active = 1', $id ) ); // phpcs:ignore
		if ( $n ) {
			/* translators: %d: numero prodotti */
			return self::err( new WP_Error( 'not_empty', sprintf( _n( 'La famiglia contiene %d prodotto: spostalo prima di eliminarla.', 'La famiglia contiene %d prodotti: spostali prima di eliminarla.', $n, 'beautyhub-core' ), $n ) ), 409 );
		}
		$wpdb->delete( bhc_table( 'product_categories' ), array( 'family_id' => $id ) );
		$wpdb->delete( bhc_table( 'product_families' ), array( 'id' => $id ) );
		$wpdb->update( bhc_table( 'products' ), array( 'family_id' => 0, 'category_id' => 0 ), array( 'family_id' => $id ) );
		return self::rest_tree();
	}

	public static function rest_save_category( WP_REST_Request $r ) {
		global $wpdb;
		$t    = bhc_table( 'product_categories' );
		$id   = isset( $r['id'] ) ? (int) $r['id'] : 0;
		$fid  = absint( $r->get_param( 'family_id' ) );
		$name = trim( sanitize_text_field( (string) $r->get_param( 'name' ) ) );
		if ( '' === $name ) {
			return self::err( new WP_Error( 'name', __( 'Inserisci il nome della categoria.', 'beautyhub-core' ) ) );
		}
		if ( ! $fid || ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'product_families' ) . ' WHERE id = %d', $fid ) ) ) { // phpcs:ignore
			return self::err( new WP_Error( 'family', __( 'Scegli la famiglia della categoria.', 'beautyhub-core' ) ) );
		}
		$dup = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE family_id = %d AND name = %s AND id <> %d", $fid, $name, $id ) ); // phpcs:ignore
		if ( $dup ) {
			return self::err( new WP_Error( 'dup', __( 'Questa categoria esiste già nella famiglia.', 'beautyhub-core' ) ) );
		}
		$row = array( 'family_id' => $fid, 'name' => $name, 'description' => sanitize_textarea_field( (string) $r->get_param( 'description' ) ) );
		if ( $id ) {
			$wpdb->update( $t, $row, array( 'id' => $id ) );
			// I prodotti della categoria seguono la nuova famiglia.
			$wpdb->update( bhc_table( 'products' ), array( 'family_id' => $fid ), array( 'category_id' => $id ) );
		} else {
			$wpdb->insert( $t, $row );
		}
		return self::rest_tree();
	}

	public static function rest_delete_category( WP_REST_Request $r ) {
		global $wpdb;
		$id = (int) $r['id'];
		$n  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . bhc_table( 'products' ) . ' WHERE category_id = %d AND active = 1', $id ) ); // phpcs:ignore
		if ( $n ) {
			/* translators: %d: numero prodotti */
			return self::err( new WP_Error( 'not_empty', sprintf( _n( 'La categoria contiene %d prodotto: spostalo prima di eliminarla.', 'La categoria contiene %d prodotti: spostali prima di eliminarla.', $n, 'beautyhub-core' ), $n ) ), 409 );
		}
		$wpdb->delete( bhc_table( 'product_categories' ), array( 'id' => $id ) );
		$wpdb->update( bhc_table( 'products' ), array( 'category_id' => 0 ), array( 'category_id' => $id ) );
		return self::rest_tree();
	}

	public static function rest_list_inv() {
		return array( 'items' => self::list_inventories() );
	}

	public static function rest_get_inv( WP_REST_Request $r ) {
		$i = self::get_inventory( (int) $r['id'] );
		return $i ? $i : self::err( new WP_Error( 'not_found', __( 'Inventario non trovato.', 'beautyhub-core' ) ), 404 );
	}

	public static function rest_create_inv( WP_REST_Request $r ) {
		$res = self::create_inventory( (array) $r->get_json_params() );
		if ( is_wp_error( $res ) ) {
			return self::err( $res );
		}
		$inv               = self::get_inventory( $res['id'] );
		$inv['other_open'] = $res['other_open'];
		return $inv;
	}

	public static function rest_save_inv( WP_REST_Request $r ) {
		global $wpdb;
		$id = (int) $r['id'];
		if ( is_array( $r->get_param( 'lines' ) ) ) {
			$res = self::save_counts( $id, $r->get_param( 'lines' ) );
			if ( is_wp_error( $res ) ) {
				return self::err( $res );
			}
		}
		$upd = array();
		if ( null !== $r->get_param( 'title' ) ) {
			$upd['title'] = sanitize_text_field( (string) $r->get_param( 'title' ) );
		}
		if ( null !== $r->get_param( 'notes' ) ) {
			$upd['notes'] = sanitize_textarea_field( (string) $r->get_param( 'notes' ) );
		}
		if ( $upd ) {
			$wpdb->update( bhc_table( 'inventories' ), $upd, array( 'id' => $id, 'status' => 'bozza' ) );
		}
		return self::get_inventory( $id );
	}

	public static function rest_delete_inv( WP_REST_Request $r ) {
		global $wpdb;
		$inv = self::get_inventory( (int) $r['id'] );
		if ( ! $inv ) {
			return self::err( new WP_Error( 'not_found', __( 'Inventario non trovato.', 'beautyhub-core' ) ), 404 );
		}
		if ( 'bozza' !== $inv['status'] ) {
			return self::err( new WP_Error( 'closed', __( 'Un inventario chiuso non si può eliminare: le rettifiche sono già nei movimenti di magazzino.', 'beautyhub-core' ) ), 409 );
		}
		$wpdb->delete( bhc_table( 'inventory_lines' ), array( 'inventory_id' => $inv['id'] ) );
		$wpdb->delete( bhc_table( 'inventory_counts' ), array( 'inventory_id' => $inv['id'] ) );
		$wpdb->delete( bhc_table( 'inventory_zones' ), array( 'inventory_id' => $inv['id'] ) );
		$wpdb->delete( bhc_table( 'inventories' ), array( 'id' => $inv['id'] ) );
		return array( 'ok' => true );
	}

	public static function rest_close_inv( WP_REST_Request $r ) {
		$res = self::close_inventory( (int) $r['id'], 'zero' === $r->get_param( 'uncounted' ) ? 'zero' : 'keep', false !== $r->get_param( 'keep_moves' ) && '0' !== (string) $r->get_param( 'keep_moves' ) );
		return is_wp_error( $res ) ? self::err( $res ) : $res;
	}

	/* ==================================================================
	 * Dati di esempio
	 * ================================================================ */

	public static function import_demo() {
		global $wpdb;
		$fa = bhc_table( 'product_families' );
		$ca = bhc_table( 'product_categories' );
		$tree = array(
			array( 'Viso', '#7d8c6f', array( 'Creme', 'Sieri', 'Maschere' ) ),
			array( 'Corpo e massaggio', '#b9805f', array( 'Oli', 'Fanghi e scrub' ) ),
			array( 'Mani e piedi', '#8a7aa8', array( 'Smalti', 'Accessori' ) ),
		);
		$ids = array();
		foreach ( $tree as $i => $f ) {
			$wpdb->insert( $fa, array( 'name' => $f[0], 'color' => $f[1], 'position' => $i ) );
			$fid = (int) $wpdb->insert_id;
			foreach ( $f[2] as $c ) {
				$wpdb->insert( $ca, array( 'family_id' => $fid, 'name' => $c ) );
				$ids[ $c ] = array( $fid, (int) $wpdb->insert_id );
			}
		}
		$map = array( 'Crema viso' => 'Creme', 'Siero' => 'Sieri', 'Olio' => 'Oli', 'Smalto' => 'Smalti', 'Lima' => 'Accessori' );
		$p   = bhc_table( 'products' );
		foreach ( $wpdb->get_results( "SELECT id, name FROM {$p}", ARRAY_A ) as $row ) { // phpcs:ignore
			foreach ( $map as $prefix => $cat ) {
				if ( 0 === strpos( $row['name'], $prefix ) ) {
					$wpdb->update( $p, array( 'family_id' => $ids[ $cat ][0], 'category_id' => $ids[ $cat ][1] ), array( 'id' => (int) $row['id'] ) );
				}
			}
		}
	}
}
