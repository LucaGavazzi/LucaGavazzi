<?php
/**
 * Personale (modello PeopleHub): operatrici, receptionist, manager.
 * Scheda completa con anagrafica, contatti, contratto, documenti, corsi, orari
 * e accesso al gestionale. Visibile solo a titolare e manager.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_People {

	/** Campi testuali semplici della scheda. */
	const FIELDS = array(
		'first_name', 'last_name', 'gender', 'birth_date', 'birth_place', 'nationality', 'tax_code',
		'address', 'city', 'zip', 'province', 'phone', 'mobile', 'email',
		'emergency_name', 'emergency_phone',
		'role', 'job_title', 'status', 'contract_type', 'contract_level', 'hire_date', 'end_date', 'weekly_hours',
		'iban', 'color', 'notes',
	);

	/** Campi strutturati salvati come JSON. */
	const JSON_FIELDS = array( 'documents', 'courses', 'schedule', 'skills' );

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function roles() {
		return array(
			'operatrice' => __( 'Operatrice', 'beautyhub-core' ),
			'reception'  => __( 'Receptionist', 'beautyhub-core' ),
			'manager'    => __( 'Manager', 'beautyhub-core' ),
		);
	}

	public static function contract_types() {
		return array(
			'indeterminato' => __( 'Tempo indeterminato', 'beautyhub-core' ),
			'determinato'   => __( 'Tempo determinato', 'beautyhub-core' ),
			'apprendistato' => __( 'Apprendistato', 'beautyhub-core' ),
			'part_time'     => __( 'Part-time', 'beautyhub-core' ),
			'collaborazione' => __( 'Collaborazione', 'beautyhub-core' ),
			'partita_iva'   => __( 'Partita IVA', 'beautyhub-core' ),
			'tirocinio'     => __( 'Tirocinio / stage', 'beautyhub-core' ),
		);
	}

	/** Ruolo WordPress collegato a ciascun ruolo del personale. */
	public static function wp_role( $role ) {
		$map = array(
			'operatrice' => 'bh_operator',
			'reception'  => 'bh_reception',
			'manager'    => 'bh_manager',
		);
		return $map[ $role ] ?? 'bh_operator';
	}

	public static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = bhc_table( 'people' );
		dbDelta(
			"CREATE TABLE {$t} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			first_name varchar(100) NOT NULL DEFAULT '',
			last_name varchar(100) NOT NULL DEFAULT '',
			gender varchar(10) NOT NULL DEFAULT '',
			birth_date date DEFAULT NULL,
			birth_place varchar(120) NOT NULL DEFAULT '',
			nationality varchar(60) NOT NULL DEFAULT '',
			tax_code varchar(32) NOT NULL DEFAULT '',
			address varchar(255) NOT NULL DEFAULT '',
			city varchar(100) NOT NULL DEFAULT '',
			zip varchar(10) NOT NULL DEFAULT '',
			province varchar(4) NOT NULL DEFAULT '',
			phone varchar(40) NOT NULL DEFAULT '',
			mobile varchar(40) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			emergency_name varchar(120) NOT NULL DEFAULT '',
			emergency_phone varchar(40) NOT NULL DEFAULT '',
			role varchar(20) NOT NULL DEFAULT 'operatrice',
			job_title varchar(120) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'attivo',
			contract_type varchar(30) NOT NULL DEFAULT '',
			contract_level varchar(60) NOT NULL DEFAULT '',
			hire_date date DEFAULT NULL,
			end_date date DEFAULT NULL,
			weekly_hours decimal(5,1) NOT NULL DEFAULT 0,
			iban varchar(40) NOT NULL DEFAULT '',
			color varchar(10) NOT NULL DEFAULT '#7d8c6f',
			notes text,
			documents longtext,
			courses longtext,
			schedule longtext,
			skills longtext,
			pin_hash varchar(64) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY role (role),
			KEY status (status),
			KEY user_id (user_id),
			KEY last_name (last_name)
			) {$wpdb->get_charset_collate()};"
		);
	}

	/* ------------------------------------------------------------------
	 * Dati
	 * ---------------------------------------------------------------- */

	private static function clean_date( $v ) {
		$v = trim( (string) $v );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : null;
	}

	/**
	 * Normalizza le liste JSON (documenti, corsi, orari, competenze).
	 */
	private static function clean_json( $field, $value ) {
		$value = is_array( $value ) ? $value : array();
		$out   = array();
		if ( 'documents' === $field ) {
			foreach ( $value as $d ) {
				if ( ! is_array( $d ) || '' === trim( (string) ( $d['type'] ?? '' ) ) ) {
					continue;
				}
				$out[] = array(
					'type'    => sanitize_text_field( $d['type'] ),
					'number'  => sanitize_text_field( $d['number'] ?? '' ),
					'issued'  => self::clean_date( $d['issued'] ?? '' ),
					'expires' => self::clean_date( $d['expires'] ?? '' ),
					'notes'   => sanitize_text_field( $d['notes'] ?? '' ),
				);
			}
		} elseif ( 'courses' === $field ) {
			foreach ( $value as $c ) {
				if ( ! is_array( $c ) || '' === trim( (string) ( $c['name'] ?? '' ) ) ) {
					continue;
				}
				$out[] = array(
					'name'     => sanitize_text_field( $c['name'] ),
					'provider' => sanitize_text_field( $c['provider'] ?? '' ),
					'date'     => self::clean_date( $c['date'] ?? '' ),
					'hours'    => (float) ( $c['hours'] ?? 0 ),
					'expires'  => self::clean_date( $c['expires'] ?? '' ),
					'mandatory' => ! empty( $c['mandatory'] ),
				);
			}
		} elseif ( 'schedule' === $field ) {
			foreach ( bhc_weekdays() as $n => $label ) {
				$out[ $n ] = sanitize_text_field( $value[ $n ] ?? ( $value[ (string) $n ] ?? '' ) );
			}
		} elseif ( 'skills' === $field ) {
			$out = array_values( array_unique( array_filter( array_map( 'absint', $value ) ) ) );
		}
		return wp_json_encode( $out );
	}

	public static function save( array $data, $id = 0 ) {
		global $wpdb;
		$row = array();
		foreach ( self::FIELDS as $f ) {
			if ( ! array_key_exists( $f, $data ) ) {
				continue;
			}
			$v = $data[ $f ];
			switch ( $f ) {
				case 'birth_date':
				case 'hire_date':
				case 'end_date':
					$row[ $f ] = self::clean_date( $v );
					break;
				case 'email':
					$row[ $f ] = sanitize_email( $v );
					break;
				case 'tax_code':
				case 'iban':
				case 'province':
					$row[ $f ] = strtoupper( preg_replace( '/\s+/', '', sanitize_text_field( $v ) ) );
					break;
				case 'weekly_hours':
					$row[ $f ] = max( 0, min( 99, (float) str_replace( ',', '.', (string) $v ) ) );
					break;
				case 'role':
					$row[ $f ] = array_key_exists( $v, self::roles() ) ? $v : 'operatrice';
					break;
				case 'status':
					$row[ $f ] = in_array( $v, array( 'attivo', 'sospeso', 'cessato' ), true ) ? $v : 'attivo';
					break;
				case 'contract_type':
					$row[ $f ] = array_key_exists( $v, self::contract_types() ) ? $v : '';
					break;
				case 'color':
					$row[ $f ] = sanitize_hex_color( $v ) ?: '#7d8c6f';
					break;
				case 'notes':
					$row[ $f ] = sanitize_textarea_field( $v );
					break;
				default:
					$row[ $f ] = sanitize_text_field( $v );
			}
		}
		foreach ( self::JSON_FIELDS as $f ) {
			if ( array_key_exists( $f, $data ) ) {
				$row[ $f ] = self::clean_json( $f, $data[ $f ] );
			}
		}

		$row['updated_at'] = current_time( 'mysql' );
		if ( $id ) {
			if ( ! self::get( $id ) ) {
				return new WP_Error( 'not_found', __( 'Scheda non trovata.', 'beautyhub-core' ) );
			}
			$ok = $wpdb->update( bhc_table( 'people' ), $row, array( 'id' => (int) $id ) );
			if ( false === $ok ) {
				return new WP_Error( 'db', __( 'Errore nel salvataggio.', 'beautyhub-core' ) );
			}
			self::sync_account( (int) $id );
			return (int) $id;
		}
		if ( empty( $row['first_name'] ) || empty( $row['last_name'] ) ) {
			return new WP_Error( 'missing', __( 'Nome e cognome sono obbligatori.', 'beautyhub-core' ) );
		}
		$row['created_at'] = $row['updated_at'];
		foreach ( self::JSON_FIELDS as $f ) {
			if ( ! isset( $row[ $f ] ) ) {
				$row[ $f ] = self::clean_json( $f, array() );
			}
		}
		$ok = $wpdb->insert( bhc_table( 'people' ), $row );
		return $ok ? (int) $wpdb->insert_id : new WP_Error( 'db', __( 'Errore nel salvataggio.', 'beautyhub-core' ) );
	}

	public static function get( $id ) {
		global $wpdb;
		$t   = bhc_table( 'people' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
		return $row ? self::decorate( $row ) : null;
	}

	public static function find_by_email( $email ) {
		global $wpdb;
		$t   = bhc_table( 'people' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE email = %s LIMIT 1", $email ), ARRAY_A ); // phpcs:ignore
		return $row ? self::decorate( $row ) : null;
	}

	public static function search( $q = '', $role = '', $status = '' ) {
		global $wpdb;
		$t     = bhc_table( 'people' );
		$where = array( '1=1' );
		$args  = array();
		if ( '' !== trim( (string) $q ) ) {
			$like    = '%' . $wpdb->esc_like( trim( $q ) ) . '%';
			$where[] = '(first_name LIKE %s OR last_name LIKE %s OR email LIKE %s OR mobile LIKE %s OR phone LIKE %s OR job_title LIKE %s)';
			array_push( $args, $like, $like, $like, $like, $like, $like );
		}
		if ( $role && array_key_exists( $role, self::roles() ) ) {
			$where[] = 'role = %s';
			$args[]  = $role;
		}
		if ( $status ) {
			$where[] = 'status = %s';
			$args[]  = $status;
		}
		$sql  = "SELECT * FROM {$t} WHERE " . implode( ' AND ', $where ) . " ORDER BY CASE status WHEN 'attivo' THEN 0 WHEN 'sospeso' THEN 1 ELSE 2 END, last_name, first_name LIMIT 500";
		$rows = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		return array_map( array( __CLASS__, 'decorate' ), $rows );
	}

	public static function delete( $id ) {
		global $wpdb;
		$p = self::get( $id );
		if ( $p && $p['user_id'] ) {
			self::revoke_access( $p['user_id'] );
		}
		$wpdb->delete( bhc_table( 'people' ), array( 'id' => (int) $id ) );
		BHC_Operators::delete_for_person( $id );
	}

	/**
	 * Calcola avvisi di scadenza (documenti e corsi) e dati di comodo.
	 */
	public static function decorate( $row ) {
		foreach ( self::JSON_FIELDS as $f ) {
			$dec       = json_decode( (string) $row[ $f ], true );
			$row[ $f ] = is_array( $dec ) ? $dec : array();
		}
		$row['id']           = (int) $row['id'];
		$row['user_id']      = (int) $row['user_id'];
		$row['weekly_hours'] = (float) $row['weekly_hours'];
		$row['has_pin']      = ! empty( $row['pin_hash'] );
		unset( $row['pin_hash'] );

		$today  = current_time( 'Y-m-d' );
		$soon   = gmdate( 'Y-m-d', strtotime( $today . ' +30 days' ) );
		$alerts = array();
		foreach ( $row['documents'] as $d ) {
			if ( ! empty( $d['expires'] ) ) {
				if ( $d['expires'] < $today ) {
					/* translators: %s: tipo documento */
					$alerts[] = array( 'level' => 'expired', 'text' => sprintf( __( '%s scaduto', 'beautyhub-core' ), $d['type'] ), 'date' => $d['expires'] );
				} elseif ( $d['expires'] <= $soon ) {
					/* translators: %s: tipo documento */
					$alerts[] = array( 'level' => 'soon', 'text' => sprintf( __( '%s in scadenza', 'beautyhub-core' ), $d['type'] ), 'date' => $d['expires'] );
				}
			}
		}
		foreach ( $row['courses'] as $c ) {
			if ( ! empty( $c['expires'] ) ) {
				if ( $c['expires'] < $today ) {
					/* translators: %s: nome corso */
					$alerts[] = array( 'level' => 'expired', 'text' => sprintf( __( 'Corso "%s" da rinnovare', 'beautyhub-core' ), $c['name'] ), 'date' => $c['expires'] );
				} elseif ( $c['expires'] <= $soon ) {
					/* translators: %s: nome corso */
					$alerts[] = array( 'level' => 'soon', 'text' => sprintf( __( 'Corso "%s" in scadenza', 'beautyhub-core' ), $c['name'] ), 'date' => $c['expires'] );
				}
			}
		}
		if ( 'determinato' === $row['contract_type'] && $row['end_date'] && $row['end_date'] >= $today && $row['end_date'] <= $soon ) {
			$alerts[] = array( 'level' => 'soon', 'text' => __( 'Contratto in scadenza', 'beautyhub-core' ), 'date' => $row['end_date'] );
		}
		$row['alerts'] = $alerts;

		$user              = $row['user_id'] ? get_userdata( $row['user_id'] ) : null;
		$row['account']    = $user ? array( 'login' => $user->user_login, 'email' => $user->user_email, 'active' => (bool) array_intersect( array( 'bh_operator', 'bh_reception', 'bh_manager', 'bh_owner', 'administrator' ), (array) $user->roles ) ) : null;
		return $row;
	}

	/* ------------------------------------------------------------------
	 * Accesso al gestionale (utente WordPress)
	 * ---------------------------------------------------------------- */

	/**
	 * Crea o collega l'utente WordPress e invia l'email per impostare la password.
	 */
	public static function create_account( $id ) {
		$p = self::get( $id );
		if ( ! $p ) {
			return new WP_Error( 'not_found', __( 'Scheda non trovata.', 'beautyhub-core' ) );
		}
		if ( ! is_email( $p['email'] ) ) {
			return new WP_Error( 'email', __( 'Inserisci un\'email valida nella scheda prima di creare l\'accesso.', 'beautyhub-core' ) );
		}
		if ( 'cessato' === $p['status'] ) {
			return new WP_Error( 'status', __( 'Non puoi creare l\'accesso per una persona cessata.', 'beautyhub-core' ) );
		}

		$user = get_user_by( 'email', $p['email'] );
		$new  = false;
		if ( ! $user ) {
			$base  = sanitize_user( strtolower( remove_accents( $p['first_name'] . '.' . $p['last_name'] ) ), true );
			$base  = $base ? str_replace( ' ', '', $base ) : 'staff';
			$login = $base;
			$i     = 2;
			while ( username_exists( $login ) ) {
				$login = $base . $i++;
			}
			$uid = wp_insert_user(
				array(
					'user_login'   => $login,
					'user_email'   => $p['email'],
					'user_pass'    => wp_generate_password( 24, true, true ),
					'first_name'   => $p['first_name'],
					'last_name'    => $p['last_name'],
					'display_name' => trim( $p['first_name'] . ' ' . $p['last_name'] ),
					'role'         => self::wp_role( $p['role'] ),
				)
			);
			if ( is_wp_error( $uid ) ) {
				return $uid;
			}
			$user = get_userdata( $uid );
			$new  = true;
		} elseif ( ! in_array( 'administrator', (array) $user->roles, true ) && ! in_array( 'bh_owner', (array) $user->roles, true ) ) {
			$user->set_role( self::wp_role( $p['role'] ) );
		}

		global $wpdb;
		$wpdb->update( bhc_table( 'people' ), array( 'user_id' => $user->ID ), array( 'id' => (int) $id ) );

		// Link per impostare la password + email in italiano; se il server non riesce a inviarla
		// il link viene restituito al gestionale per inviarlo in altro modo (WhatsApp, SMS…).
		$out = self::get( $id );
		$key = get_password_reset_key( $user );
		if ( is_wp_error( $key ) ) {
			$out['mail'] = array( 'sent' => false, 'error' => $key->get_error_message(), 'link' => '' );
			return $out;
		}
		$link = network_site_url( 'wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode( $user->user_login ), 'login' );
		$sent = BHC_Emails::staff_access( $user, $p['first_name'], $link, $new );
		$out['mail'] = array(
			'sent'  => true === $sent,
			'error' => is_wp_error( $sent ) ? $sent->get_error_message() : '',
			'link'  => $link,
			'to'    => $user->user_email,
			'login' => $user->user_login,
		);
		return $out;
	}

	/**
	 * Allinea il ruolo dell'utente collegato a ruolo/stato della scheda.
	 */
	public static function sync_account( $id ) {
		$p = self::get( $id );
		if ( ! $p || ! $p['user_id'] ) {
			return;
		}
		$user = get_userdata( $p['user_id'] );
		if ( ! $user || in_array( 'administrator', (array) $user->roles, true ) || in_array( 'bh_owner', (array) $user->roles, true ) ) {
			return;
		}
		if ( 'attivo' === $p['status'] ) {
			$user->set_role( self::wp_role( $p['role'] ) );
		} else {
			self::revoke_access( $user->ID );
		}
	}

	/**
	 * Toglie l'accesso al gestionale (l'utente resta, senza permessi).
	 */
	public static function revoke_access( $user_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user || in_array( 'administrator', (array) $user->roles, true ) || in_array( 'bh_owner', (array) $user->roles, true ) ) {
			return;
		}
		$user->set_role( '' );
		if ( class_exists( 'WP_Session_Tokens' ) ) {
			WP_Session_Tokens::get_instance( $user->ID )->destroy_all();
		}
	}

	/* ------------------------------------------------------------------
	 * REST
	 * ---------------------------------------------------------------- */

	public static function can_manage() {
		return BHC_Permissions::can( 'people' );
	}

	public static function routes() {
		$ns = BHC_REST::NS;
		register_rest_route(
			$ns,
			'/people',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_list' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_create' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
			)
		);
		register_rest_route(
			$ns,
			'/people/(?P<id>\d+)',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_get' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_update' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ),
			)
		);
		register_rest_route( $ns, '/people/(?P<id>\d+)/account', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_account' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ) );
		register_rest_route( $ns, '/people/(?P<id>\d+)/revoke', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_revoke' ), 'permission_callback' => array( __CLASS__, 'can_manage' ) ) );
	}

	private static function input( WP_REST_Request $r ) {
		$data = array();
		foreach ( array_merge( self::FIELDS, self::JSON_FIELDS ) as $f ) {
			if ( null !== $r->get_param( $f ) ) {
				$data[ $f ] = $r->get_param( $f );
			}
		}
		return $data;
	}

	private static function err( WP_Error $e, $status = 400 ) {
		return new WP_REST_Response( array( 'message' => $e->get_error_message(), 'code' => $e->get_error_code() ), $status );
	}

	public static function rest_list( WP_REST_Request $r ) {
		return array(
			'items'     => self::search( (string) $r->get_param( 'q' ), (string) $r->get_param( 'role' ), (string) $r->get_param( 'status' ) ),
			'roles'     => self::roles(),
			'contracts' => self::contract_types(),
		);
	}

	public static function rest_get( WP_REST_Request $r ) {
		$p = self::get( (int) $r['id'] );
		return $p ? $p : new WP_REST_Response( array( 'message' => __( 'Scheda non trovata.', 'beautyhub-core' ) ), 404 );
	}

	public static function rest_create( WP_REST_Request $r ) {
		$id = self::save( self::input( $r ) );
		return is_wp_error( $id ) ? self::err( $id ) : self::get( $id );
	}

	public static function rest_update( WP_REST_Request $r ) {
		$id = self::save( self::input( $r ), (int) $r['id'] );
		return is_wp_error( $id ) ? self::err( $id ) : self::get( $id );
	}

	public static function rest_delete( WP_REST_Request $r ) {
		self::delete( (int) $r['id'] );
		return array( 'ok' => true );
	}

	public static function rest_account( WP_REST_Request $r ) {
		$res = self::create_account( (int) $r['id'] );
		return is_wp_error( $res ) ? self::err( $res ) : $res;
	}

	public static function rest_revoke( WP_REST_Request $r ) {
		$p = self::get( (int) $r['id'] );
		if ( ! $p || ! $p['user_id'] ) {
			return new WP_REST_Response( array( 'message' => __( 'Nessun accesso collegato.', 'beautyhub-core' ) ), 400 );
		}
		if ( (int) $p['user_id'] === get_current_user_id() ) {
			return new WP_REST_Response( array( 'message' => __( 'Non puoi togliere l\'accesso a te stesso.', 'beautyhub-core' ) ), 400 );
		}
		self::revoke_access( $p['user_id'] );
		return self::get( $p['id'] );
	}

	/**
	 * Personale di esempio (solo nell'installazione con dati demo).
	 */
	public static function import_demo( array $treatment_ids ) {
		$hours = array( 1 => '', 2 => '09:00-13:00, 14:00-19:00', 3 => '09:00-13:00, 14:00-19:00', 4 => '09:00-13:00, 14:00-19:00', 5 => '09:00-13:00, 14:00-19:00', 6 => '09:00-17:00', 7 => '' );
		$year  = (int) current_time( 'Y' );
		$demo  = array(
			array(
				'first_name' => 'Giulia', 'last_name' => 'Ferrari (demo)', 'role' => 'operatrice', 'job_title' => 'Estetista senior', 'color' => '#7d8c6f',
				'contract_type' => 'indeterminato', 'contract_level' => '3° livello CCNL Acconciatura ed Estetica', 'weekly_hours' => 40, 'hire_date' => ( $year - 4 ) . '-03-01',
				'mobile' => '+39 333 1111111', 'email' => 'giulia.demo@example.com', 'schedule' => $hours, 'skills' => array_merge( array_slice( $treatment_ids, 0, 5 ), array_slice( $treatment_ids, 9, 1 ) ),
				'courses' => array(
					array( 'name' => 'Formazione sicurezza lavoratori', 'provider' => 'Ente formazione', 'date' => ( $year - 2 ) . '-02-10', 'hours' => 8, 'expires' => ( $year + 3 ) . '-02-10', 'mandatory' => 1 ),
					array( 'name' => 'Tecniche di massaggio drenante', 'provider' => 'Accademia estetica', 'date' => ( $year - 1 ) . '-05-20', 'hours' => 16 ),
				),
			),
			array(
				'first_name' => 'Sara', 'last_name' => 'Colombo (demo)', 'role' => 'operatrice', 'job_title' => 'Estetista e onicotecnica', 'color' => '#b9805f',
				'contract_type' => 'determinato', 'weekly_hours' => 30, 'hire_date' => $year . '-01-15', 'end_date' => gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' +20 days' ) ),
				'mobile' => '+39 333 2222222', 'email' => 'sara.demo@example.com', 'skills' => array_merge( array_slice( $treatment_ids, 2, 2 ), array_slice( $treatment_ids, 5, 5 ) ),
			),
			array(
				'first_name' => 'Marta', 'last_name' => 'Ricci (demo)', 'role' => 'reception', 'job_title' => 'Receptionist', 'color' => '#5f8a92',
				'contract_type' => 'part_time', 'weekly_hours' => 24, 'hire_date' => ( $year - 1 ) . '-09-01', 'mobile' => '+39 333 3333333', 'email' => 'marta.demo@example.com',
			),
			array(
				'first_name' => 'Laura', 'last_name' => 'Bianchi (demo)', 'role' => 'manager', 'job_title' => 'Responsabile del centro', 'color' => '#8a7aa8',
				'contract_type' => 'indeterminato', 'weekly_hours' => 40, 'hire_date' => ( $year - 6 ) . '-02-01', 'mobile' => '+39 333 4444444', 'email' => 'laura.demo@example.com',
			),
		);
		foreach ( $demo as $d ) {
			self::save( $d );
		}
	}
}
