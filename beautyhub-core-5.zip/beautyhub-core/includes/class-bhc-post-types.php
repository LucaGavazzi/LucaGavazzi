<?php
/**
 * Tipi di contenuto: Trattamenti e Operatrici, con i relativi metabox.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Post_Types {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post_bh_treatment', array( __CLASS__, 'save_treatment' ) );
		add_action( 'save_post_bh_staff', array( __CLASS__, 'save_staff' ) );
		add_filter( 'manage_bh_treatment_posts_columns', array( __CLASS__, 'treatment_columns' ) );
		add_action( 'manage_bh_treatment_posts_custom_column', array( __CLASS__, 'treatment_column' ), 10, 2 );
	}

	public static function register() {
		register_post_type(
			'bh_treatment',
			array(
				'labels'       => array(
					'name'          => __( 'Trattamenti', 'beautyhub-core' ),
					'singular_name' => __( 'Trattamento', 'beautyhub-core' ),
					'add_new_item'  => __( 'Aggiungi trattamento', 'beautyhub-core' ),
					'edit_item'     => __( 'Modifica trattamento', 'beautyhub-core' ),
					'all_items'     => __( 'Trattamenti', 'beautyhub-core' ),
				),
				'public'       => true,
				'has_archive'  => false,
				'rewrite'      => array( 'slug' => 'trattamento' ),
				'menu_icon'    => 'dashicons-heart',
				'show_in_menu' => 'beautyhub',
				'show_in_rest' => true,
				'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'elementor' ),
			)
		);

		register_taxonomy(
			'bh_treatment_cat',
			'bh_treatment',
			array(
				'labels'            => array(
					'name'          => __( 'Categorie trattamenti', 'beautyhub-core' ),
					'singular_name' => __( 'Categoria', 'beautyhub-core' ),
				),
				'hierarchical'      => true,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => 'categoria-trattamenti' ),
			)
		);

		register_post_type(
			'bh_staff',
			array(
				'labels'             => array(
					'name'          => __( 'Cabine', 'beautyhub-core' ),
					'singular_name' => __( 'Cabina', 'beautyhub-core' ),
					'add_new_item'  => __( 'Aggiungi cabina', 'beautyhub-core' ),
					'edit_item'     => __( 'Modifica cabina', 'beautyhub-core' ),
					'all_items'     => __( 'Cabine', 'beautyhub-core' ),
				),
				'public'             => false,
				'publicly_queryable' => false,
				'show_ui'            => true,
				'show_in_menu'       => 'beautyhub',
				'show_in_rest'       => false,
				'supports'           => array( 'title', 'page-attributes' ),
			)
		);
	}

	public static function meta_boxes() {
		add_meta_box( 'bh_treatment_meta', __( 'Dettagli trattamento', 'beautyhub-core' ), array( __CLASS__, 'treatment_box' ), 'bh_treatment', 'side', 'high' );
		add_meta_box( 'bh_staff_meta', __( 'Dettagli cabina', 'beautyhub-core' ), array( __CLASS__, 'staff_box' ), 'bh_staff', 'normal', 'high' );
	}

	public static function treatment_box( $post ) {
		wp_nonce_field( 'bh_treatment_save', 'bh_treatment_nonce' );
		$duration = get_post_meta( $post->ID, '_bh_duration', true );
		$buffer   = get_post_meta( $post->ID, '_bh_buffer', true );
		$price    = get_post_meta( $post->ID, '_bh_price', true );
		$online   = get_post_meta( $post->ID, '_bh_online', true );
		?>
		<p><label><?php esc_html_e( 'Durata (minuti)', 'beautyhub-core' ); ?><br>
			<input type="number" min="5" step="5" name="bh_duration" value="<?php echo esc_attr( $duration ? $duration : 60 ); ?>" class="widefat"></label></p>
		<p><label><?php esc_html_e( 'Tempo di riordino cabina (minuti)', 'beautyhub-core' ); ?><br>
			<input type="number" min="0" step="5" name="bh_buffer" value="<?php echo esc_attr( '' !== $buffer ? $buffer : 10 ); ?>" class="widefat"></label></p>
		<p><label><?php esc_html_e( 'Prezzo (€)', 'beautyhub-core' ); ?><br>
			<input type="number" min="0" step="0.5" name="bh_price" value="<?php echo esc_attr( $price ); ?>" class="widefat"></label></p>
		<p><label><input type="checkbox" name="bh_online" value="1" <?php checked( '0' !== $online ); ?>> <?php esc_html_e( 'Prenotabile online', 'beautyhub-core' ); ?></label></p>
		<p><label><?php esc_html_e( 'Operatrici necessarie contemporaneamente', 'beautyhub-core' ); ?><br>
			<select name="bh_staff_needed" class="widefat">
				<option value="1" <?php selected( BHC_Operators::needed( $post->ID ), 1 ); ?>><?php esc_html_e( '1 operatrice', 'beautyhub-core' ); ?></option>
				<option value="2" <?php selected( BHC_Operators::needed( $post->ID ), 2 ); ?>><?php esc_html_e( '2 operatrici', 'beautyhub-core' ); ?></option>
			</select></label></p>
		<?php
		$people = BHC_People::search( '', '', 'attivo' );
		if ( $people ) :
			$enabled = BHC_Operators::treatment_people( $post->ID );
			?>
			<p><strong><?php esc_html_e( 'Operatrici abilitate', 'beautyhub-core' ); ?></strong></p>
			<input type="hidden" name="bh_people_sent" value="1">
			<?php foreach ( $people as $p ) : ?>
				<label style="display:block"><input type="checkbox" name="bh_people[]" value="<?php echo esc_attr( $p['id'] ); ?>" <?php checked( in_array( $p['id'], $enabled, true ) ); ?>> <?php echo esc_html( trim( $p['first_name'] . ' ' . $p['last_name'] ) ); ?></label>
			<?php endforeach; ?>
			<p class="description"><?php esc_html_e( 'Nessuna selezione = tutte le operatrici attive.', 'beautyhub-core' ); ?></p>
			<?php
		endif;
	}

	public static function save_treatment( $post_id ) {
		if ( ! isset( $_POST['bh_treatment_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['bh_treatment_nonce'] ), 'bh_treatment_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, '_bh_duration', max( 5, absint( wp_unslash( $_POST['bh_duration'] ?? 60 ) ) ) );
		update_post_meta( $post_id, '_bh_buffer', absint( wp_unslash( $_POST['bh_buffer'] ?? 0 ) ) );
		update_post_meta( $post_id, '_bh_price', round( (float) str_replace( ',', '.', sanitize_text_field( wp_unslash( $_POST['bh_price'] ?? 0 ) ) ), 2 ) );
		update_post_meta( $post_id, '_bh_online', isset( $_POST['bh_online'] ) ? '1' : '0' );
		update_post_meta( $post_id, '_bh_staff_needed', 2 === absint( $_POST['bh_staff_needed'] ?? 1 ) ? 2 : 1 );
		if ( isset( $_POST['bh_people_sent'] ) ) {
			$ids = isset( $_POST['bh_people'] ) && is_array( $_POST['bh_people'] ) ? array_map( 'absint', wp_unslash( $_POST['bh_people'] ) ) : array();
			BHC_Operators::set_treatment_people( $post_id, $ids );
		}
	}

	public static function staff_box( $post ) {
		wp_nonce_field( 'bh_staff_save', 'bh_staff_nonce' );
		$data       = bhc_staff_data( $post );
		$treatments = bhc_get_treatments();
		?>
		<table class="form-table">
			<tr>
				<th><?php esc_html_e( 'Colore in agenda', 'beautyhub-core' ); ?></th>
				<td><input type="color" name="bh_color" value="<?php echo esc_attr( $data['color'] ); ?>"></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Trattamenti possibili', 'beautyhub-core' ); ?></th>
				<td>
					<p class="description"><?php esc_html_e( 'Nessuna selezione = tutti i trattamenti.', 'beautyhub-core' ); ?></p>
					<?php foreach ( $treatments as $t ) : ?>
						<label style="display:block"><input type="checkbox" name="bh_treatments[]" value="<?php echo esc_attr( $t['id'] ); ?>" <?php checked( in_array( $t['id'], $data['treatments'], true ) ); ?>> <?php echo esc_html( $t['name'] ); ?></label>
					<?php endforeach; ?>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Orari della cabina', 'beautyhub-core' ); ?></th>
				<td>
					<p class="description"><?php esc_html_e( 'Facoltativo. Formato: 09:00-13:00, 14:00-19:00. Se tutti i giorni sono vuoti la cabina segue gli orari del centro.', 'beautyhub-core' ); ?></p>
					<?php foreach ( bhc_weekdays() as $n => $label ) : ?>
						<p><label style="display:inline-block;width:110px"><?php echo esc_html( $label ); ?></label>
						<input type="text" name="bh_hours[<?php echo esc_attr( $n ); ?>]" value="<?php echo esc_attr( $data['hours'][ $n ] ?? '' ); ?>" placeholder="09:00-13:00, 14:00-19:00" class="regular-text"></p>
					<?php endforeach; ?>
				</td>
			</tr>
		</table>
		<?php
	}

	public static function save_staff( $post_id ) {
		if ( ! isset( $_POST['bh_staff_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['bh_staff_nonce'] ), 'bh_staff_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		BHC_Repository::save_cabin_meta(
			$post_id,
			array(
				'color'      => wp_unslash( $_POST['bh_color'] ?? '' ),
				'hours'      => isset( $_POST['bh_hours'] ) && is_array( $_POST['bh_hours'] ) ? wp_unslash( $_POST['bh_hours'] ) : array(),
				'treatments' => isset( $_POST['bh_treatments'] ) && is_array( $_POST['bh_treatments'] ) ? wp_unslash( $_POST['bh_treatments'] ) : array(),
			)
		);
	}

	public static function treatment_columns( $cols ) {
		$cols['bh_duration'] = __( 'Durata', 'beautyhub-core' );
		$cols['bh_price']    = __( 'Prezzo', 'beautyhub-core' );
		return $cols;
	}

	public static function treatment_column( $col, $post_id ) {
		if ( 'bh_duration' === $col ) {
			echo esc_html( (int) get_post_meta( $post_id, '_bh_duration', true ) . ' min' );
		} elseif ( 'bh_price' === $col ) {
			echo esc_html( bhc_price( get_post_meta( $post_id, '_bh_price', true ) ) );
		}
	}
}
