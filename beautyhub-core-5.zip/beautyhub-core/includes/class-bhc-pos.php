<?php
/**
 * Cassa: vendita di trattamenti, prodotti e card; utilizzo di sedute, gift card e punti;
 * pagamento contanti / carta / misto con resto; chiusura cassa giornaliera.
 *
 * Contabilità:
 * - la tabella "payments" resta il registro degli incassi per trattamenti, prodotti e pacchetti
 *   (è quella usata dai Report); la vendita di gift card è un credito prepagato e non va nei ricavi
 *   finché la gift card non viene usata (metodo "Gift card");
 * - la tabella "sales" è il registro di cassa: quanto è entrato in contanti e con carta.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_POS {

	const REVENUE = array( 'appointment', 'treatment', 'product', 'package' );

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'sales' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			number varchar(30) NOT NULL DEFAULT '',
			client_id bigint(20) unsigned NOT NULL DEFAULT 0,
			client_name varchar(190) NOT NULL DEFAULT '',
			subtotal decimal(10,2) NOT NULL DEFAULT 0,
			discount decimal(10,2) NOT NULL DEFAULT 0,
			points_discount decimal(10,2) NOT NULL DEFAULT 0,
			coupon_discount decimal(10,2) NOT NULL DEFAULT 0,
			coupon_used bigint(20) unsigned NOT NULL DEFAULT 0,
			coupon_issued bigint(20) unsigned NOT NULL DEFAULT 0,
			gift_used decimal(10,2) NOT NULL DEFAULT 0,
			total decimal(10,2) NOT NULL DEFAULT 0,
			cash decimal(10,2) NOT NULL DEFAULT 0,
			card decimal(10,2) NOT NULL DEFAULT 0,
			tendered decimal(10,2) NOT NULL DEFAULT 0,
			change_given decimal(10,2) NOT NULL DEFAULT 0,
			points_used decimal(10,2) NOT NULL DEFAULT 0,
			points_earned decimal(10,2) NOT NULL DEFAULT 0,
			sessions_used smallint(5) unsigned NOT NULL DEFAULT 0,
			note varchar(255) NOT NULL DEFAULT '',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY client_id (client_id)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'sale_lines' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			sale_id bigint(20) unsigned NOT NULL DEFAULT 0,
			type varchar(20) NOT NULL DEFAULT '',
			ref_id bigint(20) unsigned NOT NULL DEFAULT 0,
			card_id bigint(20) unsigned NOT NULL DEFAULT 0,
			description varchar(255) NOT NULL DEFAULT '',
			qty decimal(10,2) NOT NULL DEFAULT 1,
			unit_price decimal(10,2) NOT NULL DEFAULT 0,
			discount decimal(10,2) NOT NULL DEFAULT 0,
			total decimal(10,2) NOT NULL DEFAULT 0,
			note varchar(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY sale_id (sale_id)
			) {$c};"
		);
	}

	private static function money( $v ) {
		return round( (float) str_replace( ',', '.', (string) $v ), 2 );
	}

	/* ==================================================================
	 * Dati per la cassa
	 * ================================================================ */

	/** Appuntamenti del giorno ancora da incassare. */
	public static function to_cash( $date ) {
		global $wpdb;
		$a    = bhc_table( 'appointments' );
		$c    = bhc_table( 'clients' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT a.*, c.first_name, c.last_name, c.phone, c.email FROM {$a} a LEFT JOIN {$c} c ON c.id = a.client_id WHERE a.start_at >= %s AND a.start_at < %s AND a.status NOT IN ('cancelled','noshow') ORDER BY a.start_at", $date . ' 00:00:00', $date . ' 23:59:59' ), ARRAY_A ); // phpcs:ignore
		$out  = array();
		foreach ( $rows as $r ) {
			$d = BHC_Repository::decorate( $r );
			$session = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'card_moves' ) . " WHERE appointment_id = %d AND action = 'seduta'", $d['id'] ) ); // phpcs:ignore
			$d['due']      = $session ? 0 : max( 0, round( $d['price'] - $d['paid'], 2 ) );
			$d['session']  = (bool) $session;
			$d['settled']  = $session || ( $d['price'] > 0 && $d['due'] <= 0 ) || ( 'done' === $d['status'] && $d['paid'] > 0 );
			$out[]         = $d;
		}
		return $out;
	}

	public static function products() {
		global $wpdb;
		$t    = bhc_table( 'products' );
		$rows = $wpdb->get_results( "SELECT id, ean, sku, name, brand, family_id, sale_price, stock, unit FROM {$t} WHERE active = 1 AND type = 'rivendita' ORDER BY name", ARRAY_A ); // phpcs:ignore
		$fam  = class_exists( 'BHC_Stock' ) ? BHC_Stock::names() : array();
		foreach ( $rows as &$r ) {
			$r['id']         = (int) $r['id'];
			$r['family_id']  = (int) $r['family_id'];
			$r['sale_price'] = (float) $r['sale_price'];
			$r['stock']      = (float) $r['stock'];
			$r['family']     = isset( $fam['f'][ $r['family_id'] ] ) ? $fam['f'][ $r['family_id'] ] : '';
		}
		return $rows;
	}

	/* ==================================================================
	 * Checkout
	 * ================================================================ */

	/**
	 * Righe ammesse (lines[]):
	 *  appointment {appointment_id, unit_price, discount, session:{card_id,item_id}}
	 *  treatment   {treatment_id, unit_price, discount, session:{card_id,item_id}}
	 *  product     {product_id, qty, unit_price, discount}
	 *  gift_new    {amount, holder_id, ean, message, expires_at}
	 *  gift_topup  {card_id, amount}
	 *  package     {package_id | items+price, card_id (esistente) | holder_id (nuova card), unit_price}
	 *  loyalty_new {holder_id}
	 * use: {gift:[{card_id, amount}], points:{card_id, points}, bonus_points}
	 * pay: {cash, card, tendered}
	 */
	public static function checkout( array $d ) {
		global $wpdb;
		$client_id = absint( $d['client_id'] ?? 0 );
		$client    = $client_id ? BHC_Repository::get_client( $client_id ) : null;
		if ( $client_id && ! $client ) {
			return new WP_Error( 'client', __( 'Cliente non trovata.', 'beautyhub-core' ) );
		}
		$client_name = $client ? trim( $client['first_name'] . ' ' . $client['last_name'] ) : '';
		$in_lines    = isset( $d['lines'] ) && is_array( $d['lines'] ) ? $d['lines'] : array();
		if ( ! $in_lines ) {
			return new WP_Error( 'empty', __( 'Lo scontrino è vuoto.', 'beautyhub-core' ) );
		}

		/* ---------- 1. Normalizza e valida le righe ---------- */
		$lines        = array();
		$seen_appt    = array();
		$session_need = array(); // item_id => quante sedute
		foreach ( $in_lines as $l ) {
			$type = sanitize_key( $l['type'] ?? '' );
			$qty  = max( 0.01, (float) ( $l['qty'] ?? 1 ) );
			$up   = max( 0, self::money( $l['unit_price'] ?? 0 ) );
			$disc = max( 0, self::money( $l['discount'] ?? 0 ) );
			$row  = array( 'type' => $type, 'qty' => 1, 'unit_price' => $up, 'discount' => $disc, 'ref_id' => 0, 'card_id' => 0, 'description' => '', 'note' => '', 'raw' => $l, 'session' => null );
			switch ( $type ) {
				case 'appointment':
					$a = BHC_Repository::get_appointment( absint( $l['appointment_id'] ?? 0 ) );
					if ( ! $a ) {
						return new WP_Error( 'appt', __( 'Appuntamento non trovato.', 'beautyhub-core' ) );
					}
					if ( isset( $seen_appt[ $a['id'] ] ) ) {
						return new WP_Error( 'appt', __( 'Lo stesso appuntamento è due volte nello scontrino.', 'beautyhub-core' ) );
					}
					$seen_appt[ $a['id'] ] = 1;
					$row['ref_id']         = $a['id'];
					$row['treatment_id']   = $a['treatment_id'];
					$row['appt']           = $a;
					$row['description']    = $a['treatment_name'] . ( $a['client_name'] && $a['client_id'] !== $client_id ? ' – ' . $a['client_name'] : '' );
					if ( ! $client_id ) {
						$client_id   = $a['client_id'];
						$client      = $client_id ? BHC_Repository::get_client( $client_id ) : null;
						$client_name = $client ? trim( $client['first_name'] . ' ' . $client['last_name'] ) : '';
					}
					break;
				case 'treatment':
					$t = bhc_treatment_data( absint( $l['treatment_id'] ?? 0 ) );
					if ( ! $t ) {
						return new WP_Error( 'treat', __( 'Trattamento non trovato.', 'beautyhub-core' ) );
					}
					$row['ref_id']       = $t['id'];
					$row['treatment_id'] = $t['id'];
					$row['description']  = $t['name'];
					break;
				case 'product':
					$pid = absint( $l['product_id'] ?? 0 );
					$p   = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'products' ) . ' WHERE id = %d', $pid ), ARRAY_A ); // phpcs:ignore
					if ( ! $p ) {
						return new WP_Error( 'product', __( 'Prodotto non trovato.', 'beautyhub-core' ) );
					}
					$row['ref_id']      = $pid;
					$row['qty']         = round( $qty, 2 );
					$row['description'] = $p['name'];
					break;
				case 'gift_new':
					$up = self::money( $l['amount'] ?? $up );
					if ( $up <= 0 ) {
						return new WP_Error( 'gift', __( 'Indica il valore della gift card.', 'beautyhub-core' ) );
					}
					$row['unit_price']  = $up;
					$row['discount']    = 0;
					$row['holder_id']   = absint( $l['holder_id'] ?? $client_id );
					if ( ! $row['holder_id'] ) {
						return new WP_Error( 'holder', __( 'La gift card è nominale: scegli l\'intestataria.', 'beautyhub-core' ) );
					}
					$row['description'] = __( 'Gift card', 'beautyhub-core' );
					if ( ! empty( $l['ean'] ) ) {
						$e = preg_replace( '/\D/', '', (string) $l['ean'] );
						if ( ! BHC_Inventory::ean_valid( $e ) ) {
							return new WP_Error( 'ean', __( 'Il codice EAN della gift card non è valido.', 'beautyhub-core' ) );
						}
					}
					break;
				case 'gift_topup':
					$c = BHC_Cards::get( absint( $l['card_id'] ?? 0 ) );
					$up = self::money( $l['amount'] ?? $up );
					if ( ! $c || 'gift' !== $c['type'] || 'annullata' === $c['status'] ) {
						return new WP_Error( 'card', __( 'Gift card da ricaricare non valida.', 'beautyhub-core' ) );
					}
					if ( $up <= 0 ) {
						return new WP_Error( 'gift', __( 'Indica l\'importo della ricarica.', 'beautyhub-core' ) );
					}
					$row['unit_price']  = $up;
					$row['discount']    = 0;
					$row['card_id']     = $c['id'];
					/* translators: %s: codice card */
					$row['description'] = sprintf( __( 'Ricarica gift card %s', 'beautyhub-core' ), $c['code'] );
					break;
				case 'package':
					$pkg_id = absint( $l['package_id'] ?? 0 );
					$pkg    = $pkg_id ? BHC_Cards::get_package( $pkg_id ) : null;
					if ( ! $pkg ) {
						return new WP_Error( 'package', __( 'Pacchetto non trovato.', 'beautyhub-core' ) );
					}
					$row['ref_id']      = $pkg_id;
					$row['description'] = __( 'Pacchetto', 'beautyhub-core' ) . ' ' . $pkg['name'];
					if ( ! empty( $l['card_id'] ) ) {
						$c = BHC_Cards::get( absint( $l['card_id'] ) );
						if ( ! $c || 'package' !== $c['type'] || 'annullata' === $c['status'] ) {
							return new WP_Error( 'card', __( 'Carta trattamenti non valida.', 'beautyhub-core' ) );
						}
						$row['card_id'] = $c['id'];
					} else {
						$row['holder_id'] = absint( $l['holder_id'] ?? $client_id );
						if ( ! $row['holder_id'] ) {
							return new WP_Error( 'holder', __( 'Per vendere un pacchetto scegli la cliente.', 'beautyhub-core' ) );
						}
					}
					break;
				case 'loyalty_new':
					$row['holder_id'] = absint( $l['holder_id'] ?? $client_id );
					if ( ! $row['holder_id'] ) {
						return new WP_Error( 'holder', __( 'Per la carta fedeltà scegli la cliente.', 'beautyhub-core' ) );
					}
					$row['unit_price']  = 0;
					$row['discount']    = 0;
					$row['description'] = __( 'Carta fedeltà', 'beautyhub-core' );
					break;
				default:
					return new WP_Error( 'line', __( 'Riga dello scontrino non valida.', 'beautyhub-core' ) );
			}
			// Seduta da carta trattamenti.
			if ( in_array( $type, array( 'appointment', 'treatment' ), true ) && ! empty( $l['session']['card_id'] ) ) {
				$card = BHC_Cards::get( absint( $l['session']['card_id'] ) );
				$item = null;
				if ( $card && 'package' === $card['type'] ) {
					foreach ( $card['items'] as $it ) {
						if ( $it['id'] === absint( $l['session']['item_id'] ?? 0 ) ) {
							$item = $it;
						}
					}
				}
				if ( ! $card || ! $item || ! $card['usable'] ) {
					return new WP_Error( 'session', __( 'Carta trattamenti non utilizzabile per questa riga.', 'beautyhub-core' ) );
				}
				if ( $item['treatment_id'] !== (int) $row['treatment_id'] ) {
					return new WP_Error( 'session', __( 'La seduta della carta è per un altro trattamento.', 'beautyhub-core' ) );
				}
				$session_need[ $item['id'] ] = ( $session_need[ $item['id'] ] ?? 0 ) + 1;
				if ( $session_need[ $item['id'] ] > $item['sessions_left'] ) {
					/* translators: %s: trattamento */
					return new WP_Error( 'session', sprintf( __( 'Sedute di %s esaurite sulla carta.', 'beautyhub-core' ), $item['treatment'] ) );
				}
				$row['session']  = array( 'card' => $card, 'item' => $item );
				$row['discount'] = 0;
				$row['card_id']  = $card['id'];
				$row['note']     = $card['code'];
			}
			$gross        = round( $row['qty'] * $row['unit_price'], 2 );
			$row['disc']  = $row['session'] ? $gross : min( $gross, $row['discount'] );
			$row['net']   = round( $gross - $row['disc'], 2 );
			$row['gross'] = $gross;
			$lines[]      = $row;
		}

		/* ---------- 2. Punti e gift card ---------- */
		$use     = isset( $d['use'] ) && is_array( $d['use'] ) ? $d['use'] : array();
		$revenue = 0;
		foreach ( $lines as $r ) {
			if ( in_array( $r['type'], self::REVENUE, true ) ) {
				$revenue += $r['net'];
			}
		}
		$revenue = round( $revenue, 2 );

		$points_disc = 0;
		$points_used = 0;
		$points_card = null;
		if ( ! empty( $use['points']['card_id'] ) && (float) ( $use['points']['points'] ?? 0 ) > 0 ) {
			$points_card = BHC_Cards::get( absint( $use['points']['card_id'] ) );
			$s           = BHC_Cards::loyalty_settings();
			$points_used = (float) $use['points']['points'];
			if ( ! $points_card || 'loyalty' !== $points_card['type'] || 'attiva' !== $points_card['status'] ) {
				return new WP_Error( 'points', __( 'Carta fedeltà non valida.', 'beautyhub-core' ) );
			}
			if ( $points_used > $points_card['points'] ) {
				return new WP_Error( 'points', __( 'Punti insufficienti.', 'beautyhub-core' ) );
			}
			if ( $points_card['points'] < (float) $s['min_redeem'] ) {
				/* translators: %s: punti minimi */
				return new WP_Error( 'points', sprintf( __( 'Servono almeno %s punti per usarli.', 'beautyhub-core' ), $s['min_redeem'] ) );
			}
			$points_disc = round( $points_used * (float) $s['point_value'], 2 );
			if ( $points_disc > $revenue + 0.001 ) {
				return new WP_Error( 'points', __( 'Lo sconto punti supera l\'importo di trattamenti e prodotti.', 'beautyhub-core' ) );
			}
		}

		// Buono sconto da un acquisto precedente.
		$coupon      = null;
		$coupon_disc = 0;
		if ( ! empty( $use['coupon'] ) ) {
			$coupon = BHC_Messages::find_coupon( is_array( $use['coupon'] ) ? ( $use['coupon']['code'] ?? '' ) : $use['coupon'] );
			$chk    = BHC_Messages::coupon_check( $coupon, round( $revenue - $points_disc, 2 ) );
			if ( is_wp_error( $chk ) ) {
				return $chk;
			}
			$coupon_disc = $chk;
		}

		$gifts     = array();
		$gift_used = 0;
		foreach ( isset( $use['gift'] ) && is_array( $use['gift'] ) ? $use['gift'] : array() as $g ) {
			$amt = self::money( $g['amount'] ?? 0 );
			if ( $amt <= 0 ) {
				continue;
			}
			$c = BHC_Cards::get( absint( $g['card_id'] ?? 0 ) );
			if ( ! $c || 'gift' !== $c['type'] || ! $c['usable'] ) {
				return new WP_Error( 'gift', __( 'Gift card non utilizzabile.', 'beautyhub-core' ) );
			}
			if ( $amt > $c['balance'] + 0.001 ) {
				/* translators: 1: codice 2: saldo */
				return new WP_Error( 'gift', sprintf( __( 'Sulla gift card %1$s restano solo %2$s.', 'beautyhub-core' ), $c['code'], bhc_price( $c['balance'] ) ) );
			}
			foreach ( $lines as $r ) {
				if ( 'gift_topup' === $r['type'] && $r['card_id'] === $c['id'] ) {
					return new WP_Error( 'gift', __( 'Non puoi ricaricare e scalare la stessa gift card nello stesso scontrino.', 'beautyhub-core' ) );
				}
			}
			$gifts[]    = array( 'card' => $c, 'amount' => $amt );
			$gift_used += $amt;
		}
		$gift_used = round( $gift_used, 2 );
		if ( $gift_used > round( $revenue - $points_disc - $coupon_disc, 2 ) + 0.001 ) {
			return new WP_Error( 'gift', __( 'La gift card paga solo trattamenti, prodotti e pacchetti, non altre card.', 'beautyhub-core' ) );
		}

		/* ---------- 3. Pagamento ---------- */
		$subtotal = 0;
		$discount = 0;
		$all_net  = 0;
		foreach ( $lines as $r ) {
			$subtotal += $r['gross'];
			$discount += $r['session'] ? 0 : $r['disc'];
			$all_net  += $r['net'];
		}
		$total = round( $all_net - $points_disc - $coupon_disc - $gift_used, 2 );
		$pay   = isset( $d['pay'] ) && is_array( $d['pay'] ) ? $d['pay'] : array();
		$cash  = max( 0, self::money( $pay['cash'] ?? 0 ) );
		$card  = max( 0, self::money( $pay['card'] ?? 0 ) );
		if ( abs( $cash + $card - $total ) > 0.009 ) {
			/* translators: 1: totale 2: pagato */
			return new WP_Error( 'pay', sprintf( __( 'Il pagamento (%2$s) non corrisponde al totale da incassare (%1$s).', 'beautyhub-core' ), bhc_price( $total ), bhc_price( $cash + $card ) ) );
		}
		$tendered = isset( $pay['tendered'] ) && '' !== $pay['tendered'] ? self::money( $pay['tendered'] ) : $cash;
		if ( $tendered + 0.001 < $cash ) {
			return new WP_Error( 'pay', __( 'I contanti ricevuti sono meno dell\'importo in contanti.', 'beautyhub-core' ) );
		}
		$change = round( $tendered - $cash, 2 );

		/* ---------- 4. Registra ---------- */
		$now = current_time( 'mysql' );
		$wpdb->insert(
			bhc_table( 'sales' ),
			array(
				'client_id'       => $client_id,
				'client_name'     => $client_name,
				'subtotal'        => round( $subtotal, 2 ),
				'discount'        => round( $discount, 2 ),
				'points_discount' => $points_disc,
				'coupon_discount' => $coupon_disc,
				'coupon_used'     => $coupon ? $coupon['id'] : 0,
				'gift_used'       => $gift_used,
				'total'           => $total,
				'cash'            => $cash,
				'card'            => $card,
				'tendered'        => $tendered,
				'change_given'    => $change,
				'points_used'     => $points_used,
				'note'            => sanitize_text_field( $d['note'] ?? '' ),
				'created_by'      => get_current_user_id(),
				'created_at'      => $now,
			)
		);
		$sale_id = (int) $wpdb->insert_id;
		if ( ! $sale_id ) {
			return new WP_Error( 'db', __( 'Errore nel salvataggio della vendita.', 'beautyhub-core' ) );
		}
		$number = 'V' . current_time( 'y' ) . '-' . str_pad( (string) $sale_id, 5, '0', STR_PAD_LEFT );
		$wpdb->update( bhc_table( 'sales' ), array( 'number' => $number ), array( 'id' => $sale_id ) );

		// I punti li accredita la cassa una volta sola, non ogni riga di incasso.
		remove_action( 'bhc_payment_added', array( 'BHC_Cards', 'on_payment' ), 10 );
		$method_label = $cash > 0 && $card > 0 ? 'misto' : ( $card > 0 ? 'card' : 'cash' );

		// 4a. Card nuove, ricariche, pacchetti, sedute.
		$sessions = 0;
		foreach ( $lines as $i => $r ) {
			$l = $r['raw'];
			if ( 'gift_new' === $r['type'] ) {
				$cid = BHC_Cards::create(
					array(
						'type'           => 'gift',
						'client_id'      => $r['holder_id'],
						'value'          => $r['unit_price'],
						'buyer_name'     => $r['holder_id'] !== $client_id ? $client_name : '',
						'message'        => $l['message'] ?? '',
						'expires_at'     => $l['expires_at'] ?? gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' +1 year' ) ),
						'ean'            => $l['ean'] ?? '',
						'payment_method' => $method_label,
						'notes'          => $number,
					)
				);
				if ( ! is_wp_error( $cid ) ) {
					$c                         = BHC_Cards::get( $cid );
					$lines[ $i ]['card_id']     = $cid;
					$lines[ $i ]['description'] = __( 'Gift card', 'beautyhub-core' ) . ' ' . $c['code'] . ( $c['holder'] ? ' – ' . $c['holder'] : '' );
				} else {
					$lines[ $i ]['note'] = $cid->get_error_message();
				}
			} elseif ( 'gift_topup' === $r['type'] ) {
				BHC_Cards::topup_gift( $r['card_id'], $r['unit_price'], $method_label, $number );
			} elseif ( 'loyalty_new' === $r['type'] ) {
				$cid = BHC_Cards::create( array( 'type' => 'loyalty', 'client_id' => $r['holder_id'] ) );
				if ( ! is_wp_error( $cid ) ) {
					$c                         = BHC_Cards::get( $cid );
					$lines[ $i ]['card_id']     = $cid;
					$lines[ $i ]['description'] = __( 'Carta fedeltà', 'beautyhub-core' ) . ' ' . $c['code'];
					if ( ! $points_card && $r['holder_id'] === $client_id ) {
						$points_card = $c;
					}
				} else {
					$lines[ $i ]['note'] = $cid->get_error_message();
				}
			} elseif ( 'package' === $r['type'] ) {
				if ( $r['card_id'] ) {
					BHC_Cards::add_package( $r['card_id'], array( 'package_id' => $r['ref_id'] ), $method_label );
					$cid = $r['card_id'];
				} else {
					$cid = BHC_Cards::create( array( 'type' => 'package', 'client_id' => $r['holder_id'], 'package_id' => $r['ref_id'], 'payment_method' => $method_label, 'notes' => $number ) );
				}
				if ( ! is_wp_error( $cid ) ) {
					$c                         = BHC_Cards::get( $cid );
					$lines[ $i ]['card_id']     = $cid;
					$lines[ $i ]['description'] = $r['description'] . ' (' . $c['code'] . ')';
				}
			}
			if ( $r['session'] ) {
				$res = BHC_Cards::use_session( $r['session']['card']['id'], $r['session']['item']['id'], 'appointment' === $r['type'] ? $r['ref_id'] : 0, $number );
				if ( ! is_wp_error( $res ) ) {
					$sessions++;
				}
			}
		}

		// 4b. Punti usati e gift card scalate.
		if ( $points_used > 0 && $points_card ) {
			/* translators: 1: valore 2: numero vendita */
			BHC_Cards::points( $points_card['id'], -$points_used, 'utilizzo', sprintf( __( 'Sconto di %1$s · %2$s', 'beautyhub-core' ), bhc_price( $points_disc ), $number ) );
		}
		foreach ( $gifts as $g ) {
			BHC_Cards::redeem_gift( $g['card']['id'], $g['amount'], 0, $number );
		}

		// 4c. Ripartizione degli incassi sulle righe di ricavo (registro "payments").
		$pools = array(
			array( 'method' => 'giftcard', 'left' => $gift_used ),
			array( 'method' => 'cash', 'left' => $cash ),
			array( 'method' => 'card', 'left' => $card ),
		);
		$pdisc = round( $points_disc + $coupon_disc, 2 );
		if ( $coupon ) {
			BHC_Messages::use_coupon( $coupon['id'], $sale_id, $coupon_disc );
		}
		// Le card prepagate (gift) consumano prima contanti/carta, così i ricavi restano corretti.
		$prepaid = 0;
		foreach ( $lines as $r ) {
			if ( in_array( $r['type'], array( 'gift_new', 'gift_topup' ), true ) ) {
				$prepaid += $r['net'];
			}
		}
		foreach ( array( 1, 2 ) as $pi ) {
			$take              = min( $prepaid, $pools[ $pi ]['left'] );
			$pools[ $pi ]['left'] = round( $pools[ $pi ]['left'] - $take, 2 );
			$prepaid           = round( $prepaid - $take, 2 );
		}
		foreach ( $lines as $r ) {
			if ( ! in_array( $r['type'], self::REVENUE, true ) ) {
				continue;
			}
			$need  = $r['net'];
			$share = min( $need, $pdisc );
			$pdisc = round( $pdisc - $share, 2 );
			$need  = round( $need - $share, 2 );
			$appt  = 'appointment' === $r['type'] ? $r['ref_id'] : 0;
			$first = true;
			foreach ( $pools as &$pool ) {
				if ( $need <= 0 ) {
					break;
				}
				$take = min( $need, $pool['left'] );
				if ( $take > 0 ) {
					BHC_Repository::add_payment(
						array(
							'appointment_id' => $appt,
							'client_id'      => $client_id,
							'amount'         => $take,
							'discount'       => $first ? $r['disc'] + $share : 0,
							'method'         => $pool['method'],
							'description'    => $r['description'] . ' · ' . $number,
						)
					);
					$pool['left'] = round( $pool['left'] - $take, 2 );
					$need         = round( $need - $take, 2 );
					$first        = false;
				}
			}
			unset( $pool );
		}

		// 4d. Magazzino e appuntamenti.
		foreach ( $lines as $r ) {
			if ( 'product' === $r['type'] ) {
				BHC_Inventory::move( $r['ref_id'], -$r['qty'], 'vendita', 0, $number . ( $client_name ? ' · ' . $client_name : '' ) );
			}
			if ( 'appointment' === $r['type'] && ! in_array( $r['appt']['status'], array( 'done', 'cancelled' ), true ) ) {
				BHC_Repository::save_appointment( array( 'status' => 'done' ), $r['ref_id'], false );
			}
		}

		// 4e. Punti fedeltà guadagnati (su quanto pagato in contanti e carta, escluse le gift card vendute).
		$earned = 0;
		$s      = BHC_Cards::loyalty_settings();
		if ( $client_id ) {
			if ( ! $points_card || 'attiva' !== ( BHC_Cards::get( $points_card['id'] )['status'] ?? '' ) ) {
				$lid         = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'cards' ) . " WHERE type = 'loyalty' AND client_id = %d AND status = 'attiva' ORDER BY id DESC LIMIT 1", $client_id ) ); // phpcs:ignore
				$points_card = $lid ? BHC_Cards::get( $lid ) : null;
			}
			if ( $points_card ) {
				$base = 0;
				foreach ( $lines as $r ) {
					if ( in_array( $r['type'], self::REVENUE, true ) ) {
						$base += $r['net'];
					}
				}
				$base = max( 0, $base - $points_disc - $coupon_disc - $gift_used );
				if ( ! empty( $s['auto'] ) ) {
					$earned = floor( $base * (float) $s['points_per_euro'] );
				}
				$bonus = max( 0, (float) ( $use['bonus_points'] ?? 0 ) );
				if ( $earned > 0 ) {
					/* translators: 1: importo 2: numero vendita */
					BHC_Cards::points( $points_card['id'], $earned, 'accredito', sprintf( __( 'Acquisto di %1$s · %2$s', 'beautyhub-core' ), bhc_price( $base ), $number ) );
				}
				if ( $bonus > 0 ) {
					BHC_Cards::points( $points_card['id'], $bonus, 'accredito', __( 'Punti bonus', 'beautyhub-core' ) . ' · ' . $number );
					$earned += $bonus;
				}
			}
		}
		add_action( 'bhc_payment_added', array( 'BHC_Cards', 'on_payment' ), 10, 4 );

		// 4f. Righe dello scontrino.
		foreach ( $lines as $r ) {
			$wpdb->insert(
				bhc_table( 'sale_lines' ),
				array(
					'sale_id'     => $sale_id,
					'type'        => $r['type'],
					'ref_id'      => (int) $r['ref_id'],
					'card_id'     => (int) $r['card_id'],
					'description' => mb_substr( $r['description'], 0, 250 ),
					'qty'         => $r['qty'],
					'unit_price'  => $r['unit_price'],
					'discount'    => $r['disc'],
					'total'       => $r['net'],
					'note'        => mb_substr( ( $r['session'] ? __( 'Seduta da carta', 'beautyhub-core' ) . ' ' : '' ) . $r['note'], 0, 250 ),
				)
			);
		}
		// Buono sconto per il prossimo acquisto.
		$issued = 0;
		$rs     = BHC_Messages::receipt_settings();
		$spent  = max( 0, round( $revenue - $points_disc - $coupon_disc, 2 ) );
		$want   = isset( $d['issue_coupon'] ) && null !== $d['issue_coupon'] ? (bool) $d['issue_coupon'] : BHC_Messages::coupon_due( $spent );
		if ( $want && ! empty( $rs['coupon_enabled'] ) ) {
			$issued = BHC_Messages::issue_coupon( $client_id, $sale_id );
		}
		$wpdb->update( bhc_table( 'sales' ), array( 'points_earned' => $earned, 'sessions_used' => $sessions, 'coupon_issued' => $issued ), array( 'id' => $sale_id ) );
		return $sale_id;
	}

	/* ==================================================================
	 * Lettura vendite e chiusura cassa
	 * ================================================================ */

	public static function get_sale( $id ) {
		global $wpdb;
		$s = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'sales' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $s ) {
			return null;
		}
		$s = self::sale_out( $s );
		$s['lines'] = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'sale_lines' ) . ' WHERE sale_id = %d ORDER BY id', $id ), ARRAY_A ); // phpcs:ignore
		foreach ( $s['lines'] as &$l ) {
			foreach ( array( 'qty', 'unit_price', 'discount', 'total' ) as $k ) {
				$l[ $k ] = (float) $l[ $k ];
			}
			$l['card_id'] = (int) $l['card_id'];
		}
		unset( $l );
		$s['coupon']        = $s['coupon_issued'] ? BHC_Messages::get_coupon( $s['coupon_issued'] ) : null;
		$s['coupon_used_c'] = $s['coupon_used'] ? BHC_Messages::get_coupon( $s['coupon_used'] ) : null;
		$rs                 = BHC_Messages::receipt_settings();
		$s['footer']        = $rs['footer'];
		$s['coupon_text']   = $rs['coupon_text'];
		// Saldi aggiornati delle card usate o emesse in questa vendita (per lo scontrino).
		$ids = array_filter( wp_list_pluck( $s['lines'], 'card_id' ) );
		$mv  = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT card_id FROM ' . bhc_table( 'card_moves' ) . ' WHERE note LIKE %s', '%' . $wpdb->esc_like( $s['number'] ) . '%' ) ); // phpcs:ignore
		$s['cards'] = array();
		foreach ( array_unique( array_map( 'intval', array_merge( $ids, $mv ) ) ) as $cid ) {
			$c = BHC_Cards::get( $cid );
			if ( $c ) {
				$s['cards'][] = array( 'type' => $c['type'], 'code' => $c['code'], 'balance' => $c['balance'], 'points' => $c['points'], 'sessions_left' => $c['sessions_left'] );
			}
		}
		return $s;
	}

	private static function sale_out( $s ) {
		foreach ( array( 'subtotal', 'discount', 'points_discount', 'coupon_discount', 'gift_used', 'total', 'cash', 'card', 'tendered', 'change_given', 'points_used', 'points_earned' ) as $k ) {
			$s[ $k ] = (float) $s[ $k ];
		}
		$s['id']            = (int) $s['id'];
		$s['client_id']     = (int) $s['client_id'];
		$s['sessions_used'] = (int) $s['sessions_used'];
		$s['coupon_used']   = (int) $s['coupon_used'];
		$s['coupon_issued'] = (int) $s['coupon_issued'];
		$u                  = $s['created_by'] ? get_userdata( (int) $s['created_by'] ) : null;
		$s['user']          = $u ? $u->display_name : '';
		return $s;
	}

	public static function day( $date ) {
		global $wpdb;
		$t     = bhc_table( 'sales' );
		$l     = bhc_table( 'sale_lines' );
		$from  = $date . ' 00:00:00';
		$to    = $date . ' 23:59:59';
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE created_at >= %s AND created_at <= %s ORDER BY id DESC", $from, $to ), ARRAY_A ); // phpcs:ignore
		$sales = array_map( array( __CLASS__, 'sale_out' ), $rows );
		$tot   = array( 'count' => count( $sales ), 'cash' => 0, 'card' => 0, 'gift_used' => 0, 'points_discount' => 0, 'coupon_discount' => 0, 'coupons_issued' => 0, 'discount' => 0, 'change' => 0, 'sessions' => 0 );
		foreach ( $sales as $s ) {
			$tot['cash']            += $s['cash'];
			$tot['card']            += $s['card'];
			$tot['gift_used']       += $s['gift_used'];
			$tot['points_discount'] += $s['points_discount'];
			$tot['coupon_discount'] += $s['coupon_discount'];
			$tot['coupons_issued']  += $s['coupon_issued'] ? 1 : 0;
			$tot['discount']        += $s['discount'];
			$tot['change']          += $s['change_given'];
			$tot['sessions']        += $s['sessions_used'];
		}
		$by_type = $wpdb->get_results( $wpdb->prepare( "SELECT l.type, SUM(l.qty) qty, SUM(l.total) total FROM {$l} l INNER JOIN {$t} s ON s.id = l.sale_id WHERE s.created_at >= %s AND s.created_at <= %s GROUP BY l.type", $from, $to ), ARRAY_A ); // phpcs:ignore
		foreach ( $by_type as &$b ) {
			$b['qty']   = (float) $b['qty'];
			$b['total'] = (float) $b['total'];
		}
		unset( $b );
		foreach ( $tot as $k => $v ) {
			$tot[ $k ] = round( $v, 2 );
		}
		$tot['takings'] = round( $tot['cash'] + $tot['card'], 2 );
		return array( 'date' => $date, 'sales' => $sales, 'totals' => $tot, 'by_type' => $by_type );
	}

	/* ==================================================================
	 * REST
	 * ================================================================ */

	public static function routes() {
		$ns   = BHC_REST::NS;
		$perm = BHC_Permissions::cb( array( 'pos' ) );
		register_rest_route( $ns, '/pos/bootstrap', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_bootstrap' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/pos/todo', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_todo' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/pos/client/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_client' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/pos/scan', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_scan' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/pos/clients', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_clients' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/pos/checkout', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_checkout' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/pos/sales', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_day' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/pos/sales/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_sale' ), 'permission_callback' => $perm ) );
	}

	private static function err( WP_Error $e, $status = 400 ) {
		return new WP_REST_Response( array( 'code' => $e->get_error_code(), 'message' => $e->get_error_message() ), $status );
	}

	private static function date_param( WP_REST_Request $r ) {
		$d = (string) $r->get_param( 'date' );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ? $d : current_time( 'Y-m-d' );
	}

	public static function rest_bootstrap( WP_REST_Request $r ) {
		return array(
			'date'     => self::date_param( $r ),
			'todo'     => self::to_cash( self::date_param( $r ) ),
			'products' => self::products(),
			'packages' => BHC_Cards::packages( true ),
			'loyalty'  => BHC_Cards::loyalty_settings(),
			'receipt'  => array( 'name' => bhc_get_option( 'center_name' ), 'phone' => bhc_get_option( 'center_phone' ), 'email' => bhc_get_option( 'center_email' ) ),
			'coupon'   => BHC_Messages::receipt_settings(),
		);
	}

	public static function rest_todo( WP_REST_Request $r ) {
		return array( 'todo' => self::to_cash( self::date_param( $r ) ), 'products' => self::products() );
	}

	public static function rest_client( WP_REST_Request $r ) {
		$c = BHC_Repository::get_client( (int) $r['id'] );
		if ( ! $c ) {
			return self::err( new WP_Error( 'not_found', __( 'Cliente non trovata.', 'beautyhub-core' ) ), 404 );
		}
		return array(
			'client' => array( 'id' => (int) $c['id'], 'name' => trim( $c['first_name'] . ' ' . $c['last_name'] ), 'phone' => $c['phone'], 'email' => $c['email'], 'notes' => $c['notes'] ?? '' ),
			'cards'  => BHC_Cards::search( array( 'client' => (int) $c['id'] ) ),
		);
	}

	public static function rest_clients( WP_REST_Request $r ) {
		$res = BHC_Repository::search_clients( (string) $r->get_param( 'q' ), 10, 0 );
		$out = array();
		foreach ( $res['items'] ?? $res as $c ) {
			$out[] = array( 'id' => (int) $c['id'], 'name' => trim( $c['first_name'] . ' ' . $c['last_name'] ), 'phone' => $c['phone'], 'email' => $c['email'] );
		}
		return array( 'items' => $out );
	}

	/** Lettore barcode: prodotto (EAN) o card (EAN/codice). */
	public static function rest_scan( WP_REST_Request $r ) {
		global $wpdb;
		$code = trim( (string) $r->get_param( 'code' ) );
		if ( '' === $code ) {
			return self::err( new WP_Error( 'empty', __( 'Codice vuoto.', 'beautyhub-core' ) ) );
		}
		$coupon = BHC_Messages::find_coupon( $code );
		if ( $coupon ) {
			return array( 'kind' => 'coupon', 'coupon' => $coupon );
		}
		$card = BHC_Cards::find( $code );
		if ( $card ) {
			return array( 'kind' => 'card', 'card' => $card );
		}
		$pid = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'products' ) . ' WHERE active = 1 AND (ean = %s OR sku = %s) LIMIT 1', preg_replace( '/\s/', '', $code ), $code ) ); // phpcs:ignore
		if ( $pid ) {
			foreach ( self::products() as $p ) {
				if ( $p['id'] === $pid ) {
					return array( 'kind' => 'product', 'product' => $p );
				}
			}
			return self::err( new WP_Error( 'consumo', __( 'Questo prodotto è per uso in cabina, non in vendita.', 'beautyhub-core' ) ) );
		}
		/* translators: %s: codice letto */
		return self::err( new WP_Error( 'unknown', sprintf( __( 'Nessun prodotto o card con codice %s.', 'beautyhub-core' ), $code ) ), 404 );
	}

	public static function rest_checkout( WP_REST_Request $r ) {
		$res = self::checkout( (array) $r->get_json_params() );
		return is_wp_error( $res ) ? self::err( $res ) : self::get_sale( $res );
	}

	public static function rest_day( WP_REST_Request $r ) {
		return self::day( self::date_param( $r ) );
	}

	public static function rest_sale( WP_REST_Request $r ) {
		$s = self::get_sale( (int) $r['id'] );
		return $s ? $s : self::err( new WP_Error( 'not_found', __( 'Vendita non trovata.', 'beautyhub-core' ) ), 404 );
	}
}
