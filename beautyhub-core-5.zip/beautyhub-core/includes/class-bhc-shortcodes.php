<?php
/**
 * Shortcode (usabili anche nel widget "Shortcode" di Elementor
 * o tramite i widget BeautyHub dedicati).
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Shortcodes {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_shortcode( 'bh_booking', array( __CLASS__, 'booking' ) );
		add_shortcode( 'bh_treatments', array( __CLASS__, 'treatments' ) );
		add_shortcode( 'bh_cabins', array( __CLASS__, 'cabins' ) );
		add_shortcode( 'bh_team', array( __CLASS__, 'cabins' ) );
		add_shortcode( 'bh_client_area', array( __CLASS__, 'client_area' ) );
		add_shortcode( 'bh_manage_booking', array( __CLASS__, 'manage_booking' ) );
		add_shortcode( 'bh_dashboard', array( __CLASS__, 'dashboard' ) );
	}

	public static function register_assets() {
		wp_register_style( 'bhc', BHC_URL . 'assets/css/bhc.css', array(), BHC_VERSION );
		wp_register_script( 'bhc-booking', BHC_URL . 'assets/js/booking.js', array(), BHC_VERSION, true );
		wp_register_script( 'bhc-dashboard', BHC_URL . 'assets/js/dashboard.js', array(), BHC_VERSION, true );

		$config = array(
			'rest'  => esc_url_raw( rest_url( BHC_REST::NS . '/' ) ),
			'nonce' => wp_create_nonce( 'wp_rest' ),
			'data'  => BHC_URL . 'assets/data/',
		);
		wp_localize_script( 'bhc-booking', 'BHC', $config );
		wp_localize_script( 'bhc-dashboard', 'BHC', $config );
	}

	/**
	 * Carica gli asset anche dentro l'editor di Elementor.
	 */
	private static function enqueue( $script = '' ) {
		if ( ! wp_style_is( 'bhc', 'registered' ) ) {
			self::register_assets();
		}
		wp_enqueue_style( 'bhc' );
		if ( $script ) {
			wp_enqueue_script( $script );
		}
	}

	/**
	 * [bh_booking treatment="ID" staff="ID" title="..."]
	 */
	public static function booking( $atts ) {
		$atts = shortcode_atts(
			array(
				'treatment' => '',
				'staff'     => '',
				'title'     => '',
			),
			$atts,
			'bh_booking'
		);
		self::enqueue( 'bhc-booking' );
		$treatment = absint( $atts['treatment'] ? $atts['treatment'] : ( isset( $_GET['trattamento'] ) ? wp_unslash( $_GET['trattamento'] ) : 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification
		ob_start();
		?>
		<div class="bhc bhc-booking" data-treatment="<?php echo esc_attr( $treatment ); ?>" data-staff="<?php echo esc_attr( absint( $atts['staff'] ) ); ?>">
			<?php if ( $atts['title'] ) : ?>
				<h2 class="bhc-booking__title"><?php echo esc_html( $atts['title'] ); ?></h2>
			<?php endif; ?>
			<div class="bhc-booking__app"><div class="bhc-loading"><?php esc_html_e( 'Caricamento…', 'beautyhub-core' ); ?></div></div>
			<noscript><?php esc_html_e( 'Per prenotare online attiva JavaScript, oppure chiamaci.', 'beautyhub-core' ); ?></noscript>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * [bh_treatments category="slug" layout="cards|list" price="yes" book="yes"]
	 */
	public static function treatments( $atts ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'layout'   => 'list',
				'price'    => 'yes',
				'book'     => 'yes',
				'image'    => 'yes',
			),
			$atts,
			'bh_treatments'
		);
		self::enqueue();

		$args = array(
			'post_type'   => 'bh_treatment',
			'post_status' => 'publish',
			'numberposts' => -1,
			'orderby'     => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		);
		if ( $atts['category'] ) {
			$args['tax_query'] = array( array( 'taxonomy' => 'bh_treatment_cat', 'field' => 'slug', 'terms' => array_map( 'trim', explode( ',', $atts['category'] ) ) ) ); // phpcs:ignore
		}
		$groups = array();
		foreach ( get_posts( $args ) as $p ) {
			$t                             = bhc_treatment_data( $p );
			$groups[ $t['category'] ?: __( 'Trattamenti', 'beautyhub-core' ) ][] = $t;
		}

		$book_page = (int) get_option( 'beautyhub_page_booking' );
		$book_url  = $book_page ? get_permalink( $book_page ) : '';

		ob_start();
		echo '<div class="bhc bhc-treatments bhc-treatments--' . esc_attr( 'cards' === $atts['layout'] ? 'cards' : 'list' ) . '">';
		foreach ( $groups as $cat => $items ) {
			if ( count( $groups ) > 1 ) {
				echo '<h3 class="bhc-treatments__cat">' . esc_html( $cat ) . '</h3>';
				$bhc_term = get_term_by( 'name', $cat, 'bh_treatment_cat' );
				if ( $bhc_term && $bhc_term->description ) {
					echo '<p class="bhc-treatments__catdesc">' . esc_html( $bhc_term->description ) . '</p>';
				}
			}
			echo '<div class="bhc-treatments__grid">';
			foreach ( $items as $t ) {
				echo '<article class="bhc-treatment">';
				if ( 'cards' === $atts['layout'] && 'yes' === $atts['image'] && $t['image'] ) {
					echo '<div class="bhc-treatment__img" style="background-image:url(' . esc_url( $t['image'] ) . ')"></div>';
				}
				echo '<div class="bhc-treatment__body">';
				echo '<div class="bhc-treatment__head"><h4>' . esc_html( $t['name'] ) . '</h4>';
				if ( 'yes' === $atts['price'] ) {
					echo '<span class="bhc-treatment__price">' . esc_html( bhc_price( $t['price'] ) ) . '</span>';
				}
				echo '</div>';
				echo '<div class="bhc-treatment__meta">' . esc_html( $t['duration'] . ' min' ) . '</div>';
				if ( $t['description'] ) {
					echo '<p>' . esc_html( $t['description'] ) . '</p>';
				}
				if ( 'yes' === $atts['book'] && $book_url && $t['online'] ) {
					echo '<a class="bhc-link" href="' . esc_url( add_query_arg( 'trattamento', $t['id'], $book_url ) ) . '">' . esc_html__( 'Prenota', 'beautyhub-core' ) . ' &rarr;</a>';
				}
				echo '</div></article>';
			}
			echo '</div>';
		}
		echo '</div>';
		return ob_get_clean();
	}

	/**
	 * [bh_cabins] – elenco cabine con i trattamenti possibili ([bh_team] resta come alias).
	 */
	public static function cabins( $atts ) {
		self::enqueue();
		$names = array();
		foreach ( bhc_get_treatments() as $t ) {
			$names[ $t['id'] ] = $t['name'];
		}
		ob_start();
		echo '<div class="bhc bhc-cabins-public">';
		foreach ( bhc_get_staff() as $c ) {
			echo '<div class="bhc-cabin-card"><div class="bhc-cabin-card__icon" style="background:' . esc_attr( $c['color'] ) . '">' . self::cabin_icon() . '</div>';
			echo '<h4>' . esc_html( $c['name'] ) . '</h4><p class="bhc-muted">';
			$list = $c['treatments'] ? array_intersect_key( $names, array_flip( $c['treatments'] ) ) : array( __( 'Tutti i trattamenti', 'beautyhub-core' ) );
			echo esc_html( implode( ' · ', $list ) );
			echo '</p></div>';
		}
		echo '</div>';
		return ob_get_clean();
	}

	/**
	 * Icona "cabina" (porta con lettino) in SVG.
	 */
	public static function cabin_icon() {
		return '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="#fff" stroke-width="1.6" aria-hidden="true"><path d="M4 21V4a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v17"/><path d="M2 21h20"/><path d="M7 15h10v3H7z"/><circle cx="9" cy="10" r="1.6"/><path d="M12 10h5"/></svg>';
	}

	/**
	 * [bh_client_area]
	 */
	public static function client_area() {
		self::enqueue();
		ob_start();
		echo '<div class="bhc bhc-client">';
		if ( ! is_user_logged_in() ) {
			echo '<div class="bhc-box"><h3>' . esc_html__( 'Accedi alla tua area', 'beautyhub-core' ) . '</h3>';
			wp_login_form( array( 'redirect' => get_permalink(), 'label_username' => __( 'Email o nome utente', 'beautyhub-core' ) ) );
			if ( get_option( 'users_can_register' ) ) {
				echo '<p><a href="' . esc_url( wp_registration_url() ) . '">' . esc_html__( 'Non hai un account? Registrati', 'beautyhub-core' ) . '</a></p>';
			}
			echo '<p><a href="' . esc_url( wp_lostpassword_url( get_permalink() ) ) . '">' . esc_html__( 'Password dimenticata?', 'beautyhub-core' ) . '</a></p></div>';
		} else {
			$user   = wp_get_current_user();
			$client = BHC_Repository::find_client_by_user( $user->ID );
			if ( ! $client ) {
				$client = BHC_Repository::find_client_by_email( $user->user_email );
				if ( $client && ! (int) $client['user_id'] ) {
					BHC_Repository::save_client( array( 'user_id' => $user->ID ), $client['id'] );
				}
			}
			/* translators: %s: nome */
			echo '<h3>' . esc_html( sprintf( __( 'Ciao %s', 'beautyhub-core' ), $user->first_name ? $user->first_name : $user->display_name ) ) . '</h3>';
			$book = (int) get_option( 'beautyhub_page_booking' );
			if ( $book ) {
				echo '<p><a class="bhc-btn" href="' . esc_url( get_permalink( $book ) ) . '">' . esc_html__( 'Prenota un nuovo trattamento', 'beautyhub-core' ) . '</a></p>';
			}
			$items    = $client ? BHC_Repository::client_appointments( $client['id'], 50 ) : array();
			$now      = current_time( 'mysql' );
			$upcoming = array_reverse( array_filter( $items, function ( $a ) use ( $now ) { return $a['start_at'] >= $now && in_array( $a['status'], array( 'booked', 'confirmed' ), true ); } ) );
			$past     = array_filter( $items, function ( $a ) use ( $now ) { return $a['start_at'] < $now && 'done' === $a['status']; } );
			$statuses = bhc_statuses();

			echo '<h4>' . esc_html__( 'Prossimi appuntamenti', 'beautyhub-core' ) . '</h4>';
			if ( $upcoming ) {
				echo '<ul class="bhc-list">';
				foreach ( $upcoming as $a ) {
					echo '<li><strong>' . esc_html( date_i18n( 'D j M Y', strtotime( $a['date'] ) ) . ' · ' . $a['start'] ) . '</strong> — ' . esc_html( $a['treatment_name'] );
					echo ' <span class="bhc-badge bhc-badge--' . esc_attr( $a['status'] ) . '">' . esc_html( $statuses[ $a['status'] ] ) . '</span>';
					echo ' <a href="' . esc_url( BHC_Emails::manage_url( $a['id'] ) ) . '">' . esc_html__( 'Gestisci', 'beautyhub-core' ) . '</a></li>';
				}
				echo '</ul>';
			} else {
				echo '<p class="bhc-muted">' . esc_html__( 'Nessun appuntamento in programma.', 'beautyhub-core' ) . '</p>';
			}
			if ( $past ) {
				echo '<h4>' . esc_html__( 'Trattamenti effettuati', 'beautyhub-core' ) . '</h4><ul class="bhc-list">';
				foreach ( array_slice( $past, 0, 20 ) as $a ) {
					echo '<li>' . esc_html( date_i18n( 'j M Y', strtotime( $a['date'] ) ) ) . ' — ' . esc_html( $a['treatment_name'] ) . '</li>';
				}
				echo '</ul>';
			}
			echo '<p><a href="' . esc_url( wp_logout_url( get_permalink() ) ) . '">' . esc_html__( 'Esci', 'beautyhub-core' ) . '</a></p>';
		}
		echo '</div>';
		return ob_get_clean();
	}

	/**
	 * [bh_manage_booking] – pagina raggiunta dal link nelle email.
	 */
	public static function manage_booking() {
		self::enqueue( 'bhc-booking' );
		$token = isset( $_GET['bh'] ) ? sanitize_text_field( wp_unslash( $_GET['bh'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$a     = $token ? BHC_Repository::get_appointment_by_token( $token ) : null;
		ob_start();
		echo '<div class="bhc bhc-manage"><div class="bhc-box">';
		if ( ! $a ) {
			echo '<p>' . esc_html__( 'Prenotazione non trovata. Controlla il link ricevuto via email.', 'beautyhub-core' ) . '</p>';
		} else {
			$statuses = bhc_statuses();
			echo '<h3>' . esc_html( $a['treatment_name'] ) . '</h3>';
			echo '<p>' . esc_html( date_i18n( 'l j F Y', strtotime( $a['date'] ) ) . ' ' . __( 'alle', 'beautyhub-core' ) . ' ' . $a['start'] );
			echo '</p><p><span class="bhc-badge bhc-badge--' . esc_attr( $a['status'] ) . '">' . esc_html( $statuses[ $a['status'] ] ) . '</span></p>';
			if ( in_array( $a['status'], array( 'booked', 'confirmed' ), true ) ) {
				echo '<p><button type="button" class="bhc-btn bhc-btn--ghost" data-bh-cancel="' . esc_attr( $token ) . '">' . esc_html__( 'Annulla appuntamento', 'beautyhub-core' ) . '</button></p>';
				echo '<p class="bhc-msg" role="status"></p>';
				/* translators: %d: ore */
				echo '<p class="bhc-muted">' . esc_html( sprintf( __( 'Puoi annullare online fino a %d ore prima. Per spostare l\'appuntamento annullalo e prenotane uno nuovo, oppure chiamaci.', 'beautyhub-core' ), (int) bhc_get_option( 'cancel_hours', 24 ) ) ) . '</p>';
			}
		}
		echo '</div></div>';
		return ob_get_clean();
	}

	/**
	 * [bh_dashboard] – gestionale dello staff.
	 */
	public static function dashboard() {
		self::enqueue();
		if ( ! is_user_logged_in() ) {
			ob_start();
			echo '<div class="bhc bhc-login-screen"><div class="bhc-box"><h2>' . esc_html( bhc_get_option( 'center_name' ) ) . '</h2><p class="bhc-muted">' . esc_html__( 'Accesso riservato allo staff', 'beautyhub-core' ) . '</p>';
			wp_login_form( array( 'redirect' => get_permalink() ) );
			echo '</div></div>';
			return ob_get_clean();
		}
		if ( ! bhc_is_staff() ) {
			return '<div class="bhc"><div class="bhc-box">' . esc_html__( 'Non hai i permessi per accedere al gestionale.', 'beautyhub-core' ) . '</div></div>';
		}
		wp_enqueue_script( 'bhc-dashboard' );
		return '<div class="bhc bhc-app" id="bhc-app"><div class="bhc-loading">' . esc_html__( 'Caricamento gestionale…', 'beautyhub-core' ) . '</div></div>';
	}
}
