<?php
/**
 * Menu di amministrazione.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Admin {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( BHC_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function menu() {
		add_menu_page( 'BeautyHub', 'BeautyHub', 'manage_options', 'beautyhub', array( __CLASS__, 'overview' ), 'dashicons-heart', 3 );
		add_submenu_page( 'beautyhub', __( 'Panoramica', 'beautyhub-core' ), __( 'Panoramica', 'beautyhub-core' ), 'manage_options', 'beautyhub', array( __CLASS__, 'overview' ) );
		add_submenu_page( 'beautyhub', __( 'Categorie trattamenti', 'beautyhub-core' ), __( 'Categorie', 'beautyhub-core' ), 'manage_categories', 'edit-tags.php?taxonomy=bh_treatment_cat&post_type=bh_treatment' );
		add_submenu_page( 'beautyhub', __( 'Impostazioni', 'beautyhub-core' ), __( 'Impostazioni', 'beautyhub-core' ), 'manage_options', 'beautyhub-settings', array( 'BHC_Settings', 'render_page' ) );
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=beautyhub-settings' ) ) . '">' . esc_html__( 'Impostazioni', 'beautyhub-core' ) . '</a>' );
		return $links;
	}

	public static function overview() {
		$dash  = (int) get_option( 'beautyhub_page_dashboard' );
		$book  = (int) get_option( 'beautyhub_page_booking' );
		$today = BHC_Repository::get_appointments( current_time( 'Y-m-d' ), current_time( 'Y-m-d' ), 0, false );
		?>
		<div class="wrap">
			<h1>BeautyHub</h1>
			<div style="display:flex;gap:16px;flex-wrap:wrap;margin:20px 0">
				<div class="card" style="max-width:none;flex:1;min-width:240px">
					<h2><?php esc_html_e( 'Gestionale', 'beautyhub-core' ); ?></h2>
					<p><?php esc_html_e( 'Agenda, clienti, incassi e report si gestiscono dal gestionale front-end, pensato anche per tablet.', 'beautyhub-core' ); ?></p>
					<?php if ( $dash ) : ?>
						<p><a class="button button-primary button-hero" href="<?php echo esc_url( get_permalink( $dash ) ); ?>"><?php esc_html_e( 'Apri il gestionale', 'beautyhub-core' ); ?></a></p>
					<?php endif; ?>
				</div>
				<div class="card" style="max-width:none;flex:1;min-width:240px">
					<h2><?php esc_html_e( 'Oggi', 'beautyhub-core' ); ?></h2>
					<p style="font-size:42px;margin:10px 0"><?php echo esc_html( count( $today ) ); ?></p>
					<p><?php esc_html_e( 'appuntamenti in agenda', 'beautyhub-core' ); ?></p>
				</div>
			</div>
			<div class="card" style="max-width:none">
				<h2><?php esc_html_e( 'Primi passi', 'beautyhub-core' ); ?></h2>
				<ol>
					<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=beautyhub-settings' ) ); ?>"><?php esc_html_e( 'Imposta dati, orari e regole di prenotazione del centro', 'beautyhub-core' ); ?></a></li>
					<li><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=bh_treatment' ) ); ?>"><?php esc_html_e( 'Rivedi i trattamenti di esempio (durata, prezzo, foto)', 'beautyhub-core' ); ?></a></li>
					<li><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=bh_staff' ) ); ?>"><?php esc_html_e( 'Inserisci le cabine con i trattamenti possibili (anche dal gestionale, sezione Cabine)', 'beautyhub-core' ); ?></a></li>
					<li><a href="<?php echo esc_url( admin_url( 'user-new.php' ) ); ?>"><?php esc_html_e( 'Crea gli accessi dello staff con i ruoli Titolare centro, Reception o Operatrice', 'beautyhub-core' ); ?></a></li>
					<li><?php esc_html_e( 'Costruisci la home con Elementor usando i widget della categoria "BeautyHub"', 'beautyhub-core' ); ?></li>
					<?php if ( $book ) : ?>
						<li><a href="<?php echo esc_url( get_permalink( $book ) ); ?>" target="_blank"><?php esc_html_e( 'Prova una prenotazione online', 'beautyhub-core' ); ?></a></li>
					<?php endif; ?>
				</ol>
				<p><strong><?php esc_html_e( 'Shortcode disponibili', 'beautyhub-core' ); ?>:</strong> <code>[bh_booking]</code> <code>[bh_treatments]</code> <code>[bh_cabins]</code> <code>[bh_client_area]</code> <code>[bh_dashboard]</code> <code>[bh_manage_booking]</code></p>
			</div>
		</div>
		<?php
	}
}
