<?php
/**
 * Orari e timbrature (ispirato a PeopleHub): turni settimanali e variazioni (ferie, permessi,
 * malattia, riposo, turno diverso), timbratrice su tablet con PIN, foglio presenze e cartellino,
 * anomalie con giustificativi, riepilogo ferie e permessi.
 *
 * L'orario standard è quello della scheda del personale (campo "Orari").
 * Le variazioni valgono anche per la disponibilità delle operatrici in agenda.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Time {

	const OPT = 'bhc_time';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'kiosk_page' ), 1 );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'time_vars' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			day date NOT NULL,
			type varchar(20) NOT NULL DEFAULT '',
			ranges varchar(120) NOT NULL DEFAULT '',
			note varchar(255) NOT NULL DEFAULT '',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY person_day (person_id,day)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'punches' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			ts datetime NOT NULL,
			kind varchar(10) NOT NULL DEFAULT 'in',
			source varchar(10) NOT NULL DEFAULT 'tablet',
			note varchar(255) NOT NULL DEFAULT '',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY person_ts (person_id,ts)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'justifications' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			day date NOT NULL,
			kind varchar(30) NOT NULL DEFAULT '',
			reason varchar(60) NOT NULL DEFAULT '',
			note varchar(255) NOT NULL DEFAULT '',
			status varchar(15) NOT NULL DEFAULT 'approvata',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY pdk (person_id,day,kind)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'leave_balances' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			year smallint(5) unsigned NOT NULL DEFAULT 0,
			type varchar(20) NOT NULL DEFAULT '',
			carry decimal(8,2) NOT NULL DEFAULT 0,
			entitlement decimal(8,2) DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY pyt (person_id,year,type)
			) {$c};"
		);
		// PIN della timbratrice (impronta, mai in chiaro).
		$p = bhc_table( 'people' );
		if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$p} LIKE %s", 'pin_hash' ) ) ) { // phpcs:ignore
			$wpdb->query( "ALTER TABLE {$p} ADD pin_hash varchar(64) NOT NULL DEFAULT ''" ); // phpcs:ignore
		}
	}

	/* ==================================================================
	 * Impostazioni e tipi
	 * ================================================================ */

	public static function settings() {
		return wp_parse_args(
			get_option( self::OPT, array() ),
			array(
				'tolerance'   => 10,
				'kiosk_token' => '',
				'ferie_days'  => 26,
				'rol_hours'   => 72,
				'exf_hours'   => 32,
				'full_hours'  => 40,
			)
		);
	}

	/** Tipi di variazione: [nome, colore, unità di godimento]. */
	public static function types() {
		return array(
			'ferie'      => array( 'Ferie', '#7d8c6f', 'giorni' ),
			'rol'        => array( 'ROL', '#5f8ba8', 'ore' ),
			'exfest'     => array( 'Permesso ex festività', '#5f6b7a', 'ore' ),
			'permesso'   => array( 'Altro permesso', '#8a6fa8', 'ore' ),
			'malattia'   => array( 'Malattia', '#b55448', 'giorni' ),
			'infortunio' => array( 'Infortunio', '#a23b2f', 'giorni' ),
			'riposo'     => array( 'Riposo', '#9a958a', '' ),
			'formazione' => array( 'Formazione / corso', '#c49a3a', 'ore' ),
			'turno'      => array( 'Turno diverso', '#b0735a', '' ),
		);
	}

	public static function anomaly_types() {
		return array(
			'ritardo'            => 'Entrata in ritardo',
			'rientro_ritardo'    => 'Rientro dalla pausa in ritardo',
			'uscita_anticipata'  => 'Uscita anticipata',
			'uscita_posticipata' => 'Uscita oltre l\'orario',
			'mancante'           => 'Timbratura mancante',
			'assenza'            => 'Assenza non registrata',
			'non_prevista'       => 'Timbratura in un giorno non lavorativo',
		);
	}

	public static function reasons() {
		return array( 'Traffico o mezzi pubblici', 'Permesso concordato', 'Visita medica', 'Straordinario richiesto', 'Recupero ore', 'Dimenticata la timbratura', 'Cliente in ritardo / trattamento prolungato', 'Motivi personali', 'Altro' );
	}

	/* ==================================================================
	 * Fasce orarie
	 * ================================================================ */

	public static function hm( $t ) {
		list( $h, $m ) = array_map( 'intval', explode( ':', $t ) + array( 0, 0 ) );
		return $h * 60 + $m;
	}
	public static function fmt( $min ) {
		$min = (int) round( $min );
		return str_pad( (string) intdiv( $min, 60 ), 2, '0', STR_PAD_LEFT ) . ':' . str_pad( (string) ( $min % 60 ), 2, '0', STR_PAD_LEFT );
	}
	/** "09:00-13:00, 14:00-19:00" → [[540,780],[840,1140]] */
	public static function parse( $s ) {
		$out = array();
		foreach ( preg_split( '/[,;]+/', (string) $s ) as $p ) {
			if ( preg_match( '/(\d{1,2})[:.](\d{2})\s*[-–]\s*(\d{1,2})[:.](\d{2})/', $p, $m ) ) {
				$a = $m[1] * 60 + $m[2];
				$b = $m[3] * 60 + $m[4];
				if ( $b > $a && $b <= 1440 ) {
					$out[] = array( $a, $b );
				}
			}
		}
		usort(
			$out,
			function ( $x, $y ) {
				return $x[0] - $y[0];
			}
		);
		return $out;
	}
	public static function to_text( $ranges ) {
		return implode(
			', ',
			array_map(
				function ( $r ) {
					return BHC_Time::fmt( $r[0] ) . '-' . BHC_Time::fmt( $r[1] );
				},
				$ranges
			)
		);
	}
	public static function minutes( $ranges ) {
		$t = 0;
		foreach ( $ranges as $r ) {
			$t += $r[1] - $r[0];
		}
		return $t;
	}
	public static function subtract( $ranges, $remove ) {
		foreach ( $remove as $t ) {
			$new = array();
			foreach ( $ranges as $r ) {
				if ( $t[1] <= $r[0] || $t[0] >= $r[1] ) {
					$new[] = $r;
					continue;
				}
				if ( $t[0] > $r[0] ) {
					$new[] = array( $r[0], $t[0] );
				}
				if ( $t[1] < $r[1] ) {
					$new[] = array( $t[1], $r[1] );
				}
			}
			$ranges = $new;
		}
		return $ranges;
	}

	/* ==================================================================
	 * Orario previsto
	 * ================================================================ */

	private static $var_cache = array();

	public static function standard( array $p, $date ) {
		$dow = (int) gmdate( 'N', strtotime( $date . ' 12:00:00' ) );
		$s   = (array) ( $p['schedule'] ?? array() );
		return self::parse( $s[ $dow ] ?? ( $s[ (string) $dow ] ?? '' ) );
	}

	public static function vars( $person_id, $from, $to ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'time_vars' ) . ' WHERE person_id = %d AND day >= %s AND day <= %s ORDER BY day', $person_id, $from, $to ), ARRAY_A ); // phpcs:ignore
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ $r['day'] ] = $r;
		}
		return $out;
	}

	/**
	 * Orario previsto di un giorno.
	 * @return array type (standard|tipo variazione), ranges (minuti da lavorare), absence (fasce di permesso), note, var_id
	 */
	public static function day( array $p, $date, $var = null ) {
		if ( null === $var ) {
			$key = $p['id'] . '|' . $date;
			if ( ! array_key_exists( $key, self::$var_cache ) ) {
				$v                       = self::vars( $p['id'], $date, $date );
				self::$var_cache[ $key ] = $v[ $date ] ?? false;
			}
			$var = self::$var_cache[ $key ];
		}
		$std = self::standard( $p, $date );
		if ( ! $var ) {
			return array( 'type' => 'standard', 'ranges' => $std, 'absence' => array(), 'note' => '', 'var_id' => 0, 'std' => $std );
		}
		$vr = self::parse( $var['ranges'] );
		if ( 'turno' === $var['type'] ) {
			$ranges = $vr;
			$abs    = array();
		} elseif ( $vr ) {
			// Permesso per una parte della giornata.
			$ranges = self::subtract( $std, $vr );
			$abs    = $vr;
		} else {
			$ranges = array();
			$abs    = $std;
		}
		return array( 'type' => $var['type'], 'ranges' => $ranges, 'absence' => $abs, 'note' => $var['note'], 'var_id' => (int) $var['id'], 'std' => $std, 'partial' => (bool) $vr && 'turno' !== $var['type'] );
	}

	public static function people( $only_active = true ) {
		$list = BHC_People::search( '', '', $only_active ? 'attivo' : '' );
		return $list;
	}

	/* ==================================================================
	 * Variazioni
	 * ================================================================ */

	public static function set_var( $person_id, $from, $to, $type, $ranges, $note, $overwrite = true ) {
		global $wpdb;
		if ( ! isset( self::types()[ $type ] ) ) {
			return new WP_Error( 'type', __( 'Tipo non valido.', 'beautyhub-core' ) );
		}
		$p = BHC_People::get( $person_id );
		if ( ! $p ) {
			return new WP_Error( 'person', __( 'Persona non trovata.', 'beautyhub-core' ) );
		}
		$r = self::parse( $ranges );
		if ( 'turno' === $type && ! $r ) {
			return new WP_Error( 'ranges', __( 'Per il turno diverso indica l\'orario (es. 10:00-14:00, 15:00-19:00).', 'beautyhub-core' ) );
		}
		$d = $from;
		$n = 0;
		$i = 0;
		while ( $d <= $to && $i++ < 400 ) {
			$std = self::standard( $p, $d );
			// Le assenze a giornata intera saltano i giorni di riposo; malattia e infortunio contano tutti i giorni di calendario.
			$skip = ! $std && ! $r && ! in_array( $type, array( 'malattia', 'infortunio', 'riposo' ), true );
			if ( ! $skip ) {
				$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'time_vars' ) . ' WHERE person_id = %d AND day = %s', $person_id, $d ) ); // phpcs:ignore
				if ( $exists && ! $overwrite ) {
					$d = gmdate( 'Y-m-d', strtotime( $d . ' +1 day' ) );
					continue;
				}
				$row = array( 'person_id' => $person_id, 'day' => $d, 'type' => $type, 'ranges' => self::to_text( $r ), 'note' => sanitize_text_field( $note ), 'created_by' => get_current_user_id(), 'created_at' => current_time( 'mysql' ) );
				if ( $exists ) {
					$wpdb->update( bhc_table( 'time_vars' ), $row, array( 'id' => (int) $exists ) );
				} else {
					$wpdb->insert( bhc_table( 'time_vars' ), $row );
				}
				$n++;
			}
			$d = gmdate( 'Y-m-d', strtotime( $d . ' +1 day' ) );
		}
		self::$var_cache = array();
		return $n;
	}

	public static function del_var( $person_id, $from, $to ) {
		global $wpdb;
		self::$var_cache = array();
		return $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . bhc_table( 'time_vars' ) . ' WHERE person_id = %d AND day >= %s AND day <= %s', $person_id, $from, $to ) ); // phpcs:ignore
	}

	/** Settimana di tutto il personale. */
	public static function week( $monday ) {
		$days = array();
		for ( $i = 0; $i < 7; $i++ ) {
			$days[] = gmdate( 'Y-m-d', strtotime( $monday . ' +' . $i . ' days' ) );
		}
		$out = array();
		foreach ( self::people() as $p ) {
			$vars  = self::vars( $p['id'], $days[0], $days[6] );
			$cells = array();
			$tot   = 0;
			foreach ( $days as $d ) {
				$x       = self::day( $p, $d, $vars[ $d ] ?? false );
				$tot    += self::minutes( $x['ranges'] );
				$cells[] = array( 'date' => $d, 'type' => $x['type'], 'text' => self::to_text( $x['ranges'] ), 'abs' => self::to_text( $x['absence'] ), 'note' => $x['note'], 'partial' => ! empty( $x['partial'] ), 'minutes' => self::minutes( $x['ranges'] ) );
			}
			$out[] = array( 'id' => $p['id'], 'name' => trim( $p['first_name'] . ' ' . $p['last_name'] ), 'role' => $p['role'], 'job' => $p['job_title'], 'color' => $p['color'], 'cells' => $cells, 'total' => $tot, 'has_schedule' => (bool) array_filter( array_map( 'trim', (array) $p['schedule'] ) ) );
		}
		return array( 'days' => $days, 'people' => $out );
	}

	/* ==================================================================
	 * Timbrature
	 * ================================================================ */

	public static function punch( $person_id, $kind, $ts, $source = 'tablet', $note = '' ) {
		global $wpdb;
		$wpdb->insert(
			bhc_table( 'punches' ),
			array( 'person_id' => (int) $person_id, 'ts' => $ts, 'kind' => 'out' === $kind ? 'out' : 'in', 'source' => $source, 'note' => sanitize_text_field( $note ), 'created_by' => get_current_user_id(), 'created_at' => current_time( 'mysql' ) )
		);
		return (int) $wpdb->insert_id;
	}

	public static function punches( $person_id, $from, $to ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, ts, kind, source, note FROM ' . bhc_table( 'punches' ) . ' WHERE person_id = %d AND ts >= %s AND ts <= %s ORDER BY ts, id', $person_id, $from . ' 00:00:00', $to . ' 23:59:59' ), ARRAY_A ); // phpcs:ignore
		$out  = array();
		foreach ( $rows as $r ) {
			$r['id']                         = (int) $r['id'];
			$r['time']                       = substr( $r['ts'], 11, 5 );
			$out[ substr( $r['ts'], 0, 10 ) ][] = $r;
		}
		return $out;
	}

	/** Coppie entrata/uscita di una giornata. */
	public static function pairs( $rows ) {
		$pairs = array();
		$open  = null;
		foreach ( (array) $rows as $r ) {
			if ( 'in' === $r['kind'] ) {
				if ( null !== $open ) {
					$pairs[] = array( $open, null );
				}
				$open = $r;
			} else {
				$pairs[] = array( $open, $r );
				$open    = null;
			}
		}
		if ( null !== $open ) {
			$pairs[] = array( $open, null );
		}
		return $pairs;
	}

	/** Minuti lavorati (con l'entrata aperta di oggi conteggiata fino ad ora). */
	public static function worked( $rows, $date ) {
		$min  = 0;
		$open = false;
		foreach ( self::pairs( $rows ) as $pp ) {
			if ( $pp[0] && $pp[1] ) {
				$min += max( 0, self::hm( $pp[1]['time'] ) - self::hm( $pp[0]['time'] ) );
			} elseif ( $pp[0] && ! $pp[1] && current_time( 'Y-m-d' ) === $date ) {
				$min += max( 0, self::hm( current_time( 'H:i' ) ) - self::hm( $pp[0]['time'] ) );
				$open = true;
			}
		}
		return array( $min, $open );
	}

	/** Anomalie di una giornata, confrontando timbrature e orario previsto. */
	public static function anomalies( $day, $date, $rows ) {
		$today = current_time( 'Y-m-d' );
		$now   = self::hm( current_time( 'H:i' ) );
		$tol   = (int) self::settings()['tolerance'];
		$f     = $day['ranges'];
		$out   = array();
		$add   = function ( $k, $min, $txt ) use ( &$out ) {
			if ( isset( $out[ $k ] ) ) {
				$out[ $k ]['min'] += $min;
				$out[ $k ]['text'] .= '; ' . $txt;
				return;
			}
			$out[ $k ] = array( 'kind' => $k, 'min' => $min, 'text' => $txt );
		};
		if ( $date > $today ) {
			return array();
		}
		if ( $rows && ! $f ) {
			$add( 'non_prevista', 0, 'Timbrature in un giorno di ' . ( 'standard' === $day['type'] ? 'riposo' : strtolower( self::types()[ $day['type'] ][0] ?? $day['type'] ) ) );
			return array_values( $out );
		}
		if ( ! $f ) {
			return array();
		}
		$last_end = end( $f )[1];
		if ( ! $rows ) {
			if ( $date < $today || $now > $last_end ) {
				$add( 'assenza', self::minutes( $f ), 'Nessuna timbratura (previsto ' . self::to_text( $f ) . ')' );
			}
			return array_values( $out );
		}
		$pairs = self::pairs( $rows );
		foreach ( $pairs as $pp ) {
			if ( ! $pp[0] ) {
				$add( 'mancante', 0, 'Uscita alle ' . $pp[1]['time'] . ' senza entrata' );
			} elseif ( ! $pp[1] && $date < $today ) {
				$add( 'mancante', 0, 'Entrata alle ' . $pp[0]['time'] . ' senza uscita' );
			}
		}
		$nf = count( $f );
		$nc = count( $pairs );
		if ( $nc <= $nf ) {
			$match = array();
			foreach ( $pairs as $i => $pp ) {
				$match[] = array( $pp, $f[ $i ], $i, $i === $nf - 1 );
			}
		} else {
			$match = array( array( array( $pairs[0][0], null ), $f[0], 0, false ), array( array( null, $pairs[ $nc - 1 ][1] ), $f[ $nf - 1 ], $nf - 1, true ) );
		}
		foreach ( $match as $mm ) {
			list( $pp, $ff, $i, $last ) = $mm;
			if ( $pp[0] ) {
				$late = self::hm( $pp[0]['time'] ) - $ff[0];
				if ( $late > $tol ) {
					$add( 0 === $i ? 'ritardo' : 'rientro_ritardo', $late, 'Entrata alle ' . $pp[0]['time'] . ' invece delle ' . self::fmt( $ff[0] ) );
				}
			}
			if ( $pp[1] ) {
				$diff = self::hm( $pp[1]['time'] ) - $ff[1];
				if ( $diff < -$tol ) {
					$add( 'uscita_anticipata', -$diff, 'Uscita alle ' . $pp[1]['time'] . ' invece delle ' . self::fmt( $ff[1] ) );
				} elseif ( $diff > $tol && $last ) {
					$add( 'uscita_posticipata', $diff, 'Uscita alle ' . $pp[1]['time'] . ' invece delle ' . self::fmt( $ff[1] ) );
				}
			}
		}
		if ( $nc < $nf && ( $date < $today || $now > $last_end ) && ! isset( $out['mancante'] ) ) {
			$miss = array_slice( $f, $nc );
			$add( 'uscita_anticipata', self::minutes( $miss ), 'Non risulta il turno ' . self::to_text( $miss ) );
		}
		return array_values( $out );
	}

	public static function justifications( $person_id, $from, $to ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'justifications' ) . ' WHERE person_id = %d AND day >= %s AND day <= %s', $person_id, $from, $to ), ARRAY_A ); // phpcs:ignore
		$out  = array();
		foreach ( $rows as $r ) {
			$out[ $r['day'] . '|' . $r['kind'] ] = $r;
		}
		return $out;
	}

	/** Foglio presenze di un mese per una persona. */
	public static function sheet( $person_id, $month ) {
		$p = BHC_People::get( $person_id );
		if ( ! $p ) {
			return null;
		}
		$from  = $month . '-01';
		$to    = gmdate( 'Y-m-t', strtotime( $from ) );
		$today = current_time( 'Y-m-d' );
		$vars  = self::vars( $person_id, $from, $to );
		$pun   = self::punches( $person_id, $from, $to );
		$just  = self::justifications( $person_id, $from, $to );
		$days  = array();
		$tot   = array( 'worked' => 0, 'expected' => 0, 'diff' => 0, 'anomalies' => 0, 'open' => 0, 'absences' => array() );
		$hire  = $p['hire_date'] ?: '0000-00-00';
		$end   = $p['end_date'] ?: '9999-12-31';
		for ( $d = $from; $d <= $to; $d = gmdate( 'Y-m-d', strtotime( $d . ' +1 day' ) ) ) {
			$active = $d >= $hire && $d <= $end;
			$x      = $active ? self::day( $p, $d, $vars[ $d ] ?? false ) : array( 'type' => 'standard', 'ranges' => array(), 'absence' => array(), 'note' => '', 'var_id' => 0 );
			$rows   = $pun[ $d ] ?? array();
			list( $w, $open ) = self::worked( $rows, $d );
			$exp    = self::minutes( $x['ranges'] );
			$counts = $d < $today || ( $d === $today && $rows && ! $open );
			$an     = $active ? self::anomalies( $x, $d, $rows ) : array();
			foreach ( $an as &$a ) {
				$j          = $just[ $d . '|' . $a['kind'] ] ?? null;
				$a['label'] = self::anomaly_types()[ $a['kind'] ];
				$a['just']  = $j ? array( 'reason' => $j['reason'], 'note' => $j['note'], 'status' => $j['status'] ) : null;
				if ( ! $j || 'respinta' === $j['status'] ) {
					$tot['open']++;
				}
			}
			unset( $a );
			$tot['anomalies'] += count( $an );
			if ( $counts ) {
				$tot['worked']   += $w;
				$tot['expected'] += $exp;
			}
			if ( 'standard' !== $x['type'] && 'turno' !== $x['type'] ) {
				$tot['absences'][ $x['type'] ] = ( $tot['absences'][ $x['type'] ] ?? 0 ) + 1;
			}
			$days[] = array(
				'date'     => $d,
				'type'     => $x['type'],
				'expected' => self::to_text( $x['ranges'] ),
				'absence'  => self::to_text( $x['absence'] ),
				'note'     => $x['note'],
				'punches'  => $rows,
				'worked'   => $w,
				'exp_min'  => $exp,
				'counts'   => $counts,
				'open'     => $open,
				'anomalies' => $an,
			);
		}
		$tot['diff'] = $tot['worked'] - $tot['expected'];
		return array( 'person' => array( 'id' => $p['id'], 'name' => trim( $p['first_name'] . ' ' . $p['last_name'] ), 'job' => $p['job_title'], 'role' => $p['role'], 'schedule' => $p['schedule'], 'hire_date' => $p['hire_date'] ), 'month' => $month, 'days' => $days, 'totals' => $tot );
	}

	/** Riepilogo del mese di tutto il personale. */
	public static function month_summary( $month ) {
		$out = array();
		foreach ( self::people( false ) as $p ) {
			if ( 'cessato' === $p['status'] && $p['end_date'] && $p['end_date'] < $month . '-01' ) {
				continue;
			}
			$s     = self::sheet( $p['id'], $month );
			$out[] = array( 'id' => $p['id'], 'name' => $s['person']['name'], 'job' => $p['job_title'], 'color' => $p['color'], 'pin' => (bool) $p['pin_hash'], 'totals' => $s['totals'] );
		}
		return $out;
	}

	/** Chi è dentro adesso (ultima timbratura di oggi = entrata). */
	public static function present_now() {
		global $wpdb;
		$today = current_time( 'Y-m-d' );
		$t     = bhc_table( 'punches' );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT person_id, kind, ts FROM {$t} WHERE ts >= %s AND ts <= %s ORDER BY ts, id", $today . ' 00:00:00', $today . ' 23:59:59' ), ARRAY_A ); // phpcs:ignore
		$last  = array();
		foreach ( $rows as $r ) {
			$last[ (int) $r['person_id'] ] = $r;
		}
		$out = array();
		foreach ( $last as $pid => $r ) {
			if ( 'in' === $r['kind'] ) {
				$p     = BHC_People::get( $pid );
				$out[] = array( 'id' => $pid, 'name' => $p ? trim( $p['first_name'] . ' ' . $p['last_name'] ) : '#' . $pid, 'since' => substr( $r['ts'], 11, 5 ), 'color' => $p ? $p['color'] : '#999' );
			}
		}
		return $out;
	}

	/* ==================================================================
	 * Ferie e permessi
	 * ================================================================ */

	public static function leave_summary( $year ) {
		global $wpdb;
		$s     = self::settings();
		$today = current_time( 'Y-m-d' );
		$out   = array();
		$bal   = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'leave_balances' ) . ' WHERE year = %d', $year ), ARRAY_A ) as $b ) { // phpcs:ignore
			$bal[ $b['person_id'] . '|' . $b['type'] ] = $b;
		}
		foreach ( self::people( false ) as $p ) {
			if ( 'cessato' === $p['status'] && $p['end_date'] && $p['end_date'] < $year . '-01-01' ) {
				continue;
			}
			$vars  = self::vars( $p['id'], $year . '-01-01', $year . '-12-31' );
			$ratio = $p['weekly_hours'] > 0 ? min( 1, $p['weekly_hours'] / max( 1, (float) $s['full_hours'] ) ) : 1;
			// Mesi di servizio nell'anno (per la spettanza).
			$start  = max( $year . '-01-01', $p['hire_date'] ?: $year . '-01-01' );
			$finish = min( $year . '-12-31', $p['end_date'] ?: $year . '-12-31' );
			$months = $finish >= $start ? ( (int) substr( $finish, 5, 2 ) - (int) substr( $start, 5, 2 ) + 1 ) : 0;
			$used   = array();
			foreach ( $vars as $d => $v ) {
				$k     = $v['type'];
				$unit  = self::types()[ $k ][2] ?? '';
				if ( ! $unit ) {
					continue;
				}
				$day   = self::day( $p, $d, $v );
				$qty   = 'giorni' === $unit ? ( $day['partial'] ? 0 : 1 ) : self::minutes( $day['absence'] ) / 60;
				if ( 'giorni' === $unit && ! empty( $day['partial'] ) ) {
					$qty = round( self::minutes( $day['absence'] ) / max( 1, self::minutes( $day['std'] ) ), 2 );
				}
				$slot  = $d <= $today ? 'taken' : 'planned';
				$used[ $k ][ $slot ] = round( ( $used[ $k ][ $slot ] ?? 0 ) + $qty, 2 );
			}
			$rows = array();
			foreach ( array( 'ferie' => $s['ferie_days'], 'rol' => $s['rol_hours'], 'exfest' => $s['exf_hours'] ) as $k => $annual ) {
				$b     = $bal[ $p['id'] . '|' . $k ] ?? null;
				$ent   = null !== ( $b['entitlement'] ?? null ) ? (float) $b['entitlement'] : round( $annual * $ratio * $months / 12, 2 );
				$carry = $b ? (float) $b['carry'] : 0;
				$tk    = $used[ $k ]['taken'] ?? 0;
				$pl    = $used[ $k ]['planned'] ?? 0;
				$rows[ $k ] = array( 'unit' => self::types()[ $k ][2], 'carry' => $carry, 'entitlement' => $ent, 'taken' => $tk, 'planned' => $pl, 'balance' => round( $carry + $ent - $tk, 2 ), 'end' => round( $carry + $ent - $tk - $pl, 2 ) );
			}
			$other = array();
			foreach ( $used as $k => $u ) {
				if ( ! isset( $rows[ $k ] ) ) {
					$other[ $k ] = array( 'unit' => self::types()[ $k ][2], 'taken' => $u['taken'] ?? 0, 'planned' => $u['planned'] ?? 0 );
				}
			}
			$out[] = array( 'id' => $p['id'], 'name' => trim( $p['first_name'] . ' ' . $p['last_name'] ), 'ratio' => round( $ratio * 100 ), 'rows' => $rows, 'other' => $other );
		}
		return $out;
	}

	public static function leave_periods( $year, $person_id = 0 ) {
		global $wpdb;
		$t    = bhc_table( 'time_vars' );
		$args = array( $year . '-01-01', $year . '-12-31' );
		$sql  = "SELECT * FROM {$t} WHERE day >= %s AND day <= %s AND type <> 'turno'";
		if ( $person_id ) {
			$sql   .= ' AND person_id = %d';
			$args[] = $person_id;
		}
		$rows = $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY person_id, day', $args ), ARRAY_A ); // phpcs:ignore
		// Raggruppa giorni consecutivi con lo stesso tipo, fasce e nota.
		$out  = array();
		$cur  = null;
		foreach ( $rows as $r ) {
			$prev_day = $cur ? $cur['to'] : '';
			$gap      = $cur ? ( strtotime( $r['day'] ) - strtotime( $prev_day ) ) / DAY_IN_SECONDS : 99;
			if ( $cur && $cur['person_id'] === (int) $r['person_id'] && $cur['type'] === $r['type'] && $cur['ranges'] === $r['ranges'] && $cur['note'] === $r['note'] && $gap <= 3 ) {
				$cur['to'] = $r['day'];
				$cur['days']++;
				continue;
			}
			if ( $cur ) {
				$out[] = $cur;
			}
			$cur = array( 'person_id' => (int) $r['person_id'], 'type' => $r['type'], 'from' => $r['day'], 'to' => $r['day'], 'ranges' => $r['ranges'], 'note' => $r['note'], 'days' => 1 );
		}
		if ( $cur ) {
			$out[] = $cur;
		}
		foreach ( $out as &$o ) {
			$p         = BHC_People::get( $o['person_id'] );
			$o['name'] = $p ? trim( $p['first_name'] . ' ' . $p['last_name'] ) : '';
		}
		return $out;
	}

	/* ==================================================================
	 * PIN e timbratrice
	 * ================================================================ */

	public static function pin_hash( $pin ) {
		return hash_hmac( 'sha256', 'bhc-pin|' . $pin, wp_salt( 'auth' ) );
	}

	public static function set_pin( $person_id, $pin = '' ) {
		global $wpdb;
		$pin = preg_replace( '/\D/', '', (string) $pin );
		if ( '' === $pin ) {
			$i = 0;
			do {
				$pin = (string) wp_rand( 1000, 999999 );
				$pin = str_pad( $pin, strlen( $pin ) < 4 ? 4 : strlen( $pin ), '0', STR_PAD_LEFT );
			} while ( self::find_pin( $pin, $person_id ) && $i++ < 50 );
			$pin = substr( $pin, 0, 5 );
		}
		if ( ! preg_match( '/^\d{4,6}$/', $pin ) ) {
			return new WP_Error( 'pin', __( 'Il PIN deve avere da 4 a 6 cifre.', 'beautyhub-core' ) );
		}
		if ( self::find_pin( $pin, $person_id ) ) {
			return new WP_Error( 'pin', __( 'Questo PIN è già usato da un\'altra persona: scegline un altro.', 'beautyhub-core' ) );
		}
		$wpdb->update( bhc_table( 'people' ), array( 'pin_hash' => self::pin_hash( $pin ) ), array( 'id' => (int) $person_id ) );
		return $pin;
	}

	public static function find_pin( $pin, $exclude = 0 ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'people' ) . " WHERE pin_hash = %s AND id <> %d AND status = 'attivo'", self::pin_hash( $pin ), (int) $exclude ) ); // phpcs:ignore
	}

	public static function kiosk_url() {
		$t = self::settings()['kiosk_token'];
		return $t ? add_query_arg( 'bh_timbra', $t, home_url( '/' ) ) : '';
	}

	/** Pagina della timbratrice (senza account: si apre con il link segreto). */
	public static function kiosk_page() {
		if ( empty( $_GET['bh_timbra'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$token = sanitize_text_field( wp_unslash( $_GET['bh_timbra'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$ok    = self::settings()['kiosk_token'];
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		header( 'Referrer-Policy: no-referrer' );
		$center = bhc_get_option( 'center_name' );
		if ( ! $ok || ! hash_equals( $ok, $token ) ) {
			echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Timbratrice</title><body style="font-family:system-ui;padding:40px;text-align:center"><h1>Timbratrice non attiva</h1><p>Il link non è valido o è stato rigenerato. Chiedi alla responsabile il nuovo link.</p></body>';
			exit;
		}
		$api  = esc_url_raw( rest_url( BHC_REST::NS . '/public/clock' ) );
		$now  = current_time( 'timestamp' ) * 1000; // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested
		$days = array( 'domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato' );
		$mon  = array( 1 => 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre' );
		?><!doctype html>
<html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="robots" content="noindex,nofollow"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">
<title>Timbratura · <?php echo esc_html( $center ); ?></title>
<style>
*{box-sizing:border-box}html,body{margin:0;height:100%}body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:#f5f3ef;color:#2f2e2a;-webkit-user-select:none;user-select:none}
.w{min-height:100%;display:flex;flex-direction:column;align-items:center;padding:24px 16px}
.top{width:100%;max-width:520px;display:flex;justify-content:space-between;align-items:center}
.brand{font-weight:700;font-size:1.05rem;color:#3f4838}.clock{text-align:right}.clock b{display:block;font-size:2.4rem;font-variant-numeric:tabular-nums;line-height:1}.clock span{color:#7a776f;font-size:.9rem}
.s{width:100%;max-width:420px;margin-top:28px;text-align:center}.s[hidden]{display:none}
h1{font-size:1.5rem;margin:0 0 6px}.sub{color:#7a776f;margin:0 0 18px}
.dots{display:flex;gap:12px;justify-content:center;margin:14px 0}.dots span{width:16px;height:16px;border-radius:50%;border:2px solid #7d8c6f}.dots span.on{background:#7d8c6f}
.err{color:#b55448;min-height:1.3em;margin:6px 0}
.pad{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.k{font:inherit;font-size:1.8rem;font-weight:600;padding:18px 0;border-radius:14px;border:1px solid #ddd8cc;background:#fff;color:inherit;cursor:pointer;touch-action:manipulation}.k:active{background:#e5ebdc}.k.fn{background:#ece8df;font-size:1.3rem}.k.ok{background:#7d8c6f;color:#fff;border-color:#7d8c6f;font-size:1.2rem}
.ch{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:10px 0 16px}.big{font:inherit;font-size:1.3rem;font-weight:700;padding:30px 10px;border-radius:18px;border:3px solid transparent;cursor:pointer;color:#fff}.big.in{background:#5e7a4e}.big.out{background:#a1583f}.big.sug{border-color:#2f2e2a;box-shadow:0 0 0 4px #fff inset}.big small{display:block;font-size:.8rem;font-weight:500;opacity:.9;margin-top:4px}
ul{list-style:none;padding:0;margin:0 0 14px;color:#7a776f}.lnk{background:none;border:0;color:#7a776f;text-decoration:underline;font:inherit;cursor:pointer;padding:10px}
.done{font-size:4rem;color:#5e7a4e;line-height:1}.anom{background:#fbeee2;color:#8a4f22;border-radius:12px;padding:10px 12px;margin-top:12px;font-size:.92rem;text-align:left}
</style></head><body><div class="w">
<div class="top"><div class="brand"><?php echo esc_html( $center ); ?></div><div class="clock"><b id="t"><?php echo esc_html( current_time( 'H:i' ) ); ?></b><span><?php echo esc_html( $days[ (int) current_time( 'w' ) ] . ' ' . (int) current_time( 'j' ) . ' ' . $mon[ (int) current_time( 'n' ) ] ); ?></span></div></div>
<section class="s" id="pin"><h1>Timbratura</h1><p class="sub">Inserisci il tuo PIN personale</p><div class="dots" id="dots"></div><p class="err" id="err"></p>
<div class="pad"><?php foreach ( array( 1, 2, 3, 4, 5, 6, 7, 8, 9 ) as $n ) { echo '<button class="k" data-k="' . (int) $n . '">' . (int) $n . '</button>'; } ?><button class="k fn" id="del" aria-label="Cancella">⌫</button><button class="k" data-k="0">0</button><button class="k ok" id="ok">OK</button></div></section>
<section class="s" id="cho" hidden><h1>Ciao <span id="nm"></span></h1><p class="sub" id="st"></p><div class="ch"><button class="big in" data-a="in">→ Entrata</button><button class="big out" data-a="out">← Uscita</button></div><ul id="today"></ul><button class="lnk" id="cancel">Non sono io · Annulla</button></section>
<section class="s" id="fin" hidden><div class="done">✓</div><h1 id="m1"></h1><p class="sub" id="m2"></p><div id="an"></div></section>
</div>
<script>
(function(){
var API=<?php echo wp_json_encode( $api ); ?>,TOKEN=<?php echo wp_json_encode( $token ); ?>,off=<?php echo (int) $now; ?>-Date.now(),pin='',timer=null;
function $(i){return document.getElementById(i)}
function tick(){var d=new Date(Date.now()+off);$('t').textContent=('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2)}setInterval(tick,5000);
function dots(){var h='';for(var i=0;i<Math.max(4,pin.length);i++)h+='<span class="'+(i<pin.length?'on':'')+'"></span>';$('dots').innerHTML=h}dots();
function show(id){['pin','cho','fin'].forEach(function(x){$(x).hidden=x!==id})}
function reset(){pin='';dots();$('err').textContent='';show('pin');clearTimeout(timer)}
function call(action){return fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:TOKEN,pin:pin,action:action})}).then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.message||'Errore');return j})})}
document.querySelectorAll('[data-k]').forEach(function(b){b.onclick=function(){if(pin.length<6){pin+=b.dataset.k;dots()}}});
$('del').onclick=function(){pin=pin.slice(0,-1);dots()};
$('ok').onclick=function(){if(pin.length<4){$('err').textContent='Il PIN ha almeno 4 cifre.';return}call('check').then(function(j){$('nm').textContent=j.name;$('st').textContent=j.status;$('today').innerHTML=j.today.map(function(t){return'<li>'+t+'</li>'}).join('');document.querySelectorAll('[data-a]').forEach(function(b){b.classList.toggle('sug',b.dataset.a===j.suggested)});show('cho');timer=setTimeout(reset,30000)}).catch(function(e){$('err').textContent=e.message;pin='';dots()})};
document.querySelectorAll('[data-a]').forEach(function(b){b.onclick=function(){clearTimeout(timer);call(b.dataset.a).then(function(j){$('m1').textContent=j.msg;$('m2').textContent=j.msg2;$('an').innerHTML=j.anomalies&&j.anomalies.length?'<div class="anom"><b>Da segnalare alla responsabile:</b><br>'+j.anomalies.join('<br>')+'</div>':'';show('fin');timer=setTimeout(reset,j.anomalies&&j.anomalies.length?9000:4000)}).catch(function(e){$('err').textContent=e.message;reset();$('err').textContent=e.message})}});
$('cancel').onclick=reset;
document.addEventListener('keydown',function(e){if($('pin').hidden)return;if(/^[0-9]$/.test(e.key)&&pin.length<6){pin+=e.key;dots()}else if(e.key==='Backspace'){pin=pin.slice(0,-1);dots()}else if(e.key==='Enter'){$('ok').click()}});
})();
</script></body></html>
		<?php
		exit;
	}

	/** Richieste dalla timbratrice. */
	public static function rest_clock( WP_REST_Request $r ) {
		nocache_headers();
		$ok    = self::settings()['kiosk_token'];
		$token = (string) $r->get_param( 'token' );
		if ( ! $ok || ! hash_equals( $ok, $token ) ) {
			return new WP_REST_Response( array( 'message' => 'Timbratrice non attiva. Avvisa la responsabile.' ), 403 );
		}
		$ip   = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$fk   = 'bhc_clock_fail_' . md5( $ip );
		$fail = (int) get_transient( $fk );
		if ( $fail >= 8 ) {
			return new WP_REST_Response( array( 'message' => 'Troppi tentativi errati. Riprova tra qualche minuto.' ), 429 );
		}
		$pin = preg_replace( '/\D/', '', (string) $r->get_param( 'pin' ) );
		$pid = preg_match( '/^\d{4,6}$/', $pin ) ? self::find_pin( $pin ) : 0;
		if ( ! $pid ) {
			set_transient( $fk, $fail + 1, 10 * MINUTE_IN_SECONDS );
			return new WP_REST_Response( array( 'message' => 'PIN non riconosciuto. Riprova.' ), 401 );
		}
		delete_transient( $fk );
		$p      = BHC_People::get( $pid );
		$today  = current_time( 'Y-m-d' );
		$rows   = self::punches( $pid, $today, $today )[ $today ] ?? array();
		$last   = $rows ? end( $rows ) : null;
		$action = (string) $r->get_param( 'action' );
		if ( in_array( $action, array( 'in', 'out' ), true ) ) {
			if ( $last && $last['kind'] === $action && ( strtotime( current_time( 'mysql' ) ) - strtotime( $last['ts'] ) ) < 120 ) {
				return array( 'msg' => ( 'in' === $action ? 'Entrata' : 'Uscita' ) . ' già registrata alle ' . $last['time'], 'msg2' => 'Non serve timbrare di nuovo.', 'anomalies' => array() );
			}
			$now = current_time( 'mysql' );
			self::punch( $pid, $action, $now, 'tablet' );
			$rows = self::punches( $pid, $today, $today )[ $today ] ?? array();
			$an   = array_map(
				function ( $a ) {
					return $a['text'];
				},
				array_filter(
					self::anomalies( self::day( $p, $today ), $today, $rows ),
					function ( $a ) {
						return in_array( $a['kind'], array( 'ritardo', 'rientro_ritardo', 'uscita_anticipata', 'non_prevista' ), true );
					}
				)
			);
			return array(
				'msg'       => ( 'in' === $action ? 'Entrata' : 'Uscita' ) . ' registrata alle ' . substr( $now, 11, 5 ),
				'msg2'      => 'in' === $action ? 'Buon lavoro, ' . $p['first_name'] . '!' : 'A presto, ' . $p['first_name'] . '!',
				'anomalies' => array_values( $an ),
			);
		}
		$day = self::day( $p, $today );
		return array(
			'name'      => $p['first_name'],
			'suggested' => $last && 'in' === $last['kind'] ? 'out' : 'in',
			'status'    => $last ? ( 'in' === $last['kind'] ? 'Sei entrata alle ' . $last['time'] : 'Ultima uscita alle ' . $last['time'] ) : ( $day['ranges'] ? 'Turno di oggi: ' . self::to_text( $day['ranges'] ) : 'Nessun turno previsto oggi' ),
			'today'     => array_map(
				function ( $x ) {
					return ( 'in' === $x['kind'] ? 'Entrata ' : 'Uscita ' ) . $x['time'];
				},
				$rows
			),
		);
	}

	/* ==================================================================
	 * REST (gestionale)
	 * ================================================================ */

	public static function routes() {
		$ns   = BHC_REST::NS;
		$perm = BHC_Permissions::cb( array( 'hours' ) );
		register_rest_route( $ns, '/public/clock', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_clock' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( $ns, '/time/week', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_week' ), 'permission_callback' => $perm ) );
		register_rest_route(
			$ns,
			'/time/vars',
			array(
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_set_var' ), 'permission_callback' => $perm ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_del_var' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route( $ns, '/time/month', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_month' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/time/sheet/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_sheet' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/time/punches', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_add_punch' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/time/punches/(?P<id>\d+)', array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_del_punch' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/time/justify', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_justify' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/time/anomalies', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_anomalies' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/time/leave', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_leave' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/time/leave-balance', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_leave_balance' ), 'permission_callback' => $perm ) );
		register_rest_route(
			$ns,
			'/time/kiosk',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_kiosk' ), 'permission_callback' => $perm ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_kiosk_set' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route( $ns, '/time/pin/(?P<id>\d+)', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_pin' ), 'permission_callback' => $perm ) );
	}

	private static function err( $e, $s = 400 ) {
		return new WP_REST_Response( array( 'message' => is_wp_error( $e ) ? $e->get_error_message() : $e ), $s );
	}
	private static function date( $v, $def = '' ) {
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $v ) ? (string) $v : $def;
	}
	private static function month_param( WP_REST_Request $r ) {
		$m = (string) $r->get_param( 'month' );
		return preg_match( '/^\d{4}-\d{2}$/', $m ) ? $m : current_time( 'Y-m' );
	}

	public static function rest_week( WP_REST_Request $r ) {
		$d   = self::date( $r->get_param( 'date' ), current_time( 'Y-m-d' ) );
		$mon = gmdate( 'Y-m-d', strtotime( $d . ' -' . ( (int) gmdate( 'N', strtotime( $d ) ) - 1 ) . ' days' ) );
		return array_merge( self::week( $mon ), array( 'types' => self::types(), 'today' => current_time( 'Y-m-d' ), 'center' => array_map( 'bhc_parse_ranges', array() ) ) );
	}
	public static function rest_set_var( WP_REST_Request $r ) {
		$from = self::date( $r->get_param( 'from' ) );
		$to   = self::date( $r->get_param( 'to' ), $from );
		if ( ! $from || $to < $from ) {
			return self::err( __( 'Date non valide.', 'beautyhub-core' ) );
		}
		$ids = array_filter( array_map( 'absint', (array) $r->get_param( 'person_ids' ) ) );
		if ( ! $ids ) {
			$ids = array( absint( $r->get_param( 'person_id' ) ) );
		}
		$n = 0;
		foreach ( $ids as $pid ) {
			$res = self::set_var( $pid, $from, $to, sanitize_key( (string) $r->get_param( 'type' ) ), (string) $r->get_param( 'ranges' ), (string) $r->get_param( 'note' ), (bool) ( $r->get_param( 'overwrite' ) ?? true ) );
			if ( is_wp_error( $res ) ) {
				return self::err( $res );
			}
			$n += $res;
		}
		return array( 'days' => $n );
	}
	public static function rest_del_var( WP_REST_Request $r ) {
		$from = self::date( $r->get_param( 'from' ) );
		$to   = self::date( $r->get_param( 'to' ), $from );
		if ( ! $from ) {
			return self::err( __( 'Data non valida.', 'beautyhub-core' ) );
		}
		return array( 'deleted' => self::del_var( absint( $r->get_param( 'person_id' ) ), $from, $to ) );
	}
	public static function rest_month( WP_REST_Request $r ) {
		$m = self::month_param( $r );
		return array( 'month' => $m, 'items' => self::month_summary( $m ), 'present' => self::present_now(), 'types' => self::types() );
	}
	public static function rest_sheet( WP_REST_Request $r ) {
		$s = self::sheet( (int) $r['id'], self::month_param( $r ) );
		if ( ! $s ) {
			return self::err( __( 'Persona non trovata.', 'beautyhub-core' ), 404 );
		}
		$s['types']   = self::types();
		$s['reasons'] = self::reasons();
		return $s;
	}
	public static function rest_add_punch( WP_REST_Request $r ) {
		$pid  = absint( $r->get_param( 'person_id' ) );
		$d    = self::date( $r->get_param( 'date' ) );
		$t    = (string) $r->get_param( 'time' );
		$kind = (string) $r->get_param( 'kind' );
		if ( ! $pid || ! $d || ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $t ) || ! in_array( $kind, array( 'in', 'out' ), true ) ) {
			return self::err( __( 'Indica giorno, ora e tipo della timbratura.', 'beautyhub-core' ) );
		}
		self::punch( $pid, $kind, $d . ' ' . $t . ':00', 'manuale', (string) $r->get_param( 'note' ) );
		return array( 'ok' => true );
	}
	public static function rest_del_punch( WP_REST_Request $r ) {
		global $wpdb;
		$wpdb->delete( bhc_table( 'punches' ), array( 'id' => (int) $r['id'] ) );
		return array( 'ok' => true );
	}
	public static function rest_justify( WP_REST_Request $r ) {
		global $wpdb;
		$pid  = absint( $r->get_param( 'person_id' ) );
		$d    = self::date( $r->get_param( 'date' ) );
		$kind = sanitize_key( (string) $r->get_param( 'kind' ) );
		if ( ! $pid || ! $d || ! isset( self::anomaly_types()[ $kind ] ) ) {
			return self::err( __( 'Dati non validi.', 'beautyhub-core' ) );
		}
		$t = bhc_table( 'justifications' );
		if ( $r->get_param( 'remove' ) ) {
			$wpdb->delete( $t, array( 'person_id' => $pid, 'day' => $d, 'kind' => $kind ) );
			return array( 'ok' => true );
		}
		$st  = in_array( $r->get_param( 'status' ), array( 'approvata', 'respinta' ), true ) ? $r->get_param( 'status' ) : 'approvata';
		$row = array( 'person_id' => $pid, 'day' => $d, 'kind' => $kind, 'reason' => sanitize_text_field( (string) $r->get_param( 'reason' ) ), 'note' => sanitize_text_field( (string) $r->get_param( 'note' ) ), 'status' => $st, 'created_by' => get_current_user_id(), 'created_at' => current_time( 'mysql' ) );
		$id  = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE person_id = %d AND day = %s AND kind = %s", $pid, $d, $kind ) ); // phpcs:ignore
		if ( $id ) {
			$wpdb->update( $t, $row, array( 'id' => (int) $id ) );
		} else {
			$wpdb->insert( $t, $row );
		}
		return array( 'ok' => true );
	}
	public static function rest_anomalies( WP_REST_Request $r ) {
		$m   = self::month_param( $r );
		$out = array();
		foreach ( self::people( false ) as $p ) {
			$s = self::sheet( $p['id'], $m );
			foreach ( $s['days'] as $d ) {
				foreach ( $d['anomalies'] as $a ) {
					$out[] = array_merge( $a, array( 'person_id' => $p['id'], 'name' => $s['person']['name'], 'date' => $d['date'], 'expected' => $d['expected'], 'punches' => array_map( function ( $x ) {
						return ( 'in' === $x['kind'] ? '→' : '←' ) . $x['time'];
					}, $d['punches'] ) ) );
				}
			}
		}
		usort(
			$out,
			function ( $a, $b ) {
				return strcmp( $b['date'], $a['date'] );
			}
		);
		return array( 'month' => $m, 'items' => $out, 'reasons' => self::reasons(), 'types' => self::anomaly_types() );
	}
	public static function rest_leave( WP_REST_Request $r ) {
		$y = absint( $r->get_param( 'year' ) ) ?: (int) current_time( 'Y' );
		return array( 'year' => $y, 'items' => self::leave_summary( $y ), 'periods' => self::leave_periods( $y ), 'types' => self::types(), 'settings' => self::settings() );
	}
	public static function rest_leave_balance( WP_REST_Request $r ) {
		global $wpdb;
		$pid  = absint( $r->get_param( 'person_id' ) );
		$y    = absint( $r->get_param( 'year' ) );
		$type = sanitize_key( (string) $r->get_param( 'type' ) );
		if ( ! $pid || ! $y || ! in_array( $type, array( 'ferie', 'rol', 'exfest' ), true ) ) {
			return self::err( __( 'Dati non validi.', 'beautyhub-core' ) );
		}
		$t   = bhc_table( 'leave_balances' );
		$ent = $r->get_param( 'entitlement' );
		$row = array( 'person_id' => $pid, 'year' => $y, 'type' => $type, 'carry' => (float) str_replace( ',', '.', (string) $r->get_param( 'carry' ) ), 'entitlement' => '' === $ent || null === $ent ? null : (float) str_replace( ',', '.', (string) $ent ) );
		$id  = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE person_id = %d AND year = %d AND type = %s", $pid, $y, $type ) ); // phpcs:ignore
		if ( $id ) {
			$wpdb->update( $t, $row, array( 'id' => (int) $id ) );
		} else {
			$wpdb->insert( $t, $row );
		}
		return array( 'ok' => true );
	}
	public static function rest_kiosk() {
		$s   = self::settings();
		$out = array();
		foreach ( self::people() as $p ) {
			$out[] = array( 'id' => $p['id'], 'name' => trim( $p['first_name'] . ' ' . $p['last_name'] ), 'job' => $p['job_title'], 'pin' => (bool) $p['pin_hash'], 'schedule' => (bool) array_filter( array_map( 'trim', (array) $p['schedule'] ) ) );
		}
		return array( 'active' => (bool) $s['kiosk_token'], 'url' => self::kiosk_url(), 'tolerance' => (int) $s['tolerance'], 'people' => $out, 'settings' => $s );
	}
	public static function rest_kiosk_set( WP_REST_Request $r ) {
		$s = self::settings();
		$a = (string) $r->get_param( 'action' );
		if ( 'activate' === $a || 'regenerate' === $a ) {
			$s['kiosk_token'] = wp_generate_password( 32, false, false );
		} elseif ( 'deactivate' === $a ) {
			$s['kiosk_token'] = '';
		}
		foreach ( array( 'tolerance', 'ferie_days', 'rol_hours', 'exf_hours', 'full_hours' ) as $k ) {
			if ( null !== $r->get_param( $k ) ) {
				$s[ $k ] = max( 0, (float) str_replace( ',', '.', (string) $r->get_param( $k ) ) );
			}
		}
		update_option( self::OPT, $s, false );
		return self::rest_kiosk();
	}
	public static function rest_pin( WP_REST_Request $r ) {
		if ( $r->get_param( 'remove' ) ) {
			global $wpdb;
			$wpdb->update( bhc_table( 'people' ), array( 'pin_hash' => '' ), array( 'id' => (int) $r['id'] ) );
			return array( 'ok' => true );
		}
		$pin = self::set_pin( (int) $r['id'], (string) $r->get_param( 'pin' ) );
		return is_wp_error( $pin ) ? self::err( $pin ) : array( 'pin' => $pin );
	}
}
