<?php
/**
 * Calcolo disponibilità (logica pura, senza dipendenze da WordPress
 * per poter essere testata in isolamento).
 *
 * Tutti i tempi sono in minuti dalla mezzanotte.
 *
 * @package BeautyHubCore
 */

class BHC_Availability {

	/**
	 * Restituisce gli orari di inizio liberi.
	 *
	 * @param array $ranges    Intervalli di lavoro [[inizio, fine], ...].
	 * @param array $busy      Intervalli occupati [[inizio, fine], ...].
	 * @param int   $length    Durata richiesta (trattamento + tempo di riordino).
	 * @param int   $step      Passo della griglia (es. 15).
	 * @param int   $min_start Primo minuto prenotabile (per "oggi" con preavviso), -1 se nessun limite.
	 * @return int[] Minuti di inizio disponibili, ordinati.
	 */
	public static function free_slots( array $ranges, array $busy, $length, $step = 15, $min_start = -1 ) {
		$length = max( 1, (int) $length );
		$step   = max( 5, (int) $step );
		$slots  = array();

		foreach ( $ranges as $r ) {
			$start = (int) $r[0];
			$end   = (int) $r[1];
			// Allinea l'inizio alla griglia.
			if ( $start % $step ) {
				$start += $step - ( $start % $step );
			}
			for ( $t = $start; $t + $length <= $end; $t += $step ) {
				if ( $t < $min_start ) {
					continue;
				}
				if ( ! self::overlaps_any( $t, $t + $length, $busy ) ) {
					$slots[ $t ] = true;
				}
			}
		}

		$slots = array_keys( $slots );
		sort( $slots );
		return $slots;
	}

	/**
	 * L'intervallo [a, b) si sovrappone a uno degli intervalli occupati?
	 */
	public static function overlaps_any( $a, $b, array $busy ) {
		foreach ( $busy as $x ) {
			if ( $a < (int) $x[1] && $b > (int) $x[0] ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Intersezione tra due insiemi di intervalli.
	 */
	public static function intersect( array $a, array $b ) {
		$out = array();
		foreach ( $a as $x ) {
			foreach ( $b as $y ) {
				$s = max( (int) $x[0], (int) $y[0] );
				$e = min( (int) $x[1], (int) $y[1] );
				if ( $e > $s ) {
					$out[] = array( $s, $e );
				}
			}
		}
		usort(
			$out,
			function ( $p, $q ) {
				return $p[0] - $q[0];
			}
		);
		return $out;
	}
}
