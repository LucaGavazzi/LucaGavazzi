<?php
/**
 * Messaggi: promemoria WhatsApp del giorno prima (manuale con link wa.me o automatico con
 * WhatsApp Business Cloud API), messaggio in fondo allo scontrino e buoni sconto
 * da usare sull'acquisto successivo.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Messages {

	const OPT_WA      = 'bhc_whatsapp';
	const OPT_RECEIPT = 'bhc_receipt';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'bhc_hourly', array( __CLASS__, 'cron' ) );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'wa_log' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			appointment_id bigint(20) unsigned NOT NULL DEFAULT 0,
			client_id bigint(20) unsigned NOT NULL DEFAULT 0,
			phone varchar(40) NOT NULL DEFAULT '',
			mode varchar(10) NOT NULL DEFAULT 'manual',
			status varchar(10) NOT NULL DEFAULT 'sent',
			message text,
			error varchar(255) NOT NULL DEFAULT '',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY appointment_id (appointment_id)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'coupons' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			code varchar(30) NOT NULL DEFAULT '',
			ean varchar(20) NOT NULL DEFAULT '',
			client_id bigint(20) unsigned NOT NULL DEFAULT 0,
			sale_id bigint(20) unsigned NOT NULL DEFAULT 0,
			type varchar(10) NOT NULL DEFAULT 'percent',
			value decimal(10,2) NOT NULL DEFAULT 0,
			min_spend decimal(10,2) NOT NULL DEFAULT 0,
			expires_at date DEFAULT NULL,
			status varchar(15) NOT NULL DEFAULT 'attivo',
			used_sale_id bigint(20) unsigned NOT NULL DEFAULT 0,
			used_amount decimal(10,2) NOT NULL DEFAULT 0,
			used_at datetime DEFAULT NULL,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY code (code),
			KEY ean (ean),
			KEY client_id (client_id)
			) {$c};"
		);
	}

	/* ==================================================================
	 * Impostazioni
	 * ================================================================ */

	public static function wa_settings() {
		return wp_parse_args(
			get_option( self::OPT_WA, array() ),
			array(
				'template'        => "Ciao {nome}! 🌿\nTi ricordiamo l'appuntamento di domani, {data} alle {ora}, per {trattamento} presso {centro}.\nSe non riesci a venire avvisaci per favore, ci farebbe piacere poter offrire il posto a un'altra cliente.\nA presto!",
				'country'         => '39',
				'mode'            => 'manual',
				'send_hour'       => 10,
				'statuses'        => array( 'booked', 'confirmed' ),
				'api_version'     => 'v21.0',
				'api_token'       => '',
				'phone_number_id' => '',
				'template_name'   => '',
				'template_lang'   => 'it',
			)
		);
	}

	public static function receipt_settings() {
		return wp_parse_args(
			get_option( self::OPT_RECEIPT, array() ),
			array(
				'footer'          => "Grazie per averci scelto!\nPrenota il prossimo trattamento anche online.",
				'coupon_enabled'  => 0,
				'coupon_auto'     => 0,      // emissione automatica sopra la soglia
				'coupon_threshold' => 50,    // spesa minima per emettere il buono in automatico
				'coupon_type'     => 'percent',
				'coupon_value'    => 10,
				'coupon_min_spend' => 0,     // spesa minima per usare il buono
				'coupon_days'     => 60,
				'coupon_text'     => 'Sul tuo prossimo trattamento o acquisto',
			)
		);
	}

	/* ==================================================================
	 * Promemoria WhatsApp
	 * ================================================================ */

	/** Numero nel formato internazionale senza "+" (es. 393331234567). */
	public static function phone( $raw ) {
		$s = trim( (string) $raw );
		if ( '' === $s ) {
			return '';
		}
		$plus = 0 === strpos( $s, '+' );
		$d    = preg_replace( '/\D/', '', $s );
		if ( 0 === strpos( $d, '00' ) ) {
			return substr( $d, 2 );
		}
		if ( $plus ) {
			return $d;
		}
		$cc = preg_replace( '/\D/', '', (string) self::wa_settings()['country'] );
		// Numero nazionale: cellulari italiani iniziano con 3, fissi con 0.
		if ( $cc && strlen( $d ) <= 11 && ! ( 0 === strpos( $d, $cc ) && strlen( $d ) >= 11 ) ) {
			return $cc . $d;
		}
		return $d;
	}

	/** Data in italiano (es. "sabato 31 ottobre"), indipendente dalla lingua del sito. */
	private static function it_date( $ymd ) {
		$ts     = strtotime( $ymd . ' 12:00:00' );
		$days   = array( 'domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato' );
		$months = array( 1 => 'gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre' );
		return $days[ (int) gmdate( 'w', $ts ) ] . ' ' . (int) gmdate( 'j', $ts ) . ' ' . $months[ (int) gmdate( 'n', $ts ) ];
	}

	/** Sostituisce i segnaposto nel testo del promemoria. */
	public static function render( $template, array $a ) {
		$client = $a['client_id'] ? BHC_Repository::get_client( $a['client_id'] ) : null;
		$ops    = isset( $a['operators'] ) && $a['operators'] ? implode( ' e ', wp_list_pluck( $a['operators'], 'name' ) ) : '';
		$map    = array(
			'{nome}'          => $client ? $client['first_name'] : '',
			'{cognome}'       => $client ? $client['last_name'] : '',
			'{data}'          => self::it_date( $a['date'] ),
			'{ora}'           => $a['start'],
			'{trattamento}'   => $a['treatment_name'],
			'{operatrice}'    => $ops,
			'{cabina}'        => $a['staff_name'],
			'{centro}'        => bhc_get_option( 'center_name' ),
			'{telefono}'      => bhc_get_option( 'center_phone' ),
			'{link}'          => BHC_Emails::manage_url( $a['id'] ),
		);
		return trim( strtr( (string) $template, $map ) );
	}

	/** Appuntamenti di una data con testo, link wa.me e stato dell'invio. */
	public static function reminders( $date ) {
		global $wpdb;
		$s    = self::wa_settings();
		$t    = bhc_table( 'appointments' );
		$c    = bhc_table( 'clients' );
		$st   = array_values( array_intersect( (array) $s['statuses'], array_keys( bhc_statuses() ) ) );
		$st   = $st ? $st : array( 'booked', 'confirmed' );
		$in   = implode( ',', array_fill( 0, count( $st ), '%s' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT a.*, c.first_name, c.last_name, c.phone, c.email FROM {$t} a LEFT JOIN {$c} c ON c.id = a.client_id WHERE a.start_at >= %s AND a.start_at <= %s AND a.status IN ({$in}) ORDER BY a.start_at", array_merge( array( $date . ' 00:00:00', $date . ' 23:59:59' ), $st ) ), ARRAY_A ); // phpcs:ignore
		$out  = array();
		foreach ( $rows as $r ) {
			$a     = BHC_Repository::decorate( $r );
			$phone = self::phone( $r['phone'] );
			$msg   = self::render( $s['template'], $a );
			$log   = $wpdb->get_row( $wpdb->prepare( 'SELECT status, mode, error, created_at FROM ' . bhc_table( 'wa_log' ) . ' WHERE appointment_id = %d ORDER BY id DESC LIMIT 1', $a['id'] ), ARRAY_A ); // phpcs:ignore
			$out[] = array(
				'id'          => $a['id'],
				'client_id'   => $a['client_id'],
				'client_name' => $a['client_name'],
				'phone'       => $r['phone'],
				'wa_phone'    => $phone,
				'start'       => $a['start'],
				'date'        => $a['date'],
				'treatment'   => $a['treatment_name'],
				'status'      => $a['status'],
				'message'     => $msg,
				'url'         => $phone ? 'https://wa.me/' . $phone . '?text=' . rawurlencode( $msg ) : '',
				'sent'        => $log && 'sent' === $log['status'],
				'log'         => $log,
			);
		}
		return $out;
	}

	public static function log( $appointment_id, $client_id, $phone, $mode, $status, $message, $error = '' ) {
		global $wpdb;
		$wpdb->insert(
			bhc_table( 'wa_log' ),
			array(
				'appointment_id' => (int) $appointment_id,
				'client_id'      => (int) $client_id,
				'phone'          => $phone,
				'mode'           => $mode,
				'status'         => $status,
				'message'        => $message,
				'error'          => mb_substr( (string) $error, 0, 250 ),
				'created_by'     => get_current_user_id(),
				'created_at'     => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Invio con WhatsApp Business Cloud API (Meta).
	 * I messaggi avviati dall'azienda devono usare un modello approvato da Meta:
	 * i parametri del corpo sono {{1}} nome, {{2}} data, {{3}} ora, {{4}} trattamento, {{5}} centro.
	 */
	public static function api_send( $to, array $params ) {
		$s = self::wa_settings();
		if ( ! $s['api_token'] || ! $s['phone_number_id'] || ! $s['template_name'] ) {
			return new WP_Error( 'config', __( 'Configura token, ID numero di telefono e nome del modello WhatsApp.', 'beautyhub-core' ) );
		}
		$body = array(
			'messaging_product' => 'whatsapp',
			'to'                => $to,
			'type'              => 'template',
			'template'          => array(
				'name'       => $s['template_name'],
				'language'   => array( 'code' => $s['template_lang'] ? $s['template_lang'] : 'it' ),
				'components' => array(
					array(
						'type'       => 'body',
						'parameters' => array_map(
							function ( $p ) {
								return array( 'type' => 'text', 'text' => (string) $p );
							},
							array_values( $params )
						),
					),
				),
			),
		);
		$res  = wp_remote_post(
			'https://graph.facebook.com/' . rawurlencode( $s['api_version'] ? $s['api_version'] : 'v21.0' ) . '/' . rawurlencode( $s['phone_number_id'] ) . '/messages',
			array(
				'timeout' => 20,
				'headers' => array( 'Authorization' => 'Bearer ' . $s['api_token'], 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code >= 300 ) {
			$msg = isset( $data['error']['message'] ) ? $data['error']['message'] : 'HTTP ' . $code;
			return new WP_Error( 'api', $msg );
		}
		return $data;
	}

	private static function api_params( array $a ) {
		$client = $a['client_id'] ? BHC_Repository::get_client( $a['client_id'] ) : null;
		return array( $client ? $client['first_name'] : '', self::it_date( $a['date'] ), $a['start'], $a['treatment_name'], bhc_get_option( 'center_name' ) );
	}

	/** Invia in automatico i promemoria di una data (salta quelli già inviati). */
	public static function send_auto( $date ) {
		$res = array( 'sent' => 0, 'errors' => 0, 'skipped' => 0, 'details' => array() );
		foreach ( self::reminders( $date ) as $r ) {
			if ( $r['sent'] ) {
				$res['skipped']++;
				continue;
			}
			if ( ! $r['wa_phone'] ) {
				$res['skipped']++;
				$res['details'][] = array( 'id' => $r['id'], 'error' => __( 'Telefono mancante', 'beautyhub-core' ) );
				continue;
			}
			$a  = BHC_Repository::get_appointment( $r['id'] );
			$ok = self::api_send( $r['wa_phone'], self::api_params( $a ) );
			if ( is_wp_error( $ok ) ) {
				$res['errors']++;
				$res['details'][] = array( 'id' => $r['id'], 'error' => $ok->get_error_message() );
				self::log( $r['id'], $r['client_id'], $r['wa_phone'], 'auto', 'error', $r['message'], $ok->get_error_message() );
				if ( 'config' === $ok->get_error_code() ) {
					break;
				}
			} else {
				$res['sent']++;
				self::log( $r['id'], $r['client_id'], $r['wa_phone'], 'auto', 'sent', $r['message'] );
			}
		}
		return $res;
	}

	/** Ogni ora: dopo l'ora scelta invia una sola volta i promemoria di domani. */
	public static function cron() {
		$s = self::wa_settings();
		if ( 'auto' !== $s['mode'] ) {
			return;
		}
		$today = current_time( 'Y-m-d' );
		if ( (int) current_time( 'G' ) < (int) $s['send_hour'] || get_option( 'bhc_wa_last_run' ) === $today ) {
			return;
		}
		update_option( 'bhc_wa_last_run', $today, false );
		$res = self::send_auto( gmdate( 'Y-m-d', strtotime( $today . ' +1 day' ) ) );
		update_option( 'bhc_wa_last_result', array( 'date' => $today, 'result' => $res ), false );
	}

	/* ==================================================================
	 * Buoni sconto
	 * ================================================================ */

	public static function coupon_out( $row ) {
		if ( ! $row ) {
			return null;
		}
		foreach ( array( 'id', 'client_id', 'sale_id', 'used_sale_id' ) as $k ) {
			$row[ $k ] = (int) $row[ $k ];
		}
		foreach ( array( 'value', 'min_spend', 'used_amount' ) as $k ) {
			$row[ $k ] = (float) $row[ $k ];
		}
		$row['expired'] = $row['expires_at'] && $row['expires_at'] < current_time( 'Y-m-d' );
		$row['label']   = 'percent' === $row['type'] ? rtrim( rtrim( number_format( $row['value'], 2, ',', '' ), '0' ), ',' ) . '%' : bhc_price( $row['value'] );
		$c              = $row['client_id'] ? BHC_Repository::get_client( $row['client_id'] ) : null;
		$row['holder']  = $c ? trim( $c['first_name'] . ' ' . $c['last_name'] ) : '';
		return $row;
	}

	public static function find_coupon( $code ) {
		global $wpdb;
		$code = trim( (string) $code );
		$row  = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'coupons' ) . ' WHERE code = %s OR ean = %s ORDER BY id DESC LIMIT 1', strtoupper( $code ), preg_replace( '/\s/', '', $code ) ), ARRAY_A ); // phpcs:ignore
		return self::coupon_out( $row );
	}

	public static function get_coupon( $id ) {
		global $wpdb;
		return self::coupon_out( $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'coupons' ) . ' WHERE id = %d', $id ), ARRAY_A ) ); // phpcs:ignore
	}

	/** Verifica un buono e calcola lo sconto su un importo. */
	public static function coupon_check( $coupon, $amount ) {
		if ( ! $coupon ) {
			return new WP_Error( 'coupon', __( 'Buono sconto non trovato.', 'beautyhub-core' ) );
		}
		if ( 'attivo' !== $coupon['status'] ) {
			return new WP_Error( 'coupon', 'usato' === $coupon['status'] ? __( 'Questo buono sconto è già stato usato.', 'beautyhub-core' ) : __( 'Questo buono sconto non è valido.', 'beautyhub-core' ) );
		}
		if ( $coupon['expired'] ) {
			return new WP_Error( 'coupon', __( 'Questo buono sconto è scaduto.', 'beautyhub-core' ) );
		}
		if ( $coupon['min_spend'] > 0 && $amount + 0.001 < $coupon['min_spend'] ) {
			/* translators: %s: spesa minima */
			return new WP_Error( 'coupon', sprintf( __( 'Il buono vale con una spesa minima di %s.', 'beautyhub-core' ), bhc_price( $coupon['min_spend'] ) ) );
		}
		$disc = 'percent' === $coupon['type'] ? $amount * $coupon['value'] / 100 : $coupon['value'];
		return round( min( $amount, max( 0, $disc ) ), 2 );
	}

	public static function issue_coupon( $client_id, $sale_id ) {
		global $wpdb;
		$s   = self::receipt_settings();
		$now = current_time( 'mysql' );
		$wpdb->insert(
			bhc_table( 'coupons' ),
			array(
				'client_id'  => (int) $client_id,
				'sale_id'    => (int) $sale_id,
				'type'       => 'fixed' === $s['coupon_type'] ? 'fixed' : 'percent',
				'value'      => max( 0, (float) $s['coupon_value'] ),
				'min_spend'  => max( 0, (float) $s['coupon_min_spend'] ),
				'expires_at' => (int) $s['coupon_days'] > 0 ? gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' +' . (int) $s['coupon_days'] . ' days' ) ) : null,
				'status'     => 'attivo',
				'created_by' => get_current_user_id(),
				'created_at' => $now,
			)
		);
		$id   = (int) $wpdb->insert_id;
		$base = '294' . str_pad( (string) $id, 9, '0', STR_PAD_LEFT );
		$wpdb->update(
			bhc_table( 'coupons' ),
			array(
				'code' => 'BS' . current_time( 'y' ) . '-' . str_pad( (string) $id, 5, '0', STR_PAD_LEFT ),
				'ean'  => $base . BHC_Cards::ean_check( $base ),
			),
			array( 'id' => $id )
		);
		return $id;
	}

	public static function use_coupon( $id, $sale_id, $amount ) {
		global $wpdb;
		$wpdb->update(
			bhc_table( 'coupons' ),
			array( 'status' => 'usato', 'used_sale_id' => (int) $sale_id, 'used_amount' => round( $amount, 2 ), 'used_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $id )
		);
	}

	/** Regola automatica: emettere il buono per questa spesa? */
	public static function coupon_due( $spent ) {
		$s = self::receipt_settings();
		return ! empty( $s['coupon_enabled'] ) && ! empty( $s['coupon_auto'] ) && $spent + 0.001 >= (float) $s['coupon_threshold'];
	}

	public static function coupons( $q = '', $status = '' ) {
		global $wpdb;
		$t     = bhc_table( 'coupons' );
		$cl    = bhc_table( 'clients' );
		$where = array( '1=1' );
		$args  = array();
		if ( $status ) {
			$where[] = 'k.status = %s';
			$args[]  = $status;
		}
		if ( $q ) {
			$like    = '%' . $wpdb->esc_like( $q ) . '%';
			$where[] = '(k.code LIKE %s OR k.ean LIKE %s OR c.first_name LIKE %s OR c.last_name LIKE %s)';
			array_push( $args, $like, $like, $like, $like );
		}
		$sql  = "SELECT k.* FROM {$t} k LEFT JOIN {$cl} c ON c.id = k.client_id WHERE " . implode( ' AND ', $where ) . ' ORDER BY k.id DESC LIMIT 300';
		$rows = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		return array_map( array( __CLASS__, 'coupon_out' ), $rows );
	}

	/* ==================================================================
	 * REST
	 * ================================================================ */

	public static function routes() {
		$ns   = BHC_REST::NS;
		$perm = BHC_Permissions::cb( array( 'messages' ) );
		$pos  = BHC_Permissions::cb( array( 'messages', 'pos' ) );
		register_rest_route(
			$ns,
			'/messages/settings',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_settings' ), 'permission_callback' => $perm ),
				array( 'methods' => 'PUT', 'callback' => array( __CLASS__, 'rest_save' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route( $ns, '/messages/reminders', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_reminders' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/messages/reminders/(?P<id>\d+)/mark', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_mark' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/messages/reminders/send', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_send' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/messages/test', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_test' ), 'permission_callback' => array( 'BHC_Permissions', 'is_admin' ) ) );
		register_rest_route( $ns, '/coupons', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_coupons' ), 'permission_callback' => $pos ) );
		register_rest_route( $ns, '/coupons/check', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_coupon_check' ), 'permission_callback' => $pos ) );
		register_rest_route( $ns, '/coupons/(?P<id>\d+)', array( 'methods' => 'PUT', 'callback' => array( __CLASS__, 'rest_coupon_update' ), 'permission_callback' => $perm ) );
	}

	private static function err( $msg, $status = 400 ) {
		return new WP_REST_Response( array( 'message' => $msg ), $status );
	}

	private static function public_wa() {
		$s     = self::wa_settings();
		$admin = BHC_Permissions::is_admin();
		$s['api_configured'] = (bool) ( $s['api_token'] && $s['phone_number_id'] && $s['template_name'] );
		$s['api_token']      = $s['api_token'] ? ( $admin ? '••••' . substr( $s['api_token'], -4 ) : '••••' ) : '';
		if ( ! $admin ) {
			unset( $s['phone_number_id'] );
		}
		$s['can_api']     = $admin;
		$s['last_result'] = get_option( 'bhc_wa_last_result' );
		return $s;
	}

	public static function rest_settings() {
		$r = self::receipt_settings();
		return array(
			'whatsapp'     => self::public_wa(),
			'receipt'      => $r,
			'placeholders' => array( '{nome}', '{cognome}', '{data}', '{ora}', '{trattamento}', '{operatrice}', '{cabina}', '{centro}', '{telefono}', '{link}' ),
			'center'       => array( 'name' => bhc_get_option( 'center_name' ), 'phone' => bhc_get_option( 'center_phone' ) ),
		);
	}

	public static function rest_save( WP_REST_Request $r ) {
		$p = (array) $r->get_json_params();
		if ( isset( $p['whatsapp'] ) && is_array( $p['whatsapp'] ) ) {
			$w   = $p['whatsapp'];
			$cur = self::wa_settings();
			if ( isset( $w['template'] ) ) {
				$cur['template'] = sanitize_textarea_field( $w['template'] );
			}
			if ( isset( $w['country'] ) ) {
				$cur['country'] = preg_replace( '/\D/', '', (string) $w['country'] );
			}
			if ( isset( $w['send_hour'] ) ) {
				$cur['send_hour'] = min( 23, max( 0, (int) $w['send_hour'] ) );
			}
			if ( isset( $w['statuses'] ) && is_array( $w['statuses'] ) ) {
				$cur['statuses'] = array_values( array_intersect( array_map( 'sanitize_key', $w['statuses'] ), array_keys( bhc_statuses() ) ) );
			}
			if ( isset( $w['mode'] ) ) {
				$cur['mode'] = 'auto' === $w['mode'] ? 'auto' : 'manual';
				if ( 'auto' === $cur['mode'] && ! ( $cur['api_token'] && $cur['phone_number_id'] && $cur['template_name'] ) && ! ( BHC_Permissions::is_admin() && ! empty( $w['api_token'] ) ) ) {
					return self::err( __( 'Per l\'invio automatico l\'amministratore deve prima configurare WhatsApp Business.', 'beautyhub-core' ) );
				}
			}
			// Credenziali API: solo amministratore.
			if ( BHC_Permissions::is_admin() ) {
				if ( isset( $w['api_token'] ) && '' !== $w['api_token'] && false === strpos( $w['api_token'], '••••' ) ) {
					$cur['api_token'] = trim( sanitize_text_field( $w['api_token'] ) );
				}
				if ( ! empty( $w['api_clear'] ) ) {
					$cur['api_token'] = '';
					$cur['mode']      = 'manual';
				}
				foreach ( array( 'phone_number_id', 'template_name', 'template_lang', 'api_version' ) as $k ) {
					if ( isset( $w[ $k ] ) ) {
						$cur[ $k ] = trim( sanitize_text_field( $w[ $k ] ) );
					}
				}
			}
			update_option( self::OPT_WA, $cur, false );
		}
		if ( isset( $p['receipt'] ) && is_array( $p['receipt'] ) ) {
			$x   = $p['receipt'];
			$cur = self::receipt_settings();
			if ( isset( $x['footer'] ) ) {
				$cur['footer'] = sanitize_textarea_field( $x['footer'] );
			}
			foreach ( array( 'coupon_enabled', 'coupon_auto' ) as $k ) {
				if ( isset( $x[ $k ] ) ) {
					$cur[ $k ] = $x[ $k ] ? 1 : 0;
				}
			}
			foreach ( array( 'coupon_threshold', 'coupon_value', 'coupon_min_spend' ) as $k ) {
				if ( isset( $x[ $k ] ) ) {
					$cur[ $k ] = max( 0, round( (float) str_replace( ',', '.', (string) $x[ $k ] ), 2 ) );
				}
			}
			if ( isset( $x['coupon_type'] ) ) {
				$cur['coupon_type'] = 'fixed' === $x['coupon_type'] ? 'fixed' : 'percent';
			}
			if ( 'percent' === $cur['coupon_type'] && $cur['coupon_value'] > 100 ) {
				return self::err( __( 'La percentuale di sconto non può superare 100.', 'beautyhub-core' ) );
			}
			if ( isset( $x['coupon_days'] ) ) {
				$cur['coupon_days'] = min( 3650, max( 0, (int) $x['coupon_days'] ) );
			}
			if ( isset( $x['coupon_text'] ) ) {
				$cur['coupon_text'] = sanitize_text_field( $x['coupon_text'] );
			}
			update_option( self::OPT_RECEIPT, $cur, false );
		}
		return self::rest_settings();
	}

	private static function date_param( WP_REST_Request $r ) {
		$d = (string) $r->get_param( 'date' );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ? $d : gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' +1 day' ) );
	}

	public static function rest_reminders( WP_REST_Request $r ) {
		return array( 'date' => self::date_param( $r ), 'items' => self::reminders( self::date_param( $r ) ), 'mode' => self::wa_settings()['mode'] );
	}

	public static function rest_mark( WP_REST_Request $r ) {
		$a = BHC_Repository::get_appointment( (int) $r['id'] );
		if ( ! $a ) {
			return self::err( __( 'Appuntamento non trovato.', 'beautyhub-core' ), 404 );
		}
		$undo = (bool) $r->get_param( 'undo' );
		$msg  = self::render( self::wa_settings()['template'], $a );
		self::log( $a['id'], $a['client_id'], self::phone( $a['phone'] ?? '' ), 'manual', $undo ? 'undone' : 'sent', $msg );
		return array( 'ok' => true );
	}

	public static function rest_send( WP_REST_Request $r ) {
		return self::send_auto( self::date_param( $r ) );
	}

	public static function rest_test( WP_REST_Request $r ) {
		$to = self::phone( (string) $r->get_param( 'phone' ) );
		if ( ! $to ) {
			return self::err( __( 'Inserisci un numero di telefono.', 'beautyhub-core' ) );
		}
		$res = self::api_send( $to, array( 'Prova', self::it_date( current_time( 'Y-m-d' ) ), '10:00', __( 'Trattamento di prova', 'beautyhub-core' ), bhc_get_option( 'center_name' ) ) );
		return is_wp_error( $res ) ? self::err( $res->get_error_message() ) : array( 'ok' => true );
	}

	public static function rest_coupons( WP_REST_Request $r ) {
		return array( 'items' => self::coupons( (string) $r->get_param( 'q' ), sanitize_key( (string) $r->get_param( 'status' ) ) ) );
	}

	public static function rest_coupon_check( WP_REST_Request $r ) {
		$c   = self::find_coupon( (string) $r->get_param( 'code' ) );
		$amt = (float) $r->get_param( 'amount' );
		$res = self::coupon_check( $c, $amt );
		if ( is_wp_error( $res ) ) {
			return self::err( $res->get_error_message(), $c ? 400 : 404 );
		}
		$c['discount'] = $res;
		return $c;
	}

	public static function rest_coupon_update( WP_REST_Request $r ) {
		global $wpdb;
		$c = self::get_coupon( (int) $r['id'] );
		if ( ! $c ) {
			return self::err( __( 'Buono non trovato.', 'beautyhub-core' ), 404 );
		}
		$st = (string) $r->get_param( 'status' );
		if ( in_array( $st, array( 'attivo', 'annullato' ), true ) && 'usato' !== $c['status'] ) {
			$wpdb->update( bhc_table( 'coupons' ), array( 'status' => $st ), array( 'id' => $c['id'] ) );
		}
		return self::get_coupon( $c['id'] );
	}
}
