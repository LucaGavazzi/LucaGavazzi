<?php
/**
 * GDPR: esportazione e cancellazione dei dati tramite gli strumenti privacy di WordPress
 * (Strumenti › Esporta / Cancella dati personali).
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Privacy {

	public static function init() {
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );
		add_action( 'admin_init', array( __CLASS__, 'policy_text' ) );
	}

	public static function register_exporter( $exporters ) {
		$exporters['beautyhub'] = array(
			'exporter_friendly_name' => __( 'BeautyHub – scheda cliente e appuntamenti', 'beautyhub-core' ),
			'callback'               => array( __CLASS__, 'export' ),
		);
		return $exporters;
	}

	public static function register_eraser( $erasers ) {
		$erasers['beautyhub'] = array(
			'eraser_friendly_name' => __( 'BeautyHub – scheda cliente', 'beautyhub-core' ),
			'callback'             => array( __CLASS__, 'erase' ),
		);
		return $erasers;
	}

	public static function export( $email ) {
		$c    = BHC_Repository::find_client_by_email( $email );
		$data = array();
		if ( $c ) {
			$fields = array();
			foreach ( $c as $k => $v ) {
				if ( '' !== (string) $v && ! in_array( $k, array( 'id', 'user_id' ), true ) ) {
					$fields[] = array( 'name' => $k, 'value' => $v );
				}
			}
			$data[] = array(
				'group_id'    => 'beautyhub-client',
				'group_label' => __( 'Scheda cliente', 'beautyhub-core' ),
				'item_id'     => 'client-' . $c['id'],
				'data'        => $fields,
			);
			foreach ( BHC_Repository::client_appointments( $c['id'], 500 ) as $a ) {
				$data[] = array(
					'group_id'    => 'beautyhub-appointments',
					'group_label' => __( 'Appuntamenti', 'beautyhub-core' ),
					'item_id'     => 'appt-' . $a['id'],
					'data'        => array(
						array( 'name' => __( 'Data', 'beautyhub-core' ), 'value' => $a['start_at'] ),
						array( 'name' => __( 'Trattamento', 'beautyhub-core' ), 'value' => $a['treatment_name'] ),
						array( 'name' => __( 'Stato', 'beautyhub-core' ), 'value' => $a['status'] ),
						array( 'name' => __( 'Prezzo', 'beautyhub-core' ), 'value' => $a['price'] ),
					),
				);
			}
		}
		$p = BHC_People::find_by_email( $email );
		if ( $p ) {
			$fields = array();
			foreach ( BHC_People::FIELDS as $k ) {
				if ( '' !== (string) $p[ $k ] && null !== $p[ $k ] ) {
					$fields[] = array( 'name' => $k, 'value' => $p[ $k ] );
				}
			}
			$data[] = array(
				'group_id'    => 'beautyhub-staff',
				'group_label' => __( 'Scheda personale', 'beautyhub-core' ),
				'item_id'     => 'staff-' . $p['id'],
				'data'        => $fields,
			);
		}
		return array( 'data' => $data, 'done' => true );
	}

	public static function erase( $email ) {
		$c = BHC_Repository::find_client_by_email( $email );
		if ( ! $c ) {
			return array( 'items_removed' => false, 'items_retained' => false, 'messages' => array(), 'done' => true );
		}
		BHC_Repository::delete_client( $c['id'] );
		return array(
			'items_removed'  => true,
			'items_retained' => true,
			'messages'       => array( __( 'Gli incassi sono stati mantenuti in forma anonima per obblighi contabili.', 'beautyhub-core' ) ),
			'done'           => true,
		);
	}

	public static function policy_text() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}
		wp_add_privacy_policy_content(
			'BeautyHub',
			'<p>' . esc_html__( 'Quando prenoti un trattamento raccogliamo nome, cognome, email, telefono e le note che inserisci, per gestire l\'appuntamento e inviarti conferme e promemoria. Le informazioni sulla salute utili ai trattamenti (allergie, controindicazioni) sono accessibili solo alle operatrici autorizzate. Puoi chiedere in ogni momento l\'accesso, la rettifica o la cancellazione dei tuoi dati.', 'beautyhub-core' ) . '</p>'
		);
	}
}
