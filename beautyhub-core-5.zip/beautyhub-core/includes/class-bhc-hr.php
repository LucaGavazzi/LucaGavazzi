<?php
/**
 * Selezione e colloqui del personale (ispirato a PeopleHub):
 * candidati, colloquio di selezione e assunzione, valutazione periodica, fine periodo di prova,
 * colloquio di uscita. Compilazione dal responsabile o su tablet (con firma), stampa compilata o vuota.
 * Con l'esito "Assunto" il candidato diventa una nuova scheda del personale.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_HR {

	const STATUSES = array( 'nuovo', 'colloquio', 'valutazione', 'assunto', 'archiviato' );

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'candidates' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			first_name varchar(100) NOT NULL DEFAULT '',
			last_name varchar(100) NOT NULL DEFAULT '',
			phone varchar(40) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			position varchar(120) NOT NULL DEFAULT '',
			channel varchar(60) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'nuovo',
			rating tinyint(3) unsigned NOT NULL DEFAULT 0,
			interview_at datetime DEFAULT NULL,
			notes text,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			decided_at datetime DEFAULT NULL,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'interviews' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			type varchar(20) NOT NULL DEFAULT '',
			candidate_id bigint(20) unsigned NOT NULL DEFAULT 0,
			person_id bigint(20) unsigned NOT NULL DEFAULT 0,
			data longtext,
			status varchar(15) NOT NULL DEFAULT 'bozza',
			outcome varchar(30) NOT NULL DEFAULT '',
			rating tinyint(3) unsigned NOT NULL DEFAULT 0,
			signature longtext,
			signed_name varchar(190) NOT NULL DEFAULT '',
			signed_at datetime DEFAULT NULL,
			source varchar(10) NOT NULL DEFAULT 'staff',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY candidate_id (candidate_id),
			KEY person_id (person_id),
			KEY type (type)
			) {$c};"
		);
	}

	/* ==================================================================
	 * Modelli (stessa struttura delle schede clienti)
	 * ================================================================ */

	private static function f( $id, $label, $type = 'text', $extra = array() ) {
		return array_merge( array( 'id' => $id, 'label' => $label, 'type' => $type ), $extra );
	}
	private static function scale( $id, $label ) {
		return array( 'id' => $id, 'type' => 'scale', 'label' => $label, 'min' => 1, 'max' => 5, 'hint' => '1 insufficiente · 2 da migliorare · 3 adeguato · 4 buono · 5 eccellente', 'w' => 'half' );
	}
	private static function yn( $id, $label ) {
		return array( 'id' => $id, 'type' => 'yesno', 'label' => $label, 'detail' => 'Note' );
	}

	public static function privacy_text() {
		$center = bhc_get_option( 'center_name' );
		return "Ai sensi dell'art. 13 del Regolamento UE 2016/679 (GDPR), {$center}, titolare del trattamento, informa che i dati indicati in questa scheda sono trattati esclusivamente per la selezione del personale e, in caso di esito positivo, per l'instaurazione del rapporto di lavoro. Base giuridica: misure precontrattuali richieste dall'interessato (art. 6, par. 1, lett. b) e obblighi di legge; non è richiesto il consenso. I dati sono trattati da personale autorizzato, non sono diffusi e sono conservati per il tempo necessario alla selezione e comunque non oltre 24 mesi, salvo l'assunzione. L'interessato può esercitare i diritti di accesso, rettifica, cancellazione, limitazione e opposizione (artt. 15-22 GDPR) e proporre reclamo al Garante. Il conferimento è facoltativo, ma senza i dati non è possibile partecipare alla selezione.";
	}

	public static function templates() {
		$roles     = BHC_People::roles();
		$contracts = BHC_People::contract_types();
		$footer    = 'Uso interno | Gestione del personale';
		$t         = array(
			'assunzione' => array(
				'title'       => 'Colloquio di selezione e assunzione',
				'short'       => 'Selezione',
				'code'        => 'CS',
				'color'       => '#7d8c6f',
				'subject'     => 'candidato',
				'footer'      => $footer,
				'client'      => array(),
				'kiosk_title' => 'Benvenuta, benvenuto',
				'kiosk_intro' => 'Grazie per l\'interesse verso ' . bhc_get_option( 'center_name' ) . '. Questa scheda ci aiuta a conoscerti prima del colloquio: servono circa 10 minuti.',
				'declaration' => 'Dichiaro che le informazioni inserite sono veritiere.',
				'consent'     => 'Ho letto l\'informativa sul trattamento dei dati personali.',
				'privacy'     => self::privacy_text(),
				'pages'       => array(
					array(
						'subtitle' => 'Dati personali',
						'sections' => array(
							array(
								'title'  => 'Dati personali',
								'fields' => array(
									self::f( 'first_name', 'Nome *', 'text', array( 'map' => 'first_name', 'required' => true ) ),
									self::f( 'last_name', 'Cognome *', 'text', array( 'map' => 'last_name', 'required' => true ) ),
									self::f( 'birth_date', 'Data di nascita', 'date', array( 'map' => 'birth_date', 'w' => 'third' ) ),
									self::f( 'birth_place', 'Luogo di nascita', 'text', array( 'map' => 'birth_place', 'w' => 'third' ) ),
									self::f( 'tax_code', 'Codice fiscale', 'text', array( 'map' => 'tax_code', 'w' => 'third' ) ),
									self::f( 'nationality', 'Cittadinanza', 'text', array( 'map' => 'nationality', 'w' => 'third' ) ),
									self::f( 'address', 'Indirizzo di residenza', 'text', array( 'map' => 'address', 'w' => 'twothird' ) ),
									self::f( 'zip', 'CAP', 'text', array( 'map' => 'zip', 'w' => 'third' ) ),
									self::f( 'city', 'Comune', 'text', array( 'map' => 'city', 'w' => 'third' ) ),
									self::f( 'province', 'Provincia', 'text', array( 'map' => 'province', 'w' => 'third' ) ),
									self::f( 'mobile', 'Cellulare *', 'tel', array( 'map' => 'mobile', 'required' => true ) ),
									self::f( 'email', 'Email', 'email', array( 'map' => 'email' ) ),
									self::f( 'license', 'Patente di guida', 'radio', array( 'options' => array( 'Nessuna', 'B', 'B con auto propria' ) ) ),
									self::yn( 'protected', 'Appartieni alle categorie protette (L. 68/1999)? (facoltativo)' ),
								),
							),
						),
					),
					array(
						'subtitle' => 'Formazione ed esperienze',
						'sections' => array(
							array(
								'title'  => 'Studi e qualifiche',
								'fields' => array(
									self::f( 'school', 'Titolo di studio più alto', 'radio', array( 'options' => array( 'Licenza media', 'Qualifica professionale', 'Diploma', 'Laurea' ) ) ),
									self::f( 'qualifications', 'Qualifiche nel settore estetico', 'checks', array( 'cols' => 2, 'options' => array( 'Qualifica professionale di estetista', 'Abilitazione / specializzazione per l\'esercizio autonomo (L. 1/1990)', 'Attestato di onicotecnica', 'Diploma o attestato di massaggio', 'In corso di formazione', 'Nessuna' ) ) ),
									self::f( 'courses', 'Corsi, attestati e aggiornamenti', 'grid', array( 'rows' => 3, 'grow' => true, 'columns' => array( 'Corso o attestato', 'Ente / accademia', 'Anno' ) ) ),
									self::f( 'languages', 'Lingue straniere e livello', 'text', array( 'w' => 'full' ) ),
								),
							),
							array(
								'title'  => 'Esperienze lavorative',
								'fields' => array(
									self::f( 'experiences', 'Esperienze (dalla più recente)', 'grid', array( 'rows' => 3, 'grow' => true, 'columns' => array( 'Centro / azienda', 'Ruolo', 'Dal', 'Al', 'Motivo del cambiamento' ) ) ),
									self::yn( 'references', 'Possiamo chiedere referenze ai precedenti datori di lavoro?' ),
								),
							),
						),
					),
					array(
						'subtitle' => 'Competenze e disponibilità',
						'sections' => array(
							array(
								'title'  => 'Competenze e disponibilità',
								'fields' => array(
									self::f( 'position', 'Per quale posizione ti candidi? *', 'radio', array( 'required' => true, 'options' => array( 'Estetista', 'Onicotecnica', 'Massaggiatrice / massoterapista', 'Receptionist', 'Apprendista estetista', 'Responsabile di centro', 'Altro' ) ) ),
									self::f( 'skills', 'Trattamenti e attività che sai eseguire', 'checks', array( 'cols' => 3, 'options' => array( 'Trattamenti viso', 'Trattamenti corpo', 'Massaggi', 'Manicure / pedicure', 'Ricostruzione unghie / gel', 'Semipermanente', 'Epilazione con cera', 'Laser / luce pulsata', 'Extension e laminazione ciglia', 'Trucco', 'Vendita e consiglio prodotti', 'Reception, agenda e cassa' ) ) ),
									self::f( 'brands', 'Marchi, metodi e apparecchiature che conosci', 'textarea' ),
									self::f( 'strengths', 'Punti di forza', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'why', 'Perché vorresti lavorare con noi?', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'availability', 'Disponibilità di orario', 'checks', array( 'cols' => 5, 'options' => array( 'Tempo pieno', 'Part-time', 'Turni', 'Sabato', 'Festivi' ) ) ),
									self::f( 'start', 'Da quando saresti disponibile?', 'date', array( 'w' => 'third' ) ),
									self::f( 'salary_wish', 'Stipendio richiesto (€ netti al mese)', 'number', array( 'w' => 'third' ) ),
									self::f( 'candidate_notes', 'Vuoi aggiungere qualcosa?', 'textarea' ),
								),
							),
						),
						'sign'     => true,
					),
					array(
						'subtitle' => 'Valutazione e proposta di assunzione',
						'staff'    => true,
						'sections' => array(
							array(
								'title'  => 'Valutazione della selezionatrice',
								'staff'  => true,
								'fields' => array(
									self::f( 'interview_date', 'Data del colloquio', 'date', array( 'w' => 'third' ) ),
									self::f( 'interviewer', 'Selezionatrice', 'text', array( 'w' => 'third' ) ),
									self::f( 'practical', 'Prova pratica svolta', 'text', array( 'w' => 'third' ) ),
									self::scale( 'v_presentation', 'Presentazione e comunicazione' ),
									self::scale( 'v_technique', 'Competenze tecniche (prova pratica)' ),
									self::scale( 'v_client', 'Attenzione alla cliente e cortesia' ),
									self::scale( 'v_motivation', 'Motivazione' ),
									self::scale( 'v_flex', 'Disponibilità e flessibilità' ),
									self::scale( 'v_overall', 'Valutazione complessiva' ),
									self::f( 'v_strengths', 'Punti di forza', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'v_check', 'Aspetti da approfondire', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'v_notes', 'Note del colloquio', 'textarea' ),
								),
							),
							array(
								'title'  => 'Proposta di assunzione',
								'staff'  => true,
								'note'   => 'Si compila se la persona viene assunta: questi dati passano nella scheda del nuovo personale.',
								'fields' => array(
									self::f( 'p_role', 'Ruolo nel gestionale', 'radio', array( 'options' => array_values( $roles ), 'map' => 'role' ) ),
									self::f( 'p_job', 'Mansione', 'text', array( 'map' => 'job_title' ) ),
									self::f( 'p_contract', 'Tipo di contratto', 'radio', array( 'options' => array_values( $contracts ), 'map' => 'contract_type' ) ),
									self::f( 'p_level', 'Livello / inquadramento CCNL', 'text', array( 'map' => 'contract_level', 'w' => 'third' ) ),
									self::f( 'p_hire', 'Data di assunzione', 'date', array( 'map' => 'hire_date', 'w' => 'third' ) ),
									self::f( 'p_hours', 'Ore settimanali', 'number', array( 'map' => 'weekly_hours', 'w' => 'third' ) ),
									self::f( 'p_salary', 'Stipendio proposto (€ netti al mese)', 'number', array( 'w' => 'third' ) ),
									self::f( 'p_salary_notes', 'Note sullo stipendio (lordo annuo, superminimo, premi…)', 'text', array( 'w' => 'twothird' ) ),
									self::f( 'sign_selector', 'Firma della selezionatrice', 'sign' ),
								),
							),
						),
					),
				),
			),
			'periodica'  => array(
				'title'       => 'Valutazione periodica',
				'short'       => 'Valutazione',
				'code'        => 'VP',
				'color'       => '#5f6b7a',
				'subject'     => 'dipendente',
				'footer'      => $footer,
				'client'      => array(),
				'kiosk_title' => 'Valutazione periodica',
				'kiosk_intro' => 'Questa parte è dedicata a te: racconta com\'è andato il periodo, cosa ti ha aiutato e cosa ti servirebbe per crescere.',
				'declaration' => 'Ho preso visione della valutazione e ho aggiunto le mie osservazioni.',
				'consent'     => '',
				'pages'       => array(
					array(
						'subtitle' => 'Valutazione del responsabile',
						'staff'    => true,
						'sections' => array(
							array(
								'title'  => 'Periodo valutato',
								'staff'  => true,
								'fields' => array( self::f( 'from', 'Dal', 'date', array( 'w' => 'third' ) ), self::f( 'to', 'Al', 'date', array( 'w' => 'third' ) ), self::f( 'evaluator', 'Valutatore', 'text', array( 'w' => 'third' ) ) ),
							),
							array(
								'title'  => 'Valutazione',
								'staff'  => true,
								'fields' => array(
									self::scale( 'v_quality', 'Qualità dei trattamenti' ),
									self::scale( 'v_technique', 'Competenze tecniche e aggiornamento' ),
									self::scale( 'v_client', 'Attenzione e fidelizzazione della cliente' ),
									self::scale( 'v_sales', 'Consiglio e vendita dei prodotti' ),
									self::scale( 'v_time', 'Puntualità e rispetto dei tempi di agenda' ),
									self::scale( 'v_hygiene', 'Igiene, ordine della cabina e procedure' ),
									self::scale( 'v_team', 'Lavoro di squadra' ),
									self::scale( 'v_overall', 'Valutazione complessiva' ),
									self::f( 'v_strengths', 'Punti di forza', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'v_improve', 'Aree di miglioramento', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'goals', 'Obiettivi per il prossimo periodo', 'grid', array( 'rows' => 3, 'grow' => true, 'columns' => array( 'Obiettivo', 'Come si misura', 'Entro' ) ) ),
									self::f( 'training', 'Formazione consigliata', 'textarea' ),
								),
							),
						),
					),
					array(
						'subtitle' => 'Osservazioni del dipendente e firme',
						'sections' => array(
							array(
								'title'  => 'Osservazioni del dipendente',
								'fields' => array(
									self::scale( 'd_self', 'Come valuti il periodo trascorso?' ),
									self::f( 'd_satisfaction', 'Cosa ti ha dato più soddisfazione?', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'd_difficulties', 'Quali difficoltà hai incontrato?', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'd_needs', 'Di cosa avresti bisogno (formazione, strumenti, supporto)?', 'textarea' ),
									self::f( 'd_comments', 'Commenti sulla valutazione', 'textarea' ),
								),
							),
							array(
								'title'  => 'Chiusura',
								'staff'  => true,
								'fields' => array( self::f( 'next', 'Prossimo colloquio previsto', 'date', array( 'w' => 'third' ) ), self::f( 'sign_manager', 'Firma del responsabile', 'sign' ) ),
							),
						),
						'sign'     => true,
					),
				),
			),
			'fine_prova' => array(
				'title'       => 'Fine periodo di prova',
				'short'       => 'Fine prova',
				'code'        => 'FP',
				'color'       => '#b0735a',
				'subject'     => 'dipendente',
				'footer'      => $footer,
				'client'      => array(),
				'kiosk_title' => 'Fine del periodo di prova',
				'kiosk_intro' => 'Questa parte è dedicata a te: com\'è andato l\'inserimento?',
				'declaration' => 'Ho preso visione della valutazione e ho aggiunto le mie osservazioni.',
				'consent'     => '',
				'pages'       => array(
					array(
						'subtitle' => 'Valutazione del periodo di prova',
						'staff'    => true,
						'sections' => array(
							array(
								'title'  => 'Periodo di prova',
								'staff'  => true,
								'fields' => array( self::f( 'from', 'Inizio', 'date', array( 'w' => 'third' ) ), self::f( 'to', 'Fine', 'date', array( 'w' => 'third' ) ), self::f( 'tutor', 'Responsabile / tutor', 'text', array( 'w' => 'third' ) ) ),
							),
							array(
								'title'  => 'Valutazione',
								'staff'  => true,
								'fields' => array(
									self::scale( 'v_technique', 'Competenze tecniche per la mansione' ),
									self::scale( 'v_learning', 'Capacità di apprendimento' ),
									self::scale( 'v_client', 'Rapporto con le clienti' ),
									self::scale( 'v_time', 'Puntualità e presenza' ),
									self::scale( 'v_team', 'Collaborazione con colleghe e responsabili' ),
									self::scale( 'v_hygiene', 'Igiene e rispetto delle procedure' ),
									self::scale( 'v_overall', 'Valutazione complessiva' ),
									self::f( 'v_strengths', 'Punti di forza', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'v_improve', 'Aspetti da migliorare', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'outcome', 'Esito del periodo di prova', 'radio', array( 'options' => array( 'Superato', 'Non superato', 'Da prolungare (se previsto dal contratto)' ), 'outcome' => true ) ),
									self::f( 'outcome_notes', 'Motivazione dell\'esito', 'textarea' ),
								),
							),
						),
					),
					array(
						'subtitle' => 'Osservazioni del dipendente e firme',
						'sections' => array(
							array(
								'title'  => 'Osservazioni del dipendente',
								'fields' => array(
									self::scale( 'd_onboarding', 'Come valuti il tuo inserimento?' ),
									self::yn( 'd_training', 'La formazione ricevuta è stata sufficiente?' ),
									self::f( 'd_expectations', 'Il lavoro corrisponde a quanto ti aspettavi?', 'textarea' ),
									self::f( 'd_comments', 'Commenti', 'textarea' ),
								),
							),
							array( 'title' => 'Chiusura', 'staff' => true, 'fields' => array( self::f( 'sign_manager', 'Firma del responsabile', 'sign' ) ) ),
						),
						'sign'     => true,
					),
				),
			),
			'uscita'     => array(
				'title'       => 'Colloquio di uscita',
				'short'       => 'Uscita',
				'code'        => 'CU',
				'color'       => '#8a6fa8',
				'subject'     => 'dipendente',
				'footer'      => $footer,
				'client'      => array(),
				'kiosk_title' => 'Colloquio di uscita',
				'kiosk_intro' => 'Grazie per il tempo trascorso con noi. Le tue risposte ci aiutano a migliorare: sii sincera, non ci sono risposte sbagliate.',
				'declaration' => 'Confermo le risposte date.',
				'consent'     => '',
				'pages'       => array(
					array(
						'subtitle' => 'Motivi dell\'uscita ed esperienza',
						'sections' => array(
							array(
								'title'  => 'Motivi dell\'uscita',
								'fields' => array(
									self::f( 'reason', 'Motivo principale', 'radio', array( 'options' => array( 'Nuova opportunità di lavoro', 'Apertura di un centro proprio', 'Retribuzione', 'Mancanza di crescita', 'Orari o conciliazione vita-lavoro', 'Ambiente di lavoro', 'Rapporto con la responsabile', 'Motivi personali o familiari', 'Trasferimento', 'Fine del contratto', 'Altro' ) ) ),
									self::f( 'reason_detail', 'Vuoi spiegare meglio?', 'textarea' ),
								),
							),
							array(
								'title'  => 'La tua esperienza',
								'fields' => array(
									self::scale( 's_job', 'Soddisfazione per il lavoro in cabina' ),
									self::scale( 's_team', 'Ambiente e colleghe' ),
									self::scale( 's_manager', 'Rapporto con la responsabile' ),
									self::scale( 's_training', 'Formazione e crescita' ),
									self::scale( 's_pay', 'Retribuzione e benefit' ),
									self::scale( 's_hours', 'Orari e organizzazione dell\'agenda' ),
									self::f( 'liked', 'Cosa hai apprezzato di più?', 'textarea', array( 'w' => 'half' ) ),
									self::f( 'improve', 'Cosa dovremmo migliorare?', 'textarea', array( 'w' => 'half' ) ),
									self::yn( 'recommend', 'Consiglieresti a un\'amica di lavorare qui?' ),
									self::yn( 'return', 'Torneresti a lavorare con noi?' ),
								),
							),
						),
						'sign'     => true,
					),
					array(
						'subtitle' => 'Chiusura del rapporto',
						'staff'    => true,
						'sections' => array(
							array(
								'title'  => 'Chiusura del rapporto',
								'staff'  => true,
								'fields' => array(
									self::f( 'last_day', 'Ultimo giorno di lavoro', 'date', array( 'w' => 'third' ) ),
									self::f( 'returned', 'Materiali e accessi riconsegnati', 'checks', array( 'cols' => 3, 'options' => array( 'Divise', 'Chiavi', 'Badge', 'Attrezzature', 'Kit / prodotti in dotazione', 'Accesso al gestionale disattivato' ) ) ),
									self::yn( 'rehire', 'La riassumeresti?' ),
									self::f( 'notes', 'Note della responsabile', 'textarea' ),
									self::f( 'sign_manager', 'Firma della responsabile', 'sign' ),
								),
							),
						),
					),
				),
			),
		);
		return apply_filters( 'bhc_hr_templates', $t );
	}

	/* ==================================================================
	 * Candidati
	 * ================================================================ */

	private static function cand_out( $r ) {
		foreach ( array( 'id', 'rating', 'person_id', 'created_by' ) as $k ) {
			$r[ $k ] = (int) $r[ $k ];
		}
		$r['name'] = trim( $r['first_name'] . ' ' . $r['last_name'] );
		return $r;
	}

	public static function candidate( $id, $full = true ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'candidates' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		if ( ! $r ) {
			return null;
		}
		$r = self::cand_out( $r );
		if ( $full ) {
			$r['interviews'] = self::interviews( array( 'candidate_id' => $r['id'] ) );
		}
		return $r;
	}

	public static function candidates( $q = '', $status = '' ) {
		global $wpdb;
		$t     = bhc_table( 'candidates' );
		$where = array( '1=1' );
		$args  = array();
		if ( 'aperti' === $status ) {
			$where[] = "status IN ('nuovo','colloquio','valutazione')";
		} elseif ( in_array( $status, self::STATUSES, true ) ) {
			$where[] = 'status = %s';
			$args[]  = $status;
		}
		if ( $q ) {
			$like    = '%' . $wpdb->esc_like( $q ) . '%';
			$where[] = '(first_name LIKE %s OR last_name LIKE %s OR phone LIKE %s OR email LIKE %s OR position LIKE %s)';
			array_push( $args, $like, $like, $like, $like, $like );
		}
		$sql  = "SELECT * FROM {$t} WHERE " . implode( ' AND ', $where ) . ' ORDER BY updated_at DESC LIMIT 300';
		$rows = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		return array_map( array( __CLASS__, 'cand_out' ), $rows );
	}

	public static function counts() {
		global $wpdb;
		$t   = bhc_table( 'candidates' );
		$out = array_fill_keys( self::STATUSES, 0 );
		foreach ( $wpdb->get_results( "SELECT status, COUNT(*) n FROM {$t} GROUP BY status", ARRAY_A ) as $r ) { // phpcs:ignore
			$out[ $r['status'] ] = (int) $r['n'];
		}
		return $out;
	}

	public static function save_candidate( array $d, $id = 0 ) {
		global $wpdb;
		$row = array();
		foreach ( array( 'first_name', 'last_name', 'phone', 'position', 'channel' ) as $k ) {
			if ( isset( $d[ $k ] ) ) {
				$row[ $k ] = sanitize_text_field( (string) $d[ $k ] );
			}
		}
		if ( isset( $d['email'] ) ) {
			$row['email'] = sanitize_email( (string) $d['email'] );
		}
		if ( isset( $d['notes'] ) ) {
			$row['notes'] = sanitize_textarea_field( (string) $d['notes'] );
		}
		if ( isset( $d['interview_at'] ) ) {
			$v                   = str_replace( 'T', ' ', (string) $d['interview_at'] );
			$row['interview_at'] = null;
			if ( preg_match( '/^(\d{4}-\d{2}-\d{2})(?: (\d{2}:\d{2}))?/', $v, $mm ) ) {
				$row['interview_at'] = $mm[1] . ' ' . ( $mm[2] ?? '00:00' ) . ':00';
			}
		}
		if ( isset( $d['status'] ) && in_array( $d['status'], array( 'nuovo', 'colloquio', 'valutazione' ), true ) ) {
			$row['status'] = $d['status'];
		}
		$row['updated_at'] = current_time( 'mysql' );
		if ( $id ) {
			$wpdb->update( bhc_table( 'candidates' ), $row, array( 'id' => (int) $id ) );
			return (int) $id;
		}
		if ( empty( $row['first_name'] ) || empty( $row['last_name'] ) ) {
			return new WP_Error( 'name', __( 'Nome e cognome del candidato sono obbligatori.', 'beautyhub-core' ) );
		}
		$row['status']     = $row['status'] ?? 'nuovo';
		$row['created_by'] = get_current_user_id();
		$row['created_at'] = $row['updated_at'];
		$wpdb->insert( bhc_table( 'candidates' ), $row );
		return (int) $wpdb->insert_id;
	}

	/** Esito "Assunto": crea la scheda del personale con i dati del colloquio. */
	public static function hire( $id ) {
		global $wpdb;
		$c = self::candidate( $id );
		if ( ! $c ) {
			return new WP_Error( 'not_found', __( 'Candidato non trovato.', 'beautyhub-core' ) );
		}
		if ( $c['person_id'] && BHC_People::get( $c['person_id'] ) ) {
			return new WP_Error( 'already', __( 'Questa persona è già stata assunta.', 'beautyhub-core' ) );
		}
		$iv   = null;
		foreach ( $c['interviews'] as $i ) {
			if ( 'assunzione' === $i['type'] ) {
				$iv = self::interview( $i['id'] );
				break;
			}
		}
		$data = $iv ? (array) $iv['data'] : array();
		$tpl  = self::templates()['assunzione'];
		$p    = array(
			'first_name' => $c['first_name'],
			'last_name'  => $c['last_name'],
			'mobile'     => $c['phone'],
			'email'      => $c['email'],
			'status'     => 'attivo',
			'role'       => 'operatrice',
			'job_title'  => $c['position'],
		);
		$roles     = array_flip( BHC_People::roles() );
		$contracts = array_flip( BHC_People::contract_types() );
		foreach ( BHC_Forms::fields_of( $tpl ) as $f ) {
			if ( empty( $f['map'] ) || ! isset( $data[ $f['id'] ] ) || '' === $data[ $f['id'] ] ) {
				continue;
			}
			$v = $data[ $f['id'] ];
			if ( 'role' === $f['map'] ) {
				$v = $roles[ $v ] ?? 'operatrice';
			} elseif ( 'contract_type' === $f['map'] ) {
				$v = $contracts[ $v ] ?? '';
			}
			$p[ $f['map'] ] = $v;
		}
		if ( empty( $p['hire_date'] ) ) {
			$p['hire_date'] = current_time( 'Y-m-d' );
		}
		$notes = array( 'Assunta dalla selezione del ' . wp_date( 'd/m/Y', strtotime( current_time( 'mysql' ) ) ) . ( $c['rating'] ? ' · valutazione ' . $c['rating'] . '/5' : '' ) . '.' );
		if ( ! empty( $data['p_salary'] ) ) {
			$notes[] = 'Stipendio proposto: € ' . $data['p_salary'] . ' netti/mese' . ( ! empty( $data['p_salary_notes'] ) ? ' (' . $data['p_salary_notes'] . ')' : '' ) . '.';
		}
		if ( ! empty( $data['skills'] ) && is_array( $data['skills'] ) ) {
			$notes[] = 'Competenze dichiarate: ' . implode( ', ', $data['skills'] ) . '.';
		}
		$p['notes'] = implode( "\n", $notes );
		// Corsi dichiarati → corsi e attestati della scheda.
		$courses = array();
		foreach ( (array) ( $data['courses'] ?? array() ) as $r ) {
			if ( ! empty( $r[0] ) ) {
				$courses[] = array( 'name' => $r[0], 'provider' => $r[1] ?? '', 'date' => preg_match( '/^\d{4}$/', $r[2] ?? '' ) ? $r[2] . '-01-01' : '', 'hours' => 0, 'expires' => '' );
			}
		}
		if ( $courses ) {
			$p['courses'] = $courses;
		}
		$pid = BHC_People::save( $p );
		if ( is_wp_error( $pid ) ) {
			return $pid;
		}
		$now = current_time( 'mysql' );
		$wpdb->update( bhc_table( 'candidates' ), array( 'status' => 'assunto', 'person_id' => $pid, 'decided_at' => $now, 'updated_at' => $now ), array( 'id' => $c['id'] ) );
		// I colloqui del candidato restano consultabili anche dalla scheda del personale.
		$wpdb->update( bhc_table( 'interviews' ), array( 'person_id' => $pid ), array( 'candidate_id' => $c['id'] ) );
		if ( $iv ) {
			$wpdb->update( bhc_table( 'interviews' ), array( 'outcome' => 'assunto' ), array( 'id' => $iv['id'] ) );
		}
		return $pid;
	}

	public static function set_status( $id, $status ) {
		global $wpdb;
		$now = current_time( 'mysql' );
		$wpdb->update( bhc_table( 'candidates' ), array( 'status' => $status, 'decided_at' => 'archiviato' === $status ? $now : null, 'updated_at' => $now ), array( 'id' => (int) $id ) );
		$wpdb->update( bhc_table( 'interviews' ), array( 'outcome' => 'archiviato' === $status ? 'non assunto' : '' ), array( 'candidate_id' => (int) $id, 'type' => 'assunzione' ) );
	}

	/* ==================================================================
	 * Colloqui
	 * ================================================================ */

	private static function iv_out( $r, $full = true ) {
		foreach ( array( 'id', 'candidate_id', 'person_id', 'rating' ) as $k ) {
			$r[ $k ] = (int) $r[ $k ];
		}
		$tpl          = self::templates()[ $r['type'] ] ?? null;
		$r['title']   = $tpl ? $tpl['title'] : $r['type'];
		$r['short']   = $tpl ? $tpl['short'] : $r['type'];
		$r['code']    = ( $tpl ? $tpl['code'] : 'CO' ) . '-' . str_pad( (string) $r['id'], 6, '0', STR_PAD_LEFT );
		$r['signed']  = 'firmata' === $r['status'];
		$r['data']    = $full ? ( json_decode( (string) $r['data'], true ) ?: new stdClass() ) : '';
		if ( ! $full ) {
			unset( $r['signature'] );
		}
		$u            = $r['updated_by'] ? get_userdata( (int) $r['updated_by'] ) : null;
		$r['user']    = $u ? $u->display_name : '';
		// Nome dell'interessato.
		$r['subject'] = '';
		if ( $r['person_id'] ) {
			$p            = BHC_People::get( $r['person_id'] );
			$r['subject'] = $p ? trim( $p['first_name'] . ' ' . $p['last_name'] ) : '';
		}
		if ( ! $r['subject'] && $r['candidate_id'] ) {
			$c            = self::candidate( $r['candidate_id'], false );
			$r['subject'] = $c ? $c['name'] : '';
		}
		return $r;
	}

	public static function interview( $id ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'interviews' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		return $r ? self::iv_out( $r ) : null;
	}

	public static function interviews( array $f = array() ) {
		global $wpdb;
		$t     = bhc_table( 'interviews' );
		$where = array( '1=1' );
		$args  = array();
		foreach ( array( 'candidate_id', 'person_id' ) as $k ) {
			if ( ! empty( $f[ $k ] ) ) {
				$where[] = "{$k} = %d";
				$args[]  = (int) $f[ $k ];
			}
		}
		if ( ! empty( $f['type'] ) && isset( self::templates()[ $f['type'] ] ) ) {
			$where[] = 'type = %s';
			$args[]  = $f['type'];
		}
		$sql  = "SELECT id, type, candidate_id, person_id, status, outcome, rating, signed_name, signed_at, source, created_by, updated_by, created_at, updated_at FROM {$t} WHERE " . implode( ' AND ', $where ) . ' ORDER BY updated_at DESC LIMIT 300';
		$rows = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		return array_map(
			function ( $r ) {
				$r['data'] = '';
				return BHC_HR::iv_public( $r );
			},
			$rows
		);
	}

	public static function iv_public( $r ) {
		return self::iv_out( $r, false );
	}

	/** Campi del responsabile (modificabili anche dopo la firma dell'interessato). */
	private static function staff_ids( $type ) {
		$ids = array();
		foreach ( BHC_Forms::fields_of( self::templates()[ $type ] ) as $f ) {
			if ( $f['staff'] ) {
				$ids[] = $f['id'];
			}
		}
		return $ids;
	}

	public static function save_interview( array $d, $id = 0 ) {
		global $wpdb;
		$now = current_time( 'mysql' );
		if ( $id ) {
			$cur = self::interview( $id );
			if ( ! $cur ) {
				return new WP_Error( 'not_found', __( 'Colloquio non trovato.', 'beautyhub-core' ) );
			}
			$type  = $cur['type'];
			$tpl   = self::templates()[ $type ];
			$clean = BHC_Forms::clean_data( $tpl, $d['data'] ?? array() );
			$old   = (array) $cur['data'];
			if ( $cur['signed'] ) {
				$staff = self::staff_ids( $type );
				foreach ( $clean as $k => $v ) {
					if ( in_array( $k, $staff, true ) ) {
						$old[ $k ] = $v;
					}
				}
				$clean = $old;
			} else {
				$clean = array_merge( $old, $clean );
			}
			$row = array( 'data' => wp_json_encode( $clean ), 'updated_by' => get_current_user_id(), 'updated_at' => $now );
		} else {
			$type = sanitize_key( $d['type'] ?? '' );
			if ( ! isset( self::templates()[ $type ] ) ) {
				return new WP_Error( 'type', __( 'Tipo di colloquio non valido.', 'beautyhub-core' ) );
			}
			$tpl  = self::templates()[ $type ];
			$cid  = absint( $d['candidate_id'] ?? 0 );
			$pid  = absint( $d['person_id'] ?? 0 );
			if ( 'candidato' === $tpl['subject'] && ! $cid && ! $pid ) {
				return new WP_Error( 'subject', __( 'Scegli il candidato.', 'beautyhub-core' ) );
			}
			if ( 'dipendente' === $tpl['subject'] && ( ! $pid || ! BHC_People::get( $pid ) ) ) {
				return new WP_Error( 'subject', __( 'Scegli la persona del personale.', 'beautyhub-core' ) );
			}
			$clean = BHC_Forms::clean_data( $tpl, $d['data'] ?? array() );
			$row   = array(
				'type'         => $type,
				'candidate_id' => $cid,
				'person_id'    => $pid,
				'status'       => 'bozza',
				'source'       => 'tablet' === ( $d['source'] ?? '' ) ? 'tablet' : 'staff',
				'created_by'   => get_current_user_id(),
				'updated_by'   => get_current_user_id(),
				'created_at'   => $now,
				'updated_at'   => $now,
			);
		}
		// Valutazione complessiva ed esito per gli elenchi.
		if ( isset( $clean['v_overall'] ) && '' !== $clean['v_overall'] ) {
			$row['rating'] = (int) $clean['v_overall'];
		}
		if ( 'fine_prova' === $type && ! empty( $clean['outcome'] ) ) {
			$row['outcome'] = $clean['outcome'];
		}
		$row['data'] = wp_json_encode( $clean );
		// Firma dell'interessato.
		if ( ! empty( $d['signature'] ) && ( ! $id || empty( $cur['signed'] ) ) ) {
			$tpl = self::templates()[ $type ];
			if ( ! empty( $tpl['consent'] ) && empty( $d['data']['_consent'] ) ) {
				return new WP_Error( 'consent', __( 'Per firmare serve la presa visione dell\'informativa.', 'beautyhub-core' ) );
			}
			$sig = (string) $d['signature'];
			if ( 0 !== strpos( $sig, 'data:image/png;base64,' ) || strlen( $sig ) > 400000 ) {
				return new WP_Error( 'signature', __( 'Firma non valida.', 'beautyhub-core' ) );
			}
			$row['signature']   = $sig;
			$row['signed_name'] = sanitize_text_field( (string) ( $d['signed_name'] ?? '' ) );
			$row['signed_at']   = $now;
			$row['status']      = 'firmata';
			if ( 'tablet' === ( $d['source'] ?? '' ) ) {
				$row['source'] = 'tablet';
			}
		}
		if ( $id ) {
			$wpdb->update( bhc_table( 'interviews' ), $row, array( 'id' => (int) $id ) );
		} else {
			$wpdb->insert( bhc_table( 'interviews' ), $row );
			$id = (int) $wpdb->insert_id;
		}
		// Aggiorna il candidato (valutazione, stato).
		$iv = self::interview( $id );
		if ( $iv['candidate_id'] && 'assunzione' === $type ) {
			$c   = self::candidate( $iv['candidate_id'], false );
			$upd = array( 'updated_at' => $now );
			if ( $iv['rating'] ) {
				$upd['rating'] = $iv['rating'];
			}
			if ( $c && 'nuovo' === $c['status'] ) {
				$upd['status'] = $iv['rating'] ? 'valutazione' : 'colloquio';
			} elseif ( $c && 'colloquio' === $c['status'] && $iv['rating'] ) {
				$upd['status'] = 'valutazione';
			}
			if ( ! empty( $clean['position'] ) && $c && ! $c['position'] ) {
				$upd['position'] = $clean['position'];
			}
			$wpdb->update( bhc_table( 'candidates' ), $upd, array( 'id' => $iv['candidate_id'] ) );
		}
		return $id;
	}

	/** Colloquio di selezione compilato sul tablet da un nuovo candidato: crea il candidato. */
	public static function kiosk_candidate( array $d ) {
		$data = (array) ( $d['data'] ?? array() );
		$fn   = trim( sanitize_text_field( (string) ( $data['first_name'] ?? '' ) ) );
		$ln   = trim( sanitize_text_field( (string) ( $data['last_name'] ?? '' ) ) );
		if ( ! $fn || ! $ln ) {
			return new WP_Error( 'name', __( 'Inserisci nome e cognome.', 'beautyhub-core' ) );
		}
		$cid = self::save_candidate(
			array(
				'first_name' => $fn,
				'last_name'  => $ln,
				'phone'      => $data['mobile'] ?? '',
				'email'      => $data['email'] ?? '',
				'position'   => $data['position'] ?? '',
				'channel'    => 'Tablet in centro',
				'status'     => 'colloquio',
			)
		);
		if ( is_wp_error( $cid ) ) {
			return $cid;
		}
		$d['type']         = 'assunzione';
		$d['candidate_id'] = $cid;
		$d['source']       = 'tablet';
		$iid               = self::save_interview( $d );
		if ( is_wp_error( $iid ) ) {
			global $wpdb;
			$wpdb->delete( bhc_table( 'candidates' ), array( 'id' => $cid ) );
			return $iid;
		}
		return $iid;
	}

	/** Colloquio di uscita: chiude il rapporto (cessato, data di fine, accesso disattivato). */
	public static function close_employment( $iid ) {
		$iv = self::interview( $iid );
		if ( ! $iv || 'uscita' !== $iv['type'] || ! $iv['person_id'] ) {
			return new WP_Error( 'iv', __( 'Colloquio di uscita non valido.', 'beautyhub-core' ) );
		}
		$last = $iv['data']['last_day'] ?? '';
		$res  = BHC_People::save( array( 'status' => 'cessato', 'end_date' => $last ? $last : current_time( 'Y-m-d' ) ), $iv['person_id'] );
		return is_wp_error( $res ) ? $res : BHC_People::get( $iv['person_id'] );
	}

	/* ==================================================================
	 * REST
	 * ================================================================ */

	public static function routes() {
		$ns   = BHC_REST::NS;
		$perm = BHC_Permissions::cb( array( 'people' ) );
		$id   = '(?P<id>\d+)';
		register_rest_route( $ns, '/hr/templates', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'templates' ), 'permission_callback' => $perm ) );
		register_rest_route(
			$ns,
			'/hr/candidates',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_candidates' ), 'permission_callback' => $perm ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_cand_create' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route(
			$ns,
			'/hr/candidates/' . $id,
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_cand_get' ), 'permission_callback' => $perm ),
				array( 'methods' => 'PUT', 'callback' => array( __CLASS__, 'rest_cand_update' ), 'permission_callback' => $perm ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_cand_delete' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route( $ns, '/hr/candidates/' . $id . '/outcome', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_outcome' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/hr/kiosk-candidate', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_kiosk_candidate' ), 'permission_callback' => $perm ) );
		register_rest_route(
			$ns,
			'/hr/interviews',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_interviews' ), 'permission_callback' => $perm ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_iv_create' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route(
			$ns,
			'/hr/interviews/' . $id,
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_iv_get' ), 'permission_callback' => $perm ),
				array( 'methods' => 'PUT', 'callback' => array( __CLASS__, 'rest_iv_update' ), 'permission_callback' => $perm ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_iv_delete' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route( $ns, '/hr/interviews/' . $id . '/close-employment', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_close' ), 'permission_callback' => $perm ) );
	}

	private static function err( $e, $status = 400 ) {
		return new WP_REST_Response( array( 'message' => is_wp_error( $e ) ? $e->get_error_message() : $e ), $status );
	}

	public static function rest_candidates( WP_REST_Request $r ) {
		return array( 'items' => self::candidates( (string) $r->get_param( 'q' ), sanitize_key( (string) $r->get_param( 'status' ) ) ), 'counts' => self::counts() );
	}
	public static function rest_cand_create( WP_REST_Request $r ) {
		$id = self::save_candidate( (array) $r->get_json_params() );
		return is_wp_error( $id ) ? self::err( $id ) : self::candidate( $id );
	}
	public static function rest_cand_get( WP_REST_Request $r ) {
		$c = self::candidate( (int) $r['id'] );
		return $c ? $c : self::err( __( 'Candidato non trovato.', 'beautyhub-core' ), 404 );
	}
	public static function rest_cand_update( WP_REST_Request $r ) {
		if ( ! self::candidate( (int) $r['id'], false ) ) {
			return self::err( __( 'Candidato non trovato.', 'beautyhub-core' ), 404 );
		}
		self::save_candidate( (array) $r->get_json_params(), (int) $r['id'] );
		return self::candidate( (int) $r['id'] );
	}
	public static function rest_cand_delete( WP_REST_Request $r ) {
		global $wpdb;
		$wpdb->delete( bhc_table( 'interviews' ), array( 'candidate_id' => (int) $r['id'], 'person_id' => 0 ) );
		$wpdb->delete( bhc_table( 'candidates' ), array( 'id' => (int) $r['id'] ) );
		return array( 'ok' => true );
	}
	public static function rest_outcome( WP_REST_Request $r ) {
		$id = (int) $r['id'];
		$o  = (string) $r->get_param( 'outcome' );
		if ( 'assunto' === $o ) {
			$pid = self::hire( $id );
			if ( is_wp_error( $pid ) ) {
				return self::err( $pid );
			}
			return array( 'candidate' => self::candidate( $id ), 'person' => BHC_People::get( $pid ) );
		}
		if ( in_array( $o, array( 'archiviato', 'valutazione' ), true ) ) {
			self::set_status( $id, $o );
			return array( 'candidate' => self::candidate( $id ) );
		}
		return self::err( __( 'Esito non valido.', 'beautyhub-core' ) );
	}
	public static function rest_kiosk_candidate( WP_REST_Request $r ) {
		$iid = self::kiosk_candidate( (array) $r->get_json_params() );
		return is_wp_error( $iid ) ? self::err( $iid ) : self::interview( $iid );
	}
	public static function rest_interviews( WP_REST_Request $r ) {
		return array( 'items' => self::interviews( array( 'type' => sanitize_key( (string) $r->get_param( 'type' ) ), 'person_id' => absint( $r->get_param( 'person_id' ) ), 'candidate_id' => absint( $r->get_param( 'candidate_id' ) ) ) ) );
	}
	public static function rest_iv_create( WP_REST_Request $r ) {
		$id = self::save_interview( (array) $r->get_json_params() );
		return is_wp_error( $id ) ? self::err( $id ) : self::interview( $id );
	}
	public static function rest_iv_get( WP_REST_Request $r ) {
		$i = self::interview( (int) $r['id'] );
		return $i ? $i : self::err( __( 'Colloquio non trovato.', 'beautyhub-core' ), 404 );
	}
	public static function rest_iv_update( WP_REST_Request $r ) {
		$id = self::save_interview( (array) $r->get_json_params(), (int) $r['id'] );
		return is_wp_error( $id ) ? self::err( $id ) : self::interview( $id );
	}
	public static function rest_iv_delete( WP_REST_Request $r ) {
		global $wpdb;
		$wpdb->delete( bhc_table( 'interviews' ), array( 'id' => (int) $r['id'] ) );
		return array( 'ok' => true );
	}
	public static function rest_close( WP_REST_Request $r ) {
		$res = self::close_employment( (int) $r['id'] );
		return is_wp_error( $res ) ? self::err( $res ) : $res;
	}
}
