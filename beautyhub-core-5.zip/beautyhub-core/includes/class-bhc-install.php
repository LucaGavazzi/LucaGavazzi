<?php
/**
 * Installazione: tabelle, ruoli, pagine e dati di esempio.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Install {

	/**
	 * Attivazione plugin.
	 */
	public static function activate() {
		self::create_tables();
		BHC_Roles::add_roles();
		BHC_Post_Types::register();
		self::create_pages();
		if ( ! get_option( 'bhc_demo_imported' ) ) {
			self::import_demo();
		}
		if ( ! wp_next_scheduled( 'bhc_hourly' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'bhc_hourly' );
		}
		update_option( 'bhc_db_version', BHC_DB_VERSION );
		flush_rewrite_rules();
	}

	/**
	 * Disattivazione: rimuove solo il cron (i dati restano).
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'bhc_hourly' );
		flush_rewrite_rules();
	}

	/**
	 * Aggiornamenti dello schema.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'bhc_db_version' ) !== BHC_DB_VERSION ) {
			$from = (string) get_option( 'bhc_db_version' );
			self::create_tables();
			BHC_Roles::add_roles();
			// Nuovi permessi ai ruoli già configurati: 1.7.0 "cards", 1.8.0 "pos".
			$saved = get_option( 'bhc_role_perms', array() );
			if ( $from && is_array( $saved ) && $saved ) {
				foreach ( array( '1.7.0' => 'cards', '1.8.0' => 'pos', '1.9.0' => 'messages', '1.12.0' => 'timeclock' ) as $ver => $perm ) {
					if ( version_compare( $from, $ver, '<' ) ) {
						foreach ( 'timeclock' === $perm ? array( 'bh_owner', 'bh_manager' ) : array( 'bh_owner', 'bh_manager', 'bh_reception' ) as $role ) {
							if ( isset( $saved[ $role ] ) && is_array( $saved[ $role ] ) && ! in_array( $perm, $saved[ $role ], true ) ) {
								$saved[ $role ][] = $perm;
							}
						}
					}
				}
				BHC_Permissions::save( $saved );
			}
			update_option( 'bhc_db_version', BHC_DB_VERSION );
		}
	}

	/**
	 * Crea / aggiorna le tabelle.
	 */
	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$clients = bhc_table( 'clients' );
		$appts   = bhc_table( 'appointments' );
		$pays    = bhc_table( 'payments' );

		dbDelta(
			"CREATE TABLE {$clients} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			first_name varchar(100) NOT NULL DEFAULT '',
			last_name varchar(100) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			phone varchar(40) NOT NULL DEFAULT '',
			gender varchar(10) NOT NULL DEFAULT '',
			birth_date date DEFAULT NULL,
			birth_place varchar(120) NOT NULL DEFAULT '',
			tax_code varchar(32) NOT NULL DEFAULT '',
			address varchar(255) NOT NULL DEFAULT '',
			skin_type varchar(60) NOT NULL DEFAULT '',
			phototype varchar(10) NOT NULL DEFAULT '',
			tags varchar(255) NOT NULL DEFAULT '',
			notes text,
			health_notes text,
			privacy_consent_at datetime DEFAULT NULL,
			marketing_consent tinyint(1) NOT NULL DEFAULT 0,
			source varchar(30) NOT NULL DEFAULT 'staff',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY email (email),
			KEY phone (phone),
			KEY user_id (user_id),
			KEY last_name (last_name)
			) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$appts} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			client_id bigint(20) unsigned NOT NULL DEFAULT 0,
			treatment_id bigint(20) unsigned NOT NULL DEFAULT 0,
			staff_id bigint(20) unsigned NOT NULL DEFAULT 0,
			start_at datetime NOT NULL,
			end_at datetime NOT NULL,
			buffer_min smallint(5) unsigned NOT NULL DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'booked',
			price decimal(10,2) NOT NULL DEFAULT 0,
			notes text,
			source varchar(20) NOT NULL DEFAULT 'staff',
			token varchar(64) NOT NULL DEFAULT '',
			reminder_sent tinyint(1) NOT NULL DEFAULT 0,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY start_at (start_at),
			KEY staff_day (staff_id,start_at),
			KEY client_id (client_id),
			KEY status (status),
			KEY token (token)
			) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$pays} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			appointment_id bigint(20) unsigned NOT NULL DEFAULT 0,
			client_id bigint(20) unsigned NOT NULL DEFAULT 0,
			amount decimal(10,2) NOT NULL DEFAULT 0,
			discount decimal(10,2) NOT NULL DEFAULT 0,
			method varchar(20) NOT NULL DEFAULT 'cash',
			description varchar(255) NOT NULL DEFAULT '',
			paid_at datetime NOT NULL,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY appointment_id (appointment_id),
			KEY client_id (client_id),
			KEY paid_at (paid_at)
			) {$charset};"
		);

		BHC_People::create_table();
		BHC_Operators::create_table();
		BHC_Inventory::create_tables();
		BHC_Stock::create_tables();
		BHC_Zones::create_tables();
		BHC_Cards::create_tables();
		BHC_POS::create_tables();
		BHC_Messages::create_tables();
		BHC_Forms::create_tables();
		BHC_HR::create_tables();
		BHC_Timeclock::create_tables();
		BHC_Stock::migrate_text_categories();
	}

	/**
	 * Crea le pagine base con gli shortcode.
	 */
	public static function create_pages() {
		$pages = array(
			'beautyhub_page_booking'    => array( __( 'Prenota', 'beautyhub-core' ), 'prenota', '[bh_booking]', '' ),
			'beautyhub_page_treatments' => array( __( 'Trattamenti', 'beautyhub-core' ), 'trattamenti', '[bh_treatments]', '' ),
			'beautyhub_page_client'     => array( __( 'Area clienti', 'beautyhub-core' ), 'area-clienti', '[bh_client_area]', '' ),
			'beautyhub_page_dashboard'  => array( __( 'Gestionale', 'beautyhub-core' ), 'gestionale', '[bh_dashboard]', 'page-templates/gestionale.php' ),
			'beautyhub_page_manage'     => array( __( 'Gestisci prenotazione', 'beautyhub-core' ), 'gestisci-prenotazione', '[bh_manage_booking]', '' ),
		);

		// Home di esempio (modificabile con Elementor), impostata come pagina iniziale se non ce n'è già una.
		if ( ! (int) get_option( 'beautyhub_page_home' ) && 'page' !== get_option( 'show_on_front' ) ) {
			$home = wp_insert_post(
				array(
					'post_title'   => __( 'Home', 'beautyhub-core' ),
					'post_name'    => 'home',
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'post_content' => self::home_content(),
				)
			);
			if ( $home && ! is_wp_error( $home ) ) {
				update_option( 'beautyhub_page_home', $home );
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $home );
			}
		}

		foreach ( $pages as $option => $p ) {
			$existing = (int) get_option( $option );
			if ( $existing && get_post( $existing ) ) {
				continue;
			}
			$id = wp_insert_post(
				array(
					'post_title'   => $p[0],
					'post_name'    => $p[1],
					'post_content' => $p[2],
					'post_status'  => 'publish',
					'post_type'    => 'page',
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				if ( $p[3] ) {
					update_post_meta( $id, '_wp_page_template', $p[3] );
				}
				update_option( $option, $id );
			}
		}
	}

	/**
	 * Contenuto (blocchi) della home di esempio.
	 */
	private static function home_content() {
		return '<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"90px","bottom":"90px","left":"20px","right":"20px"}}},"backgroundColor":"sabbia"} -->
<div class="wp-block-group alignfull has-sabbia-background-color has-background" style="padding-top:90px;padding-right:20px;padding-bottom:90px;padding-left:20px"><!-- wp:heading {"textAlign":"center","level":1} -->
<h1 class="wp-block-heading has-text-align-center">' . esc_html__( 'Il tuo momento di benessere', 'beautyhub-core' ) . '</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">' . esc_html__( 'Trattamenti viso, corpo e relax in un ambiente naturale. Prenota online in pochi secondi.', 'beautyhub-core' ) . '</p>
<!-- /wp:paragraph -->
<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="' . esc_url( home_url( '/prenota/' ) ) . '">' . esc_html__( 'Prenota ora', 'beautyhub-core' ) . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">' . esc_html__( 'I nostri trattamenti', 'beautyhub-core' ) . '</h2>
<!-- /wp:heading -->
<!-- wp:shortcode -->
[bh_treatments layout="cards"]
<!-- /wp:shortcode -->';
	}

	/**
	 * Dati di esempio: categorie, trattamenti, operatrici, una cliente.
	 */
	public static function import_demo() {
		$cats = array(
			'viso'       => __( 'Viso', 'beautyhub-core' ),
			'corpo'      => __( 'Corpo', 'beautyhub-core' ),
			'mani-piedi' => __( 'Mani e piedi', 'beautyhub-core' ),
			'epilazione' => __( 'Epilazione', 'beautyhub-core' ),
			'massaggi'   => __( 'Massaggi', 'beautyhub-core' ),
		);
		foreach ( $cats as $slug => $name ) {
			if ( ! term_exists( $slug, 'bh_treatment_cat' ) ) {
				wp_insert_term( $name, 'bh_treatment_cat', array( 'slug' => $slug ) );
			}
		}

		$treatments = array(
			array( 'Pulizia viso profonda', 'viso', 60, 10, 55, 'Detersione, esfoliazione, estrazione e maschera specifica per il tuo tipo di pelle.' ),
			array( 'Trattamento viso idratante', 'viso', 50, 10, 60, 'Rituale con acido ialuronico e massaggio drenante per una pelle luminosa.' ),
			array( 'Massaggio rilassante', 'massaggi', 50, 10, 60, 'Massaggio con oli essenziali per sciogliere tensioni e stress.' ),
			array( 'Massaggio decontratturante', 'massaggi', 50, 10, 65, 'Manualità profonde per schiena, collo e spalle.' ),
			array( 'Pressoterapia', 'corpo', 40, 5, 35, 'Drenaggio linfatico per gambe leggere.' ),
			array( 'Manicure spa', 'mani-piedi', 45, 5, 30, 'Cura delle unghie, scrub, impacco e massaggio mani.' ),
			array( 'Semipermanente mani', 'mani-piedi', 60, 5, 35, 'Applicazione smalto semipermanente con preparazione dell\'unghia.' ),
			array( 'Pedicure estetico', 'mani-piedi', 50, 5, 38, 'Pediluvio, cura delle unghie, scrub e massaggio.' ),
			array( 'Epilazione gambe complete', 'epilazione', 40, 5, 30, 'Ceretta delicata con cera all\'ossido di zinco.' ),
			array( 'Massaggio a quattro mani', 'massaggi', 50, 10, 110, 'Due operatrici in sincronia per un relax profondo.', 2 ),
		);

		$treat_ids = array();
		foreach ( $treatments as $i => $t ) {
			$id = wp_insert_post(
				array(
					'post_type'    => 'bh_treatment',
					'post_status'  => 'publish',
					'post_title'   => $t[0],
					'post_excerpt' => $t[5],
					'post_content' => $t[5],
					'menu_order'   => $i,
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				wp_set_object_terms( $id, $t[1], 'bh_treatment_cat' );
				update_post_meta( $id, '_bh_duration', $t[2] );
				update_post_meta( $id, '_bh_buffer', $t[3] );
				update_post_meta( $id, '_bh_price', $t[4] );
				update_post_meta( $id, '_bh_online', '1' );
				update_post_meta( $id, '_bh_staff_needed', isset( $t[6] ) ? (int) $t[6] : 1 );
				$treat_ids[] = $id;
			}
		}

		// Cabine di esempio con i trattamenti che vi si possono eseguire.
		$cabins = array(
			array( __( 'Cabina Viso', 'beautyhub-core' ), '#7d8c6f', array_slice( $treat_ids, 0, 2 ) ),
			array( __( 'Cabina Massaggi', 'beautyhub-core' ), '#b9805f', array_merge( array_slice( $treat_ids, 2, 3 ), array_slice( $treat_ids, 8, 2 ) ) ),
			array( __( 'Postazione Mani e Piedi', 'beautyhub-core' ), '#8a7aa8', array_slice( $treat_ids, 5, 3 ) ),
		);
		foreach ( $cabins as $i => $c ) {
			BHC_Repository::save_cabin(
				array(
					'name'       => $c[0],
					'color'      => $c[1],
					'treatments' => $c[2],
					'order'      => $i,
				)
			);
		}

		BHC_People::import_demo( $treat_ids );
		BHC_Inventory::import_demo();
		BHC_Stock::import_demo();

		$demo_client = BHC_Repository::save_client(
			array(
				'first_name'         => 'Maria',
				'last_name'          => 'Rossi (demo)',
				'email'              => 'maria.demo@example.com',
				'phone'              => '+39 333 0000000',
				'skin_type'          => 'Mista',
				'phototype'          => 'III',
				'notes'              => __( 'Cliente di esempio: puoi eliminarla.', 'beautyhub-core' ),
				'privacy_consent_at' => current_time( 'mysql' ),
			)
		);

		BHC_Cards::import_demo( $treat_ids );
		if ( ! is_wp_error( $demo_client ) && $demo_client ) {
			BHC_Cards::create( array( 'type' => 'loyalty', 'client_id' => $demo_client, 'points' => 120 ) );
			BHC_Cards::create( array( 'type' => 'gift', 'client_id' => $demo_client, 'value' => 100, 'buyer_name' => 'Giulia Bianchi', 'message' => 'Buon compleanno!', 'expires_at' => gmdate( 'Y-m-d', strtotime( '+1 year' ) ) ) );
			$pk = BHC_Cards::packages();
			if ( $pk ) {
				BHC_Cards::create( array( 'type' => 'package', 'client_id' => $demo_client, 'package_id' => $pk[0]['id'] ) );
			}
		}

		update_option( 'bhc_demo_imported', 1 );
	}
}
