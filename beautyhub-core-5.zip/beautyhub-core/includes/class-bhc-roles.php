<?php
/**
 * Ruoli e permessi.
 *
 * bh_manage       → titolare: tutto (impostazioni, report, cancellazioni)
 * bh_view_agenda  → staff: vedere l'agenda e la dashboard
 * bh_edit_agenda  → reception: creare/modificare appuntamenti, clienti, incassi
 * bh_view_health  → vedere/modificare anamnesi (dati sanitari)
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Roles {

	/**
	 * Crea i ruoli e assegna i permessi all'amministratore.
	 */
	public static function add_roles() {
		$all = array(
			'read'           => true,
			'bh_manage'      => true,
			'bh_view_agenda' => true,
			'bh_edit_agenda' => true,
			'bh_view_health' => true,
			'upload_files'   => true,
		);

		remove_role( 'bh_owner' );
		remove_role( 'bh_manager' );
		remove_role( 'bh_reception' );
		remove_role( 'bh_operator' );
		remove_role( 'bh_client' );

		// Il titolare può anche gestire trattamenti, operatrici, pagine e media.
		$owner = $all + array(
			'edit_posts'             => true,
			'edit_others_posts'      => true,
			'edit_published_posts'   => true,
			'publish_posts'          => true,
			'delete_posts'           => true,
			'delete_others_posts'    => true,
			'delete_published_posts' => true,
			'read_private_posts'     => true,
			'edit_pages'             => true,
			'edit_others_pages'      => true,
			'edit_published_pages'   => true,
			'publish_pages'          => true,
			'manage_categories'      => true,
			'list_users'             => true,
		);
		add_role( 'bh_owner', __( 'Titolare centro', 'beautyhub-core' ), $owner );
		// Manager: gestisce agenda, cabine, personale e report dal gestionale (senza bacheca WordPress).
		add_role( 'bh_manager', __( 'Manager centro', 'beautyhub-core' ), $all );
		add_role(
			'bh_reception',
			__( 'Reception', 'beautyhub-core' ),
			array(
				'read'           => true,
				'bh_view_agenda' => true,
				'bh_edit_agenda' => true,
			)
		);
		add_role(
			'bh_operator',
			__( 'Operatrice', 'beautyhub-core' ),
			array(
				'read'           => true,
				'bh_view_agenda' => true,
				'bh_view_health' => true,
			)
		);
		add_role( 'bh_client', __( 'Cliente centro', 'beautyhub-core' ), array( 'read' => true ) );

		BHC_Permissions::apply();

		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( array_keys( $all ) as $cap ) {
				$admin->add_cap( $cap );
			}
		}
	}
}

/**
 * Lo staff (non admin) non vede la barra di amministrazione nel front-end.
 */
add_filter(
	'show_admin_bar',
	function ( $show ) {
		if ( is_user_logged_in() && ! current_user_can( 'edit_posts' ) ) {
			return false;
		}
		return $show;
	}
);

/**
 * Dopo il login lo staff va alla dashboard, le clienti all'area clienti.
 */
add_filter(
	'login_redirect',
	function ( $redirect_to, $requested, $user ) {
		if ( ! $user instanceof WP_User || $requested ) {
			return $redirect_to;
		}
		if ( BHC_Permissions::is_staff( $user ) && ! $user->has_cap( 'manage_options' ) ) {
			$id = (int) get_option( 'beautyhub_page_dashboard' );
			return $id ? get_permalink( $id ) : $redirect_to;
		}
		if ( in_array( 'bh_client', (array) $user->roles, true ) ) {
			$id = (int) get_option( 'beautyhub_page_client' );
			return $id ? get_permalink( $id ) : $redirect_to;
		}
		return $redirect_to;
	},
	10,
	3
);
