<?php
/**
 * Accesso ai dati: clienti, appuntamenti, incassi, disponibilità.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Repository {

	const CLIENT_FIELDS = array( 'user_id', 'first_name', 'last_name', 'email', 'phone', 'gender', 'birth_date', 'birth_place', 'tax_code', 'address', 'skin_type', 'phototype', 'tags', 'notes', 'health_notes', 'privacy_consent_at', 'marketing_consent', 'source' );

	/* ------------------------------------------------------------------
	 * Clienti
	 * ---------------------------------------------------------------- */

	/**
	 * Crea o aggiorna una cliente.
	 *
	 * @return int|WP_Error ID cliente.
	 */
	public static function save_client( array $data, $id = 0 ) {
		global $wpdb;
		$row = array();
		foreach ( self::CLIENT_FIELDS as $f ) {
			if ( ! array_key_exists( $f, $data ) ) {
				continue;
			}
			$v = $data[ $f ];
			switch ( $f ) {
				case 'user_id':
				case 'marketing_consent':
					$row[ $f ] = absint( $v );
					break;
				case 'email':
					$row[ $f ] = sanitize_email( $v );
					break;
				case 'birth_date':
					$row[ $f ] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $v ) ? $v : null;
					break;
				case 'privacy_consent_at':
					$row[ $f ] = $v ? sanitize_text_field( $v ) : null;
					break;
				case 'notes':
				case 'health_notes':
					$row[ $f ] = sanitize_textarea_field( $v );
					break;
				case 'tax_code':
					$row[ $f ] = strtoupper( sanitize_text_field( $v ) );
					break;
				default:
					$row[ $f ] = sanitize_text_field( $v );
			}
		}

		$now               = current_time( 'mysql' );
		$row['updated_at'] = $now;

		if ( $id ) {
			$ok = $wpdb->update( bhc_table( 'clients' ), $row, array( 'id' => (int) $id ) );
			return false === $ok ? new WP_Error( 'db', __( 'Errore nel salvataggio della cliente.', 'beautyhub-core' ) ) : (int) $id;
		}

		if ( empty( $row['first_name'] ) && empty( $row['last_name'] ) ) {
			return new WP_Error( 'missing', __( 'Inserisci almeno nome o cognome.', 'beautyhub-core' ) );
		}
		$row['created_at'] = $now;
		$ok                = $wpdb->insert( bhc_table( 'clients' ), $row );
		return $ok ? (int) $wpdb->insert_id : new WP_Error( 'db', __( 'Errore nel salvataggio della cliente.', 'beautyhub-core' ) );
	}

	public static function get_client( $id ) {
		global $wpdb;
		$t = bhc_table( 'clients' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function find_client_by_email( $email ) {
		global $wpdb;
		$t = bhc_table( 'clients' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE email = %s ORDER BY id ASC LIMIT 1", $email ), ARRAY_A ); // phpcs:ignore
	}

	public static function find_client_by_user( $user_id ) {
		global $wpdb;
		$t = bhc_table( 'clients' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE user_id = %d LIMIT 1", $user_id ), ARRAY_A ); // phpcs:ignore
	}

	/**
	 * Ricerca clienti per nome, cognome, email, telefono.
	 */
	public static function search_clients( $q = '', $limit = 50, $offset = 0 ) {
		global $wpdb;
		$t     = bhc_table( 'clients' );
		$limit = min( 200, max( 1, (int) $limit ) );
		if ( '' === trim( (string) $q ) ) {
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} ORDER BY last_name, first_name LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_A ); // phpcs:ignore
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ); // phpcs:ignore
		} else {
			$like  = '%' . $wpdb->esc_like( trim( $q ) ) . '%';
			$where = $wpdb->prepare( 'WHERE first_name LIKE %s OR last_name LIKE %s OR email LIKE %s OR phone LIKE %s OR CONCAT(first_name, " ", last_name) LIKE %s OR tags LIKE %s', $like, $like, $like, $like, $like, $like );
			$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} {$where} ORDER BY last_name, first_name LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_A ); // phpcs:ignore
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} {$where}" ); // phpcs:ignore
		}
		return array( 'items' => $rows, 'total' => $total );
	}

	public static function delete_client( $id ) {
		global $wpdb;
		$wpdb->delete( bhc_table( 'clients' ), array( 'id' => (int) $id ) );
		$wpdb->update( bhc_table( 'appointments' ), array( 'client_id' => 0 ), array( 'client_id' => (int) $id ) );
		$wpdb->update( bhc_table( 'payments' ), array( 'client_id' => 0 ), array( 'client_id' => (int) $id ) );
		// Schede con dati sanitari: si cancellano insieme alla cliente.
		if ( class_exists( 'BHC_Forms' ) ) {
			BHC_Forms::delete_client( $id );
		}
	}

	/* ------------------------------------------------------------------
	 * Appuntamenti
	 * ---------------------------------------------------------------- */

	/**
	 * Appuntamenti in un intervallo di date (inclusivo), con nomi già risolti.
	 */
	public static function get_appointments( $from, $to, $staff_id = 0, $include_cancelled = true ) {
		global $wpdb;
		$a    = bhc_table( 'appointments' );
		$c    = bhc_table( 'clients' );
		$sql  = "SELECT a.*, c.first_name, c.last_name, c.phone, c.email FROM {$a} a LEFT JOIN {$c} c ON c.id = a.client_id WHERE a.start_at >= %s AND a.start_at < %s";
		$args = array( $from . ' 00:00:00', gmdate( 'Y-m-d', strtotime( $to . ' +1 day' ) ) . ' 00:00:00' );
		if ( $staff_id ) {
			$sql   .= ' AND a.staff_id = %d';
			$args[] = (int) $staff_id;
		}
		if ( ! $include_cancelled ) {
			$sql .= " AND a.status NOT IN ('cancelled','noshow')";
		}
		$sql .= ' ORDER BY a.start_at ASC';
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ); // phpcs:ignore
		return array_map( array( __CLASS__, 'decorate' ), $rows );
	}

	public static function get_appointment( $id ) {
		global $wpdb;
		$a   = bhc_table( 'appointments' );
		$c   = bhc_table( 'clients' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT a.*, c.first_name, c.last_name, c.phone, c.email FROM {$a} a LEFT JOIN {$c} c ON c.id = a.client_id WHERE a.id = %d", $id ), ARRAY_A ); // phpcs:ignore
		return $row ? self::decorate( $row ) : null;
	}

	public static function get_appointment_by_token( $token ) {
		global $wpdb;
		if ( ! preg_match( '/^[a-f0-9]{32,64}$/', (string) $token ) ) {
			return null;
		}
		$a  = bhc_table( 'appointments' );
		$id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$a} WHERE token = %s", $token ) ); // phpcs:ignore
		return $id ? self::get_appointment( $id ) : null;
	}

	public static function client_appointments( $client_id, $limit = 100 ) {
		global $wpdb;
		$a    = bhc_table( 'appointments' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$a} WHERE client_id = %d ORDER BY start_at DESC LIMIT %d", $client_id, $limit ), ARRAY_A ); // phpcs:ignore
		return array_map( array( __CLASS__, 'decorate' ), $rows );
	}

	/**
	 * Aggiunge nomi di trattamento/operatrice e totale pagato.
	 */
	public static function decorate( $row ) {
		static $treat = array(), $staff = array();
		$tid = (int) $row['treatment_id'];
		$sid = (int) $row['staff_id'];
		if ( ! isset( $treat[ $tid ] ) ) {
			$treat[ $tid ] = $tid ? get_the_title( $tid ) : '';
		}
		if ( ! isset( $staff[ $sid ] ) ) {
			$sd            = $sid ? bhc_staff_data( $sid ) : null;
			$staff[ $sid ] = $sd ? array( $sd['name'], $sd['color'] ) : array( '', '#999999' );
		}
		$row['id']             = (int) $row['id'];
		$row['client_id']      = (int) $row['client_id'];
		$row['treatment_id']   = $tid;
		$row['staff_id']       = $sid;
		$row['price']          = (float) $row['price'];
		$row['buffer_min']     = (int) $row['buffer_min'];
		$row['treatment_name'] = $treat[ $tid ];
		$row['staff_name']     = $staff[ $sid ][0];
		$row['staff_color']    = $staff[ $sid ][1];
		$row['client_name']    = isset( $row['first_name'] ) ? trim( $row['first_name'] . ' ' . $row['last_name'] ) : '';
		$row['date']           = substr( $row['start_at'], 0, 10 );
		$row['start']          = substr( $row['start_at'], 11, 5 );
		$row['end']            = substr( $row['end_at'], 11, 5 );
		$row['paid']           = self::paid_total( $row['id'] );
		$row['operators']      = BHC_Operators::of( $row['id'] );
		unset( $row['token'] );
		return $row;
	}

	/**
	 * Crea o aggiorna un appuntamento verificando i conflitti.
	 *
	 * @param array $data client_id, treatment_id, staff_id, date (Y-m-d), start (H:i), [duration], [price], [status], [notes], [source].
	 * @return int|WP_Error
	 */
	public static function save_appointment( array $data, $id = 0, $check_conflicts = true ) {
		global $wpdb;

		$existing = $id ? self::get_appointment( $id ) : null;
		if ( $id && ! $existing ) {
			return new WP_Error( 'not_found', __( 'Appuntamento non trovato.', 'beautyhub-core' ) );
		}

		$treatment_id = isset( $data['treatment_id'] ) ? absint( $data['treatment_id'] ) : ( $existing ? $existing['treatment_id'] : 0 );
		$treatment    = bhc_treatment_data( $treatment_id );
		if ( ! $treatment ) {
			return new WP_Error( 'treatment', __( 'Trattamento non valido.', 'beautyhub-core' ) );
		}
		$staff_id = isset( $data['staff_id'] ) ? absint( $data['staff_id'] ) : ( $existing ? $existing['staff_id'] : 0 );
		if ( $staff_id && ! bhc_staff_data( $staff_id ) ) {
			return new WP_Error( 'staff', __( 'Cabina non valida.', 'beautyhub-core' ) );
		}

		$date  = $data['date'] ?? ( $existing ? $existing['date'] : '' );
		$start = $data['start'] ?? ( $existing ? $existing['start'] : '' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || null === bhc_time_to_min( $start ) ) {
			return new WP_Error( 'datetime', __( 'Data o ora non valide.', 'beautyhub-core' ) );
		}

		$duration = isset( $data['duration'] ) && (int) $data['duration'] > 0 ? (int) $data['duration'] : ( $existing && ! isset( $data['treatment_id'] ) ? ( bhc_time_to_min( $existing['end'] ) - bhc_time_to_min( $existing['start'] ) ) : $treatment['duration'] );
		$s_min    = bhc_time_to_min( $start );
		$e_min    = $s_min + max( 5, $duration );
		$buffer   = $treatment['buffer'];

		$status = $data['status'] ?? ( $existing ? $existing['status'] : 'booked' );
		if ( ! array_key_exists( $status, bhc_statuses() ) ) {
			$status = 'booked';
		}

		if ( $check_conflicts && $staff_id && ! in_array( $status, array( 'cancelled', 'noshow' ), true ) ) {
			$busy = self::busy_intervals( $staff_id, $date, $id );
			if ( BHC_Availability::overlaps_any( $s_min, $e_min + $buffer, $busy ) ) {
				return new WP_Error( 'conflict', __( 'La cabina è già occupata in quell\'orario.', 'beautyhub-core' ) );
			}
		}

		// Operatrici: servono quelle indicate dal trattamento (1 o 2), disponibili in quell'orario.
		$op_ids = null;
		if ( BHC_Operators::enabled() && ! in_array( $status, array( 'cancelled', 'noshow' ), true ) ) {
			$given = isset( $data['operators'] ) && is_array( $data['operators'] ) ? array_filter( array_map( 'intval', $data['operators'] ) ) : array();
			if ( $given ) {
				$op_ids = $given;
			} elseif ( $check_conflicts ) {
				$op_ids = $existing ? wp_list_pluck( BHC_Operators::of( $id ), 'id' ) : array();
				if ( count( $op_ids ) < BHC_Operators::needed( $treatment_id ) ) {
					$op_ids = BHC_Operators::auto_pick( $treatment_id, $date, $s_min, $e_min, $id );
					if ( null === $op_ids ) {
						return new WP_Error( 'operator_conflict', __( 'Nessuna operatrice abilitata è disponibile in quell\'orario.', 'beautyhub-core' ) );
					}
				}
			}
			if ( null !== $op_ids ) {
				$valid = BHC_Operators::validate( $op_ids, $treatment_id, $date, $s_min, $e_min, $id, $check_conflicts );
				if ( is_wp_error( $valid ) ) {
					return $valid;
				}
			}
		}

		$row = array(
			'client_id'    => isset( $data['client_id'] ) ? absint( $data['client_id'] ) : ( $existing ? $existing['client_id'] : 0 ),
			'treatment_id' => $treatment_id,
			'staff_id'     => $staff_id,
			'start_at'     => $date . ' ' . bhc_min_to_time( $s_min ) . ':00',
			'end_at'       => $date . ' ' . bhc_min_to_time( $e_min ) . ':00',
			'buffer_min'   => $buffer,
			'status'       => $status,
			'price'        => isset( $data['price'] ) && '' !== $data['price'] ? round( (float) $data['price'], 2 ) : ( $existing && ! isset( $data['treatment_id'] ) ? $existing['price'] : $treatment['price'] ),
			'notes'        => isset( $data['notes'] ) ? sanitize_textarea_field( $data['notes'] ) : ( $existing ? (string) $existing['notes'] : '' ),
			'updated_at'   => current_time( 'mysql' ),
		);

		if ( $existing ) {
			// Se cambia data/ora, il promemoria va rinviato.
			if ( $existing['start_at'] !== $row['start_at'] ) {
				$row['reminder_sent'] = 0;
			}
			$ok = $wpdb->update( bhc_table( 'appointments' ), $row, array( 'id' => (int) $id ) );
			if ( false === $ok ) {
				return new WP_Error( 'db', __( 'Errore nel salvataggio.', 'beautyhub-core' ) );
			}
			if ( null !== $op_ids ) {
				BHC_Operators::set( $id, $op_ids );
			}
			return (int) $id;
		}

		$row['source']     = sanitize_key( $data['source'] ?? 'staff' );
		$row['token']      = bin2hex( random_bytes( 20 ) );
		$row['created_by'] = get_current_user_id();
		$row['created_at'] = current_time( 'mysql' );
		$ok                = $wpdb->insert( bhc_table( 'appointments' ), $row );
		if ( ! $ok ) {
			return new WP_Error( 'db', __( 'Errore nel salvataggio.', 'beautyhub-core' ) );
		}
		$new_id = (int) $wpdb->insert_id;
		if ( null !== $op_ids ) {
			BHC_Operators::set( $new_id, $op_ids );
		}
		return $new_id;
	}

	public static function delete_appointment( $id ) {
		global $wpdb;
		$wpdb->delete( bhc_table( 'appointments' ), array( 'id' => (int) $id ) );
		BHC_Operators::delete_for_appointment( $id );
	}

	public static function get_token( $id ) {
		global $wpdb;
		$a = bhc_table( 'appointments' );
		return (string) $wpdb->get_var( $wpdb->prepare( "SELECT token FROM {$a} WHERE id = %d", $id ) ); // phpcs:ignore
	}

	/* ------------------------------------------------------------------
	 * Cabine
	 * ---------------------------------------------------------------- */

	/**
	 * Salva colore, orari e trattamenti di una cabina.
	 */
	public static function save_cabin_meta( $post_id, array $data ) {
		if ( array_key_exists( 'color', $data ) ) {
			update_post_meta( $post_id, '_bh_color', sanitize_hex_color( (string) $data['color'] ) ?: '#7d8c6f' );
		}
		if ( array_key_exists( 'hours', $data ) ) {
			$hours = array();
			$raw   = is_array( $data['hours'] ) ? $data['hours'] : array();
			foreach ( bhc_weekdays() as $n => $label ) {
				$hours[ $n ] = sanitize_text_field( $raw[ $n ] ?? ( $raw[ (string) $n ] ?? '' ) );
			}
			update_post_meta( $post_id, '_bh_hours', $hours );
		}
		if ( array_key_exists( 'treatments', $data ) ) {
			$tr = is_array( $data['treatments'] ) ? array_map( 'absint', $data['treatments'] ) : array();
			update_post_meta( $post_id, '_bh_treatments', array_values( array_unique( array_filter( $tr ) ) ) );
		}
	}

	/**
	 * Crea o aggiorna una cabina (dal gestionale).
	 *
	 * @return int|WP_Error
	 */
	public static function save_cabin( array $data, $id = 0 ) {
		$name = sanitize_text_field( (string) ( $data['name'] ?? '' ) );
		if ( '' === $name ) {
			return new WP_Error( 'name', __( 'Inserisci il nome della cabina.', 'beautyhub-core' ) );
		}
		$post = array(
			'post_type'   => 'bh_staff',
			'post_status' => 'publish',
			'post_title'  => $name,
		);
		if ( isset( $data['order'] ) ) {
			$post['menu_order'] = (int) $data['order'];
		}
		if ( $id ) {
			if ( ! bhc_staff_data( $id ) ) {
				return new WP_Error( 'not_found', __( 'Cabina non trovata.', 'beautyhub-core' ) );
			}
			$post['ID'] = (int) $id;
			$res        = wp_update_post( $post, true );
		} else {
			if ( ! isset( $post['menu_order'] ) ) {
				$post['menu_order'] = count( bhc_get_staff() );
			}
			$res = wp_insert_post( $post, true );
		}
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		self::save_cabin_meta( $res, array_intersect_key( $data, array_flip( array( 'color', 'hours', 'treatments' ) ) ) );
		return (int) $res;
	}

	/* ------------------------------------------------------------------
	 * Disponibilità
	 * ---------------------------------------------------------------- */

	/**
	 * Intervalli occupati (minuti) di un'operatrice in un giorno.
	 */
	public static function busy_intervals( $staff_id, $date, $exclude_id = 0 ) {
		$out = array();
		foreach ( self::get_appointments( $date, $date, $staff_id, false ) as $a ) {
			if ( (int) $a['id'] === (int) $exclude_id ) {
				continue;
			}
			$out[] = array( bhc_time_to_min( $a['start'] ), bhc_time_to_min( $a['end'] ) + (int) $a['buffer_min'] );
		}
		return $out;
	}

	/**
	 * Orari del centro in un giorno.
	 */
	public static function center_ranges( $date ) {
		if ( in_array( $date, BHC_Settings::closures(), true ) ) {
			return array();
		}
		$dow = (int) gmdate( 'N', strtotime( $date . ' 12:00:00' ) );
		return bhc_parse_ranges( bhc_get_option( 'hours_' . $dow, '' ) );
	}

	/**
	 * Orari di lavoro effettivi di un'operatrice in un giorno.
	 */
	public static function staff_ranges( array $staff, $date ) {
		$center = self::center_ranges( $date );
		if ( empty( $center ) ) {
			return array();
		}
		$has_own = false;
		foreach ( $staff['hours'] as $h ) {
			if ( '' !== trim( (string) $h ) ) {
				$has_own = true;
				break;
			}
		}
		if ( ! $has_own ) {
			return $center;
		}
		$dow = (int) gmdate( 'N', strtotime( $date . ' 12:00:00' ) );
		return BHC_Availability::intersect( $center, bhc_parse_ranges( $staff['hours'][ $dow ] ?? '' ) );
	}

	/**
	 * Operatrici che eseguono un trattamento.
	 */
	public static function staff_for_treatment( $treatment_id ) {
		$out = array();
		foreach ( bhc_get_staff() as $s ) {
			if ( empty( $s['treatments'] ) || in_array( (int) $treatment_id, $s['treatments'], true ) ) {
				$out[] = $s;
			}
		}
		return $out;
	}

	/**
	 * Slot liberi per un giorno.
	 *
	 * @param bool $public Applica preavviso minimo e finestra massima.
	 * @return array<string, int[]> 'HH:MM' => [staff_id, ...]
	 */
	public static function slots( $date, $treatment_id, $staff_id = 0, $public = true ) {
		$treatment = bhc_treatment_data( $treatment_id );
		if ( ! $treatment || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return array();
		}

		$tz       = wp_timezone();
		$now      = new DateTimeImmutable( 'now', $tz );
		$day      = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $date . ' 00:00:00', $tz );
		$min_from = -1;
		if ( $public ) {
			$earliest = $now->modify( '+' . (int) bhc_get_option( 'lead_hours', 2 ) . ' hours' );
			$latest   = $now->modify( '+' . (int) bhc_get_option( 'max_days', 60 ) . ' days' );
			if ( $day->format( 'Y-m-d' ) < $earliest->format( 'Y-m-d' ) || $day > $latest ) {
				return array();
			}
			if ( $day->format( 'Y-m-d' ) === $earliest->format( 'Y-m-d' ) ) {
				$min_from = (int) $earliest->format( 'G' ) * 60 + (int) $earliest->format( 'i' );
			}
		}

		$length = $treatment['duration'] + $treatment['buffer'];
		$step   = (int) bhc_get_option( 'slot_step', 15 );
		$result = array();

		foreach ( self::staff_for_treatment( $treatment_id ) as $s ) {
			if ( $staff_id && (int) $s['id'] !== (int) $staff_id ) {
				continue;
			}
			$ranges = self::staff_ranges( $s, $date );
			if ( empty( $ranges ) ) {
				continue;
			}
			$free = BHC_Availability::free_slots( $ranges, self::busy_intervals( $s['id'], $date ), $length, $step, $min_from );
			foreach ( $free as $m ) {
				$result[ bhc_min_to_time( $m ) ][] = (int) $s['id'];
			}
		}
		// Tieni solo gli orari in cui ci sono abbastanza operatrici libere.
		if ( $result && BHC_Operators::enabled() ) {
			$idx  = BHC_Operators::day_index( $treatment_id, $date );
			$need = BHC_Operators::needed( $treatment_id );
			foreach ( array_keys( $result ) as $time ) {
				$s = bhc_time_to_min( $time );
				if ( BHC_Operators::count_free( $idx, $s, $s + $treatment['duration'] ) < $need ) {
					unset( $result[ $time ] );
				}
			}
		}
		ksort( $result );
		return $result;
	}

	/* ------------------------------------------------------------------
	 * Incassi
	 * ---------------------------------------------------------------- */

	public static function add_payment( array $data ) {
		global $wpdb;
		$methods = bhc_payment_methods();
		$row     = array(
			'appointment_id' => absint( $data['appointment_id'] ?? 0 ),
			'client_id'      => absint( $data['client_id'] ?? 0 ),
			'amount'         => round( (float) ( $data['amount'] ?? 0 ), 2 ),
			'discount'       => round( (float) ( $data['discount'] ?? 0 ), 2 ),
			'method'         => isset( $methods[ $data['method'] ?? '' ] ) ? $data['method'] : 'cash',
			'description'    => sanitize_text_field( $data['description'] ?? '' ),
			'paid_at'        => current_time( 'mysql' ),
			'created_by'     => get_current_user_id(),
		);
		if ( $row['amount'] <= 0 ) {
			return new WP_Error( 'amount', __( 'Importo non valido.', 'beautyhub-core' ) );
		}
		$ok = $wpdb->insert( bhc_table( 'payments' ), $row );
		if ( $ok ) {
			$pid = (int) $wpdb->insert_id;
			do_action( 'bhc_payment_added', $row['client_id'], $row['amount'], $row['appointment_id'], $row['method'] );
			return $pid;
		}
		return $ok ? (int) $wpdb->insert_id : new WP_Error( 'db', __( 'Errore nel salvataggio dell\'incasso.', 'beautyhub-core' ) );
	}

	public static function paid_total( $appointment_id ) {
		global $wpdb;
		$p = bhc_table( 'payments' );
		return (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount),0) FROM {$p} WHERE appointment_id = %d", $appointment_id ) ); // phpcs:ignore
	}

	public static function client_payments( $client_id ) {
		global $wpdb;
		$p = bhc_table( 'payments' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$p} WHERE client_id = %d ORDER BY paid_at DESC LIMIT 200", $client_id ), ARRAY_A ); // phpcs:ignore
	}

	/* ------------------------------------------------------------------
	 * Report
	 * ---------------------------------------------------------------- */

	public static function stats( $from, $to ) {
		global $wpdb;
		$a     = bhc_table( 'appointments' );
		$p     = bhc_table( 'payments' );
		$c     = bhc_table( 'clients' );
		$f     = $from . ' 00:00:00';
		$t     = gmdate( 'Y-m-d', strtotime( $to . ' +1 day' ) ) . ' 00:00:00';

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$revenue  = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount),0) FROM {$p} WHERE paid_at >= %s AND paid_at < %s", $f, $t ) );
		$by_meth  = $wpdb->get_results( $wpdb->prepare( "SELECT method, SUM(amount) total FROM {$p} WHERE paid_at >= %s AND paid_at < %s GROUP BY method", $f, $t ), ARRAY_A );
		$counts   = $wpdb->get_results( $wpdb->prepare( "SELECT status, COUNT(*) n FROM {$a} WHERE start_at >= %s AND start_at < %s GROUP BY status", $f, $t ), ARRAY_A );
		$by_treat = $wpdb->get_results( $wpdb->prepare( "SELECT treatment_id, COUNT(*) n, SUM(price) value FROM {$a} WHERE start_at >= %s AND start_at < %s AND status NOT IN ('cancelled','noshow') GROUP BY treatment_id ORDER BY n DESC LIMIT 10", $f, $t ), ARRAY_A );
		$rows_st  = $wpdb->get_results( $wpdb->prepare( "SELECT staff_id, price, start_at, end_at FROM {$a} WHERE start_at >= %s AND start_at < %s AND status NOT IN ('cancelled','noshow')", $f, $t ), ARRAY_A );
		$new_cl   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$c} WHERE created_at >= %s AND created_at < %s", $f, $t ) );
		$online   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$a} WHERE created_at >= %s AND created_at < %s AND source = 'online'", $f, $t ) );
		// phpcs:enable

		$status = array_fill_keys( array_keys( bhc_statuses() ), 0 );
		foreach ( $counts as $r ) {
			$status[ $r['status'] ] = (int) $r['n'];
		}
		$total_valid = array_sum( $status ) - $status['cancelled'];

		foreach ( $by_treat as &$r ) {
			$r['name']  = get_the_title( (int) $r['treatment_id'] );
			$r['n']     = (int) $r['n'];
			$r['value'] = (float) $r['value'];
		}
		unset( $r );
		// Aggregazione per operatrice in PHP (compatibile con qualunque database).
		$by_staff = array();
		foreach ( $rows_st as $row ) {
			$sid = (int) $row['staff_id'];
			if ( ! isset( $by_staff[ $sid ] ) ) {
				$by_staff[ $sid ] = array( 'staff_id' => $sid, 'n' => 0, 'value' => 0, 'minutes' => 0 );
			}
			$by_staff[ $sid ]['n']++;
			$by_staff[ $sid ]['value']   += (float) $row['price'];
			$by_staff[ $sid ]['minutes'] += max( 0, ( strtotime( $row['end_at'] ) - strtotime( $row['start_at'] ) ) / 60 );
		}
		$by_staff = array_values( $by_staff );
		foreach ( $by_staff as &$r ) {
			$sd         = bhc_staff_data( (int) $r['staff_id'] );
			$r['name']  = $sd ? $sd['name'] : __( 'Senza cabina', 'beautyhub-core' );
			$r['color'] = $sd ? $sd['color'] : '#999999';
			$r['n']     = (int) $r['n'];
			$r['value'] = (float) $r['value'];
			$r['hours'] = round( (int) $r['minutes'] / 60, 1 );
		}
		unset( $r );

		return array(
			'from'          => $from,
			'to'            => $to,
			'revenue'       => $revenue,
			'by_method'     => $by_meth,
			'status'        => $status,
			'appointments'  => $total_valid,
			'noshow_rate'   => $total_valid ? round( $status['noshow'] / $total_valid * 100, 1 ) : 0,
			'by_treatment'  => $by_treat,
			'by_staff'      => $by_staff,
			'new_clients'   => $new_cl,
			'online_bookings' => $online,
		);
	}
}
