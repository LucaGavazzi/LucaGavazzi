<?php
/**
 * Email: conferma, notifica al centro, annullamento, promemoria.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Emails {

	public static function init() {
		add_action( 'bhc_hourly', array( __CLASS__, 'send_reminders' ) );
	}

	/**
	 * Link per gestire/annullare la prenotazione.
	 */
	public static function manage_url( $appointment_id ) {
		$page = (int) get_option( 'beautyhub_page_manage' );
		$base = $page ? get_permalink( $page ) : home_url( '/gestisci-prenotazione/' );
		return add_query_arg( 'bh', BHC_Repository::get_token( $appointment_id ), $base );
	}

	/**
	 * Impaginazione HTML semplice in stile spa.
	 */
	private static function wrap( $title, $body_html ) {
		$center = esc_html( bhc_get_option( 'center_name' ) );
		return '<div style="background:#f8f4ed;padding:30px 12px;font-family:Helvetica,Arial,sans-serif;color:#3b3a36">'
			. '<div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:14px;overflow:hidden">'
			. '<div style="background:#7d8c6f;color:#ffffff;padding:22px 28px;font-family:Georgia,serif;font-size:22px">' . $center . '</div>'
			. '<div style="padding:26px 28px;font-size:15px;line-height:1.6"><h2 style="font-family:Georgia,serif;font-weight:normal;margin-top:0">' . esc_html( $title ) . '</h2>' . $body_html . '</div>'
			. '<div style="padding:16px 28px;background:#e8dfd0;font-size:12px;color:#7a776f">' . $center . ( bhc_get_option( 'center_phone' ) ? ' · ' . esc_html( bhc_get_option( 'center_phone' ) ) : '' ) . '</div>'
			. '</div></div>';
	}

	private static function details_html( array $a ) {
		$date = date_i18n( 'l j F Y', strtotime( $a['date'] . ' 12:00:00' ) );
		$rows = array(
			__( 'Trattamento', 'beautyhub-core' ) => $a['treatment_name'],
			__( 'Data', 'beautyhub-core' )        => $date,
			__( 'Ora', 'beautyhub-core' )         => $a['start'],
			__( 'Prezzo', 'beautyhub-core' )      => bhc_price( $a['price'] ),
		);
		$html = '<table style="width:100%;border-collapse:collapse;margin:16px 0">';
		foreach ( $rows as $k => $v ) {
			if ( '' === (string) $v ) {
				continue;
			}
			$html .= '<tr><td style="padding:6px 0;color:#7a776f;width:120px">' . esc_html( $k ) . '</td><td style="padding:6px 0"><strong>' . esc_html( $v ) . '</strong></td></tr>';
		}
		return $html . '</table>';
	}

	/**
	 * Email al personale con utente e link per impostare la password.
	 * Restituisce true oppure WP_Error con il motivo per cui il server non l'ha inviata.
	 */
	public static function staff_access( WP_User $user, $first_name, $link, $is_new ) {
		$dash   = (int) get_option( 'beautyhub_page_dashboard' );
		$dash   = $dash ? get_permalink( $dash ) : home_url( '/gestionale/' );
		$center = bhc_get_option( 'center_name' );
		$btn    = 'display:inline-block;background:#7d8c6f;color:#ffffff;text-decoration:none;padding:12px 22px;border-radius:999px;font-weight:bold';
		$body   = '<p>' . sprintf( esc_html__( 'Ciao %s,', 'beautyhub-core' ), esc_html( $first_name ) ) . '</p>'
			. '<p>' . ( $is_new ? sprintf( esc_html__( 'è stato creato il tuo accesso al gestionale di %s.', 'beautyhub-core' ), esc_html( $center ) ) : esc_html__( 'ecco il link per impostare (o reimpostare) la password del gestionale.', 'beautyhub-core' ) ) . '</p>'
			. '<p>' . esc_html__( 'Nome utente:', 'beautyhub-core' ) . ' <strong>' . esc_html( $user->user_login ) . '</strong><br>' . esc_html__( 'Puoi accedere anche con la tua email:', 'beautyhub-core' ) . ' ' . esc_html( $user->user_email ) . '</p>'
			. '<p style="margin:24px 0"><a href="' . esc_url( $link ) . '" style="' . $btn . '">' . esc_html__( 'Imposta la password', 'beautyhub-core' ) . '</a></p>'
			. '<p style="font-size:13px;color:#7a776f">' . esc_html__( 'Il link è personale e vale 24 ore. Dopo aver scelto la password entra dal gestionale:', 'beautyhub-core' ) . ' <a href="' . esc_url( $dash ) . '">' . esc_html( $dash ) . '</a></p>';
		$err  = null;
		$trap = function ( $e ) use ( &$err ) {
			$err = $e;
		};
		add_action( 'wp_mail_failed', $trap );
		/* translators: %s: nome del centro */
		$ok = self::send( $user->user_email, sprintf( __( 'Il tuo accesso al gestionale di %s', 'beautyhub-core' ), $center ), self::wrap( __( 'Accesso al gestionale', 'beautyhub-core' ), $body ) );
		remove_action( 'wp_mail_failed', $trap );
		if ( $ok ) {
			return true;
		}
		return new WP_Error( 'mail', $err instanceof WP_Error ? $err->get_error_message() : __( 'la funzione di invio email del server non è disponibile', 'beautyhub-core' ) );
	}

	private static function send( $to, $subject, $html ) {
		if ( ! is_email( $to ) ) {
			return false;
		}
		$from_name  = bhc_get_option( 'center_name' );
		$from_email = bhc_get_option( 'center_email' );
		$headers    = array( 'Content-Type: text/html; charset=UTF-8' );
		if ( is_email( $from_email ) ) {
			$headers[] = 'Reply-To: ' . $from_name . ' <' . $from_email . '>';
		}
		// Mittente: nome del centro; indirizzo del centro solo se è dello stesso dominio del sito
		// (altrimenti i server di posta lo scartano come falso mittente).
		$site_host = strtolower( preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
		$from_fn   = function () use ( $from_name ) {
			return $from_name;
		};
		$addr_fn   = function ( $addr ) use ( $from_email, $site_host ) {
			if ( is_email( $from_email ) && $site_host && strtolower( substr( strrchr( $from_email, '@' ), 1 ) ) === $site_host ) {
				return $from_email;
			}
			return $addr;
		};
		if ( $from_name ) {
			add_filter( 'wp_mail_from_name', $from_fn );
		}
		add_filter( 'wp_mail_from', $addr_fn );
		$ok = wp_mail( $to, $subject, $html, $headers );
		remove_filter( 'wp_mail_from_name', $from_fn );
		remove_filter( 'wp_mail_from', $addr_fn );
		return $ok;
	}

	/**
	 * Email alla cliente dopo una nuova prenotazione.
	 */
	public static function booking_created( $appointment_id ) {
		$a = BHC_Repository::get_appointment( $appointment_id );
		if ( ! $a ) {
			return;
		}
		$confirmed = 'confirmed' === $a['status'];
		$title     = $confirmed ? __( 'Il tuo appuntamento è confermato', 'beautyhub-core' ) : __( 'Abbiamo ricevuto la tua richiesta', 'beautyhub-core' );
		$intro     = $confirmed
			? __( 'Ti aspettiamo! Ecco il riepilogo:', 'beautyhub-core' )
			: __( 'Grazie! Ti confermeremo l\'appuntamento al più presto. Ecco il riepilogo:', 'beautyhub-core' );

		/* translators: %s: nome cliente */
		$body  = '<p>' . sprintf( esc_html__( 'Ciao %s,', 'beautyhub-core' ), esc_html( $a['first_name'] ) ) . '</p><p>' . esc_html( $intro ) . '</p>';
		$body .= self::details_html( $a );
		$body .= '<p><a href="' . esc_url( self::manage_url( $appointment_id ) ) . '" style="display:inline-block;background:#7d8c6f;color:#fff;padding:10px 22px;border-radius:999px;text-decoration:none">' . esc_html__( 'Gestisci o annulla', 'beautyhub-core' ) . '</a></p>';

		self::send( $a['email'], $title . ' – ' . bhc_get_option( 'center_name' ), self::wrap( $title, $body ) );

		if ( (int) bhc_get_option( 'notify_staff', 1 ) ) {
			$body = '<p>' . esc_html__( 'Nuova prenotazione online da', 'beautyhub-core' ) . ' <strong>' . esc_html( $a['client_name'] ) . '</strong> (' . esc_html( $a['phone'] ) . ', ' . esc_html( $a['email'] ) . ')</p>' . self::details_html( $a );
			if ( $a['notes'] ) {
				$body .= '<p><em>' . esc_html( $a['notes'] ) . '</em></p>';
			}
			self::send( bhc_get_option( 'center_email' ), __( 'Nuova prenotazione online', 'beautyhub-core' ) . ': ' . $a['treatment_name'], self::wrap( __( 'Nuova prenotazione', 'beautyhub-core' ), $body ) );
		}
	}

	/**
	 * Email alla cliente quando lo staff conferma.
	 */
	public static function booking_confirmed( $appointment_id ) {
		$a = BHC_Repository::get_appointment( $appointment_id );
		if ( ! $a ) {
			return;
		}
		$title = __( 'Il tuo appuntamento è confermato', 'beautyhub-core' );
		/* translators: %s: nome cliente */
		$body  = '<p>' . sprintf( esc_html__( 'Ciao %s,', 'beautyhub-core' ), esc_html( $a['first_name'] ) ) . '</p>' . self::details_html( $a );
		$body .= '<p><a href="' . esc_url( self::manage_url( $appointment_id ) ) . '">' . esc_html__( 'Gestisci o annulla', 'beautyhub-core' ) . '</a></p>';
		self::send( $a['email'], $title, self::wrap( $title, $body ) );
	}

	/**
	 * Annullamento (dalla cliente o dallo staff).
	 */
	public static function booking_cancelled( $appointment_id, $by_client = false ) {
		$a = BHC_Repository::get_appointment( $appointment_id );
		if ( ! $a ) {
			return;
		}
		$title = __( 'Appuntamento annullato', 'beautyhub-core' );
		/* translators: %s: nome cliente */
		$body = '<p>' . sprintf( esc_html__( 'Ciao %s, il tuo appuntamento è stato annullato:', 'beautyhub-core' ), esc_html( $a['first_name'] ) ) . '</p>' . self::details_html( $a );
		$body .= '<p>' . esc_html__( 'Puoi prenotare di nuovo quando vuoi dal nostro sito.', 'beautyhub-core' ) . '</p>';
		self::send( $a['email'], $title, self::wrap( $title, $body ) );

		if ( $by_client && (int) bhc_get_option( 'notify_staff', 1 ) ) {
			$body = '<p><strong>' . esc_html( $a['client_name'] ) . '</strong> ' . esc_html__( 'ha annullato online:', 'beautyhub-core' ) . '</p>' . self::details_html( $a );
			self::send( bhc_get_option( 'center_email' ), __( 'Annullamento online', 'beautyhub-core' ), self::wrap( $title, $body ) );
		}
	}

	/**
	 * Cron orario: invia i promemoria.
	 */
	public static function send_reminders() {
		global $wpdb;
		$hours = (int) bhc_get_option( 'reminder_hours', 24 );
		if ( $hours <= 0 ) {
			return;
		}
		$tz    = wp_timezone();
		$now   = new DateTimeImmutable( 'now', $tz );
		$until = $now->modify( '+' . $hours . ' hours' );
		$t     = bhc_table( 'appointments' );

		$ids = $wpdb->get_col( // phpcs:ignore
			$wpdb->prepare(
				"SELECT id FROM {$t} WHERE reminder_sent = 0 AND status IN ('booked','confirmed') AND start_at > %s AND start_at <= %s LIMIT 100", // phpcs:ignore
				$now->format( 'Y-m-d H:i:s' ),
				$until->format( 'Y-m-d H:i:s' )
			)
		);

		foreach ( $ids as $id ) {
			$a = BHC_Repository::get_appointment( $id );
			if ( $a && $a['email'] ) {
				$title = __( 'Promemoria appuntamento', 'beautyhub-core' );
				/* translators: %s: nome cliente */
				$body  = '<p>' . sprintf( esc_html__( 'Ciao %s, ti ricordiamo il tuo appuntamento:', 'beautyhub-core' ), esc_html( $a['first_name'] ) ) . '</p>' . self::details_html( $a );
				$body .= '<p><a href="' . esc_url( self::manage_url( $id ) ) . '">' . esc_html__( 'Non puoi venire? Avvisaci qui', 'beautyhub-core' ) . '</a></p>';
				self::send( $a['email'], $title . ' – ' . bhc_get_option( 'center_name' ), self::wrap( $title, $body ) );
			}
			$wpdb->update( $t, array( 'reminder_sent' => 1 ), array( 'id' => (int) $id ) );
		}
	}
}
