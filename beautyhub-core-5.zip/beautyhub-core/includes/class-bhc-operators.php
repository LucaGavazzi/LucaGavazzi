<?php
/**
 * Operatrici sugli appuntamenti.
 *
 * - Ogni trattamento indica quante operatrici servono contemporaneamente (1 o 2)
 *   e quali operatrici possono eseguirlo (competenze nella scheda personale).
 * - Un'operatrice è "disponibile" se è attiva, abilitata al trattamento, in turno
 *   per tutta la durata e non impegnata in un altro appuntamento.
 * - Se nel centro non è ancora registrata nessuna operatrice, il controllo è disattivato.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Operators {

	/** Cache per richiesta: persone attive. */
	private static $people = null;

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = bhc_table( 'appt_people' );
		dbDelta(
			"CREATE TABLE {$t} (
			appointment_id bigint(20) unsigned NOT NULL,
			person_id bigint(20) unsigned NOT NULL,
			PRIMARY KEY  (appointment_id,person_id),
			KEY person_id (person_id)
			) {$wpdb->get_charset_collate()};"
		);
	}

	public static function reset_cache() {
		self::$people = null;
	}

	/** Operatrici necessarie per un trattamento (1 o 2). */
	public static function needed( $treatment_id ) {
		$n = (int) get_post_meta( $treatment_id, '_bh_staff_needed', true );
		return 2 === $n ? 2 : 1;
	}

	/** Persone attive (tutti i ruoli), con dati utili al calcolo. */
	public static function active_people() {
		if ( null === self::$people ) {
			self::$people = array();
			foreach ( BHC_People::search( '', '', 'attivo' ) as $p ) {
				self::$people[ $p['id'] ] = $p;
			}
		}
		return self::$people;
	}

	/** Il controllo operatrici è attivo solo se esiste almeno un'operatrice attiva. */
	public static function enabled() {
		foreach ( self::active_people() as $p ) {
			if ( 'operatrice' === $p['role'] || ! empty( $p['skills'] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Persone abilitate a un trattamento: chi lo ha tra le competenze.
	 * Se nessuno lo ha indicato, tutte le operatrici attive.
	 */
	public static function eligible( $treatment_id ) {
		$tid = (int) $treatment_id;
		$out = array();
		foreach ( self::active_people() as $p ) {
			if ( in_array( $tid, $p['skills'], true ) ) {
				$out[ $p['id'] ] = $p;
			}
		}
		if ( ! $out ) {
			foreach ( self::active_people() as $p ) {
				if ( 'operatrice' === $p['role'] ) {
					$out[ $p['id'] ] = $p;
				}
			}
		}
		return $out;
	}

	/** Turno della persona in quel giorno (minuti), dentro gli orari del centro. */
	public static function ranges( array $p, $date ) {
		$center = BHC_Repository::center_ranges( $date );
		if ( ! $center ) {
			return array();
		}
		$has = false;
		foreach ( (array) $p['schedule'] as $h ) {
			if ( '' !== trim( (string) $h ) ) {
				$has = true;
				break;
			}
		}
		if ( ! $has ) {
			return $center;
		}
		$dow = (int) gmdate( 'N', strtotime( $date . ' 12:00:00' ) );
		return BHC_Availability::intersect( $center, bhc_parse_ranges( $p['schedule'][ $dow ] ?? ( $p['schedule'][ (string) $dow ] ?? '' ) ) );
	}

	/** Appuntamenti (minuti) in cui la persona è già impegnata quel giorno. */
	public static function busy( $person_id, $date, $exclude_appt = 0 ) {
		global $wpdb;
		$a    = bhc_table( 'appointments' );
		$l    = bhc_table( 'appt_people' );
		$rows = $wpdb->get_results( // phpcs:ignore
			$wpdb->prepare(
				"SELECT a.id, a.start_at, a.end_at FROM {$a} a INNER JOIN {$l} l ON l.appointment_id = a.id WHERE l.person_id = %d AND a.start_at >= %s AND a.start_at < %s AND a.status NOT IN ('cancelled','noshow') AND a.id <> %d", // phpcs:ignore
				$person_id,
				$date . ' 00:00:00',
				$date . ' 23:59:59',
				(int) $exclude_appt
			),
			ARRAY_A
		);
		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array( bhc_time_to_min( substr( $r['start_at'], 11, 5 ) ), bhc_time_to_min( substr( $r['end_at'], 11, 5 ) ), (int) $r['id'] );
		}
		return $out;
	}

	/**
	 * Situazione di ogni operatrice abilitata per un intervallo.
	 *
	 * @return array[] id, name, color, available, reason, load (minuti già impegnati quel giorno)
	 */
	public static function availability( $treatment_id, $date, $s_min, $e_min, $exclude_appt = 0 ) {
		$out = array();
		foreach ( self::eligible( $treatment_id ) as $p ) {
			$ok     = false;
			$reason = __( 'non in turno', 'beautyhub-core' );
			foreach ( self::ranges( $p, $date ) as $r ) {
				if ( $s_min >= $r[0] && $e_min <= $r[1] ) {
					$ok     = true;
					$reason = '';
					break;
				}
			}
			$busy = self::busy( $p['id'], $date, $exclude_appt );
			$load = 0;
			foreach ( $busy as $b ) {
				$load += $b[1] - $b[0];
				if ( $ok && $s_min < $b[1] && $e_min > $b[0] ) {
					$ok = false;
					/* translators: 1: ora inizio 2: ora fine */
					$reason = sprintf( __( 'occupata %1$s–%2$s', 'beautyhub-core' ), bhc_min_to_time( $b[0] ), bhc_min_to_time( $b[1] ) );
				}
			}
			$out[] = array(
				'id'        => (int) $p['id'],
				'name'      => trim( $p['first_name'] . ' ' . $p['last_name'] ),
				'short'     => $p['first_name'],
				'color'     => $p['color'],
				'available' => $ok,
				'reason'    => $reason,
				'load'      => $load,
			);
		}
		usort(
			$out,
			function ( $a, $b ) {
				if ( $a['available'] !== $b['available'] ) {
					return $a['available'] ? -1 : 1;
				}
				return $a['load'] - $b['load'];
			}
		);
		return $out;
	}

	/**
	 * Precalcola turni e impegni del giorno per le persone abilitate (calcolo slot veloce).
	 */
	public static function day_index( $treatment_id, $date ) {
		$idx = array();
		foreach ( self::eligible( $treatment_id ) as $p ) {
			$idx[] = array( self::ranges( $p, $date ), self::busy( $p['id'], $date ) );
		}
		return $idx;
	}

	/** Quante persone dell'indice sono libere nell'intervallo [s, e). */
	public static function count_free( array $idx, $s, $e ) {
		$n = 0;
		foreach ( $idx as $item ) {
			$in = false;
			foreach ( $item[0] as $r ) {
				if ( $s >= $r[0] && $e <= $r[1] ) {
					$in = true;
					break;
				}
			}
			if ( $in && ! BHC_Availability::overlaps_any( $s, $e, $item[1] ) ) {
				$n++;
			}
		}
		return $n;
	}

	/** Sceglie automaticamente le operatrici libere meno impegnate. */
	public static function auto_pick( $treatment_id, $date, $s_min, $e_min, $exclude_appt = 0 ) {
		$need = self::needed( $treatment_id );
		$ids  = array();
		foreach ( self::availability( $treatment_id, $date, $s_min, $e_min, $exclude_appt ) as $o ) {
			if ( $o['available'] ) {
				$ids[] = $o['id'];
			}
			if ( count( $ids ) >= $need ) {
				break;
			}
		}
		return count( $ids ) >= $need ? $ids : null;
	}

	/**
	 * Verifica le operatrici scelte per un appuntamento.
	 *
	 * @return true|WP_Error
	 */
	public static function validate( array $ids, $treatment_id, $date, $s_min, $e_min, $exclude_appt, $check_availability ) {
		$need = self::needed( $treatment_id );
		$ids  = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		if ( count( $ids ) < $need ) {
			return new WP_Error(
				'operators_missing',
				2 === $need ? __( 'Questo trattamento richiede due operatrici: selezionale entrambe.', 'beautyhub-core' ) : __( 'Seleziona l\'operatrice.', 'beautyhub-core' )
			);
		}
		if ( count( $ids ) > $need ) {
			/* translators: %d: numero operatrici */
			return new WP_Error( 'operators_many', sprintf( _n( 'Questo trattamento prevede %d operatrice.', 'Questo trattamento prevede %d operatrici.', $need, 'beautyhub-core' ), $need ) );
		}
		if ( ! $check_availability ) {
			return true;
		}
		$state = array();
		foreach ( self::availability( $treatment_id, $date, $s_min, $e_min, $exclude_appt ) as $o ) {
			$state[ $o['id'] ] = $o;
		}
		foreach ( $ids as $id ) {
			if ( ! isset( $state[ $id ] ) ) {
				$p = BHC_People::get( $id );
				/* translators: %s: nome */
				return new WP_Error( 'operator_conflict', sprintf( __( '%s non è abilitata a questo trattamento.', 'beautyhub-core' ), $p ? $p['first_name'] : '#' . $id ) );
			}
			if ( ! $state[ $id ]['available'] ) {
				/* translators: 1: nome 2: motivo */
				return new WP_Error( 'operator_conflict', sprintf( __( '%1$s non è disponibile (%2$s).', 'beautyhub-core' ), $state[ $id ]['short'], $state[ $id ]['reason'] ) );
			}
		}
		return true;
	}

	/** Salva le operatrici di un appuntamento. */
	public static function set( $appointment_id, array $ids ) {
		global $wpdb;
		$t = bhc_table( 'appt_people' );
		$wpdb->delete( $t, array( 'appointment_id' => (int) $appointment_id ) );
		foreach ( array_unique( array_filter( array_map( 'intval', $ids ) ) ) as $pid ) {
			$wpdb->insert( $t, array( 'appointment_id' => (int) $appointment_id, 'person_id' => $pid ) );
		}
	}

	/** Operatrici di un appuntamento. */
	public static function of( $appointment_id ) {
		global $wpdb;
		$t   = bhc_table( 'appt_people' );
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT person_id FROM {$t} WHERE appointment_id = %d", $appointment_id ) ); // phpcs:ignore
		$out = array();
		foreach ( $ids as $id ) {
			static $cache = array();
			if ( ! isset( $cache[ $id ] ) ) {
				$p            = BHC_People::get( (int) $id );
				$cache[ $id ] = $p ? array( 'id' => (int) $id, 'name' => $p['first_name'], 'full' => trim( $p['first_name'] . ' ' . $p['last_name'] ), 'color' => $p['color'] ) : null;
			}
			if ( $cache[ $id ] ) {
				$out[] = $cache[ $id ];
			}
		}
		return $out;
	}

	public static function delete_for_appointment( $appointment_id ) {
		global $wpdb;
		$wpdb->delete( bhc_table( 'appt_people' ), array( 'appointment_id' => (int) $appointment_id ) );
	}

	public static function delete_for_person( $person_id ) {
		global $wpdb;
		$wpdb->delete( bhc_table( 'appt_people' ), array( 'person_id' => (int) $person_id ) );
	}

	/**
	 * Abilita/disabilita un elenco di persone a un trattamento
	 * (aggiorna le competenze nelle schede del personale).
	 */
	public static function set_treatment_people( $treatment_id, array $person_ids ) {
		global $wpdb;
		$tid  = (int) $treatment_id;
		$want = array_map( 'intval', $person_ids );
		foreach ( BHC_People::search( '', '', '' ) as $p ) {
			$has    = in_array( $tid, $p['skills'], true );
			$should = in_array( (int) $p['id'], $want, true );
			if ( $has === $should ) {
				continue;
			}
			$skills = $should ? array_merge( $p['skills'], array( $tid ) ) : array_values( array_diff( $p['skills'], array( $tid ) ) );
			$wpdb->update( bhc_table( 'people' ), array( 'skills' => wp_json_encode( array_values( array_unique( array_map( 'intval', $skills ) ) ) ) ), array( 'id' => (int) $p['id'] ) );
		}
		self::reset_cache();
	}

	/** Persone abilitate (esplicitamente) a un trattamento. */
	public static function treatment_people( $treatment_id ) {
		$out = array();
		foreach ( BHC_People::search( '', '', '' ) as $p ) {
			if ( in_array( (int) $treatment_id, $p['skills'], true ) ) {
				$out[] = (int) $p['id'];
			}
		}
		return $out;
	}

	/* ------------------------------------------------------------------
	 * REST
	 * ---------------------------------------------------------------- */

	public static function routes() {
		$ns = BHC_REST::NS;
		register_rest_route( $ns, '/operators', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_availability' ), 'permission_callback' => BHC_Permissions::cb( array( 'agenda_view' ) ) ) );
	}

	/**
	 * GET /operators?treatment=&date=&start=&duration=&exclude=
	 */
	public static function rest_availability( WP_REST_Request $r ) {
		$tid   = absint( $r->get_param( 'treatment' ) );
		$date  = (string) $r->get_param( 'date' );
		$start = bhc_time_to_min( (string) $r->get_param( 'start' ) );
		$t     = bhc_treatment_data( $tid );
		if ( ! $t || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || null === $start ) {
			return new WP_REST_Response( array( 'message' => __( 'Parametri non validi.', 'beautyhub-core' ) ), 400 );
		}
		$dur = absint( $r->get_param( 'duration' ) ) ?: $t['duration'];
		return array(
			'enabled'   => self::enabled(),
			'needed'    => self::needed( $tid ),
			'operators' => self::enabled() ? self::availability( $tid, $date, $start, $start + $dur, absint( $r->get_param( 'exclude' ) ) ) : array(),
		);
	}
}
