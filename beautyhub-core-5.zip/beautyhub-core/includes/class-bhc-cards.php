<?php
/**
 * Card nominali: gift card (valore scaricabile anche in parte), carte fedeltà (punti)
 * e carte trattamenti (pacchetti di sedute scontati).
 * Ogni card ha un codice identificativo (es. GC26-00012) e un codice EAN-13,
 * generato in automatico nella fascia ad uso interno (prefisso 29) oppure personalizzato.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Cards {

	const TYPES = array( 'gift', 'loyalty', 'package' );

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'bhc_payment_added', array( __CLASS__, 'on_payment' ), 10, 4 );
	}

	public static function type_labels() {
		return array(
			'gift'    => __( 'Gift card', 'beautyhub-core' ),
			'loyalty' => __( 'Carta fedeltà', 'beautyhub-core' ),
			'package' => __( 'Carta trattamenti', 'beautyhub-core' ),
		);
	}

	/* ==================================================================
	 * Tabelle
	 * ================================================================ */

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'cards' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			type varchar(20) NOT NULL DEFAULT 'gift',
			code varchar(30) NOT NULL DEFAULT '',
			ean varchar(20) NOT NULL DEFAULT '',
			client_id bigint(20) unsigned NOT NULL DEFAULT 0,
			buyer_name varchar(190) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'attiva',
			initial_value decimal(10,2) NOT NULL DEFAULT 0,
			balance decimal(10,2) NOT NULL DEFAULT 0,
			points decimal(10,2) NOT NULL DEFAULT 0,
			expires_at date DEFAULT NULL,
			message varchar(255) NOT NULL DEFAULT '',
			notes text,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY code (code),
			KEY ean (ean),
			KEY client_id (client_id),
			KEY type_status (type,status)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'card_items' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			card_id bigint(20) unsigned NOT NULL DEFAULT 0,
			package_id bigint(20) unsigned NOT NULL DEFAULT 0,
			treatment_id bigint(20) unsigned NOT NULL DEFAULT 0,
			sessions_total smallint(5) unsigned NOT NULL DEFAULT 0,
			sessions_used smallint(5) unsigned NOT NULL DEFAULT 0,
			session_value decimal(10,2) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY card_id (card_id)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'card_moves' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			card_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action varchar(20) NOT NULL DEFAULT '',
			amount decimal(10,2) NOT NULL DEFAULT 0,
			item_id bigint(20) unsigned NOT NULL DEFAULT 0,
			appointment_id bigint(20) unsigned NOT NULL DEFAULT 0,
			payment_method varchar(20) NOT NULL DEFAULT '',
			balance_after decimal(10,2) NOT NULL DEFAULT 0,
			note varchar(255) NOT NULL DEFAULT '',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY card_id (card_id),
			KEY appointment_id (appointment_id)
			) {$c};"
		);
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'card_packages' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(190) NOT NULL DEFAULT '',
			description varchar(255) NOT NULL DEFAULT '',
			items longtext,
			price decimal(10,2) NOT NULL DEFAULT 0,
			validity_days smallint(5) unsigned NOT NULL DEFAULT 365,
			active tinyint(1) NOT NULL DEFAULT 1,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id)
			) {$c};"
		);
	}

	/* ==================================================================
	 * Impostazioni fedeltà
	 * ================================================================ */

	public static function loyalty_settings() {
		return wp_parse_args(
			get_option( 'bhc_loyalty', array() ),
			array(
				'points_per_euro' => 1,      // punti accreditati per ogni euro incassato
				'point_value'     => 0.10,   // valore in euro di 1 punto quando si usa
				'min_redeem'      => 100,    // punti minimi per poterli usare
				'auto'            => 1,      // accredito automatico sugli incassi
			)
		);
	}

	/* ==================================================================
	 * Codici
	 * ================================================================ */

	/** Calcola la cifra di controllo EAN-13 per 12 cifre. */
	public static function ean_check( $twelve ) {
		$sum = 0;
		foreach ( str_split( $twelve ) as $i => $d ) {
			$sum += (int) $d * ( 0 === $i % 2 ? 1 : 3 );
		}
		return ( 10 - $sum % 10 ) % 10;
	}

	/**
	 * EAN-13 interno: 29 (circolazione interna) + tipo (1 gift, 2 fedeltà, 3 trattamenti)
	 * + id a 9 cifre + controllo.
	 */
	public static function make_ean( $type, $id ) {
		$t    = array( 'gift' => 1, 'loyalty' => 2, 'package' => 3 );
		$base = '29' . ( $t[ $type ] ?? 9 ) . str_pad( (string) $id, 9, '0', STR_PAD_LEFT );
		return $base . self::ean_check( $base );
	}

	public static function make_code( $type, $id ) {
		$p = array( 'gift' => 'GC', 'loyalty' => 'FD', 'package' => 'PK' );
		return ( $p[ $type ] ?? 'CD' ) . current_time( 'y' ) . '-' . str_pad( (string) $id, 5, '0', STR_PAD_LEFT );
	}

	/* ==================================================================
	 * Lettura dati
	 * ================================================================ */

	public static function get( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'cards' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		return $row ? self::out( $row, true ) : null;
	}

	public static function find( $code ) {
		global $wpdb;
		$code = trim( (string) $code );
		if ( '' === $code ) {
			return null;
		}
		$t  = bhc_table( 'cards' );
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE ean = %s OR code = %s ORDER BY id DESC LIMIT 1", preg_replace( '/\s/', '', $code ), strtoupper( $code ) ) ); // phpcs:ignore
		return $id ? self::get( $id ) : null;
	}

	private static function out( $row, $full = false ) {
		global $wpdb;
		foreach ( array( 'id', 'client_id', 'created_by' ) as $k ) {
			$row[ $k ] = (int) $row[ $k ];
		}
		foreach ( array( 'initial_value', 'balance', 'points' ) as $k ) {
			$row[ $k ] = (float) $row[ $k ];
		}
		$c                   = $row['client_id'] ? BHC_Repository::get_client( $row['client_id'] ) : null;
		$row['holder']       = $c ? trim( $c['first_name'] . ' ' . $c['last_name'] ) : '';
		$row['holder_phone'] = $c ? $c['phone'] : '';
		$row['holder_email'] = $c ? $c['email'] : '';
		$row['type_label']   = self::type_labels()[ $row['type'] ] ?? $row['type'];
		$row['expired']      = $row['expires_at'] && $row['expires_at'] < current_time( 'Y-m-d' );
		$row['usable']       = 'attiva' === $row['status'] && ! $row['expired'];

		// Pacchetti: voci e sedute residue.
		$row['items']          = array();
		$row['sessions_left']  = 0;
		$row['sessions_total'] = 0;
		if ( 'package' === $row['type'] ) {
			$items = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'card_items' ) . ' WHERE card_id = %d ORDER BY id', $row['id'] ), ARRAY_A ); // phpcs:ignore
			foreach ( $items as $it ) {
				$left                    = (int) $it['sessions_total'] - (int) $it['sessions_used'];
				$row['sessions_left']   += $left;
				$row['sessions_total']  += (int) $it['sessions_total'];
				$row['items'][]          = array(
					'id'             => (int) $it['id'],
					'treatment_id'   => (int) $it['treatment_id'],
					'treatment'      => $it['treatment_id'] ? get_the_title( (int) $it['treatment_id'] ) : '',
					'sessions_total' => (int) $it['sessions_total'],
					'sessions_used'  => (int) $it['sessions_used'],
					'sessions_left'  => $left,
					'session_value'  => (float) $it['session_value'],
				);
			}
		}
		if ( 'loyalty' === $row['type'] ) {
			$s                      = self::loyalty_settings();
			$row['points_value']    = round( $row['points'] * (float) $s['point_value'], 2 );
			$row['can_redeem']      = $row['points'] >= (float) $s['min_redeem'];
		}
		if ( $full ) {
			$m    = bhc_table( 'card_moves' );
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$m} WHERE card_id = %d ORDER BY id DESC LIMIT 200", $row['id'] ), ARRAY_A ); // phpcs:ignore
			foreach ( $rows as &$mv ) {
				$mv['amount']        = (float) $mv['amount'];
				$mv['balance_after'] = (float) $mv['balance_after'];
				$mv['item_id']       = (int) $mv['item_id'];
				$mv['appointment_id'] = (int) $mv['appointment_id'];
				$u                   = $mv['created_by'] ? get_userdata( (int) $mv['created_by'] ) : null;
				$mv['user']          = $u ? $u->display_name : '';
			}
			$row['moves'] = $rows;
		}
		return $row;
	}

	public static function search( array $f ) {
		global $wpdb;
		$t     = bhc_table( 'cards' );
		$cl    = bhc_table( 'clients' );
		$where = array( '1=1' );
		$args  = array();
		if ( ! empty( $f['type'] ) && in_array( $f['type'], self::TYPES, true ) ) {
			$where[] = 'k.type = %s';
			$args[]  = $f['type'];
		}
		if ( ! empty( $f['status'] ) ) {
			$where[] = 'k.status = %s';
			$args[]  = $f['status'];
		}
		if ( ! empty( $f['client'] ) ) {
			$where[] = 'k.client_id = %d';
			$args[]  = (int) $f['client'];
		}
		if ( ! empty( $f['q'] ) ) {
			$like    = '%' . $wpdb->esc_like( trim( $f['q'] ) ) . '%';
			$where[] = "(k.code LIKE %s OR k.ean LIKE %s OR c.first_name LIKE %s OR c.last_name LIKE %s OR CONCAT(c.first_name, ' ', c.last_name) LIKE %s OR c.phone LIKE %s)";
			array_push( $args, $like, $like, $like, $like, $like, $like );
		}
		$sql  = "SELECT k.* FROM {$t} k LEFT JOIN {$cl} c ON c.id = k.client_id WHERE " . implode( ' AND ', $where ) . ' ORDER BY k.id DESC LIMIT 500';
		$rows = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		return array_map(
			function ( $r ) {
				return BHC_Cards::out( $r, false );
			},
			$rows
		);
	}

	public static function summary() {
		global $wpdb;
		$t = bhc_table( 'cards' );
		$i = bhc_table( 'card_items' );
		$today = current_time( 'Y-m-d' );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array(
			'gift_active'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE type = 'gift' AND status = 'attiva' AND (expires_at IS NULL OR expires_at >= %s)", $today ) ),
			'gift_balance'   => (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(balance),0) FROM {$t} WHERE type = 'gift' AND status = 'attiva' AND (expires_at IS NULL OR expires_at >= %s)", $today ) ),
			'loyalty_active' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE type = 'loyalty' AND status = 'attiva'" ),
			'loyalty_points' => (float) $wpdb->get_var( "SELECT COALESCE(SUM(points),0) FROM {$t} WHERE type = 'loyalty' AND status = 'attiva'" ),
			'package_active' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE type = 'package' AND status = 'attiva' AND (expires_at IS NULL OR expires_at >= %s)", $today ) ),
			'sessions_left'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(i.sessions_total - i.sessions_used),0) FROM {$i} i INNER JOIN {$t} k ON k.id = i.card_id WHERE k.status = 'attiva' AND (k.expires_at IS NULL OR k.expires_at >= %s)", $today ) ),
			'expiring'       => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE status = 'attiva' AND expires_at IS NOT NULL AND expires_at >= %s AND expires_at <= %s", $today, gmdate( 'Y-m-d', strtotime( $today . ' +30 days' ) ) ) ),
		);
		// phpcs:enable
	}

	/* ==================================================================
	 * Operazioni
	 * ================================================================ */

	private static function log( $card_id, $action, $amount, $after, $note = '', $item_id = 0, $appointment_id = 0, $method = '' ) {
		global $wpdb;
		$wpdb->insert(
			bhc_table( 'card_moves' ),
			array(
				'card_id'        => (int) $card_id,
				'action'         => $action,
				'amount'         => round( $amount, 2 ),
				'item_id'        => (int) $item_id,
				'appointment_id' => (int) $appointment_id,
				'payment_method' => sanitize_key( $method ),
				'balance_after'  => round( $after, 2 ),
				'note'           => sanitize_text_field( $note ),
				'created_by'     => get_current_user_id(),
				'created_at'     => current_time( 'mysql' ),
			)
		);
	}

	private static function touch( $id, array $data ) {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql' );
		$wpdb->update( bhc_table( 'cards' ), $data, array( 'id' => (int) $id ) );
	}

	/** Verifica e normalizza un EAN personalizzato (unico tra card e prodotti). */
	private static function check_custom_ean( $ean, $exclude_card = 0 ) {
		global $wpdb;
		$ean = preg_replace( '/\D/', '', (string) $ean );
		if ( ! preg_match( '/^(\d{8}|\d{12}|\d{13})$/', $ean ) ) {
			return new WP_Error( 'ean', __( 'Il codice EAN deve avere 8, 12 o 13 cifre.', 'beautyhub-core' ) );
		}
		if ( ! BHC_Inventory::ean_valid( $ean ) ) {
			return new WP_Error( 'ean', __( 'Il codice EAN non è valido (cifra di controllo errata).', 'beautyhub-core' ) );
		}
		if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'cards' ) . ' WHERE ean = %s AND id <> %d', $ean, $exclude_card ) ) ) { // phpcs:ignore
			return new WP_Error( 'ean_dup', __( 'Questo codice EAN è già assegnato a un\'altra card.', 'beautyhub-core' ) );
		}
		if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'products' ) . ' WHERE ean = %s', $ean ) ) ) { // phpcs:ignore
			return new WP_Error( 'ean_dup', __( 'Questo codice EAN appartiene a un prodotto di magazzino.', 'beautyhub-core' ) );
		}
		return $ean;
	}

	/**
	 * Emissione di una card.
	 */
	public static function create( array $d ) {
		global $wpdb;
		$type = in_array( $d['type'] ?? '', self::TYPES, true ) ? $d['type'] : '';
		if ( ! $type ) {
			return new WP_Error( 'type', __( 'Tipo di card non valido.', 'beautyhub-core' ) );
		}
		$client_id = absint( $d['client_id'] ?? 0 );
		if ( ! $client_id || ! BHC_Repository::get_client( $client_id ) ) {
			return new WP_Error( 'client', __( 'La card è nominale: scegli la cliente intestataria.', 'beautyhub-core' ) );
		}
		if ( 'loyalty' === $type ) {
			$has = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'cards' ) . " WHERE type = 'loyalty' AND client_id = %d AND status = 'attiva'", $client_id ) ); // phpcs:ignore
			if ( $has ) {
				return new WP_Error( 'dup', __( 'La cliente ha già una carta fedeltà attiva.', 'beautyhub-core' ) );
			}
		}
		$value = round( (float) str_replace( ',', '.', (string) ( $d['value'] ?? 0 ) ), 2 );
		if ( 'gift' === $type && ( $value <= 0 || $value > 10000 ) ) {
			return new WP_Error( 'value', __( 'Indica il valore della gift card.', 'beautyhub-core' ) );
		}
		$custom_ean = '';
		if ( ! empty( $d['ean'] ) ) {
			$custom_ean = self::check_custom_ean( $d['ean'] );
			if ( is_wp_error( $custom_ean ) ) {
				return $custom_ean;
			}
		}
		$expires = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d['expires_at'] ?? '' ) ? $d['expires_at'] : null;

		$now = current_time( 'mysql' );
		$wpdb->insert(
			bhc_table( 'cards' ),
			array(
				'type'          => $type,
				'client_id'     => $client_id,
				'buyer_name'    => sanitize_text_field( $d['buyer_name'] ?? '' ),
				'status'        => 'attiva',
				'initial_value' => 'gift' === $type ? $value : 0,
				'balance'       => 'gift' === $type ? $value : 0,
				'points'        => 'loyalty' === $type ? max( 0, (float) ( $d['points'] ?? 0 ) ) : 0,
				'expires_at'    => $expires,
				'message'       => sanitize_text_field( $d['message'] ?? '' ),
				'notes'         => sanitize_textarea_field( $d['notes'] ?? '' ),
				'created_by'    => get_current_user_id(),
				'created_at'    => $now,
				'updated_at'    => $now,
			)
		);
		$id = (int) $wpdb->insert_id;
		self::touch( $id, array( 'code' => self::make_code( $type, $id ), 'ean' => $custom_ean ? $custom_ean : self::make_ean( $type, $id ) ) );

		$method = sanitize_key( $d['payment_method'] ?? '' );
		if ( 'gift' === $type ) {
			self::log( $id, 'emissione', $value, $value, sanitize_text_field( $d['buyer_name'] ?? '' ) ? __( 'Acquistata da', 'beautyhub-core' ) . ' ' . sanitize_text_field( $d['buyer_name'] ) : '', 0, 0, $method );
		} elseif ( 'loyalty' === $type ) {
			self::log( $id, 'emissione', (float) ( $d['points'] ?? 0 ), (float) ( $d['points'] ?? 0 ), __( 'Carta fedeltà emessa', 'beautyhub-core' ) );
		} else {
			$res = self::add_package( $id, $d, $method );
			if ( is_wp_error( $res ) ) {
				$wpdb->delete( bhc_table( 'cards' ), array( 'id' => $id ) );
				$wpdb->delete( bhc_table( 'card_moves' ), array( 'card_id' => $id ) );
				return $res;
			}
		}
		return $id;
	}

	/**
	 * Carica un pacchetto su una carta trattamenti: da listino (package_id)
	 * o personalizzato (items = [{treatment_id, sessions}], price).
	 */
	public static function add_package( $card_id, array $d, $method = '' ) {
		global $wpdb;
		$items = array();
		$price = null;
		$name  = '';
		$pkg_id = absint( $d['package_id'] ?? 0 );
		if ( $pkg_id ) {
			$pkg = self::get_package( $pkg_id );
			if ( ! $pkg ) {
				return new WP_Error( 'package', __( 'Pacchetto non trovato.', 'beautyhub-core' ) );
			}
			$items = $pkg['items'];
			$price = $pkg['price'];
			$name  = $pkg['name'];
			if ( empty( $d['expires_at'] ) && $pkg['validity_days'] ) {
				self::touch( $card_id, array( 'expires_at' => gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' +' . (int) $pkg['validity_days'] . ' days' ) ) ) );
			}
		} else {
			foreach ( (array) ( $d['items'] ?? array() ) as $it ) {
				$tid = absint( $it['treatment_id'] ?? 0 );
				$n   = absint( $it['sessions'] ?? 0 );
				if ( $tid && $n && bhc_treatment_data( $tid ) ) {
					$items[] = array( 'treatment_id' => $tid, 'sessions' => min( 999, $n ) );
				}
			}
			$price = isset( $d['price'] ) && '' !== $d['price'] ? round( (float) str_replace( ',', '.', (string) $d['price'] ), 2 ) : null;
			$name  = __( 'Pacchetto personalizzato', 'beautyhub-core' );
		}
		if ( ! $items ) {
			return new WP_Error( 'items', __( 'Scegli un pacchetto o aggiungi almeno un trattamento con il numero di sedute.', 'beautyhub-core' ) );
		}
		// Valore di listino e valore della seduta (prezzo pagato ripartito).
		$list = 0;
		foreach ( $items as $it ) {
			$t     = bhc_treatment_data( $it['treatment_id'] );
			$list += $t ? $t['price'] * $it['sessions'] : 0;
		}
		if ( null === $price ) {
			$price = $list;
		}
		$ratio = $list > 0 ? $price / $list : 1;
		foreach ( $items as $it ) {
			$t = bhc_treatment_data( $it['treatment_id'] );
			$wpdb->insert(
				bhc_table( 'card_items' ),
				array(
					'card_id'        => (int) $card_id,
					'package_id'     => $pkg_id,
					'treatment_id'   => (int) $it['treatment_id'],
					'sessions_total' => (int) $it['sessions'],
					'session_value'  => $t ? round( $t['price'] * $ratio, 2 ) : 0,
					'created_at'     => current_time( 'mysql' ),
				)
			);
		}
		$card = self::get( $card_id );
		/* translators: 1: nome pacchetto 2: prezzo listino */
		self::log( $card_id, 'pacchetto', $price, $card['sessions_left'], sprintf( __( '%1$s (listino %2$s)', 'beautyhub-core' ), $name, bhc_price( $list ) ), 0, 0, $method );
		if ( 'attiva' !== $card['status'] ) {
			self::touch( $card_id, array( 'status' => 'attiva' ) );
		}
		return true;
	}

	/**
	 * Scarico gift card (anche parziale).
	 */
	public static function redeem_gift( $card_id, $amount, $appointment_id = 0, $note = '' ) {
		$c      = self::get( $card_id );
		$amount = round( (float) $amount, 2 );
		if ( ! $c || 'gift' !== $c['type'] ) {
			return new WP_Error( 'card', __( 'Gift card non trovata.', 'beautyhub-core' ) );
		}
		if ( ! $c['usable'] ) {
			return new WP_Error( 'state', $c['expired'] ? __( 'La gift card è scaduta.', 'beautyhub-core' ) : __( 'La gift card non è attiva.', 'beautyhub-core' ) );
		}
		if ( $amount <= 0 ) {
			return new WP_Error( 'amount', __( 'Indica l\'importo da scaricare.', 'beautyhub-core' ) );
		}
		if ( $amount > $c['balance'] + 0.001 ) {
			/* translators: %s: saldo */
			return new WP_Error( 'balance', sprintf( __( 'Saldo insufficiente: sulla gift card restano %s.', 'beautyhub-core' ), bhc_price( $c['balance'] ) ) );
		}
		$after = round( $c['balance'] - $amount, 2 );
		self::touch( $card_id, array( 'balance' => $after, 'status' => $after <= 0 ? 'esaurita' : 'attiva' ) );
		self::log( $card_id, 'scarico', -$amount, $after, $note, 0, $appointment_id );
		return $after;
	}

	public static function topup_gift( $card_id, $amount, $method = '', $note = '' ) {
		$c      = self::get( $card_id );
		$amount = round( (float) $amount, 2 );
		if ( ! $c || 'gift' !== $c['type'] || in_array( $c['status'], array( 'annullata' ), true ) ) {
			return new WP_Error( 'card', __( 'Gift card non ricaricabile.', 'beautyhub-core' ) );
		}
		if ( $amount <= 0 ) {
			return new WP_Error( 'amount', __( 'Indica l\'importo da caricare.', 'beautyhub-core' ) );
		}
		$after = round( $c['balance'] + $amount, 2 );
		self::touch( $card_id, array( 'balance' => $after, 'status' => 'attiva' ) );
		self::log( $card_id, 'ricarica', $amount, $after, $note, 0, 0, $method );
		return $after;
	}

	/** Punti fedeltà: + accredito, − utilizzo. */
	public static function points( $card_id, $delta, $action, $note = '', $appointment_id = 0 ) {
		$c = self::get( $card_id );
		if ( ! $c || 'loyalty' !== $c['type'] ) {
			return new WP_Error( 'card', __( 'Carta fedeltà non trovata.', 'beautyhub-core' ) );
		}
		if ( 'attiva' !== $c['status'] ) {
			return new WP_Error( 'state', __( 'La carta fedeltà non è attiva.', 'beautyhub-core' ) );
		}
		$delta = round( (float) $delta, 2 );
		if ( $delta < 0 ) {
			$s = self::loyalty_settings();
			if ( -$delta > $c['points'] + 0.001 ) {
				return new WP_Error( 'points', __( 'Punti insufficienti.', 'beautyhub-core' ) );
			}
			if ( 'utilizzo' === $action && $c['points'] < (float) $s['min_redeem'] ) {
				/* translators: %s: punti minimi */
				return new WP_Error( 'points', sprintf( __( 'Servono almeno %s punti per usarli.', 'beautyhub-core' ), $s['min_redeem'] ) );
			}
		}
		$after = round( $c['points'] + $delta, 2 );
		self::touch( $card_id, array( 'points' => $after ) );
		self::log( $card_id, $action, $delta, $after, $note, 0, $appointment_id );
		return $after;
	}

	/** Usa una seduta di una carta trattamenti. */
	public static function use_session( $card_id, $item_id, $appointment_id = 0, $note = '' ) {
		global $wpdb;
		$c = self::get( $card_id );
		if ( ! $c || 'package' !== $c['type'] ) {
			return new WP_Error( 'card', __( 'Carta trattamenti non trovata.', 'beautyhub-core' ) );
		}
		if ( ! $c['usable'] ) {
			return new WP_Error( 'state', $c['expired'] ? __( 'La carta trattamenti è scaduta.', 'beautyhub-core' ) : __( 'La carta trattamenti non è attiva.', 'beautyhub-core' ) );
		}
		$item = null;
		foreach ( $c['items'] as $it ) {
			if ( $it['id'] === (int) $item_id ) {
				$item = $it;
			}
		}
		if ( ! $item ) {
			return new WP_Error( 'item', __( 'Trattamento non presente sulla carta.', 'beautyhub-core' ) );
		}
		if ( $item['sessions_left'] <= 0 ) {
			return new WP_Error( 'empty', __( 'Sedute esaurite per questo trattamento.', 'beautyhub-core' ) );
		}
		if ( $appointment_id ) {
			$dup = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'card_moves' ) . " WHERE appointment_id = %d AND action = 'seduta'", $appointment_id ) ); // phpcs:ignore
			if ( $dup ) {
				return new WP_Error( 'dup', __( 'Per questo appuntamento è già stata scalata una seduta.', 'beautyhub-core' ) );
			}
		}
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . bhc_table( 'card_items' ) . ' SET sessions_used = sessions_used + 1 WHERE id = %d', $item['id'] ) ); // phpcs:ignore
		$left = $c['sessions_left'] - 1;
		/* translators: 1: trattamento 2: usate 3: totali */
		self::log( $card_id, 'seduta', -1, $left, trim( sprintf( __( '%1$s (%2$d/%3$d)', 'beautyhub-core' ), $item['treatment'], $item['sessions_used'] + 1, $item['sessions_total'] ) . ' ' . $note ), $item['id'], $appointment_id );
		if ( $left <= 0 ) {
			self::touch( $card_id, array( 'status' => 'esaurita' ) );
		}
		if ( $appointment_id ) {
			$a = BHC_Repository::get_appointment( $appointment_id );
			if ( $a && ! in_array( $a['status'], array( 'done', 'cancelled' ), true ) ) {
				BHC_Repository::save_appointment( array( 'status' => 'done' ), $appointment_id, false );
			}
		}
		return $left;
	}

	/** Storno dell'ultimo movimento (correzione errori). */
	public static function undo_move( $card_id, $move_id ) {
		global $wpdb;
		$m  = bhc_table( 'card_moves' );
		$mv = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$m} WHERE id = %d AND card_id = %d", $move_id, $card_id ), ARRAY_A ); // phpcs:ignore
		if ( ! $mv ) {
			return new WP_Error( 'move', __( 'Movimento non trovato.', 'beautyhub-core' ) );
		}
		$last = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(id) FROM {$m} WHERE card_id = %d", $card_id ) ); // phpcs:ignore
		if ( (int) $mv['id'] !== $last || in_array( $mv['action'], array( 'emissione', 'pacchetto', 'storno' ), true ) ) {
			return new WP_Error( 'move', __( 'Si può stornare solo l\'ultimo scarico, ricarica, uso punti o seduta.', 'beautyhub-core' ) );
		}
		$c = self::get( $card_id );
		$a = (float) $mv['amount'];
		if ( 'gift' === $c['type'] ) {
			$after = round( $c['balance'] - $a, 2 );
			if ( $after < 0 ) {
				return new WP_Error( 'move', __( 'Impossibile stornare: il saldo diventerebbe negativo.', 'beautyhub-core' ) );
			}
			self::touch( $card_id, array( 'balance' => $after, 'status' => $after > 0 ? 'attiva' : 'esaurita' ) );
		} elseif ( 'loyalty' === $c['type'] ) {
			$after = round( $c['points'] - $a, 2 );
			if ( $after < 0 ) {
				return new WP_Error( 'move', __( 'Impossibile stornare: i punti diventerebbero negativi.', 'beautyhub-core' ) );
			}
			self::touch( $card_id, array( 'points' => $after ) );
		} else {
			$wpdb->query( $wpdb->prepare( 'UPDATE ' . bhc_table( 'card_items' ) . ' SET sessions_used = CASE WHEN sessions_used > 0 THEN sessions_used - 1 ELSE 0 END WHERE id = %d', (int) $mv['item_id'] ) ); // phpcs:ignore
			$after = $c['sessions_left'] + 1;
			self::touch( $card_id, array( 'status' => 'attiva' ) );
		}
		/* translators: %s: data movimento */
		self::log( $card_id, 'storno', -$a, $after, sprintf( __( 'Storno movimento del %s', 'beautyhub-core' ), substr( $mv['created_at'], 0, 16 ) ), (int) $mv['item_id'], (int) $mv['appointment_id'] );
		return true;
	}

	/**
	 * Accredito automatico dei punti quando si registra un incasso.
	 */
	public static function on_payment( $client_id, $amount, $appointment_id, $method ) {
		global $wpdb;
		$s = self::loyalty_settings();
		if ( empty( $s['auto'] ) || ! $client_id || $amount <= 0 ) {
			return;
		}
		$card = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . bhc_table( 'cards' ) . " WHERE type = 'loyalty' AND client_id = %d AND status = 'attiva' ORDER BY id DESC LIMIT 1", $client_id ) ); // phpcs:ignore
		if ( ! $card ) {
			return;
		}
		$pts = floor( $amount * (float) $s['points_per_euro'] );
		if ( $pts > 0 ) {
			/* translators: %s: importo */
			self::points( $card, $pts, 'accredito', sprintf( __( 'Incasso di %s', 'beautyhub-core' ), bhc_price( $amount ) ), $appointment_id );
		}
	}

	/* ==================================================================
	 * Listino pacchetti
	 * ================================================================ */

	private static function package_out( $row ) {
		$row['id']            = (int) $row['id'];
		$row['price']         = (float) $row['price'];
		$row['validity_days'] = (int) $row['validity_days'];
		$row['active']        = (int) $row['active'];
		$items                = json_decode( (string) $row['items'], true );
		$row['items']         = array();
		$list                 = 0;
		$sessions             = 0;
		foreach ( is_array( $items ) ? $items : array() as $it ) {
			$t = bhc_treatment_data( (int) $it['treatment_id'] );
			if ( ! $t ) {
				continue;
			}
			$row['items'][] = array( 'treatment_id' => $t['id'], 'treatment' => $t['name'], 'sessions' => (int) $it['sessions'], 'unit_price' => $t['price'] );
			$list          += $t['price'] * (int) $it['sessions'];
			$sessions      += (int) $it['sessions'];
		}
		$row['list_price'] = round( $list, 2 );
		$row['sessions']   = $sessions;
		$row['discount']   = $list > 0 ? round( ( 1 - $row['price'] / $list ) * 100, 1 ) : 0;
		return $row;
	}

	public static function get_package( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'card_packages' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		return $row ? self::package_out( $row ) : null;
	}

	public static function packages( $only_active = false ) {
		global $wpdb;
		$t    = bhc_table( 'card_packages' );
		$rows = $wpdb->get_results( "SELECT * FROM {$t}" . ( $only_active ? ' WHERE active = 1' : '' ) . ' ORDER BY active DESC, name', ARRAY_A ); // phpcs:ignore
		return array_map( array( __CLASS__, 'package_out' ), $rows );
	}

	public static function save_package( array $d, $id = 0 ) {
		global $wpdb;
		$name = trim( sanitize_text_field( $d['name'] ?? '' ) );
		if ( '' === $name ) {
			return new WP_Error( 'name', __( 'Inserisci il nome del pacchetto.', 'beautyhub-core' ) );
		}
		$items = array();
		foreach ( (array) ( $d['items'] ?? array() ) as $it ) {
			$tid = absint( $it['treatment_id'] ?? 0 );
			$n   = absint( $it['sessions'] ?? 0 );
			if ( $tid && $n && bhc_treatment_data( $tid ) ) {
				$items[] = array( 'treatment_id' => $tid, 'sessions' => min( 999, $n ) );
			}
		}
		if ( ! $items ) {
			return new WP_Error( 'items', __( 'Aggiungi almeno un trattamento con il numero di sedute.', 'beautyhub-core' ) );
		}
		$price = round( (float) str_replace( ',', '.', (string) ( $d['price'] ?? 0 ) ), 2 );
		if ( $price <= 0 ) {
			return new WP_Error( 'price', __( 'Indica il prezzo scontato del pacchetto.', 'beautyhub-core' ) );
		}
		$row = array(
			'name'          => $name,
			'description'   => sanitize_text_field( $d['description'] ?? '' ),
			'items'         => wp_json_encode( $items ),
			'price'         => $price,
			'validity_days' => min( 3650, absint( $d['validity_days'] ?? 365 ) ),
			'active'        => isset( $d['active'] ) ? ( $d['active'] ? 1 : 0 ) : 1,
		);
		if ( $id ) {
			$wpdb->update( bhc_table( 'card_packages' ), $row, array( 'id' => (int) $id ) );
			return (int) $id;
		}
		$row['created_at'] = current_time( 'mysql' );
		$wpdb->insert( bhc_table( 'card_packages' ), $row );
		return (int) $wpdb->insert_id;
	}

	/* ==================================================================
	 * REST
	 * ================================================================ */

	private static function err( WP_Error $e, $status = 400 ) {
		return new WP_REST_Response( array( 'code' => $e->get_error_code(), 'message' => $e->get_error_message() ), $status );
	}

	public static function routes() {
		$ns   = BHC_REST::NS;
		$perm = BHC_Permissions::cb( array( 'cards' ) );
		// Lettura card del cliente anche per chi registra incassi.
		$read = BHC_Permissions::cb( array( 'cards', 'payments' ) );
		$id   = '(?P<id>\d+)';
		register_rest_route(
			$ns,
			'/cards',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_list' ), 'permission_callback' => $read ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_create' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route( $ns, '/cards/lookup', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_lookup' ), 'permission_callback' => $read ) );
		register_rest_route(
			$ns,
			'/cards/' . $id,
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_get' ), 'permission_callback' => $read ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_update' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route( $ns, '/cards/' . $id . '/action', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_action' ), 'permission_callback' => $read ) );
		register_rest_route(
			$ns,
			'/card-packages',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_packages' ), 'permission_callback' => $read ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_save_package' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route( $ns, '/card-packages/' . $id, array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_save_package' ), 'permission_callback' => $perm ) );
		register_rest_route(
			$ns,
			'/card-settings',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'loyalty_settings' ), 'permission_callback' => $read ),
				array( 'methods' => 'PUT', 'callback' => array( __CLASS__, 'rest_save_settings' ), 'permission_callback' => $perm ),
			)
		);
	}

	public static function rest_list( WP_REST_Request $r ) {
		return array(
			'items'    => self::search( array( 'type' => (string) $r->get_param( 'type' ), 'status' => (string) $r->get_param( 'status' ), 'q' => (string) $r->get_param( 'q' ), 'client' => absint( $r->get_param( 'client' ) ) ) ),
			'summary'  => self::summary(),
			'loyalty'  => self::loyalty_settings(),
		);
	}

	public static function rest_lookup( WP_REST_Request $r ) {
		$c = self::find( (string) $r->get_param( 'code' ) );
		return $c ? $c : self::err( new WP_Error( 'unknown', __( 'Nessuna card con questo codice.', 'beautyhub-core' ) ), 404 );
	}

	public static function rest_get( WP_REST_Request $r ) {
		$c = self::get( (int) $r['id'] );
		return $c ? $c : self::err( new WP_Error( 'not_found', __( 'Card non trovata.', 'beautyhub-core' ) ), 404 );
	}

	public static function rest_create( WP_REST_Request $r ) {
		$res = self::create( (array) $r->get_json_params() );
		return is_wp_error( $res ) ? self::err( $res ) : self::get( $res );
	}

	public static function rest_update( WP_REST_Request $r ) {
		$id = (int) $r['id'];
		$c  = self::get( $id );
		if ( ! $c ) {
			return self::err( new WP_Error( 'not_found', __( 'Card non trovata.', 'beautyhub-core' ) ), 404 );
		}
		$upd = array();
		if ( null !== $r->get_param( 'client_id' ) ) {
			$cid = absint( $r->get_param( 'client_id' ) );
			if ( ! $cid || ! BHC_Repository::get_client( $cid ) ) {
				return self::err( new WP_Error( 'client', __( 'Cliente non valida.', 'beautyhub-core' ) ) );
			}
			$upd['client_id'] = $cid;
		}
		if ( null !== $r->get_param( 'expires_at' ) ) {
			$e                 = (string) $r->get_param( 'expires_at' );
			$upd['expires_at'] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $e ) ? $e : null;
		}
		foreach ( array( 'notes' => 'sanitize_textarea_field', 'message' => 'sanitize_text_field', 'buyer_name' => 'sanitize_text_field' ) as $k => $fn ) {
			if ( null !== $r->get_param( $k ) ) {
				$upd[ $k ] = $fn( (string) $r->get_param( $k ) );
			}
		}
		if ( null !== $r->get_param( 'status' ) && in_array( $r->get_param( 'status' ), array( 'attiva', 'sospesa', 'annullata' ), true ) ) {
			$upd['status'] = $r->get_param( 'status' );
			if ( 'attiva' === $upd['status'] && 'gift' === $c['type'] && $c['balance'] <= 0 ) {
				$upd['status'] = 'esaurita';
			}
		}
		if ( null !== $r->get_param( 'ean' ) ) {
			$ean = (string) $r->get_param( 'ean' );
			if ( 'auto' === $ean ) {
				$upd['ean'] = self::make_ean( $c['type'], $id );
			} else {
				$ean = self::check_custom_ean( $ean, $id );
				if ( is_wp_error( $ean ) ) {
					return self::err( $ean );
				}
				$upd['ean'] = $ean;
			}
		}
		if ( $upd ) {
			self::touch( $id, $upd );
			if ( isset( $upd['status'] ) && $upd['status'] !== $c['status'] ) {
				self::log( $id, 'stato', 0, 'gift' === $c['type'] ? $c['balance'] : ( 'loyalty' === $c['type'] ? $c['points'] : $c['sessions_left'] ), __( 'Stato', 'beautyhub-core' ) . ': ' . $upd['status'] );
			}
		}
		return self::get( $id );
	}

	/**
	 * Operazioni: redeem, topup, points_add, points_use, session, add_package, undo.
	 */
	public static function rest_action( WP_REST_Request $r ) {
		$id     = (int) $r['id'];
		$action = (string) $r->get_param( 'action' );
		$note   = sanitize_text_field( (string) $r->get_param( 'note' ) );
		$appt   = absint( $r->get_param( 'appointment_id' ) );
		// Chi ha solo "Registrare incassi" può scaricare gift card e usare sedute/punti, non ricaricare o emettere.
		if ( ! BHC_Permissions::can( 'cards' ) && ! in_array( $action, array( 'redeem', 'session', 'points_use' ), true ) ) {
			return self::err( new WP_Error( 'forbidden', __( 'Permesso negato.', 'beautyhub-core' ) ), 403 );
		}
		switch ( $action ) {
			case 'redeem':
				$res = self::redeem_gift( $id, $r->get_param( 'amount' ), $appt, $note );
				if ( ! is_wp_error( $res ) && $appt && $r->get_param( 'register_payment' ) ) {
					$a = BHC_Repository::get_appointment( $appt );
					if ( $a ) {
						$card = self::get( $id );
						BHC_Repository::add_payment(
							array(
								'appointment_id' => $appt,
								'client_id'      => $a['client_id'],
								'amount'         => (float) $r->get_param( 'amount' ),
								'method'         => 'giftcard',
								'description'    => $a['treatment_name'] . ' – ' . $card['code'],
							)
						);
						if ( $r->get_param( 'complete' ) && 'done' !== $a['status'] ) {
							BHC_Repository::save_appointment( array( 'status' => 'done' ), $appt, false );
						}
					}
				}
				break;
			case 'topup':
				$res = self::topup_gift( $id, $r->get_param( 'amount' ), (string) $r->get_param( 'payment_method' ), $note );
				break;
			case 'points_add':
				$res = self::points( $id, abs( (float) $r->get_param( 'amount' ) ), 'accredito', $note, $appt );
				break;
			case 'points_use':
				$pts = abs( (float) $r->get_param( 'amount' ) );
				$s   = self::loyalty_settings();
				/* translators: %s: valore in euro */
				$res = self::points( $id, -$pts, 'utilizzo', trim( sprintf( __( 'Sconto di %s', 'beautyhub-core' ), bhc_price( $pts * (float) $s['point_value'] ) ) . ' ' . $note ), $appt );
				break;
			case 'session':
				$res = self::use_session( $id, absint( $r->get_param( 'item_id' ) ), $appt, $note );
				break;
			case 'add_package':
				$res = self::add_package( $id, (array) $r->get_json_params(), (string) $r->get_param( 'payment_method' ) );
				break;
			case 'undo':
				$res = self::undo_move( $id, absint( $r->get_param( 'move_id' ) ) );
				break;
			default:
				$res = new WP_Error( 'action', __( 'Operazione non valida.', 'beautyhub-core' ) );
		}
		return is_wp_error( $res ) ? self::err( $res ) : self::get( $id );
	}

	public static function rest_packages( WP_REST_Request $r ) {
		return array( 'items' => self::packages( (bool) $r->get_param( 'active' ) ) );
	}

	public static function rest_save_package( WP_REST_Request $r ) {
		$res = self::save_package( (array) $r->get_json_params(), isset( $r['id'] ) ? (int) $r['id'] : 0 );
		return is_wp_error( $res ) ? self::err( $res ) : self::get_package( $res );
	}

	public static function rest_save_settings( WP_REST_Request $r ) {
		$s = self::loyalty_settings();
		foreach ( array( 'points_per_euro', 'point_value', 'min_redeem' ) as $k ) {
			if ( null !== $r->get_param( $k ) ) {
				$s[ $k ] = max( 0, round( (float) str_replace( ',', '.', (string) $r->get_param( $k ) ), 4 ) );
			}
		}
		if ( null !== $r->get_param( 'auto' ) ) {
			$s['auto'] = $r->get_param( 'auto' ) ? 1 : 0;
		}
		update_option( 'bhc_loyalty', $s );
		return $s;
	}

	/* ==================================================================
	 * Dati di esempio
	 * ================================================================ */

	public static function import_demo( array $treatment_ids ) {
		if ( count( $treatment_ids ) < 5 ) {
			return;
		}
		self::save_package( array( 'name' => '10 sedute di pressoterapia', 'description' => 'Paghi 8, ne fai 10', 'items' => array( array( 'treatment_id' => $treatment_ids[4], 'sessions' => 10 ) ), 'price' => 280, 'validity_days' => 365 ) );
		self::save_package( array( 'name' => 'Percorso viso luminoso', 'description' => '3 pulizie + 3 trattamenti idratanti', 'items' => array( array( 'treatment_id' => $treatment_ids[0], 'sessions' => 3 ), array( 'treatment_id' => $treatment_ids[1], 'sessions' => 3 ) ), 'price' => 290, 'validity_days' => 180 ) );
	}
}
