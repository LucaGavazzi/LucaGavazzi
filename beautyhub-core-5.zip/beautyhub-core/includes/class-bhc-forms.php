<?php
/**
 * Schede della cliente: anamnesi viso, anamnesi estetica, scheda massaggi, scheda laser.
 * Compilabili dal personale o dalla cliente su tablet (con firma), stampabili compilate o in bianco.
 * Contengono dati sanitari: visibili solo a chi ha il permesso "Vedere e modificare l'anamnesi".
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Forms {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		dbDelta(
			'CREATE TABLE ' . bhc_table( 'client_forms' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			client_id bigint(20) unsigned NOT NULL DEFAULT 0,
			type varchar(30) NOT NULL DEFAULT '',
			version varchar(10) NOT NULL DEFAULT '1',
			data longtext,
			status varchar(15) NOT NULL DEFAULT 'bozza',
			signature longtext,
			signed_name varchar(190) NOT NULL DEFAULT '',
			signed_at datetime DEFAULT NULL,
			source varchar(10) NOT NULL DEFAULT 'staff',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY client_type (client_id,type)
			) {$c};"
		);
	}

	/* ==================================================================
	 * Modelli
	 * ================================================================ */

	private static function yn( $id, $label, $detail = 'Dettagli' ) {
		return array( 'id' => $id, 'type' => 'yesno', 'label' => $label, 'detail' => $detail );
	}
	private static function tx( $id, $label, $w = 'half' ) {
		return array( 'id' => $id, 'type' => 'text', 'label' => $label, 'w' => $w );
	}
	private static function ta( $id, $label, $w = 'full' ) {
		return array( 'id' => $id, 'type' => 'textarea', 'label' => $label, 'w' => $w );
	}
	private static function photo( $id = 'phototype', $w = 'third' ) {
		return array( 'id' => $id, 'type' => 'radio', 'label' => 'Fototipo da I a VI', 'options' => array( 'I', 'II', 'III', 'IV', 'V', 'VI' ), 'w' => $w );
	}

	/**
	 * Modelli delle schede, ricalcati sulle schede cartacee del centro.
	 * Struttura: pagine › sezioni › campi. Le sezioni "staff" sono a cura dell'operatore
	 * (non compaiono alla cliente in modalità tablet e restano modificabili dopo la firma).
	 * Tipi di campo: text, textarea, number, date, radio, checks, yesno, scale, grid, measures, map.
	 */
	public static function templates() {
		$declaration = 'Confermo che le informazioni riportate corrispondono a quanto da me dichiarato.';
		$consent     = 'Acconsento al trattamento dei miei dati personali, compresi quelli relativi alla salute (art. 9 GDPR), al solo fine di eseguire in sicurezza i trattamenti estetici.';
		$t           = array(
			/* ---------------- Anamnesi viso (2 pagine) ---------------- */
			'viso'     => array(
				'title'       => 'Scheda anamnesi viso',
				'code'        => 'AV',
				'color'       => '#7d8c6f',
				'renew'       => 12,
				'footer'      => 'Uso estetico | Informazioni riferite dal cliente e osservazioni dell’operatore',
				'client'      => array( 'name', 'birth_date', 'phone', 'email' ),
				'declaration' => $declaration,
				'consent'     => $consent,
				'pages'       => array(
					array(
						'subtitle' => 'Dati cliente, informazioni preliminari e analisi estetica',
						'sections' => array(
							array( 'title' => '', 'fields' => array( self::ta( 'reason', 'Motivo della consultazione e risultato desiderato' ) ) ),
							array(
								'title'  => 'Informazioni riferite dal cliente',
								'fields' => array(
									self::ta( 'allergies', 'Allergie, intolleranze o reazioni a cosmetici e trattamenti' ),
									self::ta( 'conditions', 'Condizioni cutanee, patologie, cure o farmaci da segnalare' ),
									self::tx( 'pregnancy', 'Gravidanza / Allattamento, se pertinente' ),
									self::tx( 'recent', 'Trattamenti recenti e data' ),
									self::ta( 'routine', 'Detersione e routine cosmetica', 'half' ),
									self::tx( 'spf', 'Protezione solare / SPF' ),
									self::ta( 'other', 'Note e altre informazioni utili' ),
								),
							),
							array(
								'title'  => 'Analisi estetica e abitudini',
								'staff'  => true,
								'fields' => array(
									self::photo(),
									self::tx( 'skin_type', 'Tipo di pelle', 'third' ),
									self::tx( 'sensitivity', 'Sensibilità cutanea', 'third' ),
									array( 'id' => 'analysis', 'type' => 'checks', 'label' => '', 'cols' => 3, 'options' => array( 'Disidratazione', 'Impurità / Pori dilatati', 'Rossori / Couperose', 'Macchie', 'Rughe / Perdita di tono', 'Contorno occhi' ) ),
								),
							),
						),
						'sign'     => true,
					),
					array(
						'subtitle' => 'Mappa delle zone e piano di trattamento viso',
						'staff'    => true,
						'sections' => array(
							array(
								'title'  => '',
								'staff'  => true,
								'fields' => array(
									array( 'id' => 'map', 'type' => 'map', 'label' => 'Segnare sulle sagome le zone da trattare o da evitare e numerarle da 1 a 6. Sx e Dx indicano i lati del cliente. Riportare gli stessi numeri nella tabella.', 'views' => array( 'face_l' => 'Laterale SX', 'face_f' => 'Frontale', 'face_r' => 'Laterale DX' ) ),
								),
							),
							array(
								'title'  => 'Zone e interventi programmati',
								'staff'  => true,
								'fields' => array(
									array( 'id' => 'zones', 'type' => 'grid', 'label' => '', 'rows' => 6, 'numbered' => true, 'columns' => array( 'Zona e lato', 'Intervento / Tecnica', 'Prodotto / Note' ) ),
									self::ta( 'avoid', 'Zone da evitare / Precauzioni da verificare', 'half' ),
									self::ta( 'sequence', 'Sequenza e frequenza del percorso', 'half' ),
									self::tx( 'operator', 'Operatore / Data' ),
									self::tx( 'consents', 'Riferimento informativa e consensi' ),
								),
							),
						),
					),
				),
			),

			/* ---------------- Anamnesi estetica (7 pagine) ---------------- */
			'estetica' => array(
				'title'       => 'Scheda anamnesi estetica',
				'code'        => 'AE',
				'color'       => '#b0735a',
				'renew'       => 12,
				'footer'      => 'Uso estetico | Informazioni riferite dal cliente e osservazioni dell’operatore',
				'client'      => array( 'last_name', 'first_name', 'address', 'birth', 'phone', 'email' ),
				'declaration' => $declaration,
				'consent'     => $consent,
				'pages'       => array(
					array(
						'subtitle' => 'Dati personali e abitudini',
						'sections' => array(
							array(
								'title'  => 'Dati personali',
								'fields' => array(
									self::tx( 'city', 'Città e CAP' ),
									self::tx( 'job', 'Professione' ),
									self::ta( 'reason', 'Motivo della consultazione e obiettivi del percorso' ),
								),
							),
							array(
								'title'  => 'Abitudini e trattamenti',
								'fields' => array(
									self::tx( 'frequency', 'Frequenza dei trattamenti in istituto' ),
									self::tx( 'done', 'Trattamenti già effettuati' ),
									self::tx( 'shop', 'Dove acquista abitualmente i cosmetici', 'full' ),
									self::tx( 'smoke', 'Fumo / Sigarette al giorno' ),
									self::tx( 'water', 'Acqua bevuta al giorno in litri' ),
									self::tx( 'diet', 'Alimentazione / Eventuale dieta' ),
									self::tx( 'sport', 'Attività fisica / Frequenza' ),
									self::tx( 'digestion', 'Digestione / Funzioni intestinali' ),
									self::tx( 'sleep', 'Sonno e riposo' ),
									self::ta( 'habits', 'Commenti e altre abitudini utili' ),
								),
							),
						),
					),
					array(
						'subtitle' => 'Informazioni personali e stato di salute',
						'intro'    => 'Compilare le voci pertinenti e descrivere i dettagli utili al trattamento. Le informazioni vanno aggiornate in caso di variazioni e prima di nuovi trattamenti.',
						'sections' => array(
							array(
								'title'  => 'Informazioni personali',
								'fields' => array(
									self::tx( 'cycle', 'Ciclo mestruale / Eventuali alterazioni' ),
									self::tx( 'menopause', 'Menopausa / Da quando' ),
									self::tx( 'pregnancy', 'Gravidanza / Allattamento' ),
									self::tx( 'contraceptives', 'Anticoncezionali / Quali' ),
								),
							),
							array(
								'title'  => 'Stato di salute riferito',
								'fields' => array(
									self::yn( 'therapies', 'Cure o terapie in corso' ),
									self::yn( 'drugs', 'Farmaci assunti e frequenza' ),
									self::yn( 'diseases', 'Patologie in corso o pregresse' ),
									self::yn( 'allergies', 'Allergie o intolleranze' ),
									self::yn( 'surgery', 'Interventi chirurgici e data' ),
									self::ta( 'other_health', 'Altre condizioni da segnalare e indicazioni ricevute' ),
								),
							),
						),
						'sign'     => true,
					),
					array(
						'subtitle' => 'Analisi estetica viso',
						'sections' => array(
							array(
								'title'  => 'Osservazioni e caratteristiche',
								'staff'  => true,
								'fields' => array(
									self::photo( 'phototype', 'half' ),
									self::tx( 'face_sensitivity', 'Sensibilità e reattività cutanea' ),
									array( 'id' => 'face_analysis', 'type' => 'checks', 'label' => '', 'cols' => 3, 'options' => array( 'Disidratazione', 'Ispessimento', 'Impurità', 'Pori dilatati', 'Pelle mista', 'Perdita di tono', 'Macchie', 'Rughe', 'Rossori / Couperose', 'Segni di acne', 'Borse / Contorno occhi', 'Altro' ) ),
								),
							),
							array(
								'title'  => 'Abitudini cosmetiche',
								'fields' => array(
									self::tx( 'cleansing_freq', 'Frequenza di detersione' ),
									self::tx( 'cleansing_products', 'Prodotti usati per detergere' ),
									self::tx( 'cleansing_feel', 'Sensazioni dopo la detersione' ),
									self::tx( 'spf', 'Protezione solare / Utilizzo e SPF' ),
									array( 'id' => 'products_used', 'type' => 'checks', 'label' => 'Prodotti utilizzati abitualmente', 'cols' => 3, 'options' => array( 'Crema giorno', 'Crema notte', 'Contorno occhi', 'Siero', 'Maschera', 'Tonico / Lozione' ) ),
									self::ta( 'actives', 'Prodotti e principi attivi riferiti dal cliente' ),
								),
							),
							array(
								'title'  => '',
								'staff'  => true,
								'fields' => array(
									self::ta( 'face_notes', 'Note generali e osservazioni dell’operatore' ),
									self::ta( 'face_plan', 'Percorso viso e trattamenti programmati' ),
								),
							),
						),
					),
					array(
						'subtitle' => 'Analisi estetica corpo e misure',
						'staff'    => true,
						'sections' => array(
							array(
								'title'  => '',
								'staff'  => true,
								'fields' => array(
									array( 'id' => 'height', 'type' => 'number', 'label' => 'Altezza in cm', 'w' => 'third' ),
									array( 'id' => 'weight', 'type' => 'number', 'label' => 'Peso iniziale in kg', 'w' => 'third' ),
									self::tx( 'morphotype', 'Struttura / Morfotipo', 'third' ),
									array( 'id' => 'body_analysis', 'type' => 'checks', 'label' => '', 'cols' => 3, 'options' => array( 'Adiposità localizzata', 'Adiposità diffusa', 'Ritenzione idrica', 'Aspetto della cellulite', 'Rilassamento cutaneo', 'Smagliature', 'Capillari visibili', 'Vene visibili', 'Pesantezza gambe' ) ),
									self::ta( 'body_zones', 'Zone interessate e osservazioni' ),
								),
							),
							array(
								'title'  => 'Misure e controlli nel tempo',
								'staff'  => true,
								'fields' => array(
									array( 'id' => 'measures', 'type' => 'measures', 'label' => 'Circonferenze in cm e peso in kg. Usare gli stessi punti di riferimento nei controlli.', 'rows' => array( 'Vita', 'Fianchi', 'Addome', 'Glutei', 'Coscia destra', 'Coscia sinistra', 'Ginocchio destro', 'Ginocchio sinistro', 'Braccio destro', 'Braccio sinistro', 'Peso kg' ), 'dates' => 4, 'note' => '* Altezza dal suolo o altro riferimento di misurazione, se utilizzato.' ),
									self::ta( 'body_plan', 'Prodotti corpo abituali e percorso programmato' ),
								),
							),
						),
					),
					array(
						'subtitle' => 'Registro trattamenti viso e corpo',
						'staff'    => true,
						'sections' => array(
							array( 'title' => 'Trattamenti viso', 'staff' => true, 'fields' => array( array( 'id' => 'log_face', 'type' => 'grid', 'label' => '', 'rows' => 8, 'grow' => true, 'columns' => array( 'Data', 'Operatore', 'Trattamento', 'Prodotti usati o acquistati' ), 'auto' => array( 'date', 'user' ) ) ) ),
							array( 'title' => 'Trattamenti corpo', 'staff' => true, 'fields' => array( array( 'id' => 'log_body', 'type' => 'grid', 'label' => '', 'rows' => 8, 'grow' => true, 'columns' => array( 'Data', 'Operatore', 'Trattamento', 'Prodotti usati o acquistati' ), 'auto' => array( 'date', 'user' ) ) ) ),
							array(
								'title'  => '',
								'staff'  => true,
								'fields' => array(
									self::ta( 'home_advice', 'Note e indicazioni domiciliari' ),
									self::tx( 'operator', 'Operatore di riferimento' ),
									self::tx( 'consents', 'Riferimento informativa e consensi' ),
								),
							),
						),
					),
					array(
						'subtitle' => 'Mappa viso e collo per la pianificazione del trattamento',
						'staff'    => true,
						'sections' => array(
							array(
								'title'  => '',
								'staff'  => true,
								'fields' => array(
									array( 'id' => 'face_map', 'type' => 'map', 'label' => 'Cerchiare o tratteggiare le aree sulle figure e collegarle alle indicazioni sotto. Lato D e S riferiti al cliente.', 'views' => array( 'face_f' => 'Vista frontale', 'face_r' => 'Profilo' ) ),
									array( 'id' => 'face_zones', 'type' => 'grid', 'label' => '', 'numbered' => true, 'rows' => array( 'Fronte', 'Contorno occhi', 'Guance', 'Periorale', 'Mento / Mandibola', 'Collo / Décolleté' ), 'columns' => array( 'Zona / Lato', 'Intervento previsto', 'Prodotto / Tecnica' ) ),
									self::ta( 'face_sequence', 'Sequenza di intervento e osservazioni' ),
									self::tx( 'face_map_op', 'Operatore / Data' ),
									self::tx( 'face_map_ref', 'Riferimento seduta' ),
								),
							),
						),
					),
					array(
						'subtitle' => 'Mappa corpo per la pianificazione del trattamento',
						'staff'    => true,
						'sections' => array(
							array(
								'title'  => '',
								'staff'  => true,
								'fields' => array(
									array( 'id' => 'body_map', 'type' => 'map', 'label' => 'Segnare aree, estensione e direzione di lavoro; descrivere l’intervento nella tabella. Annotare il lato D o S del cliente.', 'views' => array( 'body_f' => 'Davanti', 'body_b' => 'Dietro', 'body_s' => 'Lato' ) ),
									array( 'id' => 'body_zones_tab', 'type' => 'grid', 'label' => '', 'numbered' => true, 'rows' => array( 'Spalle / Dorso', 'Braccia', 'Addome', 'Fianchi / Glutei', 'Cosce', 'Gambe' ), 'columns' => array( 'Zona / Lato', 'Intervento previsto', 'Prodotto / Tecnica' ) ),
									self::ta( 'body_sequence', 'Sequenza di intervento e osservazioni' ),
									self::tx( 'body_map_op', 'Operatore / Data' ),
									self::tx( 'body_map_ref', 'Riferimento seduta' ),
								),
							),
						),
					),
				),
			),

			/* ---------------- Massaggi (2 pagine) ---------------- */
			'massaggi' => array(
				'title'       => 'Scheda cliente massaggi',
				'code'        => 'SM',
				'color'       => '#8a6fa8',
				'renew'       => 12,
				'footer'      => 'Scheda cliente | Aggiornare le informazioni prima di ogni trattamento.',
				'client'      => array( 'last_name', 'first_name', 'birth_date', 'phone', 'email' ),
				'declaration' => $declaration,
				'consent'     => $consent,
				'pages'       => array(
					array(
						'subtitle' => 'Dati cliente e informazioni preliminari al trattamento',
						'intro'    => 'Per personalizzare il massaggio, segnali le condizioni che potrebbero influire sul trattamento. Indichi Sì o No per ogni voce e aggiunga i dettagli utili. In caso di dubbio, ne parli con l’operatore.',
						'sections' => array(
							array(
								'title'  => 'Informazioni riferite dal cliente',
								'table'  => true,
								'fields' => array(
									self::yn( 'allergies', 'Allergie alimentari o cosmetiche', 'Dettagli o zona interessata' ),
									self::yn( 'intolerances', 'Intolleranze alimentari o cosmetiche', 'Dettagli o zona interessata' ),
									self::yn( 'pregnancy', 'Gravidanza', 'Dettagli o zona interessata' ),
									self::yn( 'breastfeeding', 'Allattamento', 'Dettagli o zona interessata' ),
									self::yn( 'thyroid', 'Ipertiroidismo o ipotiroidismo', 'Dettagli o zona interessata' ),
									self::yn( 'breathing', 'Disturbi della respirazione', 'Dettagli o zona interessata' ),
									self::yn( 'tendons', 'Lesioni tendinee o muscolari', 'Dettagli o zona interessata' ),
									self::yn( 'venous', 'Insufficienza venosa, flebiti, trombosi o varici', 'Dettagli o zona interessata' ),
									self::yn( 'onco5', 'Patologie oncologiche negli ultimi 5 anni', 'Dettagli o zona interessata' ),
									self::yn( 'onco_now', 'Patologie o cure oncologiche in corso', 'Dettagli o zona interessata' ),
									self::yn( 'surgery5', 'Interventi chirurgici negli ultimi 5 anni', 'Dettagli o zona interessata' ),
									self::yn( 'trauma', 'Traumi recenti o loro postumi', 'Dettagli o zona interessata' ),
									self::yn( 'burns', 'Ustioni o ferite aperte', 'Dettagli o zona interessata' ),
									self::yn( 'prosthesis', 'Protesi metalliche', 'Dettagli o zona interessata' ),
									self::yn( 'skin', 'Malattie o infezioni della pelle nelle zone trattate', 'Dettagli o zona interessata' ),
									self::yn( 'cardio', 'Problemi cardiovascolari o pacemaker', 'Dettagli o zona interessata' ),
									self::yn( 'spine', 'Patologie della colonna vertebrale', 'Dettagli o zona interessata' ),
									self::yn( 'other', 'Altre condizioni di salute da segnalare', 'Dettagli o zona interessata' ),
									self::ta( 'drugs', 'Farmaci assunti con continuità e altre informazioni utili' ),
								),
							),
						),
						'sign'     => true,
					),
					array(
						'subtitle' => 'Preferenze e registro dei trattamenti',
						'sections' => array(
							array(
								'title'  => '',
								'fields' => array(
									self::ta( 'goal', 'Obiettivo e preferenze del cliente', 'half' ),
									self::ta( 'avoid', 'Zone da evitare / Indicazioni da verificare', 'half' ),
								),
							),
							array(
								'title'  => '',
								'staff'  => true,
								'fields' => array(
									self::tx( 'consents', 'Riferimento informativa e consensi' ),
									self::tx( 'operator', 'Operatore di riferimento' ),
								),
							),
							array(
								'title'  => 'Registro massaggi',
								'staff'  => true,
								'fields' => array(
									array( 'id' => 'log', 'type' => 'grid', 'label' => '', 'rows' => 8, 'grow' => true, 'numbered' => true, 'columns' => array( 'Data', 'Operatore', 'Tipo di massaggio', 'Durata min', 'Zone / Prodotti', 'Riscontro / Note', 'Info cliente verificate' ), 'auto' => array( 'date', 'user' ), 'check' => 6 ),
								),
							),
						),
					),
				),
			),

			/* ---------------- Laser (2 pagine + verifica preliminare) ---------------- */
			'laser'    => array(
				'title'       => 'Scheda cliente laser',
				'code'        => 'SL',
				'color'       => '#5f6b7a',
				'renew'       => 12,
				'footer'      => 'Scheda operativa | Parametri a cura dell’operatore secondo il protocollo dell’apparecchio.',
				'client'      => array( 'last_name', 'first_name', 'birth_date', 'phone', 'email' ),
				'declaration' => $declaration,
				'consent'     => $consent,
				'pages'       => array(
					array(
						'subtitle' => 'Anagrafica, check-up iniziale e registro sedute',
						'sections' => array(
							array( 'title' => '', 'fields' => array( self::tx( 'job', 'Professione' ) ) ),
							array(
								'title'  => 'Informazioni riferite dal cliente',
								'note'   => 'Sezione aggiunta per la sicurezza del trattamento: verificare prima del check-up.',
								'table'  => true,
								'fields' => array(
									self::yn( 'pregnancy', 'Gravidanza o allattamento', 'Dettagli' ),
									self::yn( 'sun', 'Sole, lampade o autoabbronzanti nelle ultime 4 settimane', 'Dettagli' ),
									self::yn( 'photo_drugs', 'Farmaci fotosensibilizzanti (antibiotici, isotretinoina, iperico…)', 'Quali' ),
									self::yn( 'epilepsy', 'Epilessia', 'Dettagli' ),
									self::yn( 'herpes', 'Herpes o infezioni della pelle', 'Dettagli' ),
									self::yn( 'tattoo', 'Tatuaggi, nei o lesioni nelle zone da trattare', 'Dove' ),
									self::yn( 'devices', 'Pacemaker o dispositivi impiantati', 'Dettagli' ),
									self::yn( 'other', 'Altre condizioni di salute da segnalare', 'Dettagli' ),
								),
							),
							array(
								'title'  => 'Check-up iniziale',
								'staff'  => true,
								'fields' => array(
									self::tx( 'checkup', 'Data check-up / Operatore', 'third' ),
									self::tx( 'device', 'Apparecchio / Modello / Lunghezza d’onda', 'twothird' ),
									self::photo(),
									self::tx( 'hair_color', 'Colore pelo', 'third' ),
									self::tx( 'hair_thick', 'Spessore pelo', 'third' ),
									self::tx( 'areas', 'Zone da trattare' ),
									self::tx( 'test', 'Osservazioni / Riferimento test preliminare' ),
									self::tx( 'package', 'Pagamento / Pacchetto' ),
									self::tx( 'home', 'Prodotti domiciliari / Indicazioni consegnate' ),
								),
							),
						),
						'sign'     => true,
					),
					array(
						'subtitle' => 'Registro delle sedute e aggiornamenti del percorso',
						'staff'    => true,
						'sections' => array(
							array(
								'title'  => 'Registro sedute',
								'staff'  => true,
								'fields' => array(
									array( 'id' => 'sessions', 'type' => 'grid', 'label' => 'Fototipo, pelo e variazioni da annotare nel campo note.', 'rows' => 12, 'grow' => true, 'numbered' => true, 'columns' => array( 'Data', 'Operatore', 'Zona trattata', 'Parametri e unità', 'Esito e note' ), 'auto' => array( 'date', 'user' ) ),
									self::ta( 'final', 'Note finali / Prodotti domiciliari acquistati / Prossimo controllo' ),
								),
							),
						),
					),
				),
			),
		);
		return apply_filters( 'bhc_form_templates', $t );
	}

	/** Tutti i campi di un modello, con l'indicazione se sono del personale. */
	public static function fields( $type ) {
		return self::fields_of( self::templates()[ $type ] );
	}

	/** Campi di un modello qualsiasi (usato anche dai colloqui del personale). */
	public static function fields_of( array $tpl ) {
		$out = array();
		foreach ( $tpl['pages'] as $pg ) {
			foreach ( $pg['sections'] as $sec ) {
				foreach ( $sec['fields'] as $f ) {
					$f['staff'] = ! empty( $sec['staff'] ) || ! empty( $pg['staff'] );
					$out[]      = $f;
				}
			}
		}
		return $out;
	}

	/* ==================================================================
	 * Dati
	 * ================================================================ */

	private static function out( $row, $full = true ) {
		$row['id']        = (int) $row['id'];
		$row['client_id'] = (int) $row['client_id'];
		$row['data']      = $full ? ( json_decode( (string) $row['data'], true ) ?: new stdClass() ) : null;
		$row['signed']    = 'firmata' === $row['status'];
		if ( ! $full ) {
			unset( $row['signature'] );
		}
		$u           = $row['updated_by'] ? get_userdata( (int) $row['updated_by'] ) : ( $row['created_by'] ? get_userdata( (int) $row['created_by'] ) : null );
		$row['user'] = $u ? $u->display_name : '';
		$tpl         = self::templates()[ $row['type'] ] ?? null;
		$row['title'] = $tpl ? $tpl['title'] : $row['type'];
		$row['code']  = ( $tpl ? $tpl['code'] : 'SC' ) . '-' . str_pad( (string) $row['id'], 6, '0', STR_PAD_LEFT );
		$ref          = $row['signed_at'] ? $row['signed_at'] : $row['updated_at'];
		$row['expired'] = $tpl && ! empty( $tpl['renew'] ) && strtotime( $ref ) < strtotime( '-' . (int) $tpl['renew'] . ' months', current_time( 'timestamp' ) );
		return $row;
	}

	public static function get( $id ) {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'client_forms' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		return $r ? self::out( $r ) : null;
	}

	public static function of_client( $client_id ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id, client_id, type, version, status, signed_name, signed_at, source, created_by, updated_by, created_at, updated_at FROM ' . bhc_table( 'client_forms' ) . ' WHERE client_id = %d ORDER BY updated_at DESC, id DESC', $client_id ), ARRAY_A ); // phpcs:ignore
		return array_map(
			function ( $r ) {
				$r['data'] = '';
				return BHC_Forms::out( $r, false );
			},
			$rows
		);
	}

	/** Tiene solo i campi del modello, ripuliti. */
	private static function clean( $type, $data ) {
		return self::clean_data( self::templates()[ $type ], $data );
	}

	/** Ripulisce le risposte secondo i campi di un modello. */
	public static function clean_data( array $tpl, $data ) {
		$out = array();
		foreach ( self::fields_of( $tpl ) as $f ) {
			$id = $f['id'];
			if ( ! is_array( $data ) || ! array_key_exists( $id, $data ) ) {
				continue;
			}
			$v = $data[ $id ];
			switch ( $f['type'] ) {
				case 'checks':
					$out[ $id ] = array_values( array_intersect( array_map( 'strval', (array) $v ), $f['options'] ) );
					break;
				case 'radio':
					$out[ $id ] = in_array( (string) $v, $f['options'], true ) ? (string) $v : '';
					break;
				case 'yesno':
					$v          = (array) $v;
					$out[ $id ] = array(
						'v' => in_array( $v['v'] ?? '', array( 'si', 'no' ), true ) ? $v['v'] : '',
						'd' => sanitize_text_field( (string) ( $v['d'] ?? '' ) ),
					);
					break;
				case 'scale':
					$out[ $id ] = '' === $v || null === $v ? '' : max( (int) $f['min'], min( (int) $f['max'], (int) $v ) );
					break;
				case 'grid':
					$rows = array();
					foreach ( array_slice( (array) $v, 0, 300 ) as $r ) {
						$rows[] = array_slice( array_map( 'sanitize_text_field', array_map( 'strval', (array) $r ) ), 0, count( $f['columns'] ) );
					}
					while ( $rows && implode( '', end( $rows ) ) === '' && ( ! is_array( $f['rows'] ) || count( $rows ) > count( $f['rows'] ) ) ) {
						array_pop( $rows );
					}
					$out[ $id ] = $rows;
					break;
				case 'measures':
					$v          = (array) $v;
					$cells      = array();
					foreach ( array_slice( (array) ( $v['cells'] ?? array() ), 0, count( $f['rows'] ) ) as $r ) {
						$cells[] = array_slice( array_map( 'sanitize_text_field', array_map( 'strval', (array) $r ) ), 0, 1 + (int) $f['dates'] );
					}
					$out[ $id ] = array(
						'dates' => array_slice( array_map( 'sanitize_text_field', array_map( 'strval', (array) ( $v['dates'] ?? array() ) ) ), 0, (int) $f['dates'] ),
						'cells' => $cells,
					);
					break;
				case 'map':
					$marks = array();
					foreach ( array_slice( (array) $v, 0, 120 ) as $mk ) {
						$mk = (array) $mk;
						if ( ! isset( $f['views'][ $mk['v'] ?? '' ] ) ) {
							continue;
						}
						$marks[] = array(
							'v' => $mk['v'],
							'x' => round( max( 0, min( 100, (float) ( $mk['x'] ?? 0 ) ) ), 1 ),
							'y' => round( max( 0, min( 100, (float) ( $mk['y'] ?? 0 ) ) ), 1 ),
							'n' => 'X' === ( $mk['n'] ?? '' ) ? 'X' : (string) max( 1, min( 9, (int) ( $mk['n'] ?? 1 ) ) ),
						);
					}
					$out[ $id ] = $marks;
					break;
				case 'textarea':
					$out[ $id ] = sanitize_textarea_field( (string) $v );
					break;
				case 'consent':
					$out[ $id ] = $v ? 1 : 0;
					break;
				case 'info':
					break;
				case 'sign':
					$sig        = (string) $v;
					$out[ $id ] = ( 0 === strpos( $sig, 'data:image/png;base64,' ) && strlen( $sig ) < 400000 ) ? $sig : '';
					break;
				case 'email':
					$out[ $id ] = sanitize_email( (string) $v );
					break;
				case 'date':
					$out[ $id ] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $v ) ? (string) $v : '';
					break;
				case 'number':
					$out[ $id ] = '' === $v ? '' : (string) round( (float) str_replace( ',', '.', (string) $v ), 2 );
					break;
				default:
					$out[ $id ] = sanitize_text_field( (string) $v );
			}
		}
		if ( isset( $data['_consent'] ) ) {
			$out['_consent'] = $data['_consent'] ? 1 : 0;
		}
		return $out;
	}

	/** Campi del personale (modificabili anche dopo la firma). */
	private static function staff_ids( $type ) {
		$ids = array();
		foreach ( self::fields( $type ) as $f ) {
			if ( $f['staff'] ) {
				$ids[] = $f['id'];
			}
		}
		return $ids;
	}

	public static function save( array $d, $id = 0 ) {
		global $wpdb;
		$now = current_time( 'mysql' );
		if ( $id ) {
			$cur = self::get( $id );
			if ( ! $cur ) {
				return new WP_Error( 'not_found', __( 'Scheda non trovata.', 'beautyhub-core' ) );
			}
			$type  = $cur['type'];
			$clean = self::clean( $type, $d['data'] ?? array() );
			$old   = (array) $cur['data'];
			if ( $cur['signed'] ) {
				// Dopo la firma si aggiornano solo le parti del personale.
				$staff = self::staff_ids( $type );
				foreach ( $clean as $k => $v ) {
					if ( in_array( $k, $staff, true ) ) {
						$old[ $k ] = $v;
					}
				}
				$clean = $old;
			} else {
				$clean = array_merge( $old, $clean );
			}
			$row = array( 'data' => wp_json_encode( $clean ), 'updated_by' => get_current_user_id(), 'updated_at' => $now );
		} else {
			$type      = sanitize_key( $d['type'] ?? '' );
			$client_id = absint( $d['client_id'] ?? 0 );
			if ( ! isset( self::templates()[ $type ] ) ) {
				return new WP_Error( 'type', __( 'Tipo di scheda non valido.', 'beautyhub-core' ) );
			}
			if ( ! $client_id || ! BHC_Repository::get_client( $client_id ) ) {
				return new WP_Error( 'client', __( 'Cliente non trovata.', 'beautyhub-core' ) );
			}
			$row = array(
				'client_id'  => $client_id,
				'type'       => $type,
				'data'       => wp_json_encode( self::clean( $type, $d['data'] ?? array() ) ),
				'status'     => 'bozza',
				'source'     => 'tablet' === ( $d['source'] ?? '' ) ? 'tablet' : 'staff',
				'created_by' => get_current_user_id(),
				'updated_by' => get_current_user_id(),
				'created_at' => $now,
				'updated_at' => $now,
			);
		}
		// Firma della cliente.
		if ( ! empty( $d['signature'] ) && ( ! $id || empty( $cur['signed'] ) ) ) {
			if ( empty( $d['data']['_consent'] ) ) {
				return new WP_Error( 'consent', __( 'Per firmare serve il consenso al trattamento dei dati.', 'beautyhub-core' ) );
			}
			$sig = (string) $d['signature'];
			if ( 0 !== strpos( $sig, 'data:image/png;base64,' ) || strlen( $sig ) > 400000 ) {
				return new WP_Error( 'signature', __( 'Firma non valida.', 'beautyhub-core' ) );
			}
			$row['signature']   = $sig;
			$row['signed_name'] = sanitize_text_field( (string) ( $d['signed_name'] ?? '' ) );
			$row['signed_at']   = $now;
			$row['status']      = 'firmata';
			if ( 'tablet' === ( $d['source'] ?? '' ) ) {
				$row['source'] = 'tablet';
			}
		}
		if ( $id ) {
			$wpdb->update( bhc_table( 'client_forms' ), $row, array( 'id' => (int) $id ) );
			return (int) $id;
		}
		$wpdb->insert( bhc_table( 'client_forms' ), $row );
		return (int) $wpdb->insert_id;
	}

	/* ==================================================================
	 * REST
	 * ================================================================ */

	public static function routes() {
		$ns   = BHC_REST::NS;
		$perm = BHC_Permissions::cb( array( 'health' ) );
		register_rest_route( $ns, '/forms/recent', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_recent' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, '/forms/templates', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_templates' ), 'permission_callback' => $perm ) );
		register_rest_route(
			$ns,
			'/clients/(?P<cid>\d+)/forms',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_list' ), 'permission_callback' => $perm ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_create' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route(
			$ns,
			'/forms/(?P<id>\d+)',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_get' ), 'permission_callback' => $perm ),
				array( 'methods' => 'PUT', 'callback' => array( __CLASS__, 'rest_update' ), 'permission_callback' => $perm ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete' ), 'permission_callback' => $perm ),
			)
		);
	}

	private static function err( $e, $status = 400 ) {
		return new WP_REST_Response( array( 'message' => is_wp_error( $e ) ? $e->get_error_message() : $e ), $status );
	}

	public static function rest_recent() {
		global $wpdb;
		$t    = bhc_table( 'client_forms' );
		$c    = bhc_table( 'clients' );
		$rows = $wpdb->get_results( "SELECT f.id, f.client_id, f.type, f.version, f.status, f.signed_name, f.signed_at, f.source, f.created_by, f.updated_by, f.created_at, f.updated_at, c.first_name, c.last_name FROM {$t} f LEFT JOIN {$c} c ON c.id = f.client_id ORDER BY f.updated_at DESC LIMIT 40", ARRAY_A ); // phpcs:ignore
		$out  = array();
		foreach ( $rows as $r ) {
			$name          = trim( $r['first_name'] . ' ' . $r['last_name'] );
			unset( $r['first_name'], $r['last_name'] );
			$r['data']     = '';
			$o             = self::out( $r, false );
			$o['client']   = $name;
			$out[]         = $o;
		}
		return array( 'items' => $out );
	}

	public static function rest_templates() {
		return self::templates();
	}

	public static function rest_list( WP_REST_Request $r ) {
		return array( 'items' => self::of_client( (int) $r['cid'] ) );
	}

	public static function rest_create( WP_REST_Request $r ) {
		$d              = (array) $r->get_json_params();
		$d['client_id'] = (int) $r['cid'];
		$id             = self::save( $d );
		return is_wp_error( $id ) ? self::err( $id ) : self::get( $id );
	}

	public static function rest_get( WP_REST_Request $r ) {
		$f = self::get( (int) $r['id'] );
		return $f ? $f : self::err( __( 'Scheda non trovata.', 'beautyhub-core' ), 404 );
	}

	public static function rest_update( WP_REST_Request $r ) {
		$id = self::save( (array) $r->get_json_params(), (int) $r['id'] );
		return is_wp_error( $id ) ? self::err( $id ) : self::get( $id );
	}

	public static function rest_delete( WP_REST_Request $r ) {
		global $wpdb;
		$f = self::get( (int) $r['id'] );
		if ( ! $f ) {
			return self::err( __( 'Scheda non trovata.', 'beautyhub-core' ), 404 );
		}
		if ( $f['signed'] && ! BHC_Permissions::can( 'clients_delete' ) ) {
			return self::err( __( 'Una scheda firmata può essere eliminata solo da chi può eliminare le clienti.', 'beautyhub-core' ), 403 );
		}
		$wpdb->delete( bhc_table( 'client_forms' ), array( 'id' => $f['id'] ) );
		return array( 'ok' => true );
	}

	/** Per la cancellazione dei dati della cliente (GDPR). */
	public static function delete_client( $client_id ) {
		global $wpdb;
		$wpdb->delete( bhc_table( 'client_forms' ), array( 'client_id' => (int) $client_id ) );
	}
}
