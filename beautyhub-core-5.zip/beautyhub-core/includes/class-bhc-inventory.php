<?php
/**
 * Magazzino: prodotti, fornitori, fatture di acquisto e movimenti di magazzino.
 * Registrando una fattura fornitore i prodotti vengono caricati a magazzino.
 * Accesso riservato a titolare e manager.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Inventory {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/* ==================================================================
	 * Tabelle
	 * ================================================================ */

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c  = $wpdb->get_charset_collate();
		$su = bhc_table( 'suppliers' );
		$pr = bhc_table( 'products' );
		$mv = bhc_table( 'stock_moves' );
		$in = bhc_table( 'invoices' );
		$li = bhc_table( 'invoice_lines' );

		dbDelta(
			"CREATE TABLE {$su} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			name varchar(190) NOT NULL DEFAULT '',
			vat varchar(20) NOT NULL DEFAULT '',
			tax_code varchar(20) NOT NULL DEFAULT '',
			address varchar(255) NOT NULL DEFAULT '',
			city varchar(100) NOT NULL DEFAULT '',
			zip varchar(10) NOT NULL DEFAULT '',
			province varchar(4) NOT NULL DEFAULT '',
			country varchar(60) NOT NULL DEFAULT 'Italia',
			phone varchar(40) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			pec varchar(190) NOT NULL DEFAULT '',
			sdi_code varchar(10) NOT NULL DEFAULT '',
			website varchar(190) NOT NULL DEFAULT '',
			contact_name varchar(120) NOT NULL DEFAULT '',
			contact_phone varchar(40) NOT NULL DEFAULT '',
			iban varchar(40) NOT NULL DEFAULT '',
			payment_terms varchar(120) NOT NULL DEFAULT '',
			min_order decimal(10,2) NOT NULL DEFAULT 0,
			delivery_days smallint(5) unsigned NOT NULL DEFAULT 0,
			notes text,
			active tinyint(1) NOT NULL DEFAULT 1,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY name (name),
			KEY vat (vat)
			) {$c};"
		);
		dbDelta(
			"CREATE TABLE {$pr} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			ean varchar(20) NOT NULL DEFAULT '',
			sku varchar(60) NOT NULL DEFAULT '',
			name varchar(190) NOT NULL DEFAULT '',
			brand varchar(120) NOT NULL DEFAULT '',
			category varchar(120) NOT NULL DEFAULT '',
			family_id bigint(20) unsigned NOT NULL DEFAULT 0,
			category_id bigint(20) unsigned NOT NULL DEFAULT 0,
			type varchar(20) NOT NULL DEFAULT 'rivendita',
			supplier_id bigint(20) unsigned NOT NULL DEFAULT 0,
			supplier_code varchar(60) NOT NULL DEFAULT '',
			cost_price decimal(10,2) NOT NULL DEFAULT 0,
			sale_price decimal(10,2) NOT NULL DEFAULT 0,
			vat_rate decimal(4,1) NOT NULL DEFAULT 22,
			unit varchar(20) NOT NULL DEFAULT 'pz',
			stock decimal(10,2) NOT NULL DEFAULT 0,
			min_stock decimal(10,2) NOT NULL DEFAULT 0,
			reorder_qty decimal(10,2) NOT NULL DEFAULT 0,
			location varchar(120) NOT NULL DEFAULT '',
			notes text,
			active tinyint(1) NOT NULL DEFAULT 1,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY ean (ean),
			KEY sku (sku),
			KEY supplier_id (supplier_id),
			KEY family_id (family_id),
			KEY category_id (category_id),
			KEY name (name)
			) {$c};"
		);
		dbDelta(
			"CREATE TABLE {$mv} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			qty decimal(10,2) NOT NULL DEFAULT 0,
			reason varchar(20) NOT NULL DEFAULT 'rettifica',
			invoice_id bigint(20) unsigned NOT NULL DEFAULT 0,
			note varchar(255) NOT NULL DEFAULT '',
			stock_after decimal(10,2) NOT NULL DEFAULT 0,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY product_id (product_id),
			KEY invoice_id (invoice_id)
			) {$c};"
		);
		dbDelta(
			"CREATE TABLE {$in} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			supplier_id bigint(20) unsigned NOT NULL DEFAULT 0,
			number varchar(60) NOT NULL DEFAULT '',
			date date NOT NULL,
			due_date date DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'da_pagare',
			paid_date date DEFAULT NULL,
			payment_method varchar(30) NOT NULL DEFAULT '',
			taxable decimal(10,2) NOT NULL DEFAULT 0,
			vat decimal(10,2) NOT NULL DEFAULT 0,
			shipping decimal(10,2) NOT NULL DEFAULT 0,
			total decimal(10,2) NOT NULL DEFAULT 0,
			stock_loaded tinyint(1) NOT NULL DEFAULT 0,
			notes text,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY supplier_id (supplier_id),
			KEY date (date),
			KEY status (status)
			) {$c};"
		);
		dbDelta(
			"CREATE TABLE {$li} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			invoice_id bigint(20) unsigned NOT NULL DEFAULT 0,
			product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			description varchar(255) NOT NULL DEFAULT '',
			qty decimal(10,2) NOT NULL DEFAULT 0,
			unit_price decimal(10,4) NOT NULL DEFAULT 0,
			discount decimal(5,2) NOT NULL DEFAULT 0,
			vat_rate decimal(4,1) NOT NULL DEFAULT 22,
			line_total decimal(10,2) NOT NULL DEFAULT 0,
			position smallint(5) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY invoice_id (invoice_id),
			KEY product_id (product_id)
			) {$c};"
		);
	}

	/* ==================================================================
	 * Utilità
	 * ================================================================ */

	private static function num( $v ) {
		return (float) str_replace( ',', '.', (string) $v );
	}

	private static function date_or_null( $v ) {
		$v = trim( (string) $v );
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : null;
	}

	private static function err( $code, $msg, $status = 400 ) {
		return new WP_REST_Response( array( 'code' => $code, 'message' => $msg ), $status );
	}

	/** Controlla la cifra di controllo di un codice EAN-8 / UPC-A / EAN-13 / GTIN-14. */
	public static function ean_valid( $ean ) {
		if ( ! preg_match( '/^(\d{8}|\d{12}|\d{13}|\d{14})$/', $ean ) ) {
			return false;
		}
		$digits = str_split( $ean );
		$check  = (int) array_pop( $digits );
		$sum    = 0;
		foreach ( array_reverse( $digits ) as $i => $d ) {
			$sum += (int) $d * ( 0 === $i % 2 ? 3 : 1 );
		}
		return ( 10 - $sum % 10 ) % 10 === $check;
	}

	/** Controllo formale della partita IVA italiana (11 cifre con cifra di controllo). */
	public static function vat_valid( $vat ) {
		$vat = preg_replace( '/^IT/i', '', $vat );
		if ( ! preg_match( '/^\d{11}$/', $vat ) ) {
			return false;
		}
		$s = 0;
		for ( $i = 0; $i < 10; $i++ ) {
			$n = (int) $vat[ $i ];
			if ( 1 === $i % 2 ) {
				$n *= 2;
				if ( $n > 9 ) {
					$n -= 9;
				}
			}
			$s += $n;
		}
		return ( 10 - $s % 10 ) % 10 === (int) $vat[10];
	}

	public static function payment_methods() {
		return array(
			'bonifico' => __( 'Bonifico', 'beautyhub-core' ),
			'riba'     => __( 'RiBa', 'beautyhub-core' ),
			'rid'      => __( 'RID / SDD', 'beautyhub-core' ),
			'carta'    => __( 'Carta', 'beautyhub-core' ),
			'contanti' => __( 'Contanti', 'beautyhub-core' ),
			'altro'    => __( 'Altro', 'beautyhub-core' ),
		);
	}

	/* ==================================================================
	 * Fornitori
	 * ================================================================ */

	const SUPPLIER_FIELDS = array( 'name', 'vat', 'tax_code', 'address', 'city', 'zip', 'province', 'country', 'phone', 'email', 'pec', 'sdi_code', 'website', 'contact_name', 'contact_phone', 'iban', 'payment_terms', 'min_order', 'delivery_days', 'notes', 'active' );

	public static function get_supplier( $id ) {
		global $wpdb;
		$t   = bhc_table( 'suppliers' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
		return $row ? self::supplier_out( $row ) : null;
	}

	private static function supplier_out( $row ) {
		global $wpdb;
		$row['id']            = (int) $row['id'];
		$row['active']        = (int) $row['active'];
		$row['min_order']     = (float) $row['min_order'];
		$row['delivery_days'] = (int) $row['delivery_days'];
		$p                    = bhc_table( 'products' );
		$i                    = bhc_table( 'invoices' );
		$row['products']      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p} WHERE supplier_id = %d AND active = 1", $row['id'] ) ); // phpcs:ignore
		$row['invoices']      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$i} WHERE supplier_id = %d", $row['id'] ) ); // phpcs:ignore
		$row['to_pay']        = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(total),0) FROM {$i} WHERE supplier_id = %d AND status = 'da_pagare'", $row['id'] ) ); // phpcs:ignore
		$row['vat_ok']        = '' === $row['vat'] || self::vat_valid( $row['vat'] );
		return $row;
	}

	public static function save_supplier( array $d, $id = 0 ) {
		global $wpdb;
		$row = array();
		foreach ( self::SUPPLIER_FIELDS as $f ) {
			if ( ! array_key_exists( $f, $d ) ) {
				continue;
			}
			$v = $d[ $f ];
			switch ( $f ) {
				case 'email':
				case 'pec':
					$row[ $f ] = sanitize_email( $v );
					break;
				case 'website':
					$row[ $f ] = esc_url_raw( $v );
					break;
				case 'vat':
				case 'tax_code':
				case 'iban':
				case 'sdi_code':
				case 'province':
					$row[ $f ] = strtoupper( preg_replace( '/\s+/', '', sanitize_text_field( $v ) ) );
					break;
				case 'min_order':
					$row[ $f ] = max( 0, round( self::num( $v ), 2 ) );
					break;
				case 'delivery_days':
					$row[ $f ] = absint( $v );
					break;
				case 'active':
					$row[ $f ] = $v ? 1 : 0;
					break;
				case 'notes':
					$row[ $f ] = sanitize_textarea_field( $v );
					break;
				default:
					$row[ $f ] = sanitize_text_field( $v );
			}
		}
		if ( ( ! $id || array_key_exists( 'name', $row ) ) && '' === trim( $row['name'] ?? '' ) ) {
			return new WP_Error( 'name', __( 'Inserisci la ragione sociale del fornitore.', 'beautyhub-core' ) );
		}
		if ( ! empty( $row['vat'] ) ) {
			$t     = bhc_table( 'suppliers' );
			$other = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE vat = %s AND id <> %d LIMIT 1", $row['vat'], $id ) ); // phpcs:ignore
			if ( $other ) {
				return new WP_Error( 'vat_dup', __( 'Esiste già un fornitore con questa partita IVA.', 'beautyhub-core' ) );
			}
		}
		$row['updated_at'] = current_time( 'mysql' );
		if ( $id ) {
			$wpdb->update( bhc_table( 'suppliers' ), $row, array( 'id' => (int) $id ) );
			return (int) $id;
		}
		$row['created_at'] = $row['updated_at'];
		$wpdb->insert( bhc_table( 'suppliers' ), $row );
		return (int) $wpdb->insert_id;
	}

	public static function list_suppliers( $q = '' ) {
		global $wpdb;
		$t = bhc_table( 'suppliers' );
		if ( '' !== trim( $q ) ) {
			$like = '%' . $wpdb->esc_like( trim( $q ) ) . '%';
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE name LIKE %s OR vat LIKE %s OR city LIKE %s OR contact_name LIKE %s OR email LIKE %s ORDER BY active DESC, name", $like, $like, $like, $like, $like ), ARRAY_A ); // phpcs:ignore
		} else {
			$rows = $wpdb->get_results( "SELECT * FROM {$t} ORDER BY active DESC, name", ARRAY_A ); // phpcs:ignore
		}
		return array_map( array( __CLASS__, 'supplier_out' ), $rows );
	}

	/* ==================================================================
	 * Prodotti
	 * ================================================================ */

	const PRODUCT_FIELDS = array( 'ean', 'sku', 'name', 'brand', 'family_id', 'category_id', 'type', 'supplier_id', 'supplier_code', 'cost_price', 'sale_price', 'vat_rate', 'unit', 'min_stock', 'reorder_qty', 'location', 'notes', 'active' );

	private static function product_out( $row ) {
		static $suppliers = array();
		foreach ( array( 'id', 'supplier_id', 'active', 'family_id', 'category_id' ) as $k ) {
			$row[ $k ] = (int) $row[ $k ];
		}
		$names           = BHC_Stock::names();
		$row['family']   = $names['f'][ $row['family_id'] ] ?? '';
		$row['category'] = $names['c'][ $row['category_id'] ] ?? '';
		foreach ( array( 'cost_price', 'sale_price', 'vat_rate', 'stock', 'min_stock', 'reorder_qty' ) as $k ) {
			$row[ $k ] = (float) $row[ $k ];
		}
		$sid = $row['supplier_id'];
		if ( $sid && ! isset( $suppliers[ $sid ] ) ) {
			$s                 = self::get_supplier( $sid );
			$suppliers[ $sid ] = $s ? $s['name'] : '';
		}
		$row['supplier_name'] = $sid ? $suppliers[ $sid ] : '';
		$row['low']           = $row['active'] && $row['min_stock'] > 0 && $row['stock'] <= $row['min_stock'];
		$row['out']           = $row['active'] && $row['stock'] <= 0;
		// Margine sul prezzo di vendita al netto IVA.
		$net                  = $row['vat_rate'] > 0 ? $row['sale_price'] / ( 1 + $row['vat_rate'] / 100 ) : $row['sale_price'];
		$row['margin']        = $net > 0 && $row['cost_price'] > 0 ? round( ( $net - $row['cost_price'] ) / $net * 100, 1 ) : null;
		$row['markup']        = $row['cost_price'] > 0 ? round( $net / $row['cost_price'], 2 ) : null;
		// Quantità suggerita da ordinare: riporta sopra la scorta minima.
		$row['to_order']      = $row['low'] ? max( $row['reorder_qty'], $row['min_stock'] * 2 - $row['stock'], 1 ) : 0;
		$row['ean_ok']        = '' === $row['ean'] || self::ean_valid( $row['ean'] );
		return $row;
	}

	public static function get_product( $id ) {
		global $wpdb;
		$t   = bhc_table( 'products' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
		return $row ? self::product_out( $row ) : null;
	}

	public static function list_products( array $f = array() ) {
		global $wpdb;
		$t     = bhc_table( 'products' );
		$where = array( '1=1' );
		$args  = array();
		if ( ! empty( $f['q'] ) ) {
			$like    = '%' . $wpdb->esc_like( trim( $f['q'] ) ) . '%';
			$where[] = '(name LIKE %s OR ean LIKE %s OR sku LIKE %s OR brand LIKE %s OR supplier_code LIKE %s)';
			array_push( $args, $like, $like, $like, $like, $like );
		}
		if ( ! empty( $f['supplier'] ) ) {
			$where[] = 'supplier_id = %d';
			$args[]  = (int) $f['supplier'];
		}
		if ( ! empty( $f['type'] ) ) {
			$where[] = 'type = %s';
			$args[]  = $f['type'];
		}
		if ( ! empty( $f['category'] ) ) {
			$where[] = 'category_id = %d';
			$args[]  = (int) $f['category'];
		} elseif ( ! empty( $f['family'] ) ) {
			$where[] = 'family_id = %d';
			$args[]  = (int) $f['family'];
		}
		if ( ! empty( $f['location'] ) ) {
			$where[] = 'location = %s';
			$args[]  = $f['location'];
		}
		if ( empty( $f['all'] ) ) {
			$where[] = 'active = 1';
		}
		if ( ! empty( $f['low'] ) ) {
			$where[] = 'min_stock > 0 AND stock <= min_stock';
		}
		$sql  = "SELECT * FROM {$t} WHERE " . implode( ' AND ', $where ) . ' ORDER BY name LIMIT 1000';
		$rows = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		return array_map( array( __CLASS__, 'product_out' ), $rows );
	}

	public static function save_product( array $d, $id = 0 ) {
		global $wpdb;
		$row = array();
		foreach ( self::PRODUCT_FIELDS as $f ) {
			if ( ! array_key_exists( $f, $d ) ) {
				continue;
			}
			$v = $d[ $f ];
			switch ( $f ) {
				case 'ean':
					$row[ $f ] = preg_replace( '/\D/', '', (string) $v );
					break;
				case 'sku':
				case 'supplier_code':
					$row[ $f ] = strtoupper( trim( sanitize_text_field( $v ) ) );
					break;
				case 'type':
					$row[ $f ] = in_array( $v, array( 'rivendita', 'consumo' ), true ) ? $v : 'rivendita';
					break;
				case 'supplier_id':
				case 'family_id':
				case 'category_id':
					$row[ $f ] = absint( $v );
					break;
				case 'cost_price':
				case 'sale_price':
					$row[ $f ] = max( 0, round( self::num( $v ), 2 ) );
					break;
				case 'vat_rate':
					$row[ $f ] = in_array( (float) self::num( $v ), array( 0.0, 4.0, 5.0, 10.0, 22.0 ), true ) ? self::num( $v ) : 22;
					break;
				case 'min_stock':
				case 'reorder_qty':
					$row[ $f ] = max( 0, round( self::num( $v ), 2 ) );
					break;
				case 'active':
					$row[ $f ] = $v ? 1 : 0;
					break;
				case 'notes':
					$row[ $f ] = sanitize_textarea_field( $v );
					break;
				default:
					$row[ $f ] = sanitize_text_field( $v );
			}
		}
		if ( ( ! $id || array_key_exists( 'name', $row ) ) && '' === trim( $row['name'] ?? '' ) ) {
			return new WP_Error( 'name', __( 'Inserisci il nome del prodotto.', 'beautyhub-core' ) );
		}
		if ( array_key_exists( 'family_id', $row ) || array_key_exists( 'category_id', $row ) ) {
			list( $row['family_id'], $row['category_id'] ) = BHC_Stock::normalize_pair( $row['family_id'] ?? 0, $row['category_id'] ?? 0 );
		}
		$t = bhc_table( 'products' );
		if ( ! empty( $row['ean'] ) ) {
			if ( ! preg_match( '/^(\d{8}|\d{12}|\d{13}|\d{14})$/', $row['ean'] ) ) {
				return new WP_Error( 'ean', __( 'Il codice EAN deve avere 8, 12, 13 o 14 cifre.', 'beautyhub-core' ) );
			}
			$other = $wpdb->get_var( $wpdb->prepare( "SELECT name FROM {$t} WHERE ean = %s AND id <> %d LIMIT 1", $row['ean'], $id ) ); // phpcs:ignore
			if ( $other ) {
				/* translators: %s: nome prodotto */
				return new WP_Error( 'ean_dup', sprintf( __( 'Codice EAN già usato da "%s".', 'beautyhub-core' ), $other ) );
			}
		}
		if ( ! empty( $row['sku'] ) ) {
			$other = $wpdb->get_var( $wpdb->prepare( "SELECT name FROM {$t} WHERE sku = %s AND id <> %d LIMIT 1", $row['sku'], $id ) ); // phpcs:ignore
			if ( $other ) {
				/* translators: %s: nome prodotto */
				return new WP_Error( 'sku_dup', sprintf( __( 'Codice interno già usato da "%s".', 'beautyhub-core' ), $other ) );
			}
		}
		if ( ! empty( $row['supplier_id'] ) && ! self::get_supplier( $row['supplier_id'] ) ) {
			return new WP_Error( 'supplier', __( 'Fornitore non valido.', 'beautyhub-core' ) );
		}
		$row['updated_at'] = current_time( 'mysql' );
		if ( $id ) {
			$wpdb->update( $t, $row, array( 'id' => (int) $id ) );
			return (int) $id;
		}
		$row['created_at'] = $row['updated_at'];
		if ( empty( $row['sku'] ) ) {
			$row['sku'] = '';
		}
		$wpdb->insert( $t, $row );
		$new = (int) $wpdb->insert_id;
		// Codice interno automatico se non indicato.
		if ( '' === $row['sku'] ) {
			$wpdb->update( $t, array( 'sku' => sprintf( 'PR%05d', $new ) ), array( 'id' => $new ) );
		}
		// Giacenza iniziale come movimento.
		if ( isset( $d['stock'] ) && self::num( $d['stock'] ) != 0 ) { // phpcs:ignore
			self::move( $new, self::num( $d['stock'] ), 'iniziale', 0, __( 'Giacenza iniziale', 'beautyhub-core' ) );
		}
		return $new;
	}

	/**
	 * Registra un movimento e aggiorna la giacenza.
	 *
	 * @param string $reason iniziale|fattura|storno|vendita|consumo|rettifica|inventario|reso.
	 */
	public static function move( $product_id, $qty, $reason, $invoice_id = 0, $note = '' ) {
		global $wpdb;
		$t = bhc_table( 'products' );
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET stock = stock + %f, updated_at = %s WHERE id = %d", $qty, current_time( 'mysql' ), $product_id ) ); // phpcs:ignore
		$after = (float) $wpdb->get_var( $wpdb->prepare( "SELECT stock FROM {$t} WHERE id = %d", $product_id ) ); // phpcs:ignore
		$wpdb->insert(
			bhc_table( 'stock_moves' ),
			array(
				'product_id'  => (int) $product_id,
				'qty'         => round( $qty, 2 ),
				'reason'      => sanitize_key( $reason ),
				'invoice_id'  => (int) $invoice_id,
				'note'        => sanitize_text_field( $note ),
				'stock_after' => $after,
				'created_by'  => get_current_user_id(),
				'created_at'  => current_time( 'mysql' ),
			)
		);
		return $after;
	}

	public static function moves( $product_id, $limit = 50 ) {
		global $wpdb;
		$m    = bhc_table( 'stock_moves' );
		$i    = bhc_table( 'invoices' );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT m.*, i.number AS invoice_number FROM {$m} m LEFT JOIN {$i} i ON i.id = m.invoice_id WHERE m.product_id = %d ORDER BY m.id DESC LIMIT %d", $product_id, $limit ), ARRAY_A ); // phpcs:ignore
		foreach ( $rows as &$r ) {
			$r['qty']         = (float) $r['qty'];
			$r['stock_after'] = (float) $r['stock_after'];
			$u                = $r['created_by'] ? get_userdata( $r['created_by'] ) : null;
			$r['user']        = $u ? $u->display_name : '';
		}
		return $rows;
	}

	/* ==================================================================
	 * Fatture fornitori
	 * ================================================================ */

	private static function invoice_out( $row, $with_lines = false ) {
		foreach ( array( 'id', 'supplier_id', 'stock_loaded' ) as $k ) {
			$row[ $k ] = (int) $row[ $k ];
		}
		foreach ( array( 'taxable', 'vat', 'shipping', 'total' ) as $k ) {
			$row[ $k ] = (float) $row[ $k ];
		}
		$s                    = $row['supplier_id'] ? self::get_supplier( $row['supplier_id'] ) : null;
		$row['supplier_name'] = $s ? $s['name'] : '';
		$today                = current_time( 'Y-m-d' );
		$row['overdue']       = 'da_pagare' === $row['status'] && $row['due_date'] && $row['due_date'] < $today;
		if ( $with_lines ) {
			global $wpdb;
			$l            = bhc_table( 'invoice_lines' );
			$row['lines'] = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$l} WHERE invoice_id = %d ORDER BY position, id", $row['id'] ), ARRAY_A ); // phpcs:ignore
			foreach ( $row['lines'] as &$line ) {
				foreach ( array( 'qty', 'unit_price', 'discount', 'vat_rate', 'line_total' ) as $k ) {
					$line[ $k ] = (float) $line[ $k ];
				}
				$line['product_id'] = (int) $line['product_id'];
			}
		}
		return $row;
	}

	public static function get_invoice( $id ) {
		global $wpdb;
		$t   = bhc_table( 'invoices' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
		return $row ? self::invoice_out( $row, true ) : null;
	}

	public static function list_invoices( array $f = array() ) {
		global $wpdb;
		$t     = bhc_table( 'invoices' );
		$s     = bhc_table( 'suppliers' );
		$where = array( '1=1' );
		$args  = array();
		if ( ! empty( $f['q'] ) ) {
			$like    = '%' . $wpdb->esc_like( trim( $f['q'] ) ) . '%';
			$where[] = '(i.number LIKE %s OR s.name LIKE %s)';
			array_push( $args, $like, $like );
		}
		if ( ! empty( $f['supplier'] ) ) {
			$where[] = 'i.supplier_id = %d';
			$args[]  = (int) $f['supplier'];
		}
		if ( ! empty( $f['status'] ) && in_array( $f['status'], array( 'da_pagare', 'pagata' ), true ) ) {
			$where[] = 'i.status = %s';
			$args[]  = $f['status'];
		}
		if ( ! empty( $f['year'] ) ) {
			$where[] = 'i.date >= %s AND i.date <= %s';
			array_push( $args, (int) $f['year'] . '-01-01', (int) $f['year'] . '-12-31' );
		}
		$sql  = "SELECT i.* FROM {$t} i LEFT JOIN {$s} s ON s.id = i.supplier_id WHERE " . implode( ' AND ', $where ) . ' ORDER BY i.date DESC, i.id DESC LIMIT 500';
		$rows = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		return array_map( array( __CLASS__, 'invoice_out' ), $rows );
	}

	/** Annulla il carico a magazzino di una fattura (storno dei movimenti). */
	private static function unload_invoice( $invoice_id ) {
		global $wpdb;
		$m     = bhc_table( 'stock_moves' );
		$moves = $wpdb->get_results( $wpdb->prepare( "SELECT product_id, SUM(qty) q FROM {$m} WHERE invoice_id = %d GROUP BY product_id", $invoice_id ), ARRAY_A ); // phpcs:ignore
		foreach ( $moves as $mv ) {
			if ( abs( (float) $mv['q'] ) > 0.0001 ) {
				self::move( (int) $mv['product_id'], -1 * (float) $mv['q'], 'storno', $invoice_id, __( 'Storno carico fattura', 'beautyhub-core' ) );
			}
		}
	}

	/**
	 * Crea / aggiorna una fattura con le righe, ricalcola i totali e (se richiesto)
	 * carica i prodotti a magazzino.
	 */
	public static function save_invoice( array $d, $id = 0 ) {
		global $wpdb;
		$supplier_id = absint( $d['supplier_id'] ?? 0 );
		$number      = trim( sanitize_text_field( $d['number'] ?? '' ) );
		$date        = self::date_or_null( $d['date'] ?? '' );
		if ( ! $supplier_id || ! self::get_supplier( $supplier_id ) ) {
			return new WP_Error( 'supplier', __( 'Scegli il fornitore.', 'beautyhub-core' ) );
		}
		if ( '' === $number ) {
			return new WP_Error( 'number', __( 'Inserisci il numero della fattura.', 'beautyhub-core' ) );
		}
		if ( ! $date ) {
			return new WP_Error( 'date', __( 'Inserisci la data della fattura.', 'beautyhub-core' ) );
		}
		$t   = bhc_table( 'invoices' );
		$year = substr( $date, 0, 4 );
		$dup  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE supplier_id = %d AND number = %s AND date >= %s AND date <= %s AND id <> %d LIMIT 1", $supplier_id, $number, $year . '-01-01', $year . '-12-31', $id ) ); // phpcs:ignore
		if ( $dup ) {
			return new WP_Error( 'dup', __( 'Questa fattura del fornitore è già registrata.', 'beautyhub-core' ) );
		}

		// Righe e totali.
		$lines   = array();
		$taxable = 0;
		$vat     = 0;
		foreach ( (array) ( $d['lines'] ?? array() ) as $i => $l ) {
			$qty  = round( self::num( $l['qty'] ?? 0 ), 2 );
			$desc = sanitize_text_field( $l['description'] ?? '' );
			$pid  = absint( $l['product_id'] ?? 0 );
			if ( $pid && '' === $desc ) {
				$p    = self::get_product( $pid );
				$desc = $p ? $p['name'] : '';
			}
			if ( ! $qty || ( '' === $desc && ! $pid ) ) {
				continue;
			}
			$price    = round( self::num( $l['unit_price'] ?? 0 ), 4 );
			$discount = min( 100, max( 0, round( self::num( $l['discount'] ?? 0 ), 2 ) ) );
			$rate     = self::num( $l['vat_rate'] ?? 22 );
			$total    = round( $qty * $price * ( 1 - $discount / 100 ), 2 );
			$taxable += $total;
			$vat     += $total * $rate / 100;
			$lines[]  = array(
				'product_id'  => $pid,
				'description' => $desc,
				'qty'         => $qty,
				'unit_price'  => $price,
				'discount'    => $discount,
				'vat_rate'    => $rate,
				'line_total'  => $total,
				'position'    => $i,
			);
		}
		if ( ! $lines ) {
			return new WP_Error( 'lines', __( 'Aggiungi almeno una riga alla fattura.', 'beautyhub-core' ) );
		}
		$shipping = max( 0, round( self::num( $d['shipping'] ?? 0 ), 2 ) );
		$vat      = round( $vat + $shipping * 0.22, 2 );
		$taxable  = round( $taxable + $shipping, 2 );
		$status   = 'pagata' === ( $d['status'] ?? '' ) ? 'pagata' : 'da_pagare';
		$load     = ! empty( $d['load_stock'] );
		$methods  = self::payment_methods();

		$row = array(
			'supplier_id'    => $supplier_id,
			'number'         => $number,
			'date'           => $date,
			'due_date'       => self::date_or_null( $d['due_date'] ?? '' ),
			'status'         => $status,
			'paid_date'      => 'pagata' === $status ? ( self::date_or_null( $d['paid_date'] ?? '' ) ?: current_time( 'Y-m-d' ) ) : null,
			'payment_method' => isset( $methods[ $d['payment_method'] ?? '' ] ) ? $d['payment_method'] : '',
			'taxable'        => $taxable,
			'vat'            => $vat,
			'shipping'       => $shipping,
			'total'          => round( $taxable + $vat, 2 ),
			'stock_loaded'   => $load ? 1 : 0,
			'notes'          => sanitize_textarea_field( $d['notes'] ?? '' ),
			'updated_at'     => current_time( 'mysql' ),
		);

		if ( $id ) {
			if ( ! self::get_invoice( $id ) ) {
				return new WP_Error( 'not_found', __( 'Fattura non trovata.', 'beautyhub-core' ) );
			}
			self::unload_invoice( $id );
			$wpdb->update( $t, $row, array( 'id' => (int) $id ) );
		} else {
			$row['created_by'] = get_current_user_id();
			$row['created_at'] = $row['updated_at'];
			$wpdb->insert( $t, $row );
			$id = (int) $wpdb->insert_id;
		}

		$lt = bhc_table( 'invoice_lines' );
		$wpdb->delete( $lt, array( 'invoice_id' => $id ) );
		foreach ( $lines as $l ) {
			$wpdb->insert( $lt, array( 'invoice_id' => $id ) + $l );
			if ( $load && $l['product_id'] ) {
				self::move( $l['product_id'], $l['qty'], 'fattura', $id, sprintf( 'Fatt. %s', $number ) );
				// Aggiorna il prezzo di acquisto all'ultimo costo netto.
				if ( ! empty( $d['update_costs'] ) && $l['unit_price'] > 0 ) {
					$wpdb->update( bhc_table( 'products' ), array( 'cost_price' => round( $l['unit_price'] * ( 1 - $l['discount'] / 100 ), 2 ) ), array( 'id' => $l['product_id'] ) );
				}
			}
		}
		return $id;
	}

	public static function delete_invoice( $id ) {
		global $wpdb;
		self::unload_invoice( $id );
		$wpdb->delete( bhc_table( 'invoice_lines' ), array( 'invoice_id' => (int) $id ) );
		$wpdb->delete( bhc_table( 'invoices' ), array( 'id' => (int) $id ) );
	}

	/* ==================================================================
	 * Riepilogo
	 * ================================================================ */

	public static function summary() {
		global $wpdb;
		$p = bhc_table( 'products' );
		$i = bhc_table( 'invoices' );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array(
			'products'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$p} WHERE active = 1" ),
			'low'         => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$p} WHERE active = 1 AND min_stock > 0 AND stock <= min_stock" ),
			'stock_value' => (float) $wpdb->get_var( "SELECT COALESCE(SUM(stock * cost_price),0) FROM {$p} WHERE active = 1 AND stock > 0" ),
			'sale_value'  => (float) $wpdb->get_var( "SELECT COALESCE(SUM(stock * sale_price),0) FROM {$p} WHERE active = 1 AND stock > 0 AND type = 'rivendita'" ),
			'to_pay'      => (float) $wpdb->get_var( "SELECT COALESCE(SUM(total),0) FROM {$i} WHERE status = 'da_pagare'" ),
			'overdue'     => (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(total),0) FROM {$i} WHERE status = 'da_pagare' AND due_date IS NOT NULL AND due_date < %s", current_time( 'Y-m-d' ) ) ),
			'year_total'  => (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(total),0) FROM {$i} WHERE date >= %s", current_time( 'Y' ) . '-01-01' ) ),
		);
		// phpcs:enable
	}

	/* ==================================================================
	 * REST
	 * ================================================================ */

	public static function routes() {
		$ns   = BHC_REST::NS;
		$perm = BHC_Permissions::cb( array( 'products', 'suppliers', 'invoices' ) );
		$id   = '(?P<id>\d+)';

		register_rest_route( $ns, '/inventory/summary', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'summary' ), 'permission_callback' => $perm ) );

		register_rest_route(
			$ns,
			'/suppliers',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_list_suppliers' ), 'permission_callback' => $perm ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_save_supplier' ), 'permission_callback' => BHC_Permissions::cb( array( 'suppliers' ) ) ),
			)
		);
		register_rest_route(
			$ns,
			'/suppliers/' . $id,
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_get_supplier' ), 'permission_callback' => $perm ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_save_supplier' ), 'permission_callback' => BHC_Permissions::cb( array( 'suppliers' ) ) ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete_supplier' ), 'permission_callback' => BHC_Permissions::cb( array( 'suppliers' ) ) ),
			)
		);

		register_rest_route(
			$ns,
			'/products',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_list_products' ), 'permission_callback' => BHC_Permissions::cb( array( 'products', 'invoices' ) ) ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_save_product' ), 'permission_callback' => BHC_Permissions::cb( array( 'products' ) ) ),
			)
		);
		register_rest_route(
			$ns,
			'/products/' . $id,
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_get_product' ), 'permission_callback' => BHC_Permissions::cb( array( 'products' ) ) ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_save_product' ), 'permission_callback' => BHC_Permissions::cb( array( 'products' ) ) ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete_product' ), 'permission_callback' => BHC_Permissions::cb( array( 'products' ) ) ),
			)
		);
		register_rest_route( $ns, '/products/' . $id . '/stock', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_stock' ), 'permission_callback' => BHC_Permissions::cb( array( 'products' ) ) ) );

		register_rest_route(
			$ns,
			'/invoices',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_list_invoices' ), 'permission_callback' => BHC_Permissions::cb( array( 'invoices' ) ) ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_save_invoice' ), 'permission_callback' => BHC_Permissions::cb( array( 'invoices' ) ) ),
			)
		);
		register_rest_route(
			$ns,
			'/invoices/' . $id,
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_get_invoice' ), 'permission_callback' => BHC_Permissions::cb( array( 'invoices' ) ) ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_save_invoice' ), 'permission_callback' => BHC_Permissions::cb( array( 'invoices' ) ) ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete_invoice' ), 'permission_callback' => BHC_Permissions::cb( array( 'invoices' ) ) ),
			)
		);
		register_rest_route( $ns, '/invoices/' . $id . '/pay', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_pay_invoice' ), 'permission_callback' => BHC_Permissions::cb( array( 'invoices' ) ) ) );
	}

	/* --- Fornitori --- */

	public static function rest_list_suppliers( WP_REST_Request $r ) {
		return array( 'items' => self::list_suppliers( (string) $r->get_param( 'q' ) ) );
	}

	public static function rest_get_supplier( WP_REST_Request $r ) {
		$s = self::get_supplier( (int) $r['id'] );
		if ( ! $s ) {
			return self::err( 'not_found', __( 'Fornitore non trovato.', 'beautyhub-core' ), 404 );
		}
		$s['product_list'] = self::list_products( array( 'supplier' => $s['id'] ) );
		$s['invoice_list'] = self::list_invoices( array( 'supplier' => $s['id'] ) );
		return $s;
	}

	public static function rest_save_supplier( WP_REST_Request $r ) {
		$data = array();
		foreach ( self::SUPPLIER_FIELDS as $f ) {
			if ( null !== $r->get_param( $f ) ) {
				$data[ $f ] = $r->get_param( $f );
			}
		}
		$id  = isset( $r['id'] ) ? (int) $r['id'] : 0;
		$res = self::save_supplier( $data, $id );
		return is_wp_error( $res ) ? self::err( $res->get_error_code(), $res->get_error_message() ) : self::get_supplier( $res );
	}

	public static function rest_delete_supplier( WP_REST_Request $r ) {
		global $wpdb;
		$s = self::get_supplier( (int) $r['id'] );
		if ( ! $s ) {
			return self::err( 'not_found', __( 'Fornitore non trovato.', 'beautyhub-core' ), 404 );
		}
		if ( $s['invoices'] || $s['products'] ) {
			// Con storico: si disattiva soltanto.
			$wpdb->update( bhc_table( 'suppliers' ), array( 'active' => 0 ), array( 'id' => $s['id'] ) );
			return array( 'ok' => true, 'deactivated' => true );
		}
		$wpdb->delete( bhc_table( 'suppliers' ), array( 'id' => $s['id'] ) );
		return array( 'ok' => true );
	}

	/* --- Prodotti --- */

	public static function rest_list_products( WP_REST_Request $r ) {
		return array(
			'items'   => self::list_products(
				array(
					'q'        => (string) $r->get_param( 'q' ),
					'supplier' => absint( $r->get_param( 'supplier' ) ),
					'type'     => (string) $r->get_param( 'type' ),
					'low'      => (bool) $r->get_param( 'low' ),
					'all'      => (bool) $r->get_param( 'all' ),
					'family'   => absint( $r->get_param( 'family' ) ),
					'category' => absint( $r->get_param( 'category' ) ),
					'location' => sanitize_text_field( (string) $r->get_param( 'location' ) ),
				)
			),
			'summary' => self::summary(),
		);
	}

	public static function rest_get_product( WP_REST_Request $r ) {
		$p = self::get_product( (int) $r['id'] );
		if ( ! $p ) {
			return self::err( 'not_found', __( 'Prodotto non trovato.', 'beautyhub-core' ), 404 );
		}
		$p['moves'] = self::moves( $p['id'] );
		return $p;
	}

	public static function rest_save_product( WP_REST_Request $r ) {
		$data = array();
		foreach ( array_merge( self::PRODUCT_FIELDS, array( 'stock' ) ) as $f ) {
			if ( null !== $r->get_param( $f ) ) {
				$data[ $f ] = $r->get_param( $f );
			}
		}
		$id = isset( $r['id'] ) ? (int) $r['id'] : 0;
		if ( $id ) {
			unset( $data['stock'] ); // La giacenza cambia solo con movimenti.
		}
		$res = self::save_product( $data, $id );
		if ( is_wp_error( $res ) ) {
			return self::err( $res->get_error_code(), $res->get_error_message() );
		}
		$p          = self::get_product( $res );
		$p['moves'] = self::moves( $res );
		return $p;
	}

	public static function rest_delete_product( WP_REST_Request $r ) {
		global $wpdb;
		$id   = (int) $r['id'];
		$used = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . bhc_table( 'invoice_lines' ) . ' WHERE product_id = %d', $id ) ); // phpcs:ignore
		if ( $used ) {
			$wpdb->update( bhc_table( 'products' ), array( 'active' => 0 ), array( 'id' => $id ) );
			return array( 'ok' => true, 'deactivated' => true );
		}
		$wpdb->delete( bhc_table( 'products' ), array( 'id' => $id ) );
		$wpdb->delete( bhc_table( 'stock_moves' ), array( 'product_id' => $id ) );
		return array( 'ok' => true );
	}

	/**
	 * Movimento manuale: mode = carico | scarico | inventario (imposta la giacenza contata).
	 */
	public static function rest_stock( WP_REST_Request $r ) {
		$p = self::get_product( (int) $r['id'] );
		if ( ! $p ) {
			return self::err( 'not_found', __( 'Prodotto non trovato.', 'beautyhub-core' ), 404 );
		}
		$mode = (string) $r->get_param( 'mode' );
		$qty  = self::num( $r->get_param( 'qty' ) );
		$note = sanitize_text_field( (string) $r->get_param( 'note' ) );
		if ( 'inventario' === $mode ) {
			if ( $qty < 0 ) {
				return self::err( 'qty', __( 'La quantità contata non può essere negativa.', 'beautyhub-core' ) );
			}
			$delta = $qty - $p['stock'];
			if ( abs( $delta ) > 0.0001 ) {
				self::move( $p['id'], $delta, 'inventario', 0, $note ?: __( 'Conta inventario', 'beautyhub-core' ) );
			}
		} else {
			if ( $qty <= 0 ) {
				return self::err( 'qty', __( 'Inserisci una quantità maggiore di zero.', 'beautyhub-core' ) );
			}
			$reasons = array( 'carico' => 'carico', 'vendita' => 'vendita', 'consumo' => 'consumo', 'reso' => 'reso', 'scarico' => 'rettifica' );
			$reason  = $reasons[ $mode ] ?? 'rettifica';
			$sign    = 'carico' === $mode ? 1 : -1;
			self::move( $p['id'], $sign * $qty, $reason, 0, $note );
		}
		$p          = self::get_product( $p['id'] );
		$p['moves'] = self::moves( $p['id'] );
		return $p;
	}

	/* --- Fatture --- */

	public static function rest_list_invoices( WP_REST_Request $r ) {
		return array(
			'items'   => self::list_invoices(
				array(
					'q'        => (string) $r->get_param( 'q' ),
					'supplier' => absint( $r->get_param( 'supplier' ) ),
					'status'   => (string) $r->get_param( 'status' ),
					'year'     => absint( $r->get_param( 'year' ) ),
				)
			),
			'summary' => self::summary(),
			'methods' => self::payment_methods(),
		);
	}

	public static function rest_get_invoice( WP_REST_Request $r ) {
		$i = self::get_invoice( (int) $r['id'] );
		return $i ? $i : self::err( 'not_found', __( 'Fattura non trovata.', 'beautyhub-core' ), 404 );
	}

	public static function rest_save_invoice( WP_REST_Request $r ) {
		$data = $r->get_json_params();
		$data = is_array( $data ) ? $data : array();
		$id   = isset( $r['id'] ) ? (int) $r['id'] : 0;
		$res  = self::save_invoice( $data, $id );
		return is_wp_error( $res ) ? self::err( $res->get_error_code(), $res->get_error_message() ) : self::get_invoice( $res );
	}

	public static function rest_delete_invoice( WP_REST_Request $r ) {
		if ( ! self::get_invoice( (int) $r['id'] ) ) {
			return self::err( 'not_found', __( 'Fattura non trovata.', 'beautyhub-core' ), 404 );
		}
		self::delete_invoice( (int) $r['id'] );
		return array( 'ok' => true );
	}

	public static function rest_pay_invoice( WP_REST_Request $r ) {
		global $wpdb;
		$i = self::get_invoice( (int) $r['id'] );
		if ( ! $i ) {
			return self::err( 'not_found', __( 'Fattura non trovata.', 'beautyhub-core' ), 404 );
		}
		$paid    = (bool) $r->get_param( 'paid' );
		$methods = self::payment_methods();
		$method  = (string) $r->get_param( 'payment_method' );
		$wpdb->update(
			bhc_table( 'invoices' ),
			array(
				'status'         => $paid ? 'pagata' : 'da_pagare',
				'paid_date'      => $paid ? ( self::date_or_null( $r->get_param( 'paid_date' ) ) ?: current_time( 'Y-m-d' ) ) : null,
				'payment_method' => isset( $methods[ $method ] ) ? $method : $i['payment_method'],
				'updated_at'     => current_time( 'mysql' ),
			),
			array( 'id' => $i['id'] )
		);
		return self::get_invoice( $i['id'] );
	}

	/* ==================================================================
	 * Dati di esempio
	 * ================================================================ */

	public static function import_demo() {
		$s1 = self::save_supplier(
			array(
				'name' => 'Cosmetica Naturale S.r.l. (demo)', 'vat' => '12345678903', 'address' => 'Via delle Rose 12', 'city' => 'Padova', 'zip' => '35100', 'province' => 'PD',
				'phone' => '049 1234567', 'email' => 'ordini@cosmeticanaturale.example', 'sdi_code' => 'M5UXCR1', 'contact_name' => 'Paolo Verdi', 'payment_terms' => 'Bonifico 30 gg data fattura',
				'min_order' => 150, 'delivery_days' => 3,
			)
		);
		$s2 = self::save_supplier(
			array(
				'name' => 'Nail Pro Forniture (demo)', 'city' => 'Milano', 'province' => 'MI', 'email' => 'info@nailpro.example', 'payment_terms' => 'RiBa 60 gg', 'delivery_days' => 5,
			)
		);
		$products = array(
			array( '8001234567897', 'Crema viso idratante 50 ml', 'rivendita', $s1, 12.50, 34.00, 6, 3 ),
			array( '8001234567903', 'Siero vitamina C 30 ml', 'rivendita', $s1, 15.00, 42.00, 2, 3 ),
			array( '8001234567910', 'Olio da massaggio 1 l', 'consumo', $s1, 18.00, 0, 4, 2 ),
			array( '8009876543217', 'Smalto semipermanente base', 'consumo', $s2, 6.80, 0, 10, 5 ),
			array( '8009876543224', 'Lima unghie professionale', 'consumo', $s2, 0.90, 0, 40, 30 ),
		);
		$ids = array();
		foreach ( $products as $p ) {
			$ids[] = self::save_product(
				array( 'ean' => $p[0], 'name' => $p[1], 'type' => $p[2], 'supplier_id' => $p[3], 'cost_price' => $p[4], 'sale_price' => $p[5], 'stock' => $p[6], 'min_stock' => $p[7], 'unit' => 'pz' )
			);
		}
		self::save_invoice(
			array(
				'supplier_id' => $s1, 'number' => '245/' . current_time( 'Y' ), 'date' => gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' -10 days' ) ),
				'due_date'    => gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' +20 days' ) ), 'payment_method' => 'bonifico', 'load_stock' => 0,
				'lines'       => array(
					array( 'product_id' => $ids[0], 'qty' => 6, 'unit_price' => 12.50, 'vat_rate' => 22 ),
					array( 'product_id' => $ids[2], 'qty' => 4, 'unit_price' => 18.00, 'vat_rate' => 22 ),
				),
			)
		);
	}
}
