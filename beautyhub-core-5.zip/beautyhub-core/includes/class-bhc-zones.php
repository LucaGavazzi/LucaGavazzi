<?php
/**
 * Inventario per zone: il magazzino viene diviso in N zone; in ogni zona si legge
 * il codice EAN con la pistola e si inserisce la quantità. La quantità contata di
 * ogni prodotto è la somma delle letture di tutte le zone.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_Zones {

	const MAX_ZONES = 99;

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c  = $wpdb->get_charset_collate();
		$z  = bhc_table( 'inventory_zones' );
		$r  = bhc_table( 'inventory_counts' );
		dbDelta(
			"CREATE TABLE {$z} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			inventory_id bigint(20) unsigned NOT NULL DEFAULT 0,
			number smallint(5) unsigned NOT NULL DEFAULT 1,
			name varchar(120) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'aperta',
			assigned_to varchar(120) NOT NULL DEFAULT '',
			completed_by bigint(20) unsigned NOT NULL DEFAULT 0,
			completed_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY inventory_id (inventory_id)
			) {$c};"
		);
		dbDelta(
			"CREATE TABLE {$r} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			inventory_id bigint(20) unsigned NOT NULL DEFAULT 0,
			zone_id bigint(20) unsigned NOT NULL DEFAULT 0,
			product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			ean varchar(20) NOT NULL DEFAULT '',
			qty decimal(10,2) NOT NULL DEFAULT 0,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY inv_zone (inventory_id,zone_id),
			KEY inv_product (inventory_id,product_id)
			) {$c};"
		);
	}

	/** Crea le zone di un inventario appena creato. */
	public static function create_for( $inventory_id, $count, array $names = array() ) {
		global $wpdb;
		$count = min( self::MAX_ZONES, max( 0, (int) $count ) );
		for ( $i = 1; $i <= $count; $i++ ) {
			$name = isset( $names[ $i - 1 ] ) ? trim( sanitize_text_field( $names[ $i - 1 ] ) ) : '';
			$wpdb->insert(
				bhc_table( 'inventory_zones' ),
				array(
					'inventory_id' => (int) $inventory_id,
					'number'       => $i,
					/* translators: %d: numero zona */
					'name'         => '' !== $name ? $name : sprintf( __( 'Zona %d', 'beautyhub-core' ), $i ),
				)
			);
		}
	}

	public static function has_zones( $inventory_id ) {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . bhc_table( 'inventory_zones' ) . ' WHERE inventory_id = %d', $inventory_id ) ); // phpcs:ignore
	}

	/** Zone con statistiche di lettura. */
	public static function zones( $inventory_id ) {
		global $wpdb;
		$z    = bhc_table( 'inventory_zones' );
		$r    = bhc_table( 'inventory_counts' );
		$rows = $wpdb->get_results( // phpcs:ignore
			$wpdb->prepare(
				"SELECT z.*, COUNT(c.id) n_reads, COALESCE(SUM(c.qty),0) pieces, COUNT(DISTINCT c.product_id) n_products, MAX(c.created_at) last_read
				FROM {$z} z LEFT JOIN {$r} c ON c.zone_id = z.id WHERE z.inventory_id = %d GROUP BY z.id ORDER BY z.number", // phpcs:ignore
				$inventory_id
			),
			ARRAY_A
		);
		foreach ( $rows as &$row ) {
			$row['reads']    = (int) $row['n_reads'];
			$row['products'] = (int) $row['n_products'];
			unset( $row['n_reads'], $row['n_products'] );
			foreach ( array( 'id', 'inventory_id', 'number', 'reads', 'products', 'completed_by' ) as $k ) {
				$row[ $k ] = (int) $row[ $k ];
			}
			$row['pieces'] = (float) $row['pieces'];
			$u             = $row['completed_by'] ? get_userdata( $row['completed_by'] ) : null;
			$row['completed_name'] = $u ? $u->display_name : '';
		}
		return $rows;
	}

	/** Quantità per prodotto e per zona (per il dettaglio nella scheda). */
	public static function breakdown( $inventory_id ) {
		global $wpdb;
		$r   = bhc_table( 'inventory_counts' );
		$out = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT product_id, zone_id, SUM(qty) q FROM {$r} WHERE inventory_id = %d GROUP BY product_id, zone_id", $inventory_id ), ARRAY_A ) as $row ) { // phpcs:ignore
			$out[ (int) $row['product_id'] ][ (int) $row['zone_id'] ] = (float) $row['q'];
		}
		return $out;
	}

	/** Letture di una zona (le più recenti prima). */
	public static function reads( $inventory_id, $zone_id ) {
		global $wpdb;
		$r    = bhc_table( 'inventory_counts' );
		$p    = bhc_table( 'products' );
		$rows = $wpdb->get_results( // phpcs:ignore
			$wpdb->prepare(
				"SELECT c.*, p.name, p.sku, p.unit FROM {$r} c LEFT JOIN {$p} p ON p.id = c.product_id WHERE c.inventory_id = %d AND c.zone_id = %d ORDER BY c.id DESC LIMIT 500", // phpcs:ignore
				$inventory_id,
				$zone_id
			),
			ARRAY_A
		);
		foreach ( $rows as &$row ) {
			$row['id']         = (int) $row['id'];
			$row['product_id'] = (int) $row['product_id'];
			$row['qty']        = (float) $row['qty'];
			$row['time']       = substr( $row['created_at'], 11, 5 );
		}
		return $rows;
	}

	/** Ricalcola la quantità contata di un prodotto come somma delle letture. */
	public static function recompute( $inventory_id, $product_id ) {
		global $wpdb;
		$r    = bhc_table( 'inventory_counts' );
		$stat = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) n, COALESCE(SUM(qty),0) q FROM {$r} WHERE inventory_id = %d AND product_id = %d", $inventory_id, $product_id ), ARRAY_A ); // phpcs:ignore
		$wpdb->update(
			bhc_table( 'inventory_lines' ),
			array(
				'counted'    => (int) $stat['n'] ? round( (float) $stat['q'], 2 ) : null,
				'counted_by' => get_current_user_id(),
				'counted_at' => current_time( 'mysql' ),
			),
			array( 'inventory_id' => (int) $inventory_id, 'product_id' => (int) $product_id )
		);
	}

	private static function open_inventory( $id ) {
		global $wpdb;
		$status = $wpdb->get_var( $wpdb->prepare( 'SELECT status FROM ' . bhc_table( 'inventories' ) . ' WHERE id = %d', $id ) ); // phpcs:ignore
		if ( null === $status ) {
			return new WP_Error( 'not_found', __( 'Inventario non trovato.', 'beautyhub-core' ) );
		}
		if ( 'bozza' !== $status ) {
			return new WP_Error( 'closed', __( 'L\'inventario è chiuso: non si possono più registrare letture.', 'beautyhub-core' ) );
		}
		return true;
	}

	private static function zone( $inventory_id, $zone_id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'inventory_zones' ) . ' WHERE id = %d AND inventory_id = %d', $zone_id, $inventory_id ), ARRAY_A ); // phpcs:ignore
	}

	/** Trova il prodotto da EAN o codice interno (prima nella scheda, poi in anagrafica). */
	public static function find_product( $inventory_id, $code ) {
		global $wpdb;
		$code = trim( (string) $code );
		if ( '' === $code ) {
			return null;
		}
		$p   = bhc_table( 'products' );
		$l   = bhc_table( 'inventory_lines' );
		$ean = preg_replace( '/\D/', '', $code );
		$id  = 0;
		if ( $ean && strlen( $ean ) >= 8 ) {
			$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT p.id FROM {$p} p INNER JOIN {$l} l ON l.product_id = p.id AND l.inventory_id = %d WHERE p.ean = %s LIMIT 1", $inventory_id, $ean ) ); // phpcs:ignore
			if ( ! $id ) {
				$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$p} WHERE ean = %s ORDER BY active DESC LIMIT 1", $ean ) ); // phpcs:ignore
			}
		}
		if ( ! $id ) {
			$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$p} WHERE sku = %s OR supplier_code = %s ORDER BY active DESC LIMIT 1", strtoupper( $code ), strtoupper( $code ) ) ); // phpcs:ignore
		}
		return $id ? BHC_Inventory::get_product( $id ) : null;
	}

	/* ==================================================================
	 * REST
	 * ================================================================ */

	private static function err( WP_Error $e, $status = 400 ) {
		return new WP_REST_Response( array( 'code' => $e->get_error_code(), 'message' => $e->get_error_message() ), $status );
	}

	public static function routes() {
		$ns   = BHC_REST::NS;
		$perm = BHC_Permissions::cb( array( 'products' ) );
		$base = '/inventories/(?P<id>\d+)';
		register_rest_route( $ns, $base . '/lookup', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_lookup' ), 'permission_callback' => $perm ) );
		register_rest_route( $ns, $base . '/zones', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_add_zone' ), 'permission_callback' => $perm ) );
		register_rest_route(
			$ns,
			$base . '/zones/(?P<zid>\d+)',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_zone' ), 'permission_callback' => $perm ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_update_zone' ), 'permission_callback' => $perm ),
			)
		);
		register_rest_route( $ns, $base . '/zones/(?P<zid>\d+)/reads', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_add_read' ), 'permission_callback' => $perm ) );
		register_rest_route(
			$ns,
			$base . '/reads/(?P<rid>\d+)',
			array(
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'rest_update_read' ), 'permission_callback' => $perm ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'rest_delete_read' ), 'permission_callback' => $perm ),
			)
		);
	}

	/** Riepilogo zona: dati, letture, statistiche. */
	private static function zone_payload( $inventory_id, $zone_id, $extra = array() ) {
		$zone = null;
		foreach ( self::zones( $inventory_id ) as $z ) {
			if ( $z['id'] === (int) $zone_id ) {
				$zone = $z;
			}
		}
		return array_merge(
			array(
				'zone'  => $zone,
				'reads' => self::reads( $inventory_id, $zone_id ),
			),
			$extra
		);
	}

	/** Cerca un codice (per mostrare il prodotto prima di inserire la quantità). */
	public static function rest_lookup( WP_REST_Request $r ) {
		global $wpdb;
		$id = (int) $r['id'];
		$p  = self::find_product( $id, (string) $r->get_param( 'code' ) );
		if ( ! $p ) {
			return self::err( new WP_Error( 'unknown', __( 'Codice non trovato in anagrafica prodotti.', 'beautyhub-core' ) ), 404 );
		}
		$l        = bhc_table( 'inventory_lines' );
		$in_sheet = (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$l} WHERE inventory_id = %d AND product_id = %d", $id, $p['id'] ) ); // phpcs:ignore
		$counted  = (float) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(qty),0) FROM ' . bhc_table( 'inventory_counts' ) . ' WHERE inventory_id = %d AND product_id = %d', $id, $p['id'] ) ); // phpcs:ignore
		return array(
			'product'  => array( 'id' => $p['id'], 'name' => $p['name'], 'ean' => $p['ean'], 'sku' => $p['sku'], 'unit' => $p['unit'], 'family' => $p['family'], 'category' => $p['category'], 'location' => $p['location'], 'active' => $p['active'] ),
			'in_sheet' => $in_sheet,
			'counted'  => $counted,
		);
	}

	public static function rest_zone( WP_REST_Request $r ) {
		$id  = (int) $r['id'];
		$zid = (int) $r['zid'];
		if ( ! self::zone( $id, $zid ) ) {
			return self::err( new WP_Error( 'not_found', __( 'Zona non trovata.', 'beautyhub-core' ) ), 404 );
		}
		return self::zone_payload( $id, $zid );
	}

	public static function rest_add_zone( WP_REST_Request $r ) {
		global $wpdb;
		$id   = (int) $r['id'];
		$open = self::open_inventory( $id );
		if ( is_wp_error( $open ) ) {
			return self::err( $open );
		}
		$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(MAX(number),0) FROM ' . bhc_table( 'inventory_zones' ) . ' WHERE inventory_id = %d', $id ) ) + 1; // phpcs:ignore
		if ( $n > self::MAX_ZONES ) {
			return self::err( new WP_Error( 'max', __( 'Numero massimo di zone raggiunto.', 'beautyhub-core' ) ) );
		}
		$name = trim( sanitize_text_field( (string) $r->get_param( 'name' ) ) );
		/* translators: %d: numero zona */
		$wpdb->insert( bhc_table( 'inventory_zones' ), array( 'inventory_id' => $id, 'number' => $n, 'name' => '' !== $name ? $name : sprintf( __( 'Zona %d', 'beautyhub-core' ), $n ) ) );
		return array( 'zones' => self::zones( $id ) );
	}

	public static function rest_update_zone( WP_REST_Request $r ) {
		global $wpdb;
		$id   = (int) $r['id'];
		$zid  = (int) $r['zid'];
		$open = self::open_inventory( $id );
		if ( is_wp_error( $open ) ) {
			return self::err( $open );
		}
		if ( ! self::zone( $id, $zid ) ) {
			return self::err( new WP_Error( 'not_found', __( 'Zona non trovata.', 'beautyhub-core' ) ), 404 );
		}
		$upd = array();
		if ( null !== $r->get_param( 'name' ) && '' !== trim( (string) $r->get_param( 'name' ) ) ) {
			$upd['name'] = sanitize_text_field( (string) $r->get_param( 'name' ) );
		}
		if ( null !== $r->get_param( 'assigned_to' ) ) {
			$upd['assigned_to'] = sanitize_text_field( (string) $r->get_param( 'assigned_to' ) );
		}
		if ( null !== $r->get_param( 'status' ) ) {
			$done                 = 'completata' === $r->get_param( 'status' );
			$upd['status']        = $done ? 'completata' : 'aperta';
			$upd['completed_by']  = $done ? get_current_user_id() : 0;
			$upd['completed_at']  = $done ? current_time( 'mysql' ) : null;
		}
		if ( $upd ) {
			$wpdb->update( bhc_table( 'inventory_zones' ), $upd, array( 'id' => $zid ) );
		}
		return self::zone_payload( $id, $zid, array( 'zones' => self::zones( $id ) ) );
	}

	/**
	 * Registra una lettura: codice (EAN / codice interno) o product_id + quantità.
	 */
	public static function rest_add_read( WP_REST_Request $r ) {
		global $wpdb;
		$id   = (int) $r['id'];
		$zid  = (int) $r['zid'];
		$open = self::open_inventory( $id );
		if ( is_wp_error( $open ) ) {
			return self::err( $open );
		}
		$zone = self::zone( $id, $zid );
		if ( ! $zone ) {
			return self::err( new WP_Error( 'not_found', __( 'Zona non trovata.', 'beautyhub-core' ) ), 404 );
		}
		if ( 'completata' === $zone['status'] ) {
			return self::err( new WP_Error( 'zone_done', __( 'Questa zona è segnata come completata: riaprila per aggiungere letture.', 'beautyhub-core' ) ), 409 );
		}
		$p = $r->get_param( 'product_id' ) ? BHC_Inventory::get_product( absint( $r->get_param( 'product_id' ) ) ) : self::find_product( $id, (string) $r->get_param( 'code' ) );
		if ( ! $p ) {
			return self::err( new WP_Error( 'unknown', __( 'Codice non trovato in anagrafica prodotti.', 'beautyhub-core' ) ), 404 );
		}
		$qty = round( (float) str_replace( ',', '.', (string) $r->get_param( 'qty' ) ), 2 );
		if ( $qty <= 0 || $qty > 99999 ) {
			return self::err( new WP_Error( 'qty', __( 'Inserisci una quantità maggiore di zero.', 'beautyhub-core' ) ) );
		}
		// Prodotto non presente nella scheda: lo aggiunge con la giacenza attuale.
		$l = bhc_table( 'inventory_lines' );
		if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$l} WHERE inventory_id = %d AND product_id = %d", $id, $p['id'] ) ) ) { // phpcs:ignore
			$wpdb->insert( $l, array( 'inventory_id' => $id, 'product_id' => $p['id'], 'expected' => $p['stock'], 'cost_price' => $p['cost_price'] ) );
		}
		$wpdb->insert(
			bhc_table( 'inventory_counts' ),
			array(
				'inventory_id' => $id,
				'zone_id'      => $zid,
				'product_id'   => $p['id'],
				'ean'          => preg_replace( '/\D/', '', (string) $r->get_param( 'code' ) ),
				'qty'          => $qty,
				'created_by'   => get_current_user_id(),
				'created_at'   => current_time( 'mysql' ),
			)
		);
		self::recompute( $id, $p['id'] );
		$total = (float) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(qty),0) FROM ' . bhc_table( 'inventory_counts' ) . ' WHERE inventory_id = %d AND product_id = %d', $id, $p['id'] ) ); // phpcs:ignore
		$zone_total = (float) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(qty),0) FROM ' . bhc_table( 'inventory_counts' ) . ' WHERE inventory_id = %d AND zone_id = %d AND product_id = %d', $id, $zid, $p['id'] ) ); // phpcs:ignore
		return self::zone_payload(
			$id,
			$zid,
			array(
				'last' => array( 'product' => $p['name'], 'unit' => $p['unit'], 'qty' => $qty, 'zone_total' => $zone_total, 'total' => $total ),
			)
		);
	}

	private static function get_read( $id, $rid ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . bhc_table( 'inventory_counts' ) . ' WHERE id = %d AND inventory_id = %d', $rid, $id ), ARRAY_A ); // phpcs:ignore
	}

	public static function rest_update_read( WP_REST_Request $r ) {
		global $wpdb;
		$id   = (int) $r['id'];
		$open = self::open_inventory( $id );
		if ( is_wp_error( $open ) ) {
			return self::err( $open );
		}
		$read = self::get_read( $id, (int) $r['rid'] );
		if ( ! $read ) {
			return self::err( new WP_Error( 'not_found', __( 'Lettura non trovata.', 'beautyhub-core' ) ), 404 );
		}
		$qty = round( (float) str_replace( ',', '.', (string) $r->get_param( 'qty' ) ), 2 );
		if ( $qty <= 0 ) {
			return self::err( new WP_Error( 'qty', __( 'Inserisci una quantità maggiore di zero (o elimina la lettura).', 'beautyhub-core' ) ) );
		}
		$wpdb->update( bhc_table( 'inventory_counts' ), array( 'qty' => $qty ), array( 'id' => (int) $read['id'] ) );
		self::recompute( $id, (int) $read['product_id'] );
		return self::zone_payload( $id, (int) $read['zone_id'] );
	}

	public static function rest_delete_read( WP_REST_Request $r ) {
		global $wpdb;
		$id   = (int) $r['id'];
		$open = self::open_inventory( $id );
		if ( is_wp_error( $open ) ) {
			return self::err( $open );
		}
		$read = self::get_read( $id, (int) $r['rid'] );
		if ( ! $read ) {
			return self::err( new WP_Error( 'not_found', __( 'Lettura non trovata.', 'beautyhub-core' ) ), 404 );
		}
		$wpdb->delete( bhc_table( 'inventory_counts' ), array( 'id' => (int) $read['id'] ) );
		self::recompute( $id, (int) $read['product_id'] );
		return self::zone_payload( $id, (int) $read['zone_id'] );
	}
}
