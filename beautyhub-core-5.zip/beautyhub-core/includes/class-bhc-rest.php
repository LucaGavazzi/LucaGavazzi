<?php
/**
 * API REST (namespace beautyhub/v1) usate dal form di prenotazione
 * e dalla dashboard dello staff.
 *
 * @package BeautyHubCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BHC_REST {

	const NS = 'beautyhub/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	/* Permessi */
	/* Compatibilità: i controlli veri sono in BHC_Permissions. */
	public static function can_view() {
		return BHC_Permissions::can( 'agenda_view' );
	}
	public static function can_edit() {
		return BHC_Permissions::can( 'agenda_edit' );
	}
	public static function can_manage() {
		return BHC_Permissions::is_admin();
	}
	public static function is_staff() {
		return BHC_Permissions::is_staff();
	}

	public static function routes() {
		$id = '(?P<id>\d+)';

		// --- Pubblico ---
		register_rest_route( self::NS, '/public/catalog', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'public_catalog' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NS, '/public/slots', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'public_slots' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NS, '/public/days', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'public_days' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NS, '/public/book', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'public_book' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NS, '/public/cancel', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'public_cancel' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NS, '/me/appointments', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'me_appointments' ), 'permission_callback' => 'is_user_logged_in' ) );

		// --- Staff ---
		register_rest_route( self::NS, '/bootstrap', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'bootstrap' ), 'permission_callback' => array( __CLASS__, 'is_staff' ) ) );
		register_rest_route(
			self::NS,
			'/appointments',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_appointments' ), 'permission_callback' => BHC_Permissions::cb( array( 'agenda_view' ) ) ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'create_appointment' ), 'permission_callback' => BHC_Permissions::cb( array( 'agenda_edit' ) ) ),
			)
		);
		register_rest_route(
			self::NS,
			'/appointments/' . $id,
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get_appointment' ), 'permission_callback' => BHC_Permissions::cb( array( 'agenda_view' ) ) ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'update_appointment' ), 'permission_callback' => BHC_Permissions::cb( array( 'agenda_edit' ) ) ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete_appointment' ), 'permission_callback' => BHC_Permissions::cb( array( 'appt_delete' ) ) ),
			)
		);
		register_rest_route( self::NS, '/appointments/' . $id . '/status', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'set_status' ), 'permission_callback' => BHC_Permissions::cb( array( 'agenda_edit', 'agenda_status' ) ) ) );
		register_rest_route( self::NS, '/appointments/' . $id . '/pay', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'pay' ), 'permission_callback' => BHC_Permissions::cb( array( 'payments' ) ) ) );
		register_rest_route( self::NS, '/slots', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'staff_slots' ), 'permission_callback' => BHC_Permissions::cb( array( 'agenda_view' ) ) ) );

		register_rest_route(
			self::NS,
			'/clients',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_clients' ), 'permission_callback' => BHC_Permissions::cb( array( 'clients_view', 'agenda_edit' ) ) ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'create_client' ), 'permission_callback' => BHC_Permissions::cb( array( 'clients_edit' ) ) ),
			)
		);
		register_rest_route(
			self::NS,
			'/clients/' . $id,
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'get_client' ), 'permission_callback' => BHC_Permissions::cb( array( 'clients_view' ) ) ),
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'update_client' ), 'permission_callback' => BHC_Permissions::cb( array( 'clients_edit', 'clients_notes', 'health' ) ) ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete_client' ), 'permission_callback' => BHC_Permissions::cb( array( 'clients_delete' ) ) ),
			)
		);
		register_rest_route(
			self::NS,
			'/cabins',
			array(
				array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'list_cabins' ), 'permission_callback' => array( __CLASS__, 'is_staff' ) ),
				array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'create_cabin' ), 'permission_callback' => BHC_Permissions::cb( array( 'cabins' ) ) ),
			)
		);
		register_rest_route(
			self::NS,
			'/cabins/' . $id,
			array(
				array( 'methods' => 'PUT,PATCH', 'callback' => array( __CLASS__, 'update_cabin' ), 'permission_callback' => BHC_Permissions::cb( array( 'cabins' ) ) ),
				array( 'methods' => 'DELETE', 'callback' => array( __CLASS__, 'delete_cabin' ), 'permission_callback' => BHC_Permissions::cb( array( 'cabins' ) ) ),
			)
		);
		register_rest_route( self::NS, '/stats', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'stats' ), 'permission_callback' => BHC_Permissions::cb( array( 'reports' ) ) ) );
	}

	/* ------------------------------------------------------------------
	 * Utilità
	 * ---------------------------------------------------------------- */

	private static function valid_date( $d ) {
		return is_string( $d ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) && checkdate( (int) substr( $d, 5, 2 ), (int) substr( $d, 8, 2 ), (int) substr( $d, 0, 4 ) );
	}

	private static function error( $wp_error, $status = 400 ) {
		return new WP_REST_Response( array( 'message' => $wp_error->get_error_message(), 'code' => $wp_error->get_error_code() ), $status );
	}

	private static function client_ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	}

	/**
	 * Limita le richieste per IP (anti-spam semplice).
	 */
	private static function rate_limited( $key, $max, $seconds ) {
		$tkey  = 'bhc_rl_' . md5( $key . self::client_ip() );
		$count = (int) get_transient( $tkey );
		if ( $count >= $max ) {
			return true;
		}
		set_transient( $tkey, $count + 1, $seconds );
		return false;
	}

	/**
	 * Pulisce i dati cliente in base ai permessi (dati sanitari solo a chi può).
	 */
	private static function client_out( $c ) {
		if ( ! $c ) {
			return null;
		}
		$c['id']                = (int) $c['id'];
		$c['marketing_consent'] = (int) $c['marketing_consent'];
		if ( ! BHC_Permissions::can( 'health' ) ) {
			unset( $c['health_notes'] );
		}
		return $c;
	}

	private static function client_input( WP_REST_Request $r ) {
		$data = array();
		foreach ( BHC_Repository::CLIENT_FIELDS as $f ) {
			if ( null !== $r->get_param( $f ) ) {
				$data[ $f ] = $r->get_param( $f );
			}
		}
		unset( $data['user_id'], $data['source'] );
		if ( ! BHC_Permissions::can( 'health' ) ) {
			unset( $data['health_notes'] );
		}
		if ( isset( $data['privacy_consent'] ) ) {
			unset( $data['privacy_consent'] );
		}
		if ( $r->get_param( 'privacy_consent' ) && ! $r->get_param( 'privacy_consent_at' ) ) {
			$data['privacy_consent_at'] = current_time( 'mysql' );
		}
		return $data;
	}

	/* ------------------------------------------------------------------
	 * Pubblico
	 * ---------------------------------------------------------------- */

	public static function public_catalog() {
		$staff = array();
		foreach ( bhc_get_staff() as $s ) {
			$staff[] = array(
				'id'         => $s['id'],
				'name'       => $s['name'],
				'role'       => $s['role'],
				'image'      => $s['image'],
				'treatments' => $s['treatments'],
			);
		}
		$me = null;
		if ( is_user_logged_in() ) {
			$c = BHC_Repository::find_client_by_user( get_current_user_id() );
			$u = wp_get_current_user();
			$me = array(
				'first_name' => $c ? $c['first_name'] : $u->first_name,
				'last_name'  => $c ? $c['last_name'] : $u->last_name,
				'email'      => $c ? $c['email'] : $u->user_email,
				'phone'      => $c ? $c['phone'] : '',
			);
		}
		return array(
			'treatments' => bhc_get_treatments( true ),
			'staff'      => $staff,
			'max_days'   => (int) bhc_get_option( 'max_days', 60 ),
			'note'       => bhc_get_option( 'booking_note' ),
			'privacy'    => bhc_get_option( 'privacy_url' ),
			'me'         => $me,
		);
	}

	public static function public_slots( WP_REST_Request $r ) {
		$date = (string) $r->get_param( 'date' );
		$tid  = absint( $r->get_param( 'treatment' ) );
		$sid  = absint( $r->get_param( 'staff' ) );
		if ( ! self::valid_date( $date ) || ! $tid ) {
			return new WP_REST_Response( array( 'message' => __( 'Parametri non validi.', 'beautyhub-core' ) ), 400 );
		}
		$t = bhc_treatment_data( $tid );
		if ( ! $t || ! $t['online'] ) {
			return new WP_REST_Response( array( 'message' => __( 'Trattamento non prenotabile online.', 'beautyhub-core' ) ), 400 );
		}
		return array( 'date' => $date, 'slots' => array_keys( BHC_Repository::slots( $date, $tid, $sid, true ) ) );
	}

	/**
	 * Giorni con almeno uno slot libero in un mese (per il calendario).
	 */
	public static function public_days( WP_REST_Request $r ) {
		$month = (string) $r->get_param( 'month' );
		$tid   = absint( $r->get_param( 'treatment' ) );
		$sid   = absint( $r->get_param( 'staff' ) );
		if ( ! preg_match( '/^\d{4}-\d{2}$/', $month ) || ! $tid ) {
			return new WP_REST_Response( array( 'message' => __( 'Parametri non validi.', 'beautyhub-core' ) ), 400 );
		}
		$days = array();
		$n    = (int) gmdate( 't', strtotime( $month . '-01' ) );
		for ( $d = 1; $d <= $n; $d++ ) {
			$date = sprintf( '%s-%02d', $month, $d );
			if ( BHC_Repository::slots( $date, $tid, $sid, true ) ) {
				$days[] = $date;
			}
		}
		return array( 'month' => $month, 'days' => $days );
	}

	public static function public_book( WP_REST_Request $r ) {
		// Honeypot anti-bot.
		if ( '' !== (string) $r->get_param( 'website' ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Richiesta non valida.', 'beautyhub-core' ) ), 400 );
		}
		if ( self::rate_limited( 'book', 8, HOUR_IN_SECONDS ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Troppe richieste. Riprova più tardi o chiamaci.', 'beautyhub-core' ) ), 429 );
		}

		$tid   = absint( $r->get_param( 'treatment' ) );
		$sid   = absint( $r->get_param( 'staff' ) );
		$date  = (string) $r->get_param( 'date' );
		$time  = (string) $r->get_param( 'time' );
		$first = sanitize_text_field( (string) $r->get_param( 'first_name' ) );
		$last  = sanitize_text_field( (string) $r->get_param( 'last_name' ) );
		$email = sanitize_email( (string) $r->get_param( 'email' ) );
		$phone = sanitize_text_field( (string) $r->get_param( 'phone' ) );
		$notes = sanitize_textarea_field( (string) $r->get_param( 'notes' ) );

		if ( ! $first || ! $last || ! is_email( $email ) || strlen( preg_replace( '/\D/', '', $phone ) ) < 6 ) {
			return new WP_REST_Response( array( 'message' => __( 'Compila nome, cognome, email e telefono.', 'beautyhub-core' ) ), 400 );
		}
		if ( ! $r->get_param( 'privacy' ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Devi accettare l\'informativa privacy.', 'beautyhub-core' ) ), 400 );
		}
		$t = bhc_treatment_data( $tid );
		if ( ! $t || ! $t['online'] || ! self::valid_date( $date ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Dati della prenotazione non validi.', 'beautyhub-core' ) ), 400 );
		}

		global $wpdb;
		$wpdb->query( "SELECT GET_LOCK('bhc_booking', 10)" ); // Evita doppie prenotazioni simultanee.

		$slots = BHC_Repository::slots( $date, $tid, $sid, true );
		if ( empty( $slots[ $time ] ) ) {
			$wpdb->query( "SELECT RELEASE_LOCK('bhc_booking')" );
			return new WP_REST_Response( array( 'message' => __( 'Questo orario non è più disponibile, scegline un altro.', 'beautyhub-core' ), 'code' => 'slot_taken' ), 409 );
		}

		// Assegna automaticamente la cabina libera con meno appuntamenti quel giorno.
		$candidates = $slots[ $time ];
		if ( $sid ) {
			$staff_id = $sid;
		} else {
			$staff_id = $candidates[0];
			$best     = PHP_INT_MAX;
			foreach ( $candidates as $c ) {
				$n = count( BHC_Repository::busy_intervals( $c, $date ) );
				if ( $n < $best ) {
					$best     = $n;
					$staff_id = $c;
				}
			}
		}

		// Cliente: collega a utente loggato oppure cerca per email.
		$client = is_user_logged_in() ? BHC_Repository::find_client_by_user( get_current_user_id() ) : null;
		if ( ! $client ) {
			$client = BHC_Repository::find_client_by_email( $email );
		}
		$cdata = array(
			'phone'              => $phone,
			'privacy_consent_at' => current_time( 'mysql' ),
		);
		if ( $r->get_param( 'marketing' ) ) {
			$cdata['marketing_consent'] = 1;
		}
		if ( $client ) {
			if ( is_user_logged_in() && ! (int) $client['user_id'] ) {
				$cdata['user_id'] = get_current_user_id();
			}
			$client_id = BHC_Repository::save_client( $cdata, $client['id'] );
		} else {
			$cdata += array(
				'first_name' => $first,
				'last_name'  => $last,
				'email'      => $email,
				'user_id'    => get_current_user_id(),
				'source'     => 'online',
			);
			$client_id = BHC_Repository::save_client( $cdata );
		}
		if ( is_wp_error( $client_id ) ) {
			$wpdb->query( "SELECT RELEASE_LOCK('bhc_booking')" );
			return self::error( $client_id );
		}

		$appt_id = BHC_Repository::save_appointment(
			array(
				'client_id'    => $client_id,
				'treatment_id' => $tid,
				'staff_id'     => $staff_id,
				'date'         => $date,
				'start'        => $time,
				'status'       => (int) bhc_get_option( 'auto_confirm', 0 ) ? 'confirmed' : 'booked',
				'notes'        => $notes,
				'source'       => 'online',
			)
		);
		$wpdb->query( "SELECT RELEASE_LOCK('bhc_booking')" );

		if ( is_wp_error( $appt_id ) ) {
			return self::error( $appt_id, 409 );
		}

		BHC_Emails::booking_created( $appt_id );
		do_action( 'bhc_booking_created', $appt_id );

		$a = BHC_Repository::get_appointment( $appt_id );
		return array(
			'ok'          => true,
			'id'          => $appt_id,
			'status'      => $a['status'],
			'treatment'   => $a['treatment_name'],
			'staff'       => $a['staff_name'],
			'date'        => $a['date'],
			'time'        => $a['start'],
			'manage_url'  => BHC_Emails::manage_url( $appt_id ),
		);
	}

	public static function public_cancel( WP_REST_Request $r ) {
		if ( self::rate_limited( 'cancel', 20, HOUR_IN_SECONDS ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Troppe richieste.', 'beautyhub-core' ) ), 429 );
		}
		$a = BHC_Repository::get_appointment_by_token( (string) $r->get_param( 'token' ) );
		if ( ! $a ) {
			return new WP_REST_Response( array( 'message' => __( 'Prenotazione non trovata.', 'beautyhub-core' ) ), 404 );
		}
		if ( ! in_array( $a['status'], array( 'booked', 'confirmed' ), true ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Questa prenotazione non può più essere annullata.', 'beautyhub-core' ) ), 400 );
		}
		$tz    = wp_timezone();
		$start = new DateTimeImmutable( $a['start_at'], $tz );
		$limit = $start->modify( '-' . (int) bhc_get_option( 'cancel_hours', 24 ) . ' hours' );
		if ( new DateTimeImmutable( 'now', $tz ) > $limit ) {
			/* translators: %s: telefono */
			return new WP_REST_Response( array( 'message' => sprintf( __( 'Mancano meno di %1$d ore: per annullare chiamaci al %2$s.', 'beautyhub-core' ), (int) bhc_get_option( 'cancel_hours', 24 ), bhc_get_option( 'center_phone' ) ) ), 400 );
		}
		BHC_Repository::save_appointment( array( 'status' => 'cancelled' ), $a['id'], false );
		BHC_Emails::booking_cancelled( $a['id'], true );
		do_action( 'bhc_booking_cancelled', $a['id'] );
		return array( 'ok' => true );
	}

	public static function me_appointments() {
		$c = BHC_Repository::find_client_by_user( get_current_user_id() );
		if ( ! $c ) {
			return array( 'items' => array() );
		}
		$items = array();
		foreach ( BHC_Repository::client_appointments( $c['id'], 50 ) as $a ) {
			$items[] = array(
				'id'         => $a['id'],
				'date'       => $a['date'],
				'start'      => $a['start'],
				'treatment'  => $a['treatment_name'],
				'staff'      => $a['staff_name'],
				'status'     => $a['status'],
				'manage_url' => BHC_Emails::manage_url( $a['id'] ),
			);
		}
		return array( 'items' => $items );
	}

	/* ------------------------------------------------------------------
	 * Staff
	 * ---------------------------------------------------------------- */

	public static function bootstrap() {
		$hours = array();
		foreach ( bhc_weekdays() as $n => $l ) {
			$hours[ $n ] = bhc_parse_ranges( bhc_get_option( 'hours_' . $n, '' ) );
		}
		return array(
			'treatments' => bhc_get_treatments(),
			'staff'      => bhc_get_staff(),
			'statuses'   => bhc_statuses(),
			'methods'    => bhc_payment_methods(),
			'hours'      => $hours,
			'closures'   => BHC_Settings::closures(),
			'step'       => (int) bhc_get_option( 'slot_step', 15 ),
			'center'     => bhc_get_option( 'center_name' ),
			'today'      => current_time( 'Y-m-d' ),
			'me'         => array(
				'name'       => wp_get_current_user()->display_name,
				'staff_id'   => 0,
				'perms'      => BHC_Permissions::current_map(),
				'is_admin'   => BHC_Permissions::is_admin(),
			),
			'logout'     => wp_logout_url( home_url( '/' ) ),
			'admin'      => BHC_Permissions::is_admin() ? admin_url( 'admin.php?page=beautyhub' ) : '',
		);
	}

	public static function list_appointments( WP_REST_Request $r ) {
		$from = (string) $r->get_param( 'from' );
		$to   = (string) ( $r->get_param( 'to' ) ?: $from );
		if ( ! self::valid_date( $from ) || ! self::valid_date( $to ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Date non valide.', 'beautyhub-core' ) ), 400 );
		}
		if ( ( strtotime( $to ) - strtotime( $from ) ) > 62 * DAY_IN_SECONDS ) {
			return new WP_REST_Response( array( 'message' => __( 'Intervallo troppo ampio.', 'beautyhub-core' ) ), 400 );
		}
		return array( 'items' => BHC_Repository::get_appointments( $from, $to, absint( $r->get_param( 'staff' ) ) ) );
	}

	public static function get_appointment( WP_REST_Request $r ) {
		$a = BHC_Repository::get_appointment( (int) $r['id'] );
		return $a ? $a : new WP_REST_Response( array( 'message' => __( 'Non trovato.', 'beautyhub-core' ) ), 404 );
	}

	private static function appt_input( WP_REST_Request $r ) {
		$data = array();
		foreach ( array( 'client_id', 'treatment_id', 'staff_id', 'date', 'start', 'duration', 'price', 'status', 'notes', 'operators' ) as $f ) {
			if ( null !== $r->get_param( $f ) ) {
				$data[ $f ] = $r->get_param( $f );
			}
		}
		return $data;
	}

	public static function create_appointment( WP_REST_Request $r ) {
		$data = self::appt_input( $r );
		// Nuova cliente al volo.
		if ( empty( $data['client_id'] ) && $r->get_param( 'new_client' ) ) {
			$nc  = (array) $r->get_param( 'new_client' );
			$cid = BHC_Repository::save_client(
				array(
					'first_name' => $nc['first_name'] ?? '',
					'last_name'  => $nc['last_name'] ?? '',
					'phone'      => $nc['phone'] ?? '',
					'email'      => $nc['email'] ?? '',
				)
			);
			if ( is_wp_error( $cid ) ) {
				return self::error( $cid );
			}
			$data['client_id'] = $cid;
		}
		$data['source'] = 'staff';
		if ( empty( $data['status'] ) ) {
			$data['status'] = 'confirmed';
		}
		$id = BHC_Repository::save_appointment( $data, 0, ! $r->get_param( 'force' ) );
		if ( is_wp_error( $id ) ) {
			// Non lasciare schede cliente orfane se l'appuntamento non è stato creato.
			if ( isset( $cid ) && ! is_wp_error( $cid ) ) {
				BHC_Repository::delete_client( $cid );
			}
			return self::error( $id, in_array( $id->get_error_code(), array( 'conflict', 'operator_conflict' ), true ) ? 409 : 400 );
		}
		return BHC_Repository::get_appointment( $id );
	}

	public static function update_appointment( WP_REST_Request $r ) {
		$id     = (int) $r['id'];
		$before = BHC_Repository::get_appointment( $id );
		$res    = BHC_Repository::save_appointment( self::appt_input( $r ), $id, ! $r->get_param( 'force' ) );
		if ( is_wp_error( $res ) ) {
			return self::error( $res, in_array( $res->get_error_code(), array( 'conflict', 'operator_conflict' ), true ) ? 409 : 400 );
		}
		self::status_side_effects( $before, BHC_Repository::get_appointment( $id ), (bool) $r->get_param( 'notify' ) );
		return BHC_Repository::get_appointment( $id );
	}

	public static function set_status( WP_REST_Request $r ) {
		$id     = (int) $r['id'];
		$status = sanitize_key( (string) $r->get_param( 'status' ) );
		if ( ! array_key_exists( $status, bhc_statuses() ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Stato non valido.', 'beautyhub-core' ) ), 400 );
		}
		// Lo staff senza permesso di modifica possono solo segnare arrivo/completato.
		if ( ! BHC_Permissions::can( 'agenda_edit' ) && ! in_array( $status, array( 'arrived', 'done' ), true ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Permesso negato.', 'beautyhub-core' ) ), 403 );
		}
		$before = BHC_Repository::get_appointment( $id );
		if ( ! $before ) {
			return new WP_REST_Response( array( 'message' => __( 'Non trovato.', 'beautyhub-core' ) ), 404 );
		}
		$res = BHC_Repository::save_appointment( array( 'status' => $status ), $id, 'cancelled' !== $before['status'] ? false : true );
		if ( is_wp_error( $res ) ) {
			return self::error( $res, 409 );
		}
		$after = BHC_Repository::get_appointment( $id );
		self::status_side_effects( $before, $after, (bool) $r->get_param( 'notify' ) );
		return $after;
	}

	/**
	 * Email automatiche quando cambia lo stato.
	 */
	private static function status_side_effects( $before, $after, $notify ) {
		if ( ! $before || ! $after || $before['status'] === $after['status'] || ! $notify ) {
			return;
		}
		if ( 'confirmed' === $after['status'] ) {
			BHC_Emails::booking_confirmed( $after['id'] );
		} elseif ( 'cancelled' === $after['status'] ) {
			BHC_Emails::booking_cancelled( $after['id'], false );
		}
	}

	public static function delete_appointment( WP_REST_Request $r ) {
		BHC_Repository::delete_appointment( (int) $r['id'] );
		return array( 'ok' => true );
	}

	public static function pay( WP_REST_Request $r ) {
		$a = BHC_Repository::get_appointment( (int) $r['id'] );
		if ( ! $a ) {
			return new WP_REST_Response( array( 'message' => __( 'Non trovato.', 'beautyhub-core' ) ), 404 );
		}
		$res = BHC_Repository::add_payment(
			array(
				'appointment_id' => $a['id'],
				'client_id'      => $a['client_id'],
				'amount'         => (float) str_replace( ',', '.', (string) $r->get_param( 'amount' ) ),
				'discount'       => (float) str_replace( ',', '.', (string) $r->get_param( 'discount' ) ),
				'method'         => sanitize_key( (string) $r->get_param( 'method' ) ),
				'description'    => $a['treatment_name'],
			)
		);
		if ( is_wp_error( $res ) ) {
			return self::error( $res );
		}
		if ( $r->get_param( 'complete' ) && 'done' !== $a['status'] ) {
			BHC_Repository::save_appointment( array( 'status' => 'done' ), $a['id'], false );
		}
		return BHC_Repository::get_appointment( $a['id'] );
	}

	public static function staff_slots( WP_REST_Request $r ) {
		$date = (string) $r->get_param( 'date' );
		$tid  = absint( $r->get_param( 'treatment' ) );
		if ( ! self::valid_date( $date ) || ! $tid ) {
			return new WP_REST_Response( array( 'message' => __( 'Parametri non validi.', 'beautyhub-core' ) ), 400 );
		}
		return array( 'slots' => BHC_Repository::slots( $date, $tid, absint( $r->get_param( 'staff' ) ), false ) );
	}

	public static function list_clients( WP_REST_Request $r ) {
		$page  = max( 1, absint( $r->get_param( 'page' ) ) );
		$res   = BHC_Repository::search_clients( (string) $r->get_param( 'q' ), 50, ( $page - 1 ) * 50 );
		$res['items'] = array_map( array( __CLASS__, 'client_out' ), $res['items'] );
		return $res;
	}

	public static function get_client( WP_REST_Request $r ) {
		$c = BHC_Repository::get_client( (int) $r['id'] );
		if ( ! $c ) {
			return new WP_REST_Response( array( 'message' => __( 'Cliente non trovata.', 'beautyhub-core' ) ), 404 );
		}
		$history  = BHC_Repository::client_appointments( $c['id'] );
		$payments = BHC_Repository::client_payments( $c['id'] );
		$spent    = 0;
		foreach ( $payments as $p ) {
			$spent += (float) $p['amount'];
		}
		$visits = 0;
		foreach ( $history as $h ) {
			if ( 'done' === $h['status'] ) {
				$visits++;
			}
		}
		return array(
			'client'   => self::client_out( $c ),
			'history'  => $history,
			'payments' => $payments,
			'summary'  => array(
				'visits' => $visits,
				'spent'  => $spent,
				'noshow' => count( array_filter( $history, function ( $h ) { return 'noshow' === $h['status']; } ) ),
			),
		);
	}

	public static function create_client( WP_REST_Request $r ) {
		$id = BHC_Repository::save_client( self::client_input( $r ) );
		return is_wp_error( $id ) ? self::error( $id ) : self::client_out( BHC_Repository::get_client( $id ) );
	}

	public static function update_client( WP_REST_Request $r ) {
		$data = self::client_input( $r );
		// Senza "modificare le clienti" si possono aggiornare solo note/scheda estetica (e anamnesi se permesso).
		if ( ! BHC_Permissions::can( 'clients_edit' ) ) {
			$allowed = array();
			if ( BHC_Permissions::can( 'clients_notes' ) ) {
				$allowed = array( 'notes', 'skin_type', 'phototype' );
			}
			if ( BHC_Permissions::can( 'health' ) ) {
				$allowed[] = 'health_notes';
			}
			$data = array_intersect_key( $data, array_flip( $allowed ) );
		}
		$id = BHC_Repository::save_client( $data, (int) $r['id'] );
		return is_wp_error( $id ) ? self::error( $id ) : self::client_out( BHC_Repository::get_client( $id ) );
	}

	public static function delete_client( WP_REST_Request $r ) {
		BHC_Repository::delete_client( (int) $r['id'] );
		return array( 'ok' => true );
	}

	/* ------------------------------------------------------------------
	 * Cabine
	 * ---------------------------------------------------------------- */

	private static function cabin_input( WP_REST_Request $r ) {
		$data = array();
		foreach ( array( 'name', 'color', 'hours', 'treatments', 'order' ) as $f ) {
			if ( null !== $r->get_param( $f ) ) {
				$data[ $f ] = $r->get_param( $f );
			}
		}
		if ( isset( $data['hours'] ) && ! is_array( $data['hours'] ) ) {
			$data['hours'] = array();
		}
		if ( isset( $data['treatments'] ) && ! is_array( $data['treatments'] ) ) {
			$data['treatments'] = array();
		}
		return $data;
	}

	public static function list_cabins() {
		return array( 'items' => bhc_get_staff() );
	}

	public static function create_cabin( WP_REST_Request $r ) {
		$id = BHC_Repository::save_cabin( self::cabin_input( $r ) );
		return is_wp_error( $id ) ? self::error( $id ) : bhc_staff_data( $id );
	}

	public static function update_cabin( WP_REST_Request $r ) {
		$data = self::cabin_input( $r );
		if ( ! isset( $data['name'] ) ) {
			$cur          = bhc_staff_data( (int) $r['id'] );
			$data['name'] = $cur ? $cur['name'] : '';
		}
		$id = BHC_Repository::save_cabin( $data, (int) $r['id'] );
		return is_wp_error( $id ) ? self::error( $id ) : bhc_staff_data( $id );
	}

	/**
	 * Elimina (sposta nel cestino) una cabina. Gli appuntamenti futuri restano "senza cabina".
	 */
	public static function delete_cabin( WP_REST_Request $r ) {
		$id = (int) $r['id'];
		if ( ! bhc_staff_data( $id ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Cabina non trovata.', 'beautyhub-core' ) ), 404 );
		}
		global $wpdb;
		$future = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . bhc_table( 'appointments' ) . " WHERE staff_id = %d AND start_at >= %s AND status NOT IN ('cancelled','noshow')", $id, current_time( 'mysql' ) ) ); // phpcs:ignore
		if ( $future && ! $r->get_param( 'force' ) ) {
			/* translators: %d: numero appuntamenti */
			return new WP_REST_Response( array( 'message' => sprintf( _n( 'C\'è %d appuntamento futuro in questa cabina: spostalo prima di eliminarla.', 'Ci sono %d appuntamenti futuri in questa cabina: spostali prima di eliminarla.', $future, 'beautyhub-core' ), $future ), 'code' => 'has_future' ), 409 );
		}
		wp_trash_post( $id );
		return array( 'ok' => true );
	}

	public static function stats( WP_REST_Request $r ) {
		$from = (string) $r->get_param( 'from' );
		$to   = (string) $r->get_param( 'to' );
		if ( ! self::valid_date( $from ) || ! self::valid_date( $to ) ) {
			return new WP_REST_Response( array( 'message' => __( 'Date non valide.', 'beautyhub-core' ) ), 400 );
		}
		return BHC_Repository::stats( $from, $to );
	}
}
