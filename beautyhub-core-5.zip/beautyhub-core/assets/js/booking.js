/* BeautyHub – prenotazione online (vanilla JS, nessuna dipendenza) */
( function () {
	'use strict';

	var cfg = window.BHC || {};

	function esc( s ) {
		return String( s == null ? '' : s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}

	// Compatibile sia con permalink "belli" (/wp-json/...) sia con quelli semplici (?rest_route=...).
	function restUrl( path ) {
		var i = path.indexOf( '?' );
		var base = cfg.rest + ( i === -1 ? path : path.slice( 0, i ) );
		return i === -1 ? base : base + ( base.indexOf( '?' ) === -1 ? '?' : '&' ) + path.slice( i + 1 );
	}

	function api( path, opts ) {
		opts = opts || {};
		var headers = { 'X-WP-Nonce': cfg.nonce };
		if ( opts.body ) {
			headers[ 'Content-Type' ] = 'application/json';
		}
		return fetch( restUrl( path ), {
			method: opts.method || 'GET',
			headers: headers,
			credentials: 'same-origin',
			body: opts.body ? JSON.stringify( opts.body ) : undefined
		} ).then( function ( r ) {
			return r.json().catch( function () {
				return {};
			} ).then( function ( data ) {
				if ( ! r.ok ) {
					var e = new Error( data.message || 'Errore di rete' );
					e.code = data.code;
					throw e;
				}
				return data;
			} );
		} );
	}

	function pad( n ) {
		return ( n < 10 ? '0' : '' ) + n;
	}
	function ymd( d ) {
		return d.getFullYear() + '-' + pad( d.getMonth() + 1 ) + '-' + pad( d.getDate() );
	}
	function euro( v ) {
		return '€ ' + Number( v || 0 ).toLocaleString( 'it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 } );
	}
	function longDate( s ) {
		var p = s.split( '-' );
		return new Date( +p[ 0 ], +p[ 1 ] - 1, +p[ 2 ] ).toLocaleDateString( 'it-IT', { weekday: 'long', day: 'numeric', month: 'long' } );
	}

	var MONTHS = [ 'Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre' ];
	// Passaggi visibili: [passo interno, etichetta]. La cabina viene assegnata in automatico.
	var STEPS = [ [ 0, 'Trattamento' ], [ 2, 'Data e ora' ], [ 3, 'I tuoi dati' ] ];

	function Booking( root ) {
		this.root = root;
		this.app = root.querySelector( '.bhc-booking__app' );
		this.state = {
			step: 0,
			treatment: parseInt( root.dataset.treatment, 10 ) || 0,
			staff: parseInt( root.dataset.staff, 10 ) || 0,
			staffLocked: !! parseInt( root.dataset.staff, 10 ),
			date: '',
			time: '',
			month: null
		};
		this.catalog = null;
		this.load();
	}

	Booking.prototype.load = function () {
		var self = this;
		api( 'public/catalog' ).then( function ( data ) {
			self.catalog = data;
			if ( self.state.treatment && self.treatment() ) {
				self.state.step = 2;
			}
			self.render();
		} ).catch( function ( e ) {
			self.app.innerHTML = '<div class="bhc-pane"><p class="bhc-msg is-error">' + esc( e.message ) + '</p></div>';
		} );
	};

	Booking.prototype.treatment = function () {
		var id = this.state.treatment;
		return ( this.catalog.treatments || [] ).filter( function ( t ) {
			return t.id === id;
		} )[ 0 ];
	};

	Booking.prototype.staffFor = function () {
		var id = this.state.treatment;
		return ( this.catalog.staff || [] ).filter( function ( s ) {
			return ! s.treatments.length || s.treatments.indexOf( id ) !== -1;
		} );
	};

	Booking.prototype.go = function ( step ) {
		this.state.step = step;
		this.render();
		var top = this.root.getBoundingClientRect().top + window.pageYOffset - 100;
		if ( window.pageYOffset > top ) {
			window.scrollTo( { top: top, behavior: 'smooth' } );
		}
	};

	Booking.prototype.render = function () {
		var s = this.state;
		var steps = '<div class="bhc-steps">' + STEPS.map( function ( st, i ) {
			return '<span class="' + ( st[ 0 ] === s.step ? 'is-active' : st[ 0 ] < s.step ? 'is-done' : '' ) + '">' + ( i + 1 ) + '. ' + st[ 1 ] + '</span>';
		} ).join( '' ) + '</div>';
		var html = '';
		if ( s.step === 0 ) {
			html = this.viewTreatments();
		} else if ( s.step === 2 ) {
			html = this.viewDate();
		} else if ( s.step === 3 ) {
			html = this.viewForm();
		}
		this.app.innerHTML = ( s.step < 4 ? steps : '' ) + html;
		this.bind();
		if ( s.step === 2 ) {
			this.loadMonth();
			if ( s.date ) {
				this.loadSlots();
			}
		}
	};

	Booking.prototype.viewTreatments = function () {
		var groups = {};
		var order = [];
		this.catalog.treatments.forEach( function ( t ) {
			var c = t.category || 'Trattamenti';
			if ( ! groups[ c ] ) {
				groups[ c ] = [];
				order.push( c );
			}
			groups[ c ].push( t );
		} );
		if ( ! order.length ) {
			return '<div class="bhc-pane"><p>Nessun trattamento prenotabile online al momento.</p></div>';
		}
		var sel = this.state.treatment;
		return '<div class="bhc-pane"><h3>Scegli il trattamento</h3>' + order.map( function ( c ) {
			return ( order.length > 1 ? '<div class="bhc-cat-title">' + esc( c ) + '</div>' : '' ) + '<div class="bhc-choices">' + groups[ c ].map( function ( t ) {
				return '<button type="button" class="bhc-choice' + ( t.id === sel ? ' is-selected' : '' ) + '" data-treatment="' + t.id + '"><span><strong>' + esc( t.name ) + '</strong><small>' + t.duration + ' min' + ( t.description ? ' · ' + esc( t.description.substring( 0, 90 ) ) : '' ) + '</small></span><span class="bhc-choice__price">' + euro( t.price ) + '</span></button>';
			} ).join( '' ) + '</div>';
		} ).join( '' ) + '</div>';
	};

	Booking.prototype.viewDate = function () {
		var back = 0;
		return '<div class="bhc-pane"><div class="bhc-pane__head"><button type="button" class="bhc-back" data-go="' + back + '">&larr; Indietro</button><span class="bhc-muted">' + esc( this.treatment().name ) + '</span></div>' +
			'<h3>Scegli giorno e ora</h3><div class="bhc-cal" data-cal></div><div data-slots></div></div>';
	};

	Booking.prototype.viewForm = function () {
		var t = this.treatment();
		var me = this.catalog.me || {};
		var privacy = this.catalog.privacy ? '<a href="' + esc( this.catalog.privacy ) + '" target="_blank" rel="noopener">informativa privacy</a>' : 'informativa privacy';
		return '<div class="bhc-pane"><div class="bhc-pane__head"><button type="button" class="bhc-back" data-go="2">&larr; Indietro</button></div>' +
			'<div class="bhc-summary"><strong>' + esc( t.name ) + '</strong> · ' + t.duration + ' min · ' + euro( t.price ) + '<br>' + esc( longDate( this.state.date ) ) + ' alle ' + esc( this.state.time ) + '</div>' +
			'<form data-form novalidate>' +
			'<div class="bhc-row"><div class="bhc-field"><label for="bhc-fn">Nome *</label><input id="bhc-fn" name="first_name" type="text" autocomplete="given-name" required value="' + esc( me.first_name ) + '"></div>' +
			'<div class="bhc-field"><label for="bhc-ln">Cognome *</label><input id="bhc-ln" name="last_name" type="text" autocomplete="family-name" required value="' + esc( me.last_name ) + '"></div></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label for="bhc-em">Email *</label><input id="bhc-em" name="email" type="email" autocomplete="email" required value="' + esc( me.email ) + '"></div>' +
			'<div class="bhc-field"><label for="bhc-ph">Telefono *</label><input id="bhc-ph" name="phone" type="tel" autocomplete="tel" required value="' + esc( me.phone ) + '"></div></div>' +
			'<div class="bhc-field"><label for="bhc-nt">Note per il centro (allergie, richieste…)</label><textarea id="bhc-nt" name="notes" rows="3"></textarea></div>' +
			'<input class="bhc-hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">' +
			'<div class="bhc-field"><label class="bhc-check"><input type="checkbox" name="privacy" required> <span>Ho letto l\'' + privacy + ' e acconsento al trattamento dei dati per gestire la prenotazione *</span></label></div>' +
			'<div class="bhc-field"><label class="bhc-check"><input type="checkbox" name="marketing"> <span>Desidero ricevere promozioni e novità (facoltativo)</span></label></div>' +
			( this.catalog.note ? '<p class="bhc-muted">' + esc( this.catalog.note ) + '</p>' : '' ) +
			'<p class="bhc-msg" data-msg role="alert"></p>' +
			'<button type="submit" class="bhc-btn">Conferma prenotazione</button></form></div>';
	};

	Booking.prototype.bind = function () {
		var self = this;
		this.app.querySelectorAll( '[data-go]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				self.go( parseInt( b.dataset.go, 10 ) );
			} );
		} );
		this.app.querySelectorAll( '[data-treatment]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				self.state.treatment = parseInt( b.dataset.treatment, 10 );
				self.state.date = '';
				self.state.time = '';
				if ( ! self.state.staffLocked ) {
					self.state.staff = 0; // qualsiasi cabina libera
				}
				self.state.month = null;
				self.go( 2 );
			} );
		} );
		var form = this.app.querySelector( '[data-form]' );
		if ( form ) {
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				self.submit( form );
			} );
		}
	};

	Booking.prototype.loadMonth = function () {
		var self = this;
		var box = this.app.querySelector( '[data-cal]' );
		if ( ! box ) {
			return;
		}
		var today = new Date();
		today.setHours( 0, 0, 0, 0 );
		if ( ! this.state.month ) {
			this.state.month = this.state.date ? new Date( this.state.date + 'T12:00:00' ) : new Date( today );
			this.state.month.setDate( 1 );
		}
		var m = this.state.month;
		var max = new Date( today );
		max.setDate( max.getDate() + ( this.catalog.max_days || 60 ) );
		var monthKey = m.getFullYear() + '-' + pad( m.getMonth() + 1 );

		var first = new Date( m.getFullYear(), m.getMonth(), 1 );
		var offset = ( first.getDay() + 6 ) % 7;
		var days = new Date( m.getFullYear(), m.getMonth() + 1, 0 ).getDate();
		var prevDisabled = m.getFullYear() === today.getFullYear() && m.getMonth() === today.getMonth();
		var nextDisabled = new Date( m.getFullYear(), m.getMonth() + 1, 1 ) > max;

		var html = '<div class="bhc-cal__head"><button type="button" data-prev ' + ( prevDisabled ? 'disabled' : '' ) + ' aria-label="Mese precedente">&lsaquo;</button><strong>' + MONTHS[ m.getMonth() ] + ' ' + m.getFullYear() + '</strong><button type="button" data-next ' + ( nextDisabled ? 'disabled' : '' ) + ' aria-label="Mese successivo">&rsaquo;</button></div><div class="bhc-cal__grid">';
		[ 'Lu', 'Ma', 'Me', 'Gi', 'Ve', 'Sa', 'Do' ].forEach( function ( d ) {
			html += '<div class="bhc-cal__dow">' + d + '</div>';
		} );
		for ( var i = 0; i < offset; i++ ) {
			html += '<div></div>';
		}
		for ( var d = 1; d <= days; d++ ) {
			var key = monthKey + '-' + pad( d );
			html += '<button type="button" class="bhc-cal__day' + ( key === this.state.date ? ' is-selected' : '' ) + '" data-day="' + key + '" disabled>' + d + '</button>';
		}
		box.innerHTML = html + '</div><p class="bhc-muted" data-cal-msg>Cerco i giorni disponibili…</p>';

		box.querySelector( '[data-prev]' ).addEventListener( 'click', function () {
			self.state.month = new Date( m.getFullYear(), m.getMonth() - 1, 1 );
			self.loadMonth();
		} );
		box.querySelector( '[data-next]' ).addEventListener( 'click', function () {
			self.state.month = new Date( m.getFullYear(), m.getMonth() + 1, 1 );
			self.loadMonth();
		} );

		api( 'public/days?month=' + monthKey + '&treatment=' + this.state.treatment + '&staff=' + this.state.staff ).then( function ( data ) {
			if ( self.state.month !== m ) {
				return;
			}
			var msg = box.querySelector( '[data-cal-msg]' );
			msg.textContent = data.days.length ? '' : 'Nessuna disponibilità in questo mese: prova il mese successivo.';
			data.days.forEach( function ( day ) {
				var b = box.querySelector( '[data-day="' + day + '"]' );
				if ( b ) {
					b.disabled = false;
					b.classList.add( 'is-available' );
					b.addEventListener( 'click', function () {
						self.state.date = day;
						self.state.time = '';
						box.querySelectorAll( '.bhc-cal__day' ).forEach( function ( x ) {
							x.classList.toggle( 'is-selected', x === b );
						} );
						self.loadSlots();
					} );
				}
			} );
		} ).catch( function ( e ) {
			box.querySelector( '[data-cal-msg]' ).textContent = e.message;
		} );
	};

	Booking.prototype.loadSlots = function () {
		var self = this;
		var box = this.app.querySelector( '[data-slots]' );
		box.innerHTML = '<p class="bhc-muted">Carico gli orari…</p>';
		api( 'public/slots?date=' + this.state.date + '&treatment=' + this.state.treatment + '&staff=' + this.state.staff ).then( function ( data ) {
			if ( ! data.slots.length ) {
				box.innerHTML = '<p class="bhc-muted">Nessun orario libero in questa data.</p>';
				return;
			}
			box.innerHTML = '<h4 style="margin-top:20px">' + esc( longDate( self.state.date ) ) + '</h4><div class="bhc-slots">' + data.slots.map( function ( t ) {
				return '<button type="button" class="bhc-slot" data-time="' + t + '">' + t + '</button>';
			} ).join( '' ) + '</div>';
			box.querySelectorAll( '[data-time]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					self.state.time = b.dataset.time;
					self.go( 3 );
				} );
			} );
		} ).catch( function ( e ) {
			box.innerHTML = '<p class="bhc-msg is-error">' + esc( e.message ) + '</p>';
		} );
	};

	Booking.prototype.submit = function ( form ) {
		var self = this;
		var msg = form.querySelector( '[data-msg]' );
		var btn = form.querySelector( 'button[type=submit]' );
		var f = form.elements;
		msg.className = 'bhc-msg';
		msg.textContent = '';
		if ( ! f.first_name.value.trim() || ! f.last_name.value.trim() || ! f.email.value.trim() || ! f.phone.value.trim() ) {
			msg.className = 'bhc-msg is-error';
			msg.textContent = 'Compila tutti i campi obbligatori.';
			return;
		}
		if ( ! f.privacy.checked ) {
			msg.className = 'bhc-msg is-error';
			msg.textContent = 'Per prenotare devi accettare l\'informativa privacy.';
			return;
		}
		btn.disabled = true;
		btn.textContent = 'Invio in corso…';
		api( 'public/book', {
			method: 'POST',
			body: {
				treatment: this.state.treatment,
				staff: this.state.staff,
				date: this.state.date,
				time: this.state.time,
				first_name: f.first_name.value,
				last_name: f.last_name.value,
				email: f.email.value,
				phone: f.phone.value,
				notes: f.notes.value,
				privacy: f.privacy.checked ? 1 : 0,
				marketing: f.marketing.checked ? 1 : 0,
				website: f.website.value
			}
		} ).then( function ( res ) {
			self.state.step = 4;
			var confirmed = res.status === 'confirmed';
			self.app.innerHTML = '<div class="bhc-success"><div class="bhc-success__icon">✓</div><h3>' + ( confirmed ? 'Prenotazione confermata!' : 'Richiesta inviata!' ) + '</h3>' +
				'<p><strong>' + esc( res.treatment ) + '</strong><br>' + esc( longDate( res.date ) ) + ' alle ' + esc( res.time ) + '</p>' +
				'<p class="bhc-muted">' + ( confirmed ? 'Ti abbiamo inviato una email di riepilogo.' : 'Ti confermeremo l\'appuntamento via email al più presto.' ) + '</p>' +
				'<p><a class="bhc-btn bhc-btn--ghost" href="' + esc( res.manage_url ) + '">Gestisci la prenotazione</a></p></div>';
		} ).catch( function ( e ) {
			btn.disabled = false;
			btn.textContent = 'Conferma prenotazione';
			msg.className = 'bhc-msg is-error';
			msg.textContent = e.message;
			if ( e.code === 'slot_taken' ) {
				setTimeout( function () {
					self.state.time = '';
					self.go( 2 );
				}, 1800 );
			}
		} );
	};

	function initCancel() {
		document.querySelectorAll( '[data-bh-cancel]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Vuoi davvero annullare questo appuntamento?' ) ) {
					return;
				}
				var msg = b.closest( '.bhc-box' ).querySelector( '.bhc-msg' );
				b.disabled = true;
				api( 'public/cancel', { method: 'POST', body: { token: b.dataset.bhCancel } } ).then( function () {
					msg.className = 'bhc-msg is-ok';
					msg.textContent = 'Appuntamento annullato. Ti abbiamo inviato una email di conferma.';
					b.remove();
				} ).catch( function ( e ) {
					b.disabled = false;
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		} );
	}

	function init() {
		document.querySelectorAll( '.bhc-booking' ).forEach( function ( el ) {
			if ( ! el.dataset.bhcInit ) {
				el.dataset.bhcInit = '1';
				new Booking( el );
			}
		} );
		initCancel();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
	// Anteprima nell'editor di Elementor.
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/global', init );
			}
		} );
	}
} )();
