/* BeautyHub – gestionale staff (vanilla JS, nessuna dipendenza) */
( function () {
	'use strict';

	var cfg = window.BHC || {};
	var root = document.getElementById( 'bhc-app' );
	if ( ! root ) {
		return;
	}

	/* ================= Utilità ================= */

	function esc( s ) {
		return String( s == null ? '' : s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}
	// Compatibile sia con permalink "belli" (/wp-json/...) sia con quelli semplici (?rest_route=...).
	function restUrl( path ) {
		var i = path.indexOf( '?' );
		var base = cfg.rest + ( i === -1 ? path : path.slice( 0, i ) );
		return i === -1 ? base : base + ( base.indexOf( '?' ) === -1 ? '?' : '&' ) + path.slice( i + 1 );
	}

	function api( path, opts ) {
		opts = opts || {};
		var headers = { 'X-WP-Nonce': cfg.nonce };
		if ( opts.body ) {
			headers[ 'Content-Type' ] = 'application/json';
		}
		return fetch( restUrl( path ), {
			method: opts.method || 'GET',
			headers: headers,
			credentials: 'same-origin',
			body: opts.body ? JSON.stringify( opts.body ) : undefined
		} ).then( function ( r ) {
			return r.json().catch( function () {
				return {};
			} ).then( function ( data ) {
				if ( ! r.ok ) {
					var e = new Error( data.message || ( r.status === 403 ? 'Sessione scaduta: ricarica la pagina.' : 'Errore di rete' ) );
					e.code = data.code;
					e.status = r.status;
					throw e;
				}
				return data;
			} );
		} );
	}
	function pad( n ) {
		return ( n < 10 ? '0' : '' ) + n;
	}
	function ymd( d ) {
		return d.getFullYear() + '-' + pad( d.getMonth() + 1 ) + '-' + pad( d.getDate() );
	}
	function parseDate( s ) {
		var p = s.split( '-' );
		return new Date( +p[ 0 ], +p[ 1 ] - 1, +p[ 2 ], 12 );
	}
	function addDays( s, n ) {
		var d = parseDate( s );
		d.setDate( d.getDate() + n );
		return ymd( d );
	}
	function toMin( t ) {
		var m = /^(\d{1,2}):(\d{2})/.exec( t || '' );
		return m ? +m[ 1 ] * 60 + +m[ 2 ] : null;
	}
	function toTime( m ) {
		return pad( Math.floor( m / 60 ) ) + ':' + pad( m % 60 );
	}
	function euro( v ) {
		return '€ ' + Number( v || 0 ).toLocaleString( 'it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 } );
	}
	function fmtDate( s, opts ) {
		return parseDate( s ).toLocaleDateString( 'it-IT', opts || { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' } );
	}
	function dow( s ) {
		var d = parseDate( s ).getDay();
		return d === 0 ? 7 : d;
	}
	function parseRanges( str ) {
		var out = [];
		String( str || '' ).split( /[,;]+/ ).forEach( function ( part ) {
			var m = /(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})/.exec( part );
			if ( m ) {
				var a = toMin( m[ 1 ] ), b = toMin( m[ 2 ] );
				if ( b > a ) {
					out.push( [ a, b ] );
				}
			}
		} );
		return out;
	}
	function intersect( a, b ) {
		var out = [];
		a.forEach( function ( x ) {
			b.forEach( function ( y ) {
				var s = Math.max( x[ 0 ], y[ 0 ] ), e = Math.min( x[ 1 ], y[ 1 ] );
				if ( e > s ) {
					out.push( [ s, e ] );
				}
			} );
		} );
		return out;
	}
	function toast( msg, isError ) {
		var t = document.createElement( 'div' );
		t.className = 'bhc-toast' + ( isError ? ' is-error' : '' );
		t.textContent = msg;
		document.body.appendChild( t );
		setTimeout( function () {
			t.remove();
		}, isError ? 4500 : 2600 );
	}
	function debounce( fn, ms ) {
		var t;
		return function () {
			var args = arguments, ctx = this;
			clearTimeout( t );
			t = setTimeout( function () {
				fn.apply( ctx, args );
			}, ms );
		};
	}

	var ICONS = {
		agenda: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>',
		clients: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.4-5.5 6.5-5.5s5.7 1.9 6.5 5.5"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14.6c2.6.2 4.6 2 5.3 5.1"/></svg>',
		report: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
		plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 5v14M5 12h14"/></svg>',
		settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
		cabins: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 21V4a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v17"/><path d="M2 21h20"/><path d="M7 15h10v3H7z"/><circle cx="9" cy="10" r="1.6"/><path d="M12 10h5"/></svg>',
		products: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M9 3h6v3H9z"/><path d="M8 6h8l1 3v10a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V9z"/><path d="M7 12h10"/></svg>',
		inventory: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 3h6v3H9z"/><path d="M8.5 11l1.5 1.5 3-3M8.5 16.5h7"/></svg>',
		suppliers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M2 16V6h11v10"/><path d="M13 9h4l4 4v3h-8"/><circle cx="6.5" cy="17.5" r="2"/><circle cx="17.5" cy="17.5" r="2"/></svg>',
		invoices: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 2h9l4 4v16l-2.5-1.5L14 22l-2-1.5L10 22l-2.5-1.5L5 22V3a1 1 0 0 1 1-1z"/><path d="M9 8h6M9 12h6M9 16h4"/></svg>',
		treatments: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 21c-4-2.5-7-6-7-10a7 7 0 0 1 14 0c0 4-3 7.5-7 10z"/><path d="M12 7v8M8.5 11h7"/></svg>',
		people: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10.5" r="2.5"/><path d="M5 17c.6-2.2 2.1-3.3 4-3.3s3.4 1.1 4 3.3"/><path d="M15 9h3M15 12.5h3"/></svg>',
		cards: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 9.5h19"/><path d="M6 15h4"/><path d="M16.5 13.2c.9-.9 2.3-.2 2 1-.2.8-2 2-2 2s-1.8-1.2-2-2c-.3-1.2 1.1-1.9 2-1z"/></svg>',
		pos: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="4" y="9" width="16" height="12" rx="2"/><path d="M7 9V4h10v5"/><path d="M9 6.5h6"/><path d="M8 13h2M12 13h2M16 13h0M8 16.5h2M12 16.5h2"/></svg>',
		scan: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 7V4h3M21 7V4h-3M3 17v3h3M21 17v3h-3"/><path d="M7 8v8M10 8v8M13 8v8M15.5 8v8M18 8v8"/></svg>',
		cash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 9.5v5M18 9.5v5"/></svg>',
		cardpay: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 9.5h19M6 15h5"/></svg>',
		mixed: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="2.5" y="4" width="13" height="9" rx="1.6"/><rect x="8.5" y="11" width="13" height="9" rx="1.6"/><path d="M8.5 14.5h13"/></svg>',
		check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
		messages: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 5h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H9l-5 4V6a1 1 0 0 1 1-1z"/><path d="M8 9.5h8M8 13h5"/></svg>',
		whatsapp: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.2a9.8 9.8 0 0 0-8.4 14.9L2.3 21.8l4.8-1.3A9.8 9.8 0 1 0 12 2.2zm0 17.9a8.1 8.1 0 0 1-4.1-1.1l-.3-.2-2.9.8.8-2.8-.2-.3A8.1 8.1 0 1 1 12 20.1zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.6 6.6 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.1.7a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3z"/></svg>',
		forms: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="3.5" width="14" height="17.5" rx="2"/><path d="M9 3.5h6v3H9z"/><path d="M8.5 11h7M8.5 14.5h7M8.5 18h4"/></svg>',
		timeclock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9.5 3h5M12 3v2M19 6l1.5-1.5"/></svg>',
		print: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M6 14h12v7H6z"/></svg>',
		alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/></svg>',
		edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/></svg>',
		out: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 17l5-5-5-5M15 12H3"/></svg>'
	};

	/* ================= Stato ================= */

	var B = null; // bootstrap
	var S = {
		view: 'agenda',
		mode: 'day',
		date: '',
		staffFilter: 0,
		items: [],
		clientQuery: '',
		clientPage: 1,
		reportRange: 'month'
	};
	var PX = 1.5; // pixel per minuto nell'agenda giornaliera

	function staffById( id ) {
		return B.staff.filter( function ( s ) {
			return s.id === id;
		} )[ 0 ];
	}
	function treatmentById( id ) {
		return B.treatments.filter( function ( t ) {
			return t.id === id;
		} )[ 0 ];
	}
	function centerRanges( date ) {
		if ( B.closures.indexOf( date ) !== -1 ) {
			return [];
		}
		return B.hours[ dow( date ) ] || [];
	}
	function staffRanges( st, date ) {
		var center = centerRanges( date );
		var own = false;
		Object.keys( st.hours || {} ).forEach( function ( k ) {
			if ( String( st.hours[ k ] || '' ).trim() ) {
				own = true;
			}
		} );
		return own ? intersect( center, parseRanges( st.hours[ dow( date ) ] ) ) : center;
	}

	/* ================= Shell ================= */

	/** Permesso dell'utente corrente (l'amministratore li ha tutti). */
	function can( k ) {
		return !! ( B.me.is_admin || ( B.me.perms && B.me.perms[ k ] ) );
	}

	/** Voci di menu in base ai permessi. */
	function navItems() {
		var all = [
			[ 'agenda', 'Agenda', 'agenda_view' ], [ 'pos', 'Cassa', 'pos' ], [ 'clients', 'Clienti', 'clients_view' ], [ 'forms', 'Schede anamnesi', 'health' ], [ 'cabins', 'Cabine', 'agenda_view' ],
			[ 'treatments', 'Trattamenti', 'treatments' ], [ 'people', 'Operatrici', 'people' ], [ 'timeclock', 'Orari e presenze', 'timeclock' ], [ 'cards', 'Card', 'cards' ], [ 'messages', 'Messaggi', 'messages' ], [ 'products', 'Prodotti', 'products' ], [ 'inventory', 'Inventario', 'products' ],
			[ 'suppliers', 'Fornitori', 'suppliers' ], [ 'invoices', 'Fatture', 'invoices' ], [ 'report', 'Report', 'reports' ]
		];
		var nav = all.filter( function ( n ) {
			return can( n[ 2 ] );
		} );
		if ( B.me.is_admin ) {
			nav.push( [ 'settings', 'Impostazioni' ] );
		}
		return nav;
	}

	function nameInitials( s ) {
		var w = String( s || '' ).trim().split( /\s+/ ).filter( Boolean );
		return ( ( w[ 0 ] || '?' ).charAt( 0 ) + ( w.length > 1 ? w[ w.length - 1 ].charAt( 0 ) : '' ) ).toUpperCase();
	}

	function shell() {
		var nav = navItems();
		root.classList.add( 'bhc-pro' );
		root.innerHTML =
			'<aside class="bhc-side"><div class="bhc-side__brand" title="' + esc( B.center ) + '">' + esc( nameInitials( B.center ) ) + '</div><nav class="bhc-side__nav">' +
			nav.map( function ( n ) {
				return '<button type="button" data-view="' + n[ 0 ] + '" data-tip="' + esc( n[ 1 ] ) + '" aria-label="' + esc( n[ 1 ] ) + '">' + ICONS[ n[ 0 ] ] + '</button>';
			} ).join( '' ) +
			'</nav><div class="bhc-side__foot"><span class="bhc-side__me" data-tip="' + esc( B.me.name ) + '">' + esc( nameInitials( B.me.name ) ) + '</span><a href="' + esc( B.logout ) + '" data-tip="Esci" aria-label="Esci">' + ICONS.out + '</a></div></aside>' +
			'<main class="bhc-main" id="bhc-main"></main>' +
			'<nav class="bhc-mobile-nav">' + nav.map( function ( n ) {
				return '<button type="button" data-view="' + n[ 0 ] + '">' + ICONS[ n[ 0 ] ] + n[ 1 ] + '</button>';
			} ).join( '' ) + ( can( 'agenda_edit' ) ? '<button type="button" data-new>' + ICONS.plus + 'Nuovo</button>' : '' ) + '<button type="button" data-logout>' + ICONS.out + 'Esci</button></nav>';

		// Etichette a comparsa della barra a icone.
		var tip = document.createElement( 'div' );
		tip.className = 'bhc-tip';
		document.body.appendChild( tip );
		root.querySelectorAll( '.bhc-side [data-tip]' ).forEach( function ( el ) {
			el.addEventListener( 'mouseenter', function () {
				var r = el.getBoundingClientRect();
				tip.textContent = el.dataset.tip;
				tip.style.top = ( r.top + r.height / 2 ) + 'px';
				tip.style.left = ( r.right + 8 ) + 'px';
				tip.classList.add( 'is-on' );
			} );
			el.addEventListener( 'mouseleave', function () {
				tip.classList.remove( 'is-on' );
			} );
		} );
		root.querySelectorAll( '[data-view]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				tip.classList.remove( 'is-on' );
				S.view = b.dataset.view;
				if ( S.view === 'inventory' && typeof INVT !== 'undefined' ) {
					INVT.current = null;
					INVT.zone = null;
				}
				render();
			} );
		} );
		var nb = root.querySelector( '.bhc-mobile-nav [data-new]' );
		if ( nb ) {
			nb.addEventListener( 'click', function () {
				openAppointment( null, { date: S.date } );
			} );
		}
		root.querySelector( '[data-logout]' ).addEventListener( 'click', function () {
			window.location.href = B.logout;
		} );
	}

	function render() {
		root.querySelectorAll( '[data-view]' ).forEach( function ( b ) {
			b.classList.toggle( 'is-active', b.dataset.view === S.view );
		} );
		if ( S.view === 'agenda' ) {
			renderAgenda();
		} else if ( S.view === 'clients' ) {
			renderClients();
		} else if ( S.view === 'cabins' ) {
			renderCabins();
		} else if ( S.view === 'settings' ) {
			renderSettings();
		} else if ( S.view === 'treatments' ) {
			renderTreatments();
		} else if ( S.view === 'products' ) {
			renderProducts();
		} else if ( S.view === 'inventory' ) {
			renderInventory();
		} else if ( S.view === 'suppliers' ) {
			renderSuppliers();
		} else if ( S.view === 'invoices' ) {
			renderInvoices();
		} else if ( S.view === 'people' ) {
			renderPeople();
		} else if ( S.view === 'cards' ) {
			renderCards();
		} else if ( S.view === 'pos' ) {
			renderPos();
		} else if ( S.view === 'messages' ) {
			renderMessages();
		} else if ( S.view === 'timeclock' ) {
			renderTimeclock();
		} else if ( S.view === 'forms' ) {
			renderFormsView();
		} else if ( S.view === 'report' ) {
			renderReport();
		}
	}

	/* ================= Agenda ================= */

	function renderAgenda() {
		var main = document.getElementById( 'bhc-main' );
		var title = S.mode === 'day' ? fmtDate( S.date ) : 'Settimana dal ' + fmtDate( weekStart( S.date ), { day: 'numeric', month: 'long' } );
		main.innerHTML =
			'<div class="bhc-top"><h2>' + esc( title.charAt( 0 ).toUpperCase() + title.slice( 1 ) ) + '</h2><div class="bhc-top__actions">' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-nav="-1">&lsaquo;</button>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-today>Oggi</button>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-nav="1">&rsaquo;</button>' +
			'<input type="date" data-date value="' + S.date + '">' +
			'<select data-mode><option value="day"' + ( S.mode === 'day' ? ' selected' : '' ) + '>Giorno</option><option value="week"' + ( S.mode === 'week' ? ' selected' : '' ) + '>Settimana</option></select>' +
			'<select data-staff><option value="0">Tutte le cabine</option>' + B.staff.map( function ( s ) {
				return '<option value="' + s.id + '"' + ( S.staffFilter === s.id ? ' selected' : '' ) + '>' + esc( s.name ) + '</option>';
			} ).join( '' ) + '</select>' +
			( can( 'agenda_edit' ) ? '<button type="button" class="bhc-btn bhc-btn--sm" data-new>' + '+ Appuntamento</button>' : '' ) +
			'</div></div><div data-kpis></div><div data-grid><div class="bhc-loading">Caricamento…</div></div>';

		main.querySelectorAll( '[data-nav]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				S.date = addDays( S.date, +b.dataset.nav * ( S.mode === 'week' ? 7 : 1 ) );
				renderAgenda();
			} );
		} );
		main.querySelector( '[data-today]' ).addEventListener( 'click', function () {
			S.date = B.today;
			renderAgenda();
		} );
		main.querySelector( '[data-date]' ).addEventListener( 'change', function ( e ) {
			if ( e.target.value ) {
				S.date = e.target.value;
				renderAgenda();
			}
		} );
		main.querySelector( '[data-mode]' ).addEventListener( 'change', function ( e ) {
			S.mode = e.target.value;
			renderAgenda();
		} );
		main.querySelector( '[data-staff]' ).addEventListener( 'change', function ( e ) {
			S.staffFilter = +e.target.value;
			renderAgenda();
		} );
		var nb = main.querySelector( '[data-new]' );
		if ( nb ) {
			nb.addEventListener( 'click', function () {
				openAppointment( null, { date: S.date, staff_id: S.staffFilter } );
			} );
		}
		loadAgenda();
	}

	function weekStart( date ) {
		return addDays( date, 1 - dow( date ) );
	}

	function loadAgenda() {
		var from = S.mode === 'week' ? weekStart( S.date ) : S.date;
		var to = S.mode === 'week' ? addDays( from, 6 ) : S.date;
		api( 'appointments?from=' + from + '&to=' + to + ( S.staffFilter ? '&staff=' + S.staffFilter : '' ) ).then( function ( data ) {
			S.items = data.items;
			if ( S.mode === 'week' ) {
				drawWeek( from );
			} else {
				drawKpis();
				drawDay();
			}
		} ).catch( function ( e ) {
			document.querySelector( '[data-grid]' ).innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function drawKpis() {
		var box = document.querySelector( '[data-kpis]' );
		if ( ! box ) {
			return;
		}
		var active = S.items.filter( function ( a ) {
			return [ 'cancelled', 'noshow' ].indexOf( a.status ) === -1;
		} );
		var toConfirm = S.items.filter( function ( a ) {
			return a.status === 'booked';
		} ).length;
		var value = active.reduce( function ( s, a ) {
			return s + a.price;
		}, 0 );
		var paid = S.items.reduce( function ( s, a ) {
			return s + a.paid;
		}, 0 );
		box.innerHTML = '<div class="bhc-kpis">' +
			kpi( 'Appuntamenti', active.length ) +
			kpi( 'Da confermare', toConfirm ) +
			kpi( 'Valore previsto', euro( value ) ) +
			( can( 'payments' ) ? kpi( 'Incassato', euro( paid ) ) : '' ) + '</div>';
	}

	function kpi( label, value ) {
		return '<div class="bhc-card"><div class="bhc-kpi__label">' + esc( label ) + '</div><div class="bhc-kpi__value">' + esc( value ) + '</div></div>';
	}

	function drawDay() {
		var grid = document.querySelector( '[data-grid]' );
		var date = S.date;
		var cols = S.staffFilter ? B.staff.filter( function ( s ) {
			return s.id === S.staffFilter;
		} ) : B.staff.slice();
		var unassigned = S.items.filter( function ( a ) {
			return ! a.staff_id;
		} );
		if ( unassigned.length && ! S.staffFilter ) {
			cols.push( { id: 0, name: 'Senza cabina', color: '#999999', hours: {} } );
		}
		if ( ! cols.length ) {
			grid.innerHTML = '<div class="bhc-card"><p>Non ci sono ancora cabine: aggiungine una per vedere l\'agenda.</p>' + ( can( 'cabins' ) ? '<button type="button" class="bhc-btn" data-add-cabin>' + ICONS.cabins + ' Aggiungi cabina</button>' : '' ) + '</div>';
			bindCabinButtons( grid );
			return;
		}

		// Fascia oraria da mostrare.
		var start = 24 * 60, end = 0;
		Object.keys( B.hours ).forEach( function ( k ) {
			( B.hours[ k ] || [] ).forEach( function ( r ) {
				start = Math.min( start, r[ 0 ] );
				end = Math.max( end, r[ 1 ] );
			} );
		} );
		S.items.forEach( function ( a ) {
			start = Math.min( start, toMin( a.start ) );
			end = Math.max( end, toMin( a.end ) );
		} );
		if ( start >= end ) {
			start = 8 * 60;
			end = 20 * 60;
		}
		start = Math.floor( start / 60 ) * 60;
		end = Math.ceil( end / 60 ) * 60;
		var height = ( end - start ) * PX;
		var tmpl = '64px repeat(' + cols.length + ', minmax(140px, 1fr))';

		var head = '<div class="bhc-day__head" style="grid-template-columns:' + tmpl + '"><div class="bhc-day__corner">' +
			( can( 'cabins' ) ? '<button type="button" class="bhc-icon-btn" data-add-cabin title="Aggiungi cabina" aria-label="Aggiungi cabina">' + ICONS.cabins + '<b>+</b></button>' : '' ) + '</div>' + cols.map( function ( c ) {
			return '<div><i style="background:' + esc( c.color ) + '"></i>' + esc( c.name ) +
				( can( 'cabins' ) && c.id ? ' <button type="button" class="bhc-icon-btn bhc-icon-btn--sm" data-edit-cabin="' + c.id + '" title="Modifica cabina" aria-label="Modifica ' + esc( c.name ) + '">' + ICONS.edit + '</button>' : '' ) + '</div>';
		} ).join( '' ) + '</div>';

		var times = '<div class="bhc-day__times" style="height:' + height + 'px">';
		for ( var h = start; h <= end; h += 60 ) {
			times += '<span style="top:' + ( ( h - start ) * PX ) + 'px">' + toTime( h ) + '</span>';
		}
		times += '</div>';

		var body = cols.map( function ( c ) {
			var html = '<div class="bhc-day__col" style="height:' + height + 'px">';
			for ( var hh = start; hh < end; hh += 60 ) {
				html += '<div class="bhc-day__hourline" style="top:' + ( ( hh - start ) * PX ) + 'px"></div>';
			}
			var ranges = c.id ? staffRanges( c, date ) : [ [ start, end ] ];
			// Zone non lavorative.
			var cursor = start;
			ranges.slice().sort( function ( x, y ) {
				return x[ 0 ] - y[ 0 ];
			} ).forEach( function ( r ) {
				if ( r[ 0 ] > cursor ) {
					html += '<div class="bhc-day__off" style="top:' + ( ( cursor - start ) * PX ) + 'px;height:' + ( ( r[ 0 ] - cursor ) * PX ) + 'px"></div>';
				}
				cursor = Math.max( cursor, r[ 1 ] );
			} );
			if ( cursor < end ) {
				html += '<div class="bhc-day__off" style="top:' + ( ( cursor - start ) * PX ) + 'px;height:' + ( ( end - cursor ) * PX ) + 'px"></div>';
			}
			// Zone cliccabili per nuovo appuntamento.
			if ( can( 'agenda_edit' ) && c.id ) {
				ranges.forEach( function ( r ) {
					for ( var m = r[ 0 ]; m < r[ 1 ]; m += B.step ) {
						html += '<div class="bhc-day__click" data-slot="' + toTime( m ) + '" data-col="' + c.id + '" style="top:' + ( ( m - start ) * PX ) + 'px;height:' + ( B.step * PX ) + 'px" title="' + toTime( m ) + '"></div>';
					}
				} );
			}
			// Appuntamenti.
			S.items.filter( function ( a ) {
				return a.staff_id === c.id;
			} ).forEach( function ( a ) {
				var top = ( toMin( a.start ) - start ) * PX;
				var hgt = Math.max( 22, ( toMin( a.end ) - toMin( a.start ) ) * PX - 2 );
				html += '<div class="bhc-appt bhc-appt--' + a.status + '" data-appt="' + a.id + '" style="top:' + top + 'px;height:' + hgt + 'px;border-color:' + esc( a.staff_color ) + ';background-color:' + esc( a.staff_color ) + '22">' +
					'<strong>' + esc( a.start ) + ' ' + esc( a.client_name || 'Cliente' ) + '</strong>' +
					'<small>' + esc( a.treatment_name ) + ( a.operators && a.operators.length ? ' · ' + esc( a.operators.map( function ( o ) {
						return o.name;
					} ).join( ' + ' ) ) : '' ) + ( a.status === 'booked' ? ' · da confermare' : '' ) + ( a.paid > 0 ? ' · pagato' : '' ) + '</small></div>';
			} );
			if ( date === B.today ) {
				var now = new Date();
				var nm = now.getHours() * 60 + now.getMinutes();
				if ( nm >= start && nm <= end ) {
					html += '<div class="bhc-day__now" style="top:' + ( ( nm - start ) * PX ) + 'px"></div>';
				}
			}
			return html + '</div>';
		} ).join( '' );

		grid.innerHTML = '<div class="bhc-day">' + head + '<div class="bhc-day__body" style="grid-template-columns:' + tmpl + '">' + times + body + '</div></div>' +
			( centerRanges( date ).length ? '' : '<p class="bhc-muted" style="margin-top:10px">Il centro risulta chiuso in questa data.</p>' );

		grid.querySelectorAll( '[data-appt]' ).forEach( function ( el ) {
			el.addEventListener( 'click', function () {
				openAppointment( +el.dataset.appt );
			} );
		} );
		bindCabinButtons( grid );
		grid.querySelectorAll( '[data-slot]' ).forEach( function ( el ) {
			el.addEventListener( 'click', function () {
				openAppointment( null, { date: date, start: el.dataset.slot, staff_id: +el.dataset.col } );
			} );
		} );
	}

	function drawWeek( from ) {
		var grid = document.querySelector( '[data-grid]' );
		document.querySelector( '[data-kpis]' ).innerHTML = '';
		var html = '<div class="bhc-week">';
		for ( var i = 0; i < 7; i++ ) {
			var d = addDays( from, i );
			var list = S.items.filter( function ( a ) {
				return a.date === d;
			} );
			html += '<div class="bhc-week__day' + ( d === B.today ? ' is-today' : '' ) + '"><h4 data-day="' + d + '">' + esc( fmtDate( d, { weekday: 'short', day: 'numeric', month: 'short' } ) ) + ' <span class="bhc-muted">(' + list.length + ')</span></h4>' +
				list.map( function ( a ) {
					return '<div class="bhc-week__item bhc-appt--' + a.status + '" data-appt="' + a.id + '" style="border-color:' + esc( a.staff_color ) + '"><strong>' + esc( a.start ) + '</strong> ' + esc( a.client_name || 'Cliente' ) + '<br><span class="bhc-muted">' + esc( a.treatment_name ) + ( a.operators && a.operators.length ? ' · ' + esc( a.operators.map( function ( o ) {
						return o.name;
					} ).join( ' + ' ) ) : '' ) + '</span></div>';
				} ).join( '' ) + '</div>';
		}
		grid.innerHTML = html + '</div>';
		grid.querySelectorAll( '[data-appt]' ).forEach( function ( el ) {
			el.addEventListener( 'click', function () {
				openAppointment( +el.dataset.appt );
			} );
		} );
		grid.querySelectorAll( '[data-day]' ).forEach( function ( el ) {
			el.addEventListener( 'click', function () {
				S.date = el.dataset.day;
				S.mode = 'day';
				renderAgenda();
			} );
		} );
	}

	/* ================= Modale ================= */

	function modal( title, bodyHtml, footHtml, wide ) {
		closeModal();
		var m = document.createElement( 'div' );
		m.className = 'bhc bhc-pro bhc-modal';
		m.innerHTML = '<div class="bhc-modal__box' + ( wide ? ' bhc-modal__box--wide' : '' ) + '" role="dialog" aria-modal="true"><div class="bhc-modal__head"><h3>' + esc( title ) + '</h3><button type="button" class="bhc-modal__close" aria-label="Chiudi">&times;</button></div><div class="bhc-modal__body">' + bodyHtml + '</div>' + ( footHtml ? '<div class="bhc-modal__foot">' + footHtml + '</div>' : '' ) + '</div>';
		document.body.appendChild( m );
		m.querySelector( '.bhc-modal__close' ).addEventListener( 'click', closeModal );
		m.addEventListener( 'mousedown', function ( e ) {
			if ( e.target === m ) {
				closeModal();
			}
		} );
		document.addEventListener( 'keydown', escClose );
		return m;
	}
	function escClose( e ) {
		if ( e.key === 'Escape' ) {
			closeModal();
		}
	}
	function closeModal() {
		var m = document.querySelector( '.bhc-modal' );
		if ( m ) {
			m.remove();
		}
		document.removeEventListener( 'keydown', escClose );
	}

	/* ================= Appuntamento ================= */

	function openAppointment( id, preset ) {
		if ( id ) {
			api( 'appointments/' + id ).then( function ( a ) {
				appointmentForm( a );
			} ).catch( function ( e ) {
				toast( e.message, true );
			} );
		} else {
			appointmentForm( null, preset || {} );
		}
	}

	function appointmentForm( a, preset ) {
		var isNew = ! a;
		var canEdit = can( 'agenda_edit' );
		a = a || {
			client_id: 0,
			client_name: '',
			treatment_id: 0,
			staff_id: preset.staff_id || ( B.me.staff_id || 0 ),
			date: preset.date || S.date,
			start: preset.start || '',
			end: '',
			price: '',
			notes: '',
			status: 'confirmed',
			paid: 0
		};
		var dur = a.end ? toMin( a.end ) - toMin( a.start ) : '';
		var dis = canEdit ? '' : ' disabled';

		var statusBar = isNew ? '' : '<div class="bhc-statusbar">' + Object.keys( B.statuses ).map( function ( k ) {
			var allowed = canEdit || ( can( 'agenda_status' ) && ( k === 'arrived' || k === 'done' ) );
			return '<button type="button" data-status="' + k + '" class="' + ( a.status === k ? 'is-active' : '' ) + '"' + ( allowed ? '' : ' disabled' ) + '>' + esc( B.statuses[ k ] ) + '</button>';
		} ).join( '' ) + '</div>';

		var clientBlock = isNew
			? '<div class="bhc-field"><label>Cliente</label><input type="search" data-client-search placeholder="Cerca per nome, telefono o email…" autocomplete="off"><input type="hidden" data-client-id value="0"><div data-client-results></div>' +
			'<div data-new-client hidden><div class="bhc-row" style="margin-top:10px"><div><label>Nome</label><input type="text" data-nc="first_name"></div><div><label>Cognome</label><input type="text" data-nc="last_name"></div></div><div class="bhc-row" style="margin-top:10px"><div><label>Telefono</label><input type="tel" data-nc="phone"></div><div><label>Email</label><input type="email" data-nc="email"></div></div></div>' +
			'<p style="margin:6px 0 0"><a href="#" data-toggle-new>+ Nuova cliente</a></p></div>'
			: '<div class="bhc-field"><label>Cliente</label><div style="display:flex;gap:10px;align-items:center;justify-content:space-between"><strong>' + esc( a.client_name || '—' ) + '</strong>' + ( a.client_id && can( 'clients_view' ) ? '<span><a href="#" data-open-client="' + a.client_id + '">Apri scheda</a>' + ( can( 'health' ) ? ' · <a href="#" data-open-forms="' + a.client_id + '">Schede anamnesi</a>' : '' ) + '</span>' : '' ) + '</div><div class="bhc-muted">' + esc( [ a.phone, a.email ].filter( Boolean ).join( ' · ' ) ) + '</div></div>';

		var body = statusBar + clientBlock +
			'<div class="bhc-row"><div class="bhc-field"><label>Trattamento</label><select data-f="treatment_id"' + dis + '><option value="">— scegli —</option>' + B.treatments.map( function ( t ) {
				return '<option value="' + t.id + '"' + ( t.id === a.treatment_id ? ' selected' : '' ) + '>' + esc( t.name ) + ' (' + t.duration + ' min)</option>';
			} ).join( '' ) + '</select></div>' +
			'<div class="bhc-field"><label>Cabina</label><select data-f="staff_id"' + dis + '><option value="0">— prima libera —</option>' + B.staff.map( function ( s ) {
				return '<option value="' + s.id + '"' + ( s.id === a.staff_id ? ' selected' : '' ) + '>' + esc( s.name ) + '</option>';
			} ).join( '' ) + '</select></div></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Data</label><input type="date" data-f="date" value="' + esc( a.date ) + '"' + dis + '></div>' +
			'<div class="bhc-field"><label>Ora</label><input type="time" data-f="start" step="300" value="' + esc( a.start ) + '"' + dis + '><div class="bhc-muted" data-free></div></div></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Durata (min)</label><input type="number" min="5" step="5" data-f="duration" value="' + esc( dur ) + '"' + dis + '></div>' +
			'<div class="bhc-field"><label>Prezzo (€)</label><input type="number" min="0" step="0.5" data-f="price" value="' + esc( a.price === '' ? '' : a.price ) + '"' + dis + '></div></div>' +
			'<div class="bhc-field bhc-ops" data-ops><label>Operatrici</label><div class="bhc-muted" data-ops-body>Scegli trattamento, data e ora per vedere le operatrici disponibili.</div></div>' +
			'<div class="bhc-field"><label>Note appuntamento</label><textarea rows="2" data-f="notes"' + dis + '>' + esc( a.notes ) + '</textarea></div>' +
			( ! isNew && canEdit ? '<label class="bhc-check"><input type="checkbox" data-notify> <span>Avvisa la cliente via email quando confermo o annullo</span></label>' : '' ) +
			( ! isNew && can( 'payments' ) ? '<div class="bhc-card" style="margin-top:14px;background:#faf8f4;box-shadow:none"><strong>Incasso</strong> <span class="bhc-muted">· già pagato ' + euro( a.paid ) + ' su ' + euro( a.price ) + '</span>' +
				'<div class="bhc-row" style="margin-top:10px"><div><label>Importo (€)</label><input type="number" min="0" step="0.5" data-pay-amount value="' + Math.max( 0, a.price - a.paid ).toFixed( 2 ) + '"></div><div><label>Metodo</label><select data-pay-method>' + methodOptions() + '</select></div></div><p style="margin:10px 0 0"><button type="button" class="bhc-btn bhc-btn--sm" data-pay>Registra incasso e chiudi</button></p>' + ( a.client_id ? '<div data-cards-panel class="bhc-cards-panel"></div>' : '' ) + '</div>' : '' ) +
			'<p class="bhc-msg" data-msg></p>';

		var foot = '<div>' + ( ! isNew && can( 'appt_delete' ) ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-delete>Elimina</button>' : '' ) + '</div><div>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost" data-cancel-modal>Chiudi</button>' +
			( canEdit ? '<button type="button" class="bhc-btn" data-save>' + ( isNew ? 'Crea appuntamento' : 'Salva modifiche' ) + '</button>' : '' ) + '</div>';

		var m = modal( isNew ? 'Nuovo appuntamento' : 'Appuntamento', body, foot );
		if ( ! isNew && can( 'payments' ) && a.client_id ) {
			cardsPanel( m, a );
		}
		var f = function ( n ) {
			return m.querySelector( '[data-f="' + n + '"]' );
		};
		var msg = m.querySelector( '[data-msg]' );

		m.querySelector( '[data-cancel-modal]' ).addEventListener( 'click', closeModal );

		// Selezione trattamento: imposta durata/prezzo e propone gli orari liberi.
		f( 'treatment_id' ).addEventListener( 'change', function () {
			var t = treatmentById( +this.value );
			if ( t ) {
				f( 'duration' ).value = t.duration;
				f( 'price' ).value = t.price;
			}
			suggestTimes();
		} );
		[ 'staff_id', 'date' ].forEach( function ( n ) {
			f( n ).addEventListener( 'change', suggestTimes );
		} );

		// Operatrici presenti e disponibili per trattamento, data, ora e durata scelti.
		var opsState = { enabled: false, needed: 1, list: [] };
		var currentOps = ( a.operators || [] ).map( function ( o ) {
			return o.id;
		} );
		function opSelects() {
			return m.querySelectorAll( '[data-op]' );
		}
		function chosenOps() {
			var ids = [];
			opSelects().forEach( function ( sEl ) {
				if ( +sEl.value ) {
					ids.push( +sEl.value );
				}
			} );
			return ids;
		}
		function loadOperators() {
			var body = m.querySelector( '[data-ops-body]' );
			var tid = +f( 'treatment_id' ).value, date = f( 'date' ).value, start = f( 'start' ).value;
			if ( opSelects().length ) {
				currentOps = chosenOps();
			}
			if ( ! tid || ! date || ! start ) {
				return;
			}
			var dur = +f( 'duration' ).value || '';
			api( 'operators?treatment=' + tid + '&date=' + date + '&start=' + start + '&duration=' + dur + ( a.id ? '&exclude=' + a.id : '' ) ).then( function ( d ) {
				opsState = { enabled: d.enabled, needed: d.needed, list: d.operators };
				if ( ! d.enabled ) {
					body.innerHTML = '<span class="bhc-muted">Nessuna operatrice registrata: aggiungile dalla sezione Operatrici.</span>';
					return;
				}
				if ( ! d.operators.length ) {
					body.innerHTML = '<span class="bhc-msg is-error">Nessuna operatrice è abilitata a questo trattamento.</span>';
					return;
				}
				var pick = currentOps.slice( 0, d.needed );
				d.operators.forEach( function ( o ) {
					if ( pick.length < d.needed && o.available && pick.indexOf( o.id ) === -1 ) {
						pick.push( o.id );
					}
				} );
				var html = '<div class="bhc-row">';
				for ( var i = 0; i < d.needed; i++ ) {
					html += '<div><select data-op' + dis + '><option value="0">— scegli —</option>' + d.operators.map( function ( o ) {
						return '<option value="' + o.id + '"' + ( pick[ i ] === o.id ? ' selected' : '' ) + ( o.available ? '' : ' class="is-off"' ) + '>' + esc( o.name ) + ( o.available ? ' · disponibile' : ' · ' + esc( o.reason ) ) + '</option>';
					} ).join( '' ) + '</select></div>';
				}
				html += '</div>';
				var free = d.operators.filter( function ( o ) {
					return o.available;
				} ).length;
				html += '<div class="bhc-muted" style="margin-top:6px">' + ( d.needed === 2 ? '<strong>Trattamento a due operatrici.</strong> ' : '' ) + free + ' disponibil' + ( free === 1 ? 'e' : 'i' ) + ' su ' + d.operators.length + ' abilitat' + ( d.operators.length === 1 ? 'a' : 'e' ) + ' in questo orario.</div>';
				body.innerHTML = html;
			} ).catch( function () {
				body.textContent = '';
			} );
		}
		[ 'treatment_id', 'date', 'start', 'duration' ].forEach( function ( n ) {
			f( n ).addEventListener( 'change', loadOperators );
		} );
		loadOperators();

		function suggestTimes() {
			var box = m.querySelector( '[data-free]' );
			var tid = +f( 'treatment_id' ).value, sid = +f( 'staff_id' ).value, date = f( 'date' ).value;
			if ( ! tid || ! date || ! canEdit ) {
				box.innerHTML = '';
				return;
			}
			box.textContent = 'Cerco orari liberi…';
			api( 'slots?date=' + date + '&treatment=' + tid + '&staff=' + sid ).then( function ( data ) {
				var keys = Object.keys( data.slots );
				if ( ! keys.length ) {
					box.textContent = 'Nessun orario libero.';
					return;
				}
				box.innerHTML = 'Liberi: ' + keys.slice( 0, 12 ).map( function ( k ) {
					return '<a href="#" data-pick="' + k + '" data-pick-staff="' + data.slots[ k ][ 0 ] + '">' + k + '</a>';
				} ).join( ' · ' ) + ( keys.length > 12 ? ' …' : '' );
				box.querySelectorAll( '[data-pick]' ).forEach( function ( l ) {
					l.addEventListener( 'click', function ( e ) {
						e.preventDefault();
						f( 'start' ).value = l.dataset.pick;
						loadOperators();
						if ( ! +f( 'staff_id' ).value ) {
							f( 'staff_id' ).value = l.dataset.pickStaff;
						}
					} );
				} );
			} ).catch( function () {
				box.textContent = '';
			} );
		}

		// Ricerca cliente.
		if ( isNew ) {
			var search = m.querySelector( '[data-client-search]' );
			var results = m.querySelector( '[data-client-results]' );
			var cid = m.querySelector( '[data-client-id]' );
			var newBox = m.querySelector( '[data-new-client]' );
			search.addEventListener( 'input', debounce( function () {
				cid.value = '0';
				var q = search.value.trim();
				if ( q.length < 2 ) {
					results.innerHTML = '';
					return;
				}
				api( 'clients?q=' + encodeURIComponent( q ) ).then( function ( data ) {
					results.innerHTML = data.items.length ? '<div class="bhc-search-results">' + data.items.slice( 0, 8 ).map( function ( c ) {
						return '<button type="button" data-cid="' + c.id + '">' + esc( c.first_name + ' ' + c.last_name ) + ' <span class="bhc-muted">' + esc( c.phone || c.email ) + '</span></button>';
					} ).join( '' ) + '</div>' : '<p class="bhc-muted">Nessuna cliente trovata. <a href="#" data-create-from-search>Creala ora</a></p>';
					results.querySelectorAll( '[data-cid]' ).forEach( function ( b ) {
						b.addEventListener( 'click', function () {
							cid.value = b.dataset.cid;
							search.value = b.textContent;
							results.innerHTML = '';
							newBox.hidden = true;
						} );
					} );
					var cf = results.querySelector( '[data-create-from-search]' );
					if ( cf ) {
						cf.addEventListener( 'click', function ( e ) {
							e.preventDefault();
							newBox.hidden = false;
							var parts = q.split( /\s+/ );
							if ( /^[\d\s+]+$/.test( q ) ) {
								newBox.querySelector( '[data-nc="phone"]' ).value = q;
							} else {
								newBox.querySelector( '[data-nc="first_name"]' ).value = parts[ 0 ] || '';
								newBox.querySelector( '[data-nc="last_name"]' ).value = parts.slice( 1 ).join( ' ' );
							}
						} );
					}
				} );
			}, 250 ) );
			m.querySelector( '[data-toggle-new]' ).addEventListener( 'click', function ( e ) {
				e.preventDefault();
				newBox.hidden = ! newBox.hidden;
			} );
		} else {
			var of = m.querySelector( '[data-open-forms]' );
			if ( of ) {
				of.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					openClient( +of.dataset.openForms, 'schede' );
				} );
			}
			var oc = m.querySelector( '[data-open-client]' );
			if ( oc ) {
				oc.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					openClient( +oc.dataset.openClient );
				} );
			}
		}

		function payload() {
			var p = {
				treatment_id: +f( 'treatment_id' ).value,
				staff_id: +f( 'staff_id' ).value,
				date: f( 'date' ).value,
				start: f( 'start' ).value,
				duration: +f( 'duration' ).value || undefined,
				price: f( 'price' ).value,
				notes: f( 'notes' ).value
			};
			if ( opsState.enabled ) {
				p.operators = chosenOps();
			}
			if ( isNew ) {
				p.client_id = +m.querySelector( '[data-client-id]' ).value;
				var nb = m.querySelector( '[data-new-client]' );
				if ( ! p.client_id && ! nb.hidden ) {
					p.new_client = {};
					nb.querySelectorAll( '[data-nc]' ).forEach( function ( i ) {
						p.new_client[ i.dataset.nc ] = i.value;
					} );
				}
			}
			var n = m.querySelector( '[data-notify]' );
			if ( n ) {
				p.notify = n.checked ? 1 : 0;
			}
			return p;
		}

		function save( force ) {
			var p = payload();
			msg.className = 'bhc-msg';
			if ( ! p.treatment_id || ! p.date || ! p.start ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Scegli trattamento, data e ora.';
				return;
			}
			if ( opsState.enabled && p.operators ) {
				var uniq = p.operators.filter( function ( v, i, arr ) {
					return arr.indexOf( v ) === i;
				} );
				if ( uniq.length < opsState.needed ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = opsState.needed === 2 ? 'Questo trattamento richiede due operatrici diverse.' : 'Scegli l\'operatrice.';
					return;
				}
			}
			if ( isNew && ! p.client_id && ! p.new_client ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Seleziona o crea una cliente.';
				return;
			}
			if ( force ) {
				p.force = 1;
			}
			api( isNew ? 'appointments' : 'appointments/' + a.id, { method: isNew ? 'POST' : 'PUT', body: p } ).then( function () {
				closeModal();
				toast( isNew ? 'Appuntamento creato' : 'Appuntamento aggiornato' );
				if ( S.view === 'agenda' ) {
					if ( p.date !== S.date && S.mode === 'day' ) {
						S.date = p.date;
						renderAgenda();
					} else {
						loadAgenda();
					}
				}
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				if ( e.code === 'conflict' || e.code === 'operator_conflict' ) {
					msg.innerHTML = esc( e.message ) + ' <a href="#" data-force>Salva comunque</a>';
					msg.querySelector( '[data-force]' ).addEventListener( 'click', function ( ev ) {
						ev.preventDefault();
						save( true );
					} );
				} else {
					msg.textContent = e.message;
				}
			} );
		}

		var sb = m.querySelector( '[data-save]' );
		if ( sb ) {
			sb.addEventListener( 'click', function () {
				save( false );
			} );
		}

		m.querySelectorAll( '[data-status]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var n = m.querySelector( '[data-notify]' );
				api( 'appointments/' + a.id + '/status', { method: 'POST', body: { status: b.dataset.status, notify: n && n.checked ? 1 : 0 } } ).then( function ( upd ) {
					a.status = upd.status;
					m.querySelectorAll( '[data-status]' ).forEach( function ( x ) {
						x.classList.toggle( 'is-active', x.dataset.status === upd.status );
					} );
					toast( 'Stato: ' + B.statuses[ upd.status ] );
					if ( S.view === 'agenda' ) {
						loadAgenda();
					}
				} ).catch( function ( e ) {
					toast( e.message, true );
				} );
			} );
		} );

		var pb = m.querySelector( '[data-pay]' );
		if ( pb ) {
			pb.addEventListener( 'click', function () {
				var amount = parseFloat( m.querySelector( '[data-pay-amount]' ).value );
				if ( ! amount || amount <= 0 ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = 'Inserisci un importo.';
					return;
				}
				api( 'appointments/' + a.id + '/pay', { method: 'POST', body: { amount: amount, method: m.querySelector( '[data-pay-method]' ).value, complete: 1 } } ).then( function () {
					closeModal();
					toast( 'Incasso registrato: ' + euro( amount ) );
					if ( S.view === 'agenda' ) {
						loadAgenda();
					}
				} ).catch( function ( e ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		}

		var db = m.querySelector( '[data-delete]' );
		if ( db ) {
			db.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Eliminare definitivamente l\'appuntamento? (Per le statistiche è meglio segnarlo come Annullato.)' ) ) {
					return;
				}
				api( 'appointments/' + a.id, { method: 'DELETE' } ).then( function () {
					closeModal();
					toast( 'Appuntamento eliminato' );
					loadAgenda();
				} ).catch( function ( e ) {
					toast( e.message, true );
				} );
			} );
		}

		if ( isNew && preset && preset.start ) {
			f( 'treatment_id' ).focus();
		}
	}

	/* ================= Clienti ================= */

	function renderClients() {
		var main = document.getElementById( 'bhc-main' );
		main.innerHTML = '<div class="bhc-top"><h2>Clienti</h2><div class="bhc-top__actions"><input type="search" data-q placeholder="Cerca nome, telefono, email, tag…" value="' + esc( S.clientQuery ) + '" style="min-width:260px">' +
			( can( 'clients_edit' ) ? '<button type="button" class="bhc-btn bhc-btn--sm" data-new-client>+ Nuova cliente</button>' : '' ) + '</div></div><div data-list><div class="bhc-loading">Caricamento…</div></div>';
		var q = main.querySelector( '[data-q]' );
		q.addEventListener( 'input', debounce( function () {
			S.clientQuery = q.value;
			S.clientPage = 1;
			loadClients();
		}, 300 ) );
		var nc = main.querySelector( '[data-new-client]' );
		if ( nc ) {
			nc.addEventListener( 'click', function () {
				clientForm( null );
			} );
		}
		loadClients();
	}

	function loadClients() {
		var box = document.querySelector( '[data-list]' );
		api( 'clients?q=' + encodeURIComponent( S.clientQuery ) + '&page=' + S.clientPage ).then( function ( data ) {
			if ( ! data.items.length ) {
				box.innerHTML = '<div class="bhc-card bhc-muted">Nessuna cliente trovata.</div>';
				return;
			}
			var pages = Math.ceil( data.total / 50 );
			box.innerHTML = '<table class="bhc-table"><thead><tr><th>Cliente</th><th>Telefono</th><th>Email</th><th>Tag</th><th>Privacy</th>' + ( can( 'health' ) ? '<th></th>' : '' ) + '</tr></thead><tbody>' +
				data.items.map( function ( c ) {
					return '<tr class="is-click" data-cid="' + c.id + '"><td><strong>' + esc( c.last_name + ' ' + c.first_name ) + '</strong></td><td>' + esc( c.phone ) + '</td><td>' + esc( c.email ) + '</td><td>' + esc( c.tags ) + '</td><td>' + ( c.privacy_consent_at ? '✓' : '<span class="bhc-badge bhc-badge--noshow">manca</span>' ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table>' +
				'<p class="bhc-muted" style="display:flex;gap:10px;align-items:center;margin-top:12px">' + data.total + ' clienti' +
				( pages > 1 ? ' · pagina ' + S.clientPage + ' di ' + pages + ' <button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-p="-1"' + ( S.clientPage <= 1 ? ' disabled' : '' ) + '>&lsaquo;</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-p="1"' + ( S.clientPage >= pages ? ' disabled' : '' ) + '>&rsaquo;</button>' : '' ) + '</p>';
			if ( can( 'health' ) ) {
				box.querySelectorAll( 'tr[data-cid]' ).forEach( function ( r ) {
					r.insertAdjacentHTML( 'beforeend', '<td class="nw"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cforms="' + r.dataset.cid + '">' + ICONS.forms + ' Schede</button></td>' );
				} );
			}
			box.querySelectorAll( '[data-cid]' ).forEach( function ( r ) {
				r.addEventListener( 'click', function ( e ) {
					var fb = e.target.closest( '[data-cforms]' );
					openClient( +r.dataset.cid, fb ? 'schede' : '' );
				} );
			} );
			box.querySelectorAll( '[data-p]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					S.clientPage += +b.dataset.p;
					loadClients();
				} );
			} );
		} ).catch( function ( e ) {
			box.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function openClient( id, tab ) {
		api( 'clients/' + id ).then( function ( data ) {
			clientForm( data );
			if ( tab ) {
				var t = document.querySelector( '.bhc-modal [data-tab="' + tab + '"]' );
				if ( t ) {
					t.click();
				}
			}
		} ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	function clientForm( data ) {
		var isNew = ! data;
		var c = data ? data.client : { first_name: '', last_name: '', email: '', phone: '', gender: '', birth_date: '', birth_place: '', tax_code: '', address: '', skin_type: '', phototype: '', tags: '', notes: '', health_notes: '', privacy_consent_at: '', marketing_consent: 0 };
		var canEdit = can( 'clients_edit' );
		var ro = canEdit ? '' : ' disabled';
		var roNotes = canEdit || can( 'clients_notes' ) ? '' : ' disabled';
		function inp( name, label, type ) {
			return '<div class="bhc-field"><label>' + label + '</label><input type="' + ( type || 'text' ) + '" data-c="' + name + '" value="' + esc( c[ name ] || '' ) + '"' + ro + '></div>';
		}
		var skinTypes = [ '', 'Normale', 'Secca', 'Grassa', 'Mista', 'Sensibile', 'Matura' ];
		var tabScheda =
			'<div class="bhc-row">' + inp( 'first_name', 'Nome' ) + inp( 'last_name', 'Cognome' ) + '</div>' +
			'<div class="bhc-row">' + inp( 'phone', 'Telefono', 'tel' ) + inp( 'email', 'Email', 'email' ) + '</div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Sesso</label><select data-c="gender"' + ro + '>' + [ [ '', '—' ], [ 'F', 'Femmina' ], [ 'M', 'Maschio' ] ].map( function ( o ) {
				return '<option value="' + o[ 0 ] + '"' + ( ( c.gender || '' ) === o[ 0 ] ? ' selected' : '' ) + '>' + o[ 1 ] + '</option>';
			} ).join( '' ) + '</select></div>' + inp( 'birth_date', 'Data di nascita', 'date' ) + '</div>' +
			'<div class="bhc-row">' + inp( 'birth_place', 'Luogo di nascita' ) + inp( 'tax_code', 'Codice fiscale' ) + '</div>' +
			inp( 'address', 'Indirizzo' ) +
			'<div class="bhc-row"><div class="bhc-field"><label>Tipo di pelle</label><select data-c="skin_type"' + roNotes + '>' + skinTypes.map( function ( s ) {
				return '<option' + ( s === c.skin_type ? ' selected' : '' ) + '>' + esc( s ) + '</option>';
			} ).join( '' ) + '</select></div><div class="bhc-field"><label>Fototipo</label><select data-c="phototype"' + roNotes + '>' + [ '', 'I', 'II', 'III', 'IV', 'V', 'VI' ].map( function ( s ) {
				return '<option' + ( s === c.phototype ? ' selected' : '' ) + '>' + s + '</option>';
			} ).join( '' ) + '</select></div></div>' +
			inp( 'tags', 'Tag (separati da virgola, es. VIP, sposa)' ) +
			'<div class="bhc-field"><label>Note</label><textarea rows="3" data-c="notes"' + roNotes + '>' + esc( c.notes ) + '</textarea></div>' +
			( can( 'health' ) ? '<div class="bhc-field bhc-health"><label>Anamnesi e controindicazioni (riservato)</label><textarea rows="3" data-c="health_notes" placeholder="Allergie, gravidanza, farmaci, patologie rilevanti…">' + esc( c.health_notes ) + '</textarea></div>' : '' ) +
			'<div class="bhc-field"><label class="bhc-check"><input type="checkbox" data-c-check="privacy_consent"' + ( c.privacy_consent_at ? ' checked disabled' : '' ) + ro + '> <span>Consenso privacy' + ( c.privacy_consent_at ? ' raccolto il ' + esc( c.privacy_consent_at.substring( 0, 10 ).split( '-' ).reverse().join( '/' ) ) : '' ) + '</span></label>' +
			'<label class="bhc-check"><input type="checkbox" data-c-check="marketing_consent"' + ( +c.marketing_consent ? ' checked' : '' ) + ro + '> <span>Consenso marketing</span></label></div>' +
			'<p class="bhc-msg" data-msg></p>';

		var body;
		if ( isNew ) {
			body = tabScheda;
		} else {
			var sum = data.summary;
			body = '<div class="bhc-kpis">' + kpi( 'Visite completate', sum.visits ) + kpi( 'Totale speso', euro( sum.spent ) ) + kpi( 'No-show', sum.noshow ) + '</div>' +
				'<div class="bhc-tabs"><button type="button" class="is-active" data-tab="scheda">Scheda</button><button type="button" data-tab="storico">Storico (' + data.history.length + ')</button><button type="button" data-tab="incassi">Incassi (' + data.payments.length + ')</button>' + ( can( 'health' ) ? '<button type="button" data-tab="schede">Schede</button>' : '' ) + ( can( 'cards' ) || can( 'payments' ) ? '<button type="button" data-tab="card">Card</button>' : '' ) + '</div>' +
				'<div data-pane="scheda">' + tabScheda + '</div>' +
				'<div data-pane="storico" hidden>' + ( data.history.length ? '<table class="bhc-table"><thead><tr><th>Data</th><th>Trattamento</th><th>Cabina e operatrici</th><th>Stato</th><th>Prezzo</th></tr></thead><tbody>' + data.history.map( function ( h ) {
					return '<tr class="is-click" data-appt="' + h.id + '"><td>' + esc( h.date.split( '-' ).reverse().join( '/' ) + ' ' + h.start ) + '</td><td>' + esc( h.treatment_name ) + '</td><td>' + esc( h.staff_name ) + ( h.operators && h.operators.length ? ' · ' + esc( h.operators.map( function ( o ) {
						return o.name;
					} ).join( ' + ' ) ) : '' ) + '</td><td><span class="bhc-badge bhc-badge--' + h.status + '">' + esc( B.statuses[ h.status ] ) + '</span></td><td>' + euro( h.price ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table>' : '<p class="bhc-muted">Nessun appuntamento.</p>' ) + '</div>' +
				'<div data-pane="incassi" hidden>' + ( data.payments.length ? '<table class="bhc-table"><thead><tr><th>Data</th><th>Descrizione</th><th>Metodo</th><th>Importo</th></tr></thead><tbody>' + data.payments.map( function ( p ) {
					return '<tr><td>' + esc( p.paid_at.substring( 0, 10 ).split( '-' ).reverse().join( '/' ) ) + '</td><td>' + esc( p.description ) + '</td><td>' + esc( B.methods[ p.method ] || p.method ) + '</td><td>' + euro( p.amount ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table>' : '<p class="bhc-muted">Nessun incasso registrato.</p>' ) + '</div>' +
				'<div data-pane="card" hidden><div data-client-cards><div class="bhc-loading">Caricamento…</div></div></div>' +
				'<div data-pane="schede" hidden><div data-client-forms><div class="bhc-loading">Caricamento…</div></div></div>';
		}

		var foot = '<div>' + ( ! isNew ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-print>Stampa / PDF</button>' : '' ) +
			( ! isNew && can( 'clients_delete' ) ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-del-client>Elimina</button>' : '' ) +
			( ! isNew && can( 'agenda_edit' ) ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-book>+ Appuntamento</button>' : '' ) + '</div>' +
			'<div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Chiudi</button>' + ( canEdit || can( 'clients_notes' ) || can( 'health' ) ? '<button type="button" class="bhc-btn" data-save-client>Salva</button>' : '' ) + '</div>';

		var m = modal( isNew ? 'Nuova cliente' : ( c.first_name + ' ' + c.last_name ), body, foot, ! isNew );
		cfAttach( m, { cf: '[data-c="tax_code"]', first: '[data-c="first_name"]', last: '[data-c="last_name"]', birth: '[data-c="birth_date"]', gender: '[data-c="gender"]', place: '[data-c="birth_place"]' } );
		if ( ! isNew && ( can( 'cards' ) || can( 'payments' ) ) ) {
			clientCardsPane( m, c.id, c.first_name + ' ' + c.last_name );
		}
		if ( ! isNew && can( 'health' ) ) {
			clientFormsPane( m, c );
		}
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );

		m.querySelectorAll( '[data-tab]' ).forEach( function ( t ) {
			t.addEventListener( 'click', function () {
				m.querySelectorAll( '[data-tab]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === t );
				} );
				m.querySelectorAll( '[data-pane]' ).forEach( function ( p ) {
					p.hidden = p.dataset.pane !== t.dataset.tab;
				} );
			} );
		} );
		m.querySelectorAll( '[data-appt]' ).forEach( function ( r ) {
			r.addEventListener( 'click', function () {
				openAppointment( +r.dataset.appt );
			} );
		} );

		var saveBtn = m.querySelector( '[data-save-client]' );
		if ( saveBtn ) saveBtn.addEventListener( 'click', function () {
			var msg = m.querySelector( '[data-msg]' );
			var p = {};
			m.querySelectorAll( '[data-c]' ).forEach( function ( i ) {
				p[ i.dataset.c ] = i.value;
			} );
			var pc = m.querySelector( '[data-c-check="privacy_consent"]' );
			if ( pc && pc.checked && ! pc.disabled ) {
				p.privacy_consent = 1;
			}
			p.marketing_consent = m.querySelector( '[data-c-check="marketing_consent"]' ).checked ? 1 : 0;
			api( isNew ? 'clients' : 'clients/' + c.id, { method: isNew ? 'POST' : 'PUT', body: p } ).then( function () {
				closeModal();
				toast( 'Scheda salvata' );
				if ( S.view === 'clients' ) {
					loadClients();
				}
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );

		var pr = m.querySelector( '[data-print]' );
		if ( pr ) {
			pr.addEventListener( 'click', function () {
				m.querySelectorAll( '[data-pane]' ).forEach( function ( p ) {
					p.hidden = false;
				} );
				document.body.classList.add( 'bhc-printing' );
				window.print();
				document.body.classList.remove( 'bhc-printing' );
			} );
		}
		var dc = m.querySelector( '[data-del-client]' );
		if ( dc ) {
			dc.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Eliminare la scheda cliente? Gli appuntamenti e gli incassi restano ma senza nome.' ) ) {
					return;
				}
				api( 'clients/' + c.id, { method: 'DELETE' } ).then( function () {
					closeModal();
					toast( 'Cliente eliminata' );
					if ( S.view === 'clients' ) {
						loadClients();
					}
				} );
			} );
		}
		var bk = m.querySelector( '[data-book]' );
		if ( bk ) {
			bk.addEventListener( 'click', function () {
				var name = c.first_name + ' ' + c.last_name;
				openAppointment( null, { date: S.date } );
				setTimeout( function () {
					var mm = document.querySelector( '.bhc-modal' );
					mm.querySelector( '[data-client-id]' ).value = c.id;
					mm.querySelector( '[data-client-search]' ).value = name;
				}, 0 );
			} );
		}
	}

	/* ================= Cabine ================= */

	var WEEKDAYS = [ [ 1, 'Lunedì' ], [ 2, 'Martedì' ], [ 3, 'Mercoledì' ], [ 4, 'Giovedì' ], [ 5, 'Venerdì' ], [ 6, 'Sabato' ], [ 7, 'Domenica' ] ];
	var CABIN_COLORS = [ '#7d8c6f', '#b9805f', '#8a7aa8', '#5f8a92', '#c2a14d', '#a8687a', '#6d7f9e', '#8b6f5a' ];

	function bindCabinButtons( scope ) {
		scope.querySelectorAll( '[data-add-cabin]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function ( e ) {
				e.stopPropagation();
				cabinForm( null );
			} );
		} );
		scope.querySelectorAll( '[data-edit-cabin]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function ( e ) {
				e.stopPropagation();
				cabinForm( staffById( +b.dataset.editCabin ) );
			} );
		} );
	}

	function reloadCabins() {
		return api( 'cabins' ).then( function ( d ) {
			B.staff = d.items;
		} );
	}

	function treatmentNames( c ) {
		if ( ! c.treatments.length ) {
			return [ 'Tutti i trattamenti' ];
		}
		return c.treatments.map( function ( id ) {
			var t = treatmentById( id );
			return t ? t.name : null;
		} ).filter( Boolean );
	}

	function renderCabins() {
		var main = document.getElementById( 'bhc-main' );
		main.innerHTML = '<div class="bhc-top"><h2>Cabine</h2><div class="bhc-top__actions">' +
			( can( 'cabins' ) ? '<button type="button" class="bhc-btn bhc-btn--sm" data-add-cabin>' + ICONS.cabins + ' Nuova cabina</button>' : '' ) +
			'</div></div><div class="bhc-cabins">' +
			B.staff.map( function ( c ) {
				return '<div class="bhc-cabin" style="--cab:' + esc( c.color ) + '">' +
					'<div class="bhc-cabin__icon">' + ICONS.cabins + '</div>' +
					'<div class="bhc-cabin__body"><h3>' + esc( c.name ) + '</h3>' +
					'<div class="bhc-cabin__tags">' + treatmentNames( c ).map( function ( n ) {
						return '<span>' + esc( n ) + '</span>';
					} ).join( '' ) + '</div></div>' +
					( can( 'cabins' ) ? '<button type="button" class="bhc-icon-btn" data-edit-cabin="' + c.id + '" title="Modifica" aria-label="Modifica ' + esc( c.name ) + '">' + ICONS.edit + '</button>' : '' ) +
					'</div>';
			} ).join( '' ) +
			( can( 'cabins' ) ? '<button type="button" class="bhc-cabin bhc-cabin--add" data-add-cabin><div class="bhc-cabin__icon">' + ICONS.cabins + '<b>+</b></div><div class="bhc-cabin__body"><h3>Aggiungi cabina</h3><span class="bhc-muted">Nome, colore e trattamenti possibili</span></div></button>' : '' ) +
			'</div>' + ( ! B.staff.length && ! can( 'cabins' ) ? '<p class="bhc-muted">Nessuna cabina configurata.</p>' : '' );
		bindCabinButtons( main );
	}

	function cabinForm( c ) {
		var isNew = ! c;
		c = c || { name: '', color: CABIN_COLORS[ B.staff.length % CABIN_COLORS.length ], treatments: [], hours: {} };
		var cats = {};
		var order = [];
		B.treatments.forEach( function ( t ) {
			var k = t.category || 'Altri';
			if ( ! cats[ k ] ) {
				cats[ k ] = [];
				order.push( k );
			}
			cats[ k ].push( t );
		} );
		var allSelected = ! c.treatments.length;
		var body =
			'<div class="bhc-field"><label>Nome cabina</label><input type="text" data-cab-name value="' + esc( c.name ) + '" placeholder="Es. Cabina Viso, Cabina 2, Sala relax"></div>' +
			'<div class="bhc-field"><label>Colore in agenda</label><div class="bhc-swatches">' + CABIN_COLORS.map( function ( col ) {
				return '<button type="button" class="bhc-swatch' + ( col === c.color ? ' is-active' : '' ) + '" data-color="' + col + '" style="background:' + col + '" aria-label="Colore ' + col + '"></button>';
			} ).join( '' ) + '<input type="color" data-cab-color value="' + esc( c.color ) + '" title="Altro colore"></div></div>' +
			'<div class="bhc-field"><label>Trattamenti possibili in questa cabina</label>' +
			'<label class="bhc-check"><input type="checkbox" data-cab-all' + ( allSelected ? ' checked' : '' ) + '> <span><strong>Tutti i trattamenti</strong></span></label>' +
			'<div class="bhc-cab-treatments" data-cab-list' + ( allSelected ? ' hidden' : '' ) + '>' + order.map( function ( k ) {
				return '<div class="bhc-cat-title">' + esc( k ) + '</div>' + cats[ k ].map( function ( t ) {
					return '<label class="bhc-check"><input type="checkbox" data-cab-t="' + t.id + '"' + ( c.treatments.indexOf( t.id ) !== -1 ? ' checked' : '' ) + '> <span>' + esc( t.name ) + ' <span class="bhc-muted">· ' + t.duration + ' min</span></span></label>';
				} ).join( '' );
			} ).join( '' ) + '</div></div>' +
			'<details class="bhc-field"' + ( Object.keys( c.hours || {} ).some( function ( k ) {
				return String( c.hours[ k ] || '' ).trim();
			} ) ? ' open' : '' ) + '><summary>Orari particolari della cabina (facoltativo)</summary><p class="bhc-muted">Lascia vuoto per seguire gli orari del centro. Formato: 09:00-13:00, 14:00-19:00.</p>' +
			WEEKDAYS.map( function ( d ) {
				return '<div class="bhc-row" style="grid-template-columns:110px 1fr;align-items:center;margin-bottom:6px"><span>' + d[ 1 ] + '</span><input type="text" data-cab-h="' + d[ 0 ] + '" value="' + esc( ( c.hours || {} )[ d[ 0 ] ] || '' ) + '" placeholder="orari del centro"></div>';
			} ).join( '' ) + '</details>' +
			'<p class="bhc-msg" data-msg></p>';
		var foot = '<div>' + ( ! isNew ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cab-del>Elimina cabina</button>' : '' ) + '</div>' +
			'<div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Annulla</button><button type="button" class="bhc-btn" data-cab-save>' + ( isNew ? 'Crea cabina' : 'Salva' ) + '</button></div>';
		var m = modal( isNew ? 'Nuova cabina' : 'Modifica cabina', body, foot );
		var msg = m.querySelector( '[data-msg]' );
		var colorInput = m.querySelector( '[data-cab-color]' );
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
		m.querySelectorAll( '[data-color]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				colorInput.value = b.dataset.color;
				m.querySelectorAll( '[data-color]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === b );
				} );
			} );
		} );
		colorInput.addEventListener( 'input', function () {
			m.querySelectorAll( '[data-color]' ).forEach( function ( x ) {
				x.classList.remove( 'is-active' );
			} );
		} );
		m.querySelector( '[data-cab-all]' ).addEventListener( 'change', function () {
			m.querySelector( '[data-cab-list]' ).hidden = this.checked;
		} );
		m.querySelector( '[data-cab-name]' ).focus();

		function afterChange( text ) {
			closeModal();
			toast( text );
			reloadCabins().then( render );
		}

		m.querySelector( '[data-cab-save]' ).addEventListener( 'click', function () {
			var name = m.querySelector( '[data-cab-name]' ).value.trim();
			if ( ! name ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Inserisci il nome della cabina.';
				return;
			}
			var treatments = [];
			if ( ! m.querySelector( '[data-cab-all]' ).checked ) {
				m.querySelectorAll( '[data-cab-t]:checked' ).forEach( function ( i ) {
					treatments.push( +i.dataset.cabT );
				} );
				if ( ! treatments.length ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = 'Scegli almeno un trattamento, oppure "Tutti i trattamenti".';
					return;
				}
			}
			var hours = {};
			m.querySelectorAll( '[data-cab-h]' ).forEach( function ( i ) {
				hours[ i.dataset.cabH ] = i.value.trim();
			} );
			api( isNew ? 'cabins' : 'cabins/' + c.id, {
				method: isNew ? 'POST' : 'PUT',
				body: { name: name, color: colorInput.value, treatments: treatments, hours: hours }
			} ).then( function () {
				afterChange( isNew ? 'Cabina creata' : 'Cabina aggiornata' );
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );

		var del = m.querySelector( '[data-cab-del]' );
		if ( del ) {
			del.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Eliminare la cabina "' + c.name + '"?' ) ) {
					return;
				}
				api( 'cabins/' + c.id, { method: 'DELETE' } ).then( function () {
					afterChange( 'Cabina eliminata' );
				} ).catch( function ( e ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		}
	}

	/* ================= Operatrici / personale (modello PeopleHub) ================= */

	var P = { q: '', role: '', status: 'attivo', items: [], roles: {}, contracts: {} };
	var DOC_TYPES = [ 'Carta d\'identità', 'Passaporto', 'Patente', 'Tessera sanitaria', 'Certificato di idoneità', 'Diploma / qualifica estetista', 'Altro' ];
	var STATUS_LABEL = { attivo: 'Attivo', sospeso: 'Sospeso', cessato: 'Cessato' };

	function initials( p ) {
		return ( ( p.first_name || '' ).charAt( 0 ) + ( p.last_name || '' ).charAt( 0 ) ).toUpperCase();
	}
	function itDate( d ) {
		return d ? d.split( '-' ).reverse().join( '/' ) : '';
	}
	function rangeHours( str ) {
		return parseRanges( str ).reduce( function ( t, r ) {
			return t + ( r[ 1 ] - r[ 0 ] ) / 60;
		}, 0 );
	}

	function renderPeople() {
		var main = document.getElementById( 'bhc-main' );
		if ( HR.tab === 'cand' ) {
			renderCandidates( main );
			return;
		}
		if ( HR.tab === 'coll' ) {
			renderInterviews( main );
			return;
		}
		main.innerHTML = '<div class="bhc-top"><h2>Operatrici e personale</h2><div class="bhc-top__actions">' +
			'<input type="search" data-pq placeholder="Cerca nome, mansione, telefono…" value="' + esc( P.q ) + '" style="min-width:220px">' +
			'<select data-prole><option value="">Tutti i ruoli</option><option value="operatrice">Operatrici</option><option value="reception">Receptionist</option><option value="manager">Manager</option></select>' +
			'<select data-pstatus><option value="attivo">Attivi</option><option value="sospeso">Sospesi</option><option value="cessato">Cessati</option><option value="">Tutti</option></select>' +
			'<button type="button" class="bhc-btn bhc-btn--sm" data-new-person>' + ICONS.people + ' Nuova scheda</button></div></div>' + hrTabsHtml() +
			'<div data-plist><div class="bhc-loading">Caricamento…</div></div>';
		main.querySelector( '[data-prole]' ).value = P.role;
		main.querySelector( '[data-pstatus]' ).value = P.status;
		main.querySelector( '[data-pq]' ).addEventListener( 'input', debounce( function ( e ) {
			P.q = e.target.value;
			loadPeople();
		}, 300 ) );
		main.querySelector( '[data-prole]' ).addEventListener( 'change', function ( e ) {
			P.role = e.target.value;
			loadPeople();
		} );
		main.querySelector( '[data-pstatus]' ).addEventListener( 'change', function ( e ) {
			P.status = e.target.value;
			loadPeople();
		} );
		main.querySelector( '[data-new-person]' ).addEventListener( 'click', function () {
			personForm( null );
		} );
		hrBindTabs( main );
		loadPeople();
	}

	function loadPeople() {
		var box = document.querySelector( '[data-plist]' );
		if ( ! box ) {
			return;
		}
		api( 'people?q=' + encodeURIComponent( P.q ) + '&role=' + P.role + '&status=' + P.status ).then( function ( d ) {
			P.items = d.items;
			P.roles = d.roles;
			P.contracts = d.contracts;
			var counts = { operatrice: 0, reception: 0, manager: 0 };
			d.items.forEach( function ( p ) {
				counts[ p.role ] = ( counts[ p.role ] || 0 ) + 1;
			} );
			var alerts = d.items.reduce( function ( n, p ) {
				return n + p.alerts.length;
			}, 0 );
			box.innerHTML = '<div class="bhc-kpis">' + kpi( 'Operatrici', counts.operatrice ) + kpi( 'Receptionist', counts.reception ) + kpi( 'Manager', counts.manager ) + kpi( 'Scadenze da controllare', alerts ) + '</div>' +
				'<div class="bhc-people">' + d.items.map( function ( p ) {
					return '<button type="button" class="bhc-person" data-pid="' + p.id + '"' + ( p.status !== 'attivo' ? ' style="opacity:.6"' : '' ) + '>' +
						'<span class="bhc-person__avatar" style="background:' + esc( p.color ) + '">' + esc( initials( p ) ) + '</span>' +
						'<span class="bhc-person__body"><strong>' + esc( p.first_name + ' ' + p.last_name ) + '</strong>' +
						'<span class="bhc-muted">' + esc( p.job_title || P.roles[ p.role ] ) + '</span>' +
						'<span class="bhc-person__meta"><span class="bhc-role bhc-role--' + p.role + '">' + esc( P.roles[ p.role ] ) + '</span>' +
						( p.status !== 'attivo' ? '<span class="bhc-badge bhc-badge--cancelled">' + STATUS_LABEL[ p.status ] + '</span>' : '' ) +
						( p.account && p.account.active ? '<span class="bhc-badge bhc-badge--confirmed">Accesso attivo</span>' : '' ) + '</span>' +
						'<span class="bhc-muted" style="font-size:.85rem">' + esc( [ p.mobile || p.phone, p.email ].filter( Boolean ).join( ' · ' ) ) + '</span></span>' +
						( p.alerts.length ? '<span class="bhc-person__alert" title="' + esc( p.alerts.map( function ( a ) {
							return a.text;
						} ).join( '\n' ) ) + '">' + ICONS.alert + p.alerts.length + '</span>' : '' ) +
						'</button>';
				} ).join( '' ) +
				'<button type="button" class="bhc-person bhc-person--add" data-new-person><span class="bhc-person__avatar">' + ICONS.people + '<b>+</b></span><span class="bhc-person__body"><strong>Aggiungi persona</strong><span class="bhc-muted">Operatrice, receptionist o manager</span></span></button></div>';
			box.querySelectorAll( '[data-pid]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					api( 'people/' + b.dataset.pid ).then( personForm ).catch( function ( e ) {
						toast( e.message, true );
					} );
				} );
			} );
			box.querySelectorAll( '[data-new-person]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					personForm( null );
				} );
			} );
		} ).catch( function ( e ) {
			box.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	/** Esito dell'invio dell'accesso: link da copiare o mandare su WhatsApp se l'email non arriva. */
	function accessLinkBox( p, mail ) {
		var m = document.querySelector( '.bhc-modal' );
		if ( ! m || ! mail.link ) {
			return;
		}
		// Apre la scheda "Note e accesso".
		var tab = m.querySelector( '[data-ptab="acc"]' );
		if ( tab ) {
			tab.click();
		}
		var phone = ( p.mobile || p.phone || '' ).trim();
		var txt = 'Ciao ' + p.first_name + ', ecco il link per impostare la password del gestionale di ' + B.center + ' (utente: ' + mail.login + '). Vale 24 ore: ' + mail.link;
		var wa = phone && typeof BHC_waPhone === 'function' ? BHC_waPhone( phone ) : '';
		var box = document.createElement( 'div' );
		box.className = 'bhc-acclink ' + ( mail.sent ? 'is-ok' : 'is-err' );
		box.innerHTML = ( mail.sent
			? '<p><b>' + ICONS.check + ' Email inviata a ' + esc( mail.to ) + '.</b> Se non arriva entro qualche minuto controlla la cartella spam, oppure manda tu il link qui sotto.</p>'
			: '<p><b>L\'email non è partita.</b> Il server del sito ha risposto: <i>' + esc( mail.error || 'errore sconosciuto' ) + '</i>.<br>L\'accesso è stato creato: manda tu il link qui sotto a ' + esc( p.first_name ) + '. Per far partire le email del sito serve un plugin SMTP (es. «WP Mail SMTP») configurato con la casella email del centro.</p>' ) +
			'<div class="bhc-acclink__row"><input type="text" readonly value="' + esc( mail.link ) + '"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-copy>Copia link</button>' +
			( wa ? '<a class="bhc-btn bhc-btn--sm bhc-btn--wa" target="_blank" rel="noopener" href="https://wa.me/' + esc( wa ) + '?text=' + encodeURIComponent( txt ) + '">' + ICONS.whatsapp + 'Invia su WhatsApp</a>' : '' ) + '</div>';
		var target = m.querySelector( '[data-account]' );
		target = target ? target.closest( '.bhc-card' ) : m.querySelector( '.bhc-modal__body' );
		target.appendChild( box );
		box.querySelector( '[data-copy]' ).addEventListener( 'click', function () {
			var inp = box.querySelector( 'input' );
			inp.select();
			try {
				navigator.clipboard.writeText( inp.value ).then( function () {
					toast( 'Link copiato' );
				}, function () {
					document.execCommand( 'copy' );
					toast( 'Link copiato' );
				} );
			} catch ( e ) {
				document.execCommand( 'copy' );
				toast( 'Link copiato' );
			}
		} );
	}

	/** Numero per wa.me: aggiunge +39 ai numeri italiani senza prefisso. */
	function BHC_waPhone( raw ) {
		var s = String( raw || '' ).trim(), d = s.replace( /\D/g, '' );
		if ( ! d ) {
			return '';
		}
		if ( d.indexOf( '00' ) === 0 ) {
			return d.slice( 2 );
		}
		if ( s.charAt( 0 ) === '+' ) {
			return d;
		}
		return d.length <= 11 && d.indexOf( '39' ) !== 0 ? '39' + d : d;
	}

	function personForm( p ) {
		var isNew = ! p;
		p = p || {
			first_name: '', last_name: '', gender: '', birth_date: '', birth_place: '', nationality: 'Italiana', tax_code: '',
			address: '', city: '', zip: '', province: '', phone: '', mobile: '', email: '', emergency_name: '', emergency_phone: '',
			role: 'operatrice', job_title: '', status: 'attivo', contract_type: '', contract_level: '', hire_date: '', end_date: '',
			weekly_hours: '', iban: '', color: CABIN_COLORS[ P.items.length % CABIN_COLORS.length ], notes: '',
			documents: [], courses: [], schedule: {}, skills: [], alerts: [], account: null
		};

		function fld( name, label, type, extra ) {
			return '<div class="bhc-field"><label>' + label + '</label><input type="' + ( type || 'text' ) + '" data-p="' + name + '" value="' + esc( p[ name ] == null ? '' : p[ name ] ) + '"' + ( extra || '' ) + '></div>';
		}
		function sel( name, label, opts ) {
			return '<div class="bhc-field"><label>' + label + '</label><select data-p="' + name + '">' + Object.keys( opts ).map( function ( k ) {
				return '<option value="' + esc( k ) + '"' + ( String( p[ name ] ) === k ? ' selected' : '' ) + '>' + esc( opts[ k ] ) + '</option>';
			} ).join( '' ) + '</select></div>';
		}
		var contracts = { '': '—' };
		Object.keys( P.contracts ).forEach( function ( k ) {
			contracts[ k ] = P.contracts[ k ];
		} );

		var tabs = [
			[ 'anag', 'Anagrafica' ], [ 'cont', 'Contatti' ], [ 'lav', 'Contratto' ], [ 'skill', 'Competenze' ],
			[ 'doc', 'Documenti' ], [ 'corsi', 'Corsi e attestati' ], [ 'orari', 'Orari' ], [ 'acc', 'Note e accesso' ]
		];
		if ( ! isNew ) {
			tabs.push( [ 'coll', 'Colloqui' ] );
		}

		var anag =
			'<div class="bhc-row">' + fld( 'first_name', 'Nome *' ) + fld( 'last_name', 'Cognome *' ) + '</div>' +
			'<div class="bhc-row">' + sel( 'gender', 'Sesso', { '': '—', F: 'Femmina', M: 'Maschio', X: 'Altro / non specificato' } ) + fld( 'birth_date', 'Data di nascita', 'date' ) + '</div>' +
			'<div class="bhc-row">' + fld( 'birth_place', 'Luogo di nascita' ) + fld( 'nationality', 'Nazionalità' ) + '</div>' +
			'<div class="bhc-row">' + fld( 'tax_code', 'Codice fiscale', 'text', ' maxlength="16" style="text-transform:uppercase"' ) + '<div></div></div>';

		var cont =
			fld( 'address', 'Indirizzo di residenza' ) +
			'<div class="bhc-row" style="grid-template-columns:2fr 1fr 1fr">' + fld( 'city', 'Comune' ) + fld( 'zip', 'CAP', 'text', ' maxlength="5"' ) + fld( 'province', 'Provincia', 'text', ' maxlength="2" style="text-transform:uppercase"' ) + '</div>' +
			'<div class="bhc-row">' + fld( 'mobile', 'Cellulare', 'tel' ) + fld( 'phone', 'Telefono fisso', 'tel' ) + '</div>' +
			fld( 'email', 'Email', 'email' ) +
			'<h4 style="margin-top:12px">Contatto di emergenza</h4><div class="bhc-row">' + fld( 'emergency_name', 'Nome e parentela' ) + fld( 'emergency_phone', 'Telefono', 'tel' ) + '</div>';

		var lav =
			'<div class="bhc-row">' + sel( 'role', 'Ruolo nel centro', P.roles ) + fld( 'job_title', 'Mansione / qualifica', 'text', ' placeholder="Es. Estetista senior"' ) + '</div>' +
			'<div class="bhc-row">' + sel( 'status', 'Stato', STATUS_LABEL ) + sel( 'contract_type', 'Tipo di contratto', contracts ) + '</div>' +
			'<div class="bhc-row">' + fld( 'contract_level', 'Livello / CCNL' ) + fld( 'weekly_hours', 'Ore settimanali', 'number', ' min="0" max="60" step="0.5"' ) + '</div>' +
			'<div class="bhc-row">' + fld( 'hire_date', 'Data di assunzione', 'date' ) + fld( 'end_date', 'Data di fine rapporto', 'date' ) + '</div>' +
			'<div class="bhc-row">' + fld( 'iban', 'IBAN per lo stipendio', 'text', ' maxlength="34" style="text-transform:uppercase"' ) +
			'<div class="bhc-field"><label>Colore</label><div class="bhc-swatches">' + CABIN_COLORS.map( function ( col ) {
				return '<button type="button" class="bhc-swatch' + ( col === p.color ? ' is-active' : '' ) + '" data-pcolor="' + col + '" style="background:' + col + '" aria-label="Colore ' + col + '"></button>';
			} ).join( '' ) + '</div><input type="hidden" data-p="color" value="' + esc( p.color ) + '"></div></div>';

		var skill = '<p class="bhc-muted">Trattamenti che questa persona sa eseguire.</p><div class="bhc-skill-grid">' + B.treatments.map( function ( t ) {
			return '<label class="bhc-check"><input type="checkbox" data-skill="' + t.id + '"' + ( p.skills.indexOf( t.id ) !== -1 ? ' checked' : '' ) + '> <span>' + esc( t.name ) + '</span></label>';
		} ).join( '' ) + '</div>';

		function docRow( d ) {
			d = d || {};
			return '<div class="bhc-rowitem" data-doc><div class="bhc-rowitem__grid">' +
				'<div><label>Tipo</label><input type="text" list="bhc-doc-types" data-k="type" value="' + esc( d.type ) + '" placeholder="Es. Carta d\'identità"></div>' +
				'<div><label>Numero</label><input type="text" data-k="number" value="' + esc( d.number ) + '"></div>' +
				'<div><label>Rilascio</label><input type="date" data-k="issued" value="' + esc( d.issued ) + '"></div>' +
				'<div><label>Scadenza</label><input type="date" data-k="expires" value="' + esc( d.expires ) + '"></div>' +
				'<div class="bhc-rowitem__wide"><label>Note</label><input type="text" data-k="notes" value="' + esc( d.notes ) + '"></div>' +
				'</div><button type="button" class="bhc-rowitem__del" data-del-row aria-label="Rimuovi">&times;</button></div>';
		}
		function courseRow( c ) {
			c = c || {};
			return '<div class="bhc-rowitem" data-course><div class="bhc-rowitem__grid">' +
				'<div class="bhc-rowitem__wide"><label>Corso / attestato</label><input type="text" data-k="name" value="' + esc( c.name ) + '" placeholder="Es. Formazione sicurezza, HACCP, corso laser"></div>' +
				'<div><label>Ente</label><input type="text" data-k="provider" value="' + esc( c.provider ) + '"></div>' +
				'<div><label>Data</label><input type="date" data-k="date" value="' + esc( c.date ) + '"></div>' +
				'<div><label>Ore</label><input type="number" min="0" step="0.5" data-k="hours" value="' + esc( c.hours || '' ) + '"></div>' +
				'<div><label>Scadenza</label><input type="date" data-k="expires" value="' + esc( c.expires ) + '"></div>' +
				'<div style="display:flex;align-items:flex-end"><label class="bhc-check"><input type="checkbox" data-k="mandatory"' + ( c.mandatory ? ' checked' : '' ) + '> <span>Obbligatorio</span></label></div>' +
				'</div><button type="button" class="bhc-rowitem__del" data-del-row aria-label="Rimuovi">&times;</button></div>';
		}

		var doc = '<datalist id="bhc-doc-types">' + DOC_TYPES.map( function ( t ) {
			return '<option value="' + esc( t ) + '">';
		} ).join( '' ) + '</datalist><div data-doc-list>' + p.documents.map( docRow ).join( '' ) + '</div><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-add-doc>+ Aggiungi documento</button>';
		var corsi = '<div data-course-list>' + p.courses.map( courseRow ).join( '' ) + '</div><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-add-course>+ Aggiungi corso</button>';

		var orari = '<p class="bhc-muted">Turni settimanali. Formato: 09:00-13:00, 14:00-19:00. Vuoto = giorno libero.</p>' + WEEKDAYS.map( function ( d ) {
			return '<div class="bhc-row" style="grid-template-columns:110px 1fr 70px;align-items:center;margin-bottom:6px"><span>' + d[ 1 ] + '</span><input type="text" data-sched="' + d[ 0 ] + '" value="' + esc( ( p.schedule || {} )[ d[ 0 ] ] || '' ) + '" placeholder="libero"><span class="bhc-muted" data-sched-h="' + d[ 0 ] + '"></span></div>';
		} ).join( '' ) + '<p><strong>Totale: <span data-sched-total></span> ore/settimana</strong> <span class="bhc-muted" data-sched-cmp></span></p>';

		var acc = '<div class="bhc-field"><label>Note interne</label><textarea rows="4" data-p="notes">' + esc( p.notes ) + '</textarea></div>' +
			'<div class="bhc-card" style="background:#faf8f4;box-shadow:none"><h4>Accesso al gestionale</h4>' +
			( isNew ? '<p class="bhc-muted">Salva la scheda per poter creare l\'accesso.</p>' :
				( p.account ? '<p>Utente: <strong>' + esc( p.account.login ) + '</strong> (' + esc( p.account.email ) + ') · ' + ( p.account.active ? '<span class="bhc-badge bhc-badge--confirmed">attivo</span>' : '<span class="bhc-badge bhc-badge--cancelled">disattivato</span>' ) + '</p>' +
					'<p><button type="button" class="bhc-btn bhc-btn--sm" data-account>' + ( p.account.active ? 'Reinvia email per la password' : 'Riattiva accesso' ) + '</button> ' +
					( p.account.active ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-revoke>Disattiva accesso</button>' : '' ) + '</p>'
					: '<p class="bhc-muted">Crea un accesso con il ruolo scelto nella scheda (' + esc( P.roles[ p.role ] ) + '). Riceverà un\'email all\'indirizzo indicato per impostare la password.</p><p><button type="button" class="bhc-btn bhc-btn--sm" data-account>Crea accesso e invia email</button></p>' ) ) +
			'<p class="bhc-muted" style="margin:0">Operatrice: agenda e schede clienti · Receptionist: agenda, clienti, incassi · Manager: tutto, compresi personale, cabine e report.</p></div>';

		var panes = { anag: anag, cont: cont, lav: lav, skill: skill, doc: doc, corsi: corsi, orari: orari, acc: acc, coll: '<div data-hr-person><div class="bhc-loading">Caricamento…</div></div>' };
		var alertsHtml = p.alerts.length ? '<div class="bhc-alerts">' + p.alerts.map( function ( a ) {
			return '<div class="bhc-alert bhc-alert--' + a.level + '">' + ICONS.alert + '<span>' + esc( a.text ) + ' — ' + itDate( a.date ) + '</span></div>';
		} ).join( '' ) + '</div>' : '';

		var head = isNew ? '' : '<div class="bhc-person-head"><span class="bhc-person__avatar bhc-person__avatar--lg" style="background:' + esc( p.color ) + '">' + esc( initials( p ) ) + '</span><div><div class="bhc-muted">' + esc( P.roles[ p.role ] ) + ( p.job_title ? ' · ' + esc( p.job_title ) : '' ) + '</div><div class="bhc-muted">' + ( p.hire_date ? 'In servizio dal ' + itDate( p.hire_date ) : '' ) + '</div></div></div>';

		var body = head + alertsHtml + '<div class="bhc-tabs">' + tabs.map( function ( t, i ) {
			return '<button type="button" data-ptab="' + t[ 0 ] + '"' + ( i === 0 ? ' class="is-active"' : '' ) + '>' + t[ 1 ] + '</button>';
		} ).join( '' ) + '</div>' + tabs.map( function ( t, i ) {
			return '<div data-ppane="' + t[ 0 ] + '"' + ( i ? ' hidden' : '' ) + '>' + panes[ t[ 0 ] ] + '</div>';
		} ).join( '' ) + '<p class="bhc-msg" data-msg></p>';

		var foot = '<div>' + ( ! isNew ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pprint>' + ICONS.print + ' Stampa / PDF</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pdel>Elimina</button>' : '' ) + '</div>' +
			'<div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Chiudi</button><button type="button" class="bhc-btn" data-psave>' + ( isNew ? 'Crea scheda' : 'Salva' ) + '</button></div>';

		var m = modal( isNew ? 'Nuova scheda personale' : p.first_name + ' ' + p.last_name, body, foot, true );
		if ( ! isNew ) {
			hrPersonPane( m, p );
		}
		cfAttach( m, { cf: '[data-p="tax_code"]', first: '[data-p="first_name"]', last: '[data-p="last_name"]', birth: '[data-p="birth_date"]', gender: '[data-p="gender"]', place: '[data-p="birth_place"]' } );
		var msg = m.querySelector( '[data-msg]' );
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );

		m.querySelectorAll( '[data-ptab]' ).forEach( function ( t ) {
			t.addEventListener( 'click', function () {
				m.querySelectorAll( '[data-ptab]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === t );
				} );
				m.querySelectorAll( '[data-ppane]' ).forEach( function ( x ) {
					x.hidden = x.dataset.ppane !== t.dataset.ptab;
				} );
			} );
		} );
		m.querySelectorAll( '[data-pcolor]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				m.querySelector( '[data-p="color"]' ).value = b.dataset.pcolor;
				m.querySelectorAll( '[data-pcolor]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === b );
				} );
			} );
		} );
		function bindDel( scope ) {
			scope.querySelectorAll( '[data-del-row]' ).forEach( function ( b ) {
				b.onclick = function () {
					b.closest( '.bhc-rowitem' ).remove();
				};
			} );
		}
		bindDel( m );
		m.querySelector( '[data-add-doc]' ).addEventListener( 'click', function () {
			m.querySelector( '[data-doc-list]' ).insertAdjacentHTML( 'beforeend', docRow() );
			bindDel( m );
		} );
		m.querySelector( '[data-add-course]' ).addEventListener( 'click', function () {
			m.querySelector( '[data-course-list]' ).insertAdjacentHTML( 'beforeend', courseRow() );
			bindDel( m );
		} );

		function updateHours() {
			var tot = 0;
			m.querySelectorAll( '[data-sched]' ).forEach( function ( i ) {
				var h = rangeHours( i.value );
				tot += h;
				m.querySelector( '[data-sched-h="' + i.dataset.sched + '"]' ).textContent = h ? h + ' h' : '';
			} );
			m.querySelector( '[data-sched-total]' ).textContent = tot;
			var contract = parseFloat( m.querySelector( '[data-p="weekly_hours"]' ).value ) || 0;
			m.querySelector( '[data-sched-cmp]' ).textContent = contract && tot && contract !== tot ? '(da contratto: ' + contract + ' h)' : '';
		}
		m.querySelectorAll( '[data-sched]' ).forEach( function ( i ) {
			i.addEventListener( 'input', updateHours );
		} );
		updateHours();

		function collect() {
			var d = {};
			m.querySelectorAll( '[data-p]' ).forEach( function ( i ) {
				d[ i.dataset.p ] = i.value;
			} );
			d.skills = [];
			m.querySelectorAll( '[data-skill]:checked' ).forEach( function ( i ) {
				d.skills.push( +i.dataset.skill );
			} );
			function rows( selector ) {
				var out = [];
				m.querySelectorAll( selector ).forEach( function ( row ) {
					var o = {};
					row.querySelectorAll( '[data-k]' ).forEach( function ( i ) {
						o[ i.dataset.k ] = i.type === 'checkbox' ? ( i.checked ? 1 : 0 ) : i.value;
					} );
					out.push( o );
				} );
				return out;
			}
			d.documents = rows( '[data-doc]' );
			d.courses = rows( '[data-course]' );
			d.schedule = {};
			m.querySelectorAll( '[data-sched]' ).forEach( function ( i ) {
				d.schedule[ i.dataset.sched ] = i.value.trim();
			} );
			return d;
		}

		m.querySelector( '[data-psave]' ).addEventListener( 'click', function () {
			var d = collect();
			if ( ! d.first_name.trim() || ! d.last_name.trim() ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Nome e cognome sono obbligatori.';
				m.querySelector( '[data-ptab="anag"]' ).click();
				return;
			}
			if ( d.tax_code && ! /^[A-Za-z0-9]{16}$/.test( d.tax_code.trim() ) ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Il codice fiscale deve avere 16 caratteri.';
				m.querySelector( '[data-ptab="anag"]' ).click();
				return;
			}
			api( isNew ? 'people' : 'people/' + p.id, { method: isNew ? 'POST' : 'PUT', body: d } ).then( function ( saved ) {
				toast( isNew ? 'Scheda creata' : 'Scheda salvata' );
				loadPeople();
				personForm( saved );
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );

		var accBtn = m.querySelector( '[data-account]' );
		if ( accBtn ) {
			accBtn.addEventListener( 'click', function () {
				accBtn.disabled = true;
				api( 'people/' + p.id + '/account', { method: 'POST' } ).then( function ( saved ) {
					var mail = saved.mail || {};
					loadPeople();
					personForm( saved );
					if ( mail.sent ) {
						toast( 'Email per l\'accesso inviata a ' + mail.to );
					} else {
						toast( 'Accesso creato, ma l\'email non è partita', true );
					}
					accessLinkBox( saved, mail );
				} ).catch( function ( e ) {
					accBtn.disabled = false;
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		}
		var rev = m.querySelector( '[data-revoke]' );
		if ( rev ) {
			rev.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Disattivare l\'accesso al gestionale di ' + p.first_name + '?' ) ) {
					return;
				}
				api( 'people/' + p.id + '/revoke', { method: 'POST' } ).then( function ( saved ) {
					toast( 'Accesso disattivato' );
					loadPeople();
					personForm( saved );
				} ).catch( function ( e ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		}
		var del = m.querySelector( '[data-pdel]' );
		if ( del ) {
			del.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Eliminare definitivamente la scheda di ' + p.first_name + ' ' + p.last_name + '? Per chi lascia il centro è meglio impostare lo stato "Cessato".' ) ) {
					return;
				}
				api( 'people/' + p.id, { method: 'DELETE' } ).then( function () {
					closeModal();
					toast( 'Scheda eliminata' );
					loadPeople();
				} );
			} );
		}
		var pr = m.querySelector( '[data-pprint]' );
		if ( pr ) {
			pr.addEventListener( 'click', function () {
				printPerson( p );
			} );
		}
	}

	/**
	 * Scheda dipendente stampabile / salvabile in PDF (nuova finestra).
	 */
	function printPerson( p ) {
		function row( label, value ) {
			return value ? '<tr><th>' + esc( label ) + '</th><td>' + esc( value ) + '</td></tr>' : '';
		}
		var skills = p.skills.map( function ( id ) {
			var t = treatmentById( id );
			return t ? t.name : '';
		} ).filter( Boolean ).join( ', ' );
		var sched = WEEKDAYS.map( function ( d ) {
			return '<tr><th>' + d[ 1 ] + '</th><td>' + esc( ( p.schedule || {} )[ d[ 0 ] ] || 'libero' ) + '</td></tr>';
		} ).join( '' );
		var html = '<!doctype html><html lang="it"><head><meta charset="utf-8"><title>Scheda ' + esc( p.first_name + ' ' + p.last_name ) + '</title><style>' +
			'body{font-family:Helvetica,Arial,sans-serif;color:#3b3a36;margin:28px;font-size:12px}h1{font-family:Georgia,serif;font-weight:normal;font-size:26px;margin:0}' +
			'h2{font-family:Georgia,serif;font-weight:normal;font-size:16px;border-bottom:2px solid ' + esc( p.color ) + ';padding-bottom:4px;margin:22px 0 8px}' +
			'.head{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:1px solid #ddd;padding-bottom:12px}.muted{color:#7a776f}' +
			'table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:5px 6px;border-bottom:1px solid #eee;vertical-align:top}th{width:32%;color:#7a776f;font-weight:normal}' +
			'.cols{display:grid;grid-template-columns:1fr 1fr;gap:24px}.list th{width:auto}.alert{color:#b55448}@page{margin:14mm}' +
			'</style></head><body>' +
			'<div class="head"><div><div class="muted">' + esc( B.center ) + ' — Scheda personale</div><h1>' + esc( p.first_name + ' ' + p.last_name ) + '</h1><div>' + esc( P.roles[ p.role ] ) + ( p.job_title ? ' · ' + esc( p.job_title ) : '' ) + ' · ' + esc( STATUS_LABEL[ p.status ] ) + '</div></div><div class="muted">Stampata il ' + new Date().toLocaleDateString( 'it-IT' ) + '</div></div>' +
			'<div class="cols"><div><h2>Anagrafica</h2><table>' + row( 'Sesso', { F: 'Femmina', M: 'Maschio', X: 'Altro' }[ p.gender ] ) + row( 'Data di nascita', itDate( p.birth_date ) ) + row( 'Luogo di nascita', p.birth_place ) + row( 'Nazionalità', p.nationality ) + row( 'Codice fiscale', p.tax_code ) + '</table>' +
			'<h2>Contatti</h2><table>' + row( 'Indirizzo', [ p.address, [ p.zip, p.city, p.province ? '(' + p.province + ')' : '' ].filter( Boolean ).join( ' ' ) ].filter( Boolean ).join( ', ' ) ) + row( 'Cellulare', p.mobile ) + row( 'Telefono', p.phone ) + row( 'Email', p.email ) + row( 'Emergenza', [ p.emergency_name, p.emergency_phone ].filter( Boolean ).join( ' — ' ) ) + '</table></div>' +
			'<div><h2>Rapporto di lavoro</h2><table>' + row( 'Contratto', P.contracts[ p.contract_type ] ) + row( 'Livello / CCNL', p.contract_level ) + row( 'Ore settimanali', p.weekly_hours ? String( p.weekly_hours ) : '' ) + row( 'Assunzione', itDate( p.hire_date ) ) + row( 'Fine rapporto', itDate( p.end_date ) ) + row( 'IBAN', p.iban ) + '</table>' +
			'<h2>Orari</h2><table>' + sched + '</table></div></div>' +
			( skills ? '<h2>Competenze</h2><p>' + esc( skills ) + '</p>' : '' ) +
			'<h2>Documenti</h2>' + ( p.documents.length ? '<table class="list"><tr><th>Tipo</th><th>Numero</th><th>Rilascio</th><th>Scadenza</th><th>Note</th></tr>' + p.documents.map( function ( d ) {
				return '<tr><td>' + esc( d.type ) + '</td><td>' + esc( d.number ) + '</td><td>' + itDate( d.issued ) + '</td><td>' + itDate( d.expires ) + '</td><td>' + esc( d.notes ) + '</td></tr>';
			} ).join( '' ) + '</table>' : '<p class="muted">Nessun documento registrato.</p>' ) +
			'<h2>Corsi e attestati</h2>' + ( p.courses.length ? '<table class="list"><tr><th>Corso</th><th>Ente</th><th>Data</th><th>Ore</th><th>Scadenza</th></tr>' + p.courses.map( function ( c ) {
				return '<tr><td>' + esc( c.name ) + ( c.mandatory ? ' (obbl.)' : '' ) + '</td><td>' + esc( c.provider ) + '</td><td>' + itDate( c.date ) + '</td><td>' + esc( c.hours || '' ) + '</td><td>' + itDate( c.expires ) + '</td></tr>';
			} ).join( '' ) + '</table>' : '<p class="muted">Nessun corso registrato.</p>' ) +
			( p.alerts.length ? '<h2>Scadenze</h2>' + p.alerts.map( function ( a ) {
				return '<p class="alert">' + esc( a.text ) + ' — ' + itDate( a.date ) + '</p>';
			} ).join( '' ) : '' ) +
			( p.notes ? '<h2>Note</h2><p>' + esc( p.notes ).replace( /\n/g, '<br>' ) + '</p>' : '' ) +
			'<script>window.onload=function(){window.print();}<\/script></body></html>';
		var w = window.open( '', '_blank' );
		if ( ! w ) {
			toast( 'Consenti le finestre popup per stampare la scheda.', true );
			return;
		}
		w.document.open();
		w.document.write( html );
		w.document.close();
	}

	/* ================= Trattamenti: elenco e scheda completa ================= */

	var T = { q: '', cat: '', data: null };

	function refreshTreatmentsCache( list ) {
		B.treatments = list.map( function ( t ) {
			return t;
		} );
	}

	function renderTreatments() {
		var main = document.getElementById( 'bhc-main' );
		main.innerHTML = '<div class="bhc-top"><h2>Trattamenti</h2><div class="bhc-top__actions">' +
			'<input type="search" data-tq placeholder="Cerca trattamento…" value="' + esc( T.q ) + '" style="min-width:200px">' +
			'<select data-tcat><option value="">Tutte le categorie</option></select>' +
			'<button type="button" class="bhc-btn bhc-btn--sm" data-tnew>' + ICONS.treatments + ' Nuovo trattamento</button></div></div><div data-tlist><div class="bhc-loading">Caricamento…</div></div>';
		main.querySelector( '[data-tq]' ).addEventListener( 'input', debounce( function ( e ) {
			T.q = e.target.value;
			drawTreatments();
		}, 200 ) );
		main.querySelector( '[data-tcat]' ).addEventListener( 'change', function ( e ) {
			if ( e.target.value === '__new' ) {
				e.target.value = T.cat;
				categoryForm( null );
				return;
			}
			T.cat = e.target.value;
			drawTreatments();
		} );
		main.querySelector( '[data-tnew]' ).addEventListener( 'click', function () {
			if ( T.data ) {
				treatmentForm( null );
			}
		} );
		api( 'treatments' ).then( function ( d ) {
			T.data = d;
			refreshTreatmentsCache( d.items );
			var sel = main.querySelector( '[data-tcat]' );
			if ( T.cat && d.categories.indexOf( T.cat ) === -1 ) {
				T.cat = '';
			}
			sel.innerHTML = '<option value="">Tutte le categorie</option>' + d.categories.map( function ( c ) {
				return '<option' + ( c === T.cat ? ' selected' : '' ) + '>' + esc( c ) + '</option>';
			} ).join( '' ) + '<option value="__new">+ Nuova categoria…</option>';
			drawTreatments();
		} ).catch( function ( e ) {
			main.querySelector( '[data-tlist]' ).innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function drawTreatments() {
		var box = document.querySelector( '[data-tlist]' );
		if ( ! box || ! T.data ) {
			return;
		}
		var d = T.data;
		var people = {}, cabins = {};
		d.people.forEach( function ( p ) {
			people[ p.id ] = p;
		} );
		d.cabins.forEach( function ( c ) {
			cabins[ c.id ] = c;
		} );
		var q = T.q.trim().toLowerCase();
		var list = d.items.filter( function ( t ) {
			return ( ! T.cat || t.category === T.cat ) && ( ! q || ( t.name + ' ' + t.description + ' ' + t.category ).toLowerCase().indexOf( q ) !== -1 );
		} );
		var groups = {}, order = [];
		list.forEach( function ( t ) {
			var c = t.category || 'Senza categoria';
			if ( ! groups[ c ] ) {
				groups[ c ] = [];
				order.push( c );
			}
			groups[ c ].push( t );
		} );
		function chips( ids, map, empty ) {
			if ( ! ids.length ) {
				return '<span class="bhc-muted">' + empty + '</span>';
			}
			return ids.map( function ( id ) {
				var x = map[ id ];
				return x ? '<span class="bhc-chip"><i style="background:' + esc( x.color ) + '"></i>' + esc( x.name.split( ' (' )[ 0 ] ) + '</span>' : '';
			} ).join( '' );
		}
		var html = '<div class="bhc-kpis">' + kpi( 'Trattamenti', d.items.length ) + kpi( 'Prenotabili online', d.items.filter( function ( t ) {
			return t.online;
		} ).length ) + kpi( 'A due operatrici', d.items.filter( function ( t ) {
			return t.staff_needed === 2;
		} ).length ) + kpi( 'Categorie', d.categories.length ) + '</div>';
		var info = {};
		( d.category_info || [] ).forEach( function ( c ) {
			info[ c.name ] = c;
		} );
		if ( T.cat && info[ T.cat ] ) {
			var ci = info[ T.cat ];
			html += '<div class="bhc-catpanel"><div class="bhc-catpanel__head"><h3>' + esc( ci.name ) + '</h3><span class="bhc-muted">' + ci.count + ' trattament' + ( ci.count === 1 ? 'o' : 'i' ) + '</span>' +
				'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cat-edit="' + ci.id + '">' + ICONS.edit + ' Modifica categoria</button></div>' +
				'<div class="bhc-catpanel__desc">' + ( ci.description ? esc( ci.description ).replace( /\n/g, '<br>' ) : '<span class="bhc-muted">Nessuna descrizione. <a href="#" data-cat-edit="' + ci.id + '">Aggiungila</a>: compare anche nel listino del sito.</span>' ) + '</div></div>';
		}
		if ( ! list.length ) {
			html += '<div class="bhc-card bhc-muted">Nessun trattamento ' + ( T.cat ? 'in questa categoria. <a href="#" data-tnew>Aggiungine uno</a>.' : 'trovato.' ) + '</div>';
		}
		order.forEach( function ( cat ) {
			var gi = info[ cat ];
			html += ( T.cat ? '' : '<h3 class="bhc-tgroup">' + esc( cat ) + ' <span class="bhc-muted">(' + groups[ cat ].length + ')</span>' + ( gi ? ' <button type="button" class="bhc-icon-btn bhc-icon-btn--sm" data-cat-edit="' + gi.id + '" title="Modifica categoria" aria-label="Modifica categoria ' + esc( cat ) + '">' + ICONS.edit + '</button>' : '' ) + '</h3>' +
				( gi && gi.description ? '<details class="bhc-tgroup__desc"><summary>Descrizione</summary><p>' + esc( gi.description ).replace( /\n/g, '<br>' ) + '</p></details>' : '' ) ) + '<div class="bhc-tcards">' + groups[ cat ].map( function ( t ) {
				var allCabins = t.cabins.length === d.cabins.length;
				return '<button type="button" class="bhc-tcard" data-tid="' + t.id + '">' +
					'<span class="bhc-tcard__img"' + ( t.thumb ? ' style="background-image:url(' + esc( t.thumb ) + ')"' : '' ) + '>' + ( t.thumb ? '' : ICONS.treatments ) + '</span>' +
					'<span class="bhc-tcard__body"><span class="bhc-tcard__head"><strong>' + esc( t.name ) + '</strong><span class="bhc-tcard__price">' + euro( t.price ) + '</span></span>' +
					'<span class="bhc-muted bhc-tcard__desc">' + esc( t.description || '' ) + '</span>' +
					'<span class="bhc-tcard__meta"><span class="bhc-pill">⏱ ' + t.duration + ' min</span><span class="bhc-need bhc-need--' + t.staff_needed + '">' + ( t.staff_needed === 2 ? '👥 2 operatrici' : '👤 1 operatrice' ) + '</span>' +
					( t.online ? '<span class="bhc-pill bhc-pill--ok">Online</span>' : '<span class="bhc-pill bhc-pill--off">Solo in sede</span>' ) + '</span>' +
					'<span class="bhc-tcard__row"><span class="bhc-tcard__label">Operatrici</span>' + chips( t.people, people, 'tutte' ) + '</span>' +
					'<span class="bhc-tcard__row"><span class="bhc-tcard__label">Cabine</span>' + ( allCabins ? '<span class="bhc-muted">tutte</span>' : chips( t.cabins, cabins, 'nessuna' ) ) + '</span>' +
					'</span></button>';
			} ).join( '' ) + '</div>';
		} );
		html += '<button type="button" class="bhc-cabin bhc-cabin--add" data-tnew style="margin-top:16px;max-width:420px"><div class="bhc-cabin__icon">' + ICONS.treatments + '<b>+</b></div><div class="bhc-cabin__body"><h3>Aggiungi trattamento</h3><span class="bhc-muted">Nome, durata, prezzo, operatrici e cabine</span></div></button>';
		box.innerHTML = html;
		box.querySelectorAll( '[data-tid]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				treatmentForm( d.items.filter( function ( x ) {
					return x.id === +b.dataset.tid;
				} )[ 0 ] );
			} );
		} );
		box.querySelectorAll( '[data-tnew]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				treatmentForm( null );
			} );
		} );
		box.querySelectorAll( '[data-cat-edit]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				categoryForm( ( d.category_info || [] ).filter( function ( c ) {
					return c.id === +b.dataset.catEdit;
				} )[ 0 ] );
			} );
		} );
	}

	/** Scheda categoria: nome e descrizione. */
	function categoryForm( c ) {
		var isNew = ! c;
		c = c || { name: '', description: '', count: 0 };
		var body = '<div class="bhc-field"><label>Nome della categoria *</label><input type="text" data-cname value="' + esc( c.name ) + '" placeholder="Es. Trattamenti viso, Epilazione, Benessere"></div>' +
			'<div class="bhc-field"><label>Descrizione <span class="bhc-muted" data-ccount></span></label><textarea rows="6" maxlength="600" data-cdesc placeholder="Presenta la categoria: a chi è rivolta, benefici, prodotti utilizzati… Compare nel gestionale e sopra i trattamenti nel listino del sito.">' + esc( c.description ) + '</textarea></div>' +
			( ! isNew ? '<p class="bhc-muted">' + c.count + ' trattament' + ( c.count === 1 ? 'o' : 'i' ) + ' in questa categoria.</p>' : '' ) +
			'<p class="bhc-msg" data-msg></p>';
		var foot = '<div>' + ( ! isNew ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cdel>Elimina</button>' : '' ) + '</div>' +
			'<div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Annulla</button><button type="button" class="bhc-btn" data-csave>' + ( isNew ? 'Crea categoria' : 'Salva' ) + '</button></div>';
		var m = modal( isNew ? 'Nuova categoria' : 'Categoria: ' + c.name, body, foot );
		var msg = m.querySelector( '[data-msg]' );
		var desc = m.querySelector( '[data-cdesc]' );
		var counter = m.querySelector( '[data-ccount]' );
		function count() {
			counter.textContent = '(' + desc.value.length + '/600)';
		}
		desc.addEventListener( 'input', count );
		count();
		m.querySelector( '[data-cname]' ).focus();
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
		m.querySelector( '[data-csave]' ).addEventListener( 'click', function () {
			var name = m.querySelector( '[data-cname]' ).value.trim();
			msg.className = 'bhc-msg';
			msg.textContent = '';
			if ( ! name ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Inserisci il nome della categoria.';
				return;
			}
			api( isNew ? 'categories' : 'categories/' + c.id, { method: isNew ? 'POST' : 'PUT', body: { name: name, description: desc.value.trim() } } ).then( function ( saved ) {
				closeModal();
				toast( isNew ? 'Categoria creata' : 'Categoria salvata' );
				T.cat = saved.name;
				renderTreatments();
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
		var del = m.querySelector( '[data-cdel]' );
		if ( del ) {
			del.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Eliminare la categoria "' + c.name + '"?' ) ) {
					return;
				}
				api( 'categories/' + c.id, { method: 'DELETE' } ).then( function () {
					closeModal();
					toast( 'Categoria eliminata' );
					T.cat = '';
					renderTreatments();
				} ).catch( function ( e ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		}
	}

	function treatmentForm( t ) {
		var d = T.data;
		var isNew = ! t;
		t = t || {
			name: '', category: T.cat || ( d.categories[ 0 ] || '' ), description: '', duration: 60, buffer: 10, price: '', online: true,
			staff_needed: 1, people: [], cabins: d.cabins.map( function ( c ) {
				return c.id;
			} ), thumb: '', image_id: 0
		};
		var roles = { operatrice: 'Operatrice', reception: 'Receptionist', manager: 'Manager' };
		var pendingFile = null;
		var removeImage = false;

		var catOptions = d.categories.map( function ( c ) {
			return '<option' + ( c === t.category ? ' selected' : '' ) + '>' + esc( c ) + '</option>';
		} ).join( '' );

		var left =
			'<div class="bhc-tphoto" data-tphoto' + ( t.thumb ? ' style="background-image:url(' + esc( t.thumb ) + ')"' : '' ) + '>' + ( t.thumb ? '' : '<span>' + ICONS.treatments + '<br>Nessuna foto</span>' ) + '</div>' +
			'<div class="bhc-tphoto__actions"><label class="bhc-btn bhc-btn--ghost bhc-btn--sm" style="cursor:pointer">Carica foto<input type="file" accept="image/jpeg,image/png,image/webp" data-tfile hidden></label>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-tnoimg' + ( t.thumb ? '' : ' hidden' ) + '>Rimuovi</button></div>' +
			'<div class="bhc-field"><label>Nome del trattamento *</label><input type="text" data-tf="name" value="' + esc( t.name ) + '" placeholder="Es. Pulizia viso profonda"></div>' +
			'<div class="bhc-field"><label>Categoria</label><select data-tcatsel><option value="">— nessuna —</option>' + catOptions + '<option value="__new">+ Nuova categoria…</option></select>' +
			'<input type="text" data-tnewcat placeholder="Nome nuova categoria" hidden style="margin-top:8px"></div>' +
			'<div class="bhc-field"><label>Descrizione <span class="bhc-muted" data-tcount></span></label><textarea rows="4" maxlength="300" data-tf="description" placeholder="Cosa comprende, a chi è indicato… (si vede nel listino e nella prenotazione online)">' + esc( t.description ) + '</textarea></div>';

		var right =
			'<div class="bhc-tsection"><h4>Tempi e prezzo</h4>' +
			'<div class="bhc-field"><label>Durata</label><div class="bhc-durations">' + [ 15, 30, 45, 60, 75, 90, 120 ].map( function ( m ) {
				return '<button type="button" data-tdur="' + m + '"' + ( +t.duration === m ? ' class="is-active"' : '' ) + '>' + m + '′</button>';
			} ).join( '' ) + '<input type="number" min="5" step="5" data-tf="duration" value="' + esc( t.duration ) + '" title="Minuti"></div></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Prezzo (€)</label><input type="number" min="0" step="0.5" data-tf="price" value="' + esc( t.price ) + '"></div>' +
			'<div class="bhc-field"><label>Riordino cabina (min)</label><input type="number" min="0" step="5" data-tf="buffer" value="' + esc( t.buffer ) + '"></div></div>' +
			'<label class="bhc-switch"><input type="checkbox" data-tonline' + ( t.online ? ' checked' : '' ) + '><span></span> Prenotabile online</label></div>' +

			'<div class="bhc-tsection"><h4>Operatrici</h4>' +
			'<div class="bhc-need-pick"><label><input type="radio" name="bhc-need" value="1"' + ( t.staff_needed !== 2 ? ' checked' : '' ) + '><span>👤 1 operatrice</span></label>' +
			'<label><input type="radio" name="bhc-need" value="2"' + ( t.staff_needed === 2 ? ' checked' : '' ) + '><span>👥 2 operatrici</span><small>contemporaneamente</small></label></div>' +
			'<p class="bhc-muted" style="margin:10px 0 6px">Chi può eseguirlo (nessuna selezione = tutte le operatrici)</p>' +
			( d.people.length ? '<div class="bhc-skill-grid">' + d.people.map( function ( p ) {
				return '<label class="bhc-check"><input type="checkbox" data-tperson="' + p.id + '"' + ( t.people.indexOf( p.id ) !== -1 ? ' checked' : '' ) + '> <span><i class="bhc-dot" style="background:' + esc( p.color ) + '"></i>' + esc( p.name ) + ' <span class="bhc-muted">· ' + roles[ p.role ] + '</span></span></label>';
			} ).join( '' ) + '</div>' : '<p class="bhc-muted">Nessuna persona registrata nella sezione Operatrici.</p>' ) + '</div>' +

			'<div class="bhc-tsection"><h4>Cabine</h4>' +
			( d.cabins.length ? '<div class="bhc-skill-grid">' + d.cabins.map( function ( c ) {
				return '<label class="bhc-check"><input type="checkbox" data-tcabin="' + c.id + '"' + ( t.cabins.indexOf( c.id ) !== -1 ? ' checked' : '' ) + '> <span><i class="bhc-dot" style="background:' + esc( c.color ) + '"></i>' + esc( c.name ) + '</span></label>';
			} ).join( '' ) + '</div>' : '<p class="bhc-muted">Nessuna cabina: aggiungile dalla sezione Cabine.</p>' ) + '</div>';

		var body = '<div class="bhc-tform"><div>' + left + '</div><div>' + right + '</div></div><p class="bhc-msg" data-msg></p>';
		var foot = '<div>' + ( ! isNew ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-tdel>Elimina</button>' : '' ) + '</div>' +
			'<div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Annulla</button><button type="button" class="bhc-btn" data-tsave>' + ( isNew ? 'Crea trattamento' : 'Salva' ) + '</button></div>';
		var m = modal( isNew ? 'Nuovo trattamento' : t.name, body, foot, true );
		var msg = m.querySelector( '[data-msg]' );
		var tf = function ( n ) {
			return m.querySelector( '[data-tf="' + n + '"]' );
		};
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
		tf( 'name' ).focus();

		// Categoria nuova.
		var catSel = m.querySelector( '[data-tcatsel]' ), newCat = m.querySelector( '[data-tnewcat]' );
		catSel.addEventListener( 'change', function () {
			newCat.hidden = catSel.value !== '__new';
			if ( ! newCat.hidden ) {
				newCat.focus();
			}
		} );
		// Contatore descrizione.
		var desc = tf( 'description' ), counter = m.querySelector( '[data-tcount]' );
		function count() {
			counter.textContent = '(' + desc.value.length + '/300)';
		}
		desc.addEventListener( 'input', count );
		count();
		// Durata rapida.
		m.querySelectorAll( '[data-tdur]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				tf( 'duration' ).value = b.dataset.tdur;
				m.querySelectorAll( '[data-tdur]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === b );
				} );
			} );
		} );
		tf( 'duration' ).addEventListener( 'input', function () {
			m.querySelectorAll( '[data-tdur]' ).forEach( function ( x ) {
				x.classList.toggle( 'is-active', +x.dataset.tdur === +tf( 'duration' ).value );
			} );
		} );
		// Foto.
		var photo = m.querySelector( '[data-tphoto]' ), noImg = m.querySelector( '[data-tnoimg]' );
		m.querySelector( '[data-tfile]' ).addEventListener( 'change', function ( e ) {
			var file = e.target.files[ 0 ];
			if ( ! file ) {
				return;
			}
			if ( file.size > 8 * 1024 * 1024 ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'L\'immagine supera 8 MB.';
				return;
			}
			pendingFile = file;
			removeImage = false;
			photo.style.backgroundImage = 'url(' + URL.createObjectURL( file ) + ')';
			photo.innerHTML = '';
			noImg.hidden = false;
		} );
		noImg.addEventListener( 'click', function () {
			pendingFile = null;
			removeImage = true;
			photo.style.backgroundImage = '';
			photo.innerHTML = '<span>' + ICONS.treatments + '<br>Nessuna foto</span>';
			noImg.hidden = true;
		} );

		function uploadImage( id ) {
			var fd = new FormData();
			fd.append( 'file', pendingFile );
			return fetch( restUrl( 'treatments/' + id + '/image' ), { method: 'POST', headers: { 'X-WP-Nonce': cfg.nonce }, credentials: 'same-origin', body: fd } ).then( function ( r ) {
				return r.json().then( function ( j ) {
					if ( ! r.ok ) {
						throw new Error( j.message || 'Errore nel caricamento della foto' );
					}
					return j;
				} );
			} );
		}

		m.querySelector( '[data-tsave]' ).addEventListener( 'click', function () {
			var btn = this;
			msg.className = 'bhc-msg';
			msg.textContent = '';
			var category = catSel.value === '__new' ? newCat.value.trim() : catSel.value;
			var payload = {
				name: tf( 'name' ).value.trim(),
				category: category,
				description: desc.value.trim(),
				duration: +tf( 'duration' ).value,
				price: tf( 'price' ).value || 0,
				buffer: +tf( 'buffer' ).value || 0,
				online: m.querySelector( '[data-tonline]' ).checked ? 1 : 0,
				staff_needed: +m.querySelector( 'input[name="bhc-need"]:checked' ).value,
				people: [],
				cabins: []
			};
			m.querySelectorAll( '[data-tperson]:checked' ).forEach( function ( i ) {
				payload.people.push( +i.dataset.tperson );
			} );
			m.querySelectorAll( '[data-tcabin]:checked' ).forEach( function ( i ) {
				payload.cabins.push( +i.dataset.tcabin );
			} );
			if ( removeImage ) {
				payload.image_id = 0;
			}
			function fail( text ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = text;
			}
			if ( ! payload.name ) {
				return fail( 'Inserisci il nome del trattamento.' );
			}
			if ( catSel.value === '__new' && ! category ) {
				return fail( 'Scrivi il nome della nuova categoria.' );
			}
			if ( ! payload.duration || payload.duration < 5 ) {
				return fail( 'Indica la durata (almeno 5 minuti).' );
			}
			if ( payload.staff_needed === 2 && payload.people.length === 1 ) {
				return fail( 'Servono 2 operatrici: abilitane almeno due, oppure nessuna (tutte).' );
			}
			if ( d.cabins.length && ! payload.cabins.length ) {
				return fail( 'Scegli almeno una cabina.' );
			}
			btn.disabled = true;
			api( isNew ? 'treatments' : 'treatments/' + t.id, { method: isNew ? 'POST' : 'PUT', body: payload } ).then( function ( saved ) {
				return pendingFile ? uploadImage( saved.id ) : saved;
			} ).then( function () {
				closeModal();
				toast( isNew ? 'Trattamento creato' : 'Trattamento salvato' );
				reloadCabins().then( renderTreatments );
			} ).catch( function ( e ) {
				btn.disabled = false;
				fail( e.message );
			} );
		} );

		var del = m.querySelector( '[data-tdel]' );
		if ( del ) {
			del.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Eliminare il trattamento "' + t.name + '"? Lo storico degli appuntamenti resta.' ) ) {
					return;
				}
				api( 'treatments/' + t.id, { method: 'DELETE' } ).then( function () {
					closeModal();
					toast( 'Trattamento eliminato' );
					renderTreatments();
				} ).catch( function ( e ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		}
	}

	/* ================= Magazzino: prodotti, fornitori, fatture ================= */

	var INV = { pq: '', ptype: '', psup: '', pfam: '', pcat: '', tree: [], locations: [], plow: false, sq: '', iq: '', isup: '', istatus: '', iyear: '', suppliers: [], methods: {} };
	var VAT_RATES = [ 22, 10, 5, 4, 0 ];
	var MOVE_LABEL = { iniziale: 'Giacenza iniziale', fattura: 'Carico da fattura', storno: 'Storno fattura', vendita: 'Vendita', consumo: 'Consumo in cabina', rettifica: 'Scarico / rettifica', inventario: 'Inventario', carico: 'Carico manuale', reso: 'Reso al fornitore' };

	function qty( v ) {
		return Number( v || 0 ).toLocaleString( 'it-IT', { maximumFractionDigits: 2 } );
	}
	function eanValid( e ) {
		if ( ! /^(\d{8}|\d{12}|\d{13}|\d{14})$/.test( e ) ) {
			return false;
		}
		var d = e.split( '' ).map( Number ), check = d.pop(), sum = 0;
		d.reverse().forEach( function ( n, i ) {
			sum += n * ( i % 2 === 0 ? 3 : 1 );
		} );
		return ( 10 - sum % 10 ) % 10 === check;
	}
	function vatValid( v ) {
		v = String( v || '' ).replace( /^IT/i, '' );
		if ( ! /^\d{11}$/.test( v ) ) {
			return false;
		}
		var s = 0;
		for ( var i = 0; i < 10; i++ ) {
			var n = +v[ i ];
			if ( i % 2 === 1 ) {
				n *= 2;
				if ( n > 9 ) {
					n -= 9;
				}
			}
			s += n;
		}
		return ( 10 - s % 10 ) % 10 === +v[ 10 ];
	}
	function loadSuppliers() {
		return api( 'suppliers' ).then( function ( d ) {
			INV.suppliers = d.items;
			return d.items;
		} );
	}
	function supplierOptions( selected, withAll ) {
		return ( withAll ? '<option value="">Tutti i fornitori</option>' : '<option value="0">— nessuno —</option>' ) + INV.suppliers.filter( function ( s ) {
			return s.active || s.id === +selected;
		} ).map( function ( s ) {
			return '<option value="' + s.id + '"' + ( +selected === s.id ? ' selected' : '' ) + '>' + esc( s.name ) + '</option>';
		} ).join( '' );
	}
	function printHtml( title, inner ) {
		var w = window.open( '', '_blank' );
		if ( ! w ) {
			toast( 'Consenti le finestre popup per stampare.', true );
			return;
		}
		w.document.open();
		w.document.write( '<!doctype html><html lang="it"><head><meta charset="utf-8"><title>' + esc( title ) + '</title><style>body{font-family:Helvetica,Arial,sans-serif;color:#3b3a36;margin:28px;font-size:12px}h1{font-family:Georgia,serif;font-weight:normal;font-size:22px;margin:0 0 4px}h2{font-family:Georgia,serif;font-weight:normal;font-size:16px;margin:20px 0 6px;border-bottom:2px solid #7d8c6f;padding-bottom:3px}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:5px 6px;border-bottom:1px solid #e5e5e5}th{color:#7a776f;font-weight:normal}.r{text-align:right}.muted{color:#7a776f}@page{margin:14mm}</style></head><body>' + inner + '<script>window.onload=function(){window.print();}<\/script></body></html>' );
		w.document.close();
	}

	/* ---------- Prodotti ---------- */

	function renderProducts() {
		var main = document.getElementById( 'bhc-main' );
		main.innerHTML = '<div class="bhc-top"><h2>Prodotti</h2><div class="bhc-top__actions">' +
			'<input type="search" data-pq placeholder="Nome, EAN, codice… (anche lettore barcode)" value="' + esc( INV.pq ) + '" style="min-width:260px">' +
			'<select data-pfam></select><select data-pcat></select>' +
			'<select data-ptype><option value="">Tutti i tipi</option><option value="rivendita">Rivendita</option><option value="consumo">Consumo in cabina</option></select>' +
			'<select data-psup></select>' +
			'<label class="bhc-switch"><input type="checkbox" data-plow' + ( INV.plow ? ' checked' : '' ) + '><span></span> Sotto scorta</label>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-tree>Famiglie e categorie</button>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-stockprint>' + ICONS.print + ' Stampa stock</button>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-reorder>Lista riordino</button>' +
			'<button type="button" class="bhc-btn bhc-btn--sm" data-pnew>' + ICONS.products + ' Nuovo prodotto</button></div></div><div data-plist><div class="bhc-loading">Caricamento…</div></div>';
		main.querySelector( '[data-ptype]' ).value = INV.ptype;
		var pq = main.querySelector( '[data-pq]' );
		pq.addEventListener( 'input', debounce( function () {
			INV.pq = pq.value;
			loadProducts();
		}, 250 ) );
		// Lettore di codici a barre: invio con EAN esatto apre la scheda.
		pq.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Enter' && /^\d{8,14}$/.test( pq.value.trim() ) ) {
				e.preventDefault();
				var code = pq.value.trim();
				api( 'products?q=' + code ).then( function ( d ) {
					var hit = d.items.filter( function ( p ) {
						return p.ean === code;
					} )[ 0 ];
					if ( hit ) {
						openProduct( hit.id );
					} else if ( window.confirm( 'Nessun prodotto con EAN ' + code + '. Vuoi crearlo?' ) ) {
						productForm( null, { ean: code } );
					}
				} );
			}
		} );
		main.querySelector( '[data-ptype]' ).addEventListener( 'change', function ( e ) {
			INV.ptype = e.target.value;
			loadProducts();
		} );
		main.querySelector( '[data-plow]' ).addEventListener( 'change', function ( e ) {
			INV.plow = e.target.checked;
			loadProducts();
		} );
		main.querySelector( '[data-pnew]' ).addEventListener( 'click', function () {
			productForm( null );
		} );
		main.querySelector( '[data-reorder]' ).addEventListener( 'click', reorderList );
		main.querySelector( '[data-tree]' ).addEventListener( 'click', treeManager );
		main.querySelector( '[data-stockprint]' ).addEventListener( 'click', stockPrintDialog );
		var famSel = main.querySelector( '[data-pfam]' ), catSel = main.querySelector( '[data-pcat]' );
		famSel.addEventListener( 'change', function () {
			INV.pfam = famSel.value;
			INV.pcat = '';
			fillTreeFilters( famSel, catSel, INV.pfam, INV.pcat );
			loadProducts();
		} );
		catSel.addEventListener( 'change', function () {
			INV.pcat = catSel.value;
			loadProducts();
		} );
		Promise.all( [ loadSuppliers(), loadTree() ] ).then( function () {
			fillTreeFilters( famSel, catSel, INV.pfam, INV.pcat );
			var sel = main.querySelector( '[data-psup]' );
			sel.innerHTML = supplierOptions( INV.psup, true );
			sel.addEventListener( 'change', function () {
				INV.psup = sel.value;
				loadProducts();
			} );
			loadProducts();
		} );
	}

	function loadProducts() {
		var box = document.querySelector( '[data-plist]' );
		if ( ! box ) {
			return;
		}
		api( 'products?q=' + encodeURIComponent( INV.pq ) + '&type=' + INV.ptype + '&supplier=' + INV.psup + '&family=' + INV.pfam + '&category=' + INV.pcat + ( INV.plow ? '&low=1' : '' ) ).then( function ( d ) {
			var s = d.summary;
			var html = '<div class="bhc-kpis">' + kpi( 'Prodotti attivi', s.products ) +
				'<div class="bhc-card' + ( s.low ? ' bhc-card--warn' : '' ) + '" data-kpi-low style="cursor:pointer"><div class="bhc-kpi__label">Sotto scorta minima</div><div class="bhc-kpi__value">' + s.low + '</div></div>' +
				kpi( 'Valore magazzino (costo)', euro( s.stock_value ) ) + kpi( 'Valore vendita rivendita', euro( s.sale_value ) ) + '</div>';
			if ( ! d.items.length ) {
				html += '<div class="bhc-card bhc-muted">Nessun prodotto trovato.</div>';
			} else {
				html += '<table class="bhc-table"><thead><tr><th>Codice / EAN</th><th>Prodotto</th><th>Fornitore</th><th class="bhc-r">Acquisto</th><th class="bhc-r">Vendita</th><th class="bhc-r">Margine</th><th class="bhc-r">Giacenza</th><th class="bhc-r">Scorta min.</th></tr></thead><tbody>' + d.items.map( function ( p ) {
					var st = p.out ? 'bhc-stock--out' : p.low ? 'bhc-stock--low' : 'bhc-stock--ok';
					return '<tr class="is-click" data-prid="' + p.id + '"><td><strong>' + esc( p.sku ) + '</strong><div class="bhc-muted bhc-mono">' + esc( p.ean || '—' ) + ( p.ean && ! p.ean_ok ? ' ⚠' : '' ) + '</div></td>' +
						'<td>' + esc( p.name ) + '<div class="bhc-muted" style="font-size:.82rem">' + esc( [ p.family ? p.family + ( p.category ? ' › ' + p.category : '' ) : '', p.brand, p.type === 'consumo' ? 'Consumo in cabina' : 'Rivendita' ].filter( Boolean ).join( ' · ' ) ) + '</div></td>' +
						'<td>' + esc( p.supplier_name || '—' ) + '</td><td class="bhc-r">' + euro( p.cost_price ) + '</td><td class="bhc-r">' + ( p.type === 'rivendita' ? euro( p.sale_price ) : '<span class="bhc-muted">—</span>' ) + '</td>' +
						'<td class="bhc-r">' + ( p.margin !== null && p.type === 'rivendita' ? p.margin + '%' : '<span class="bhc-muted">—</span>' ) + '</td>' +
						'<td class="bhc-r"><span class="bhc-stock ' + st + '">' + qty( p.stock ) + ' ' + esc( p.unit ) + '</span></td><td class="bhc-r">' + qty( p.min_stock ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table>';
			}
			box.innerHTML = html;
			box.querySelector( '[data-kpi-low]' ).addEventListener( 'click', function () {
				INV.plow = true;
				renderProducts();
			} );
			box.querySelectorAll( '[data-prid]' ).forEach( function ( r ) {
				r.addEventListener( 'click', function () {
					openProduct( +r.dataset.prid );
				} );
			} );
		} ).catch( function ( e ) {
			box.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function openProduct( id ) {
		Promise.all( [ api( 'products/' + id ), INV.suppliers.length ? Promise.resolve() : loadSuppliers() ] ).then( function ( r ) {
			productForm( r[ 0 ] );
		} ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	function productForm( p, preset ) {
		var isNew = ! p;
		p = p || Object.assign( { ean: '', sku: '', name: '', brand: '', category: '', type: 'rivendita', supplier_id: +INV.psup || 0, supplier_code: '', cost_price: '', sale_price: '', vat_rate: 22, unit: 'pz', stock: 0, min_stock: '', reorder_qty: '', location: '', notes: '', active: 1, moves: [] }, preset || {} );
		function fld( n, label, type, extra ) {
			return '<div class="bhc-field"><label>' + label + '</label><input type="' + ( type || 'text' ) + '" data-pf="' + n + '" value="' + esc( p[ n ] === null ? '' : p[ n ] ) + '"' + ( extra || '' ) + '></div>';
		}
		var codes = '<div class="bhc-tsection"><h4>Codici</h4>' +
			'<div class="bhc-field"><label>Codice EAN (barcode)</label><input type="text" inputmode="numeric" maxlength="14" data-pf="ean" value="' + esc( p.ean ) + '" class="bhc-mono" placeholder="Scansiona o digita"><div class="bhc-muted" data-ean-msg style="font-size:.8rem;margin-top:4px"></div></div><div class="bhc-row">' +
			fld( 'sku', 'Codice interno', 'text', ' class="bhc-mono" placeholder="' + ( isNew ? 'Automatico se vuoto' : '' ) + '" style="text-transform:uppercase"' ) +
			fld( 'supplier_code', 'Codice del fornitore', 'text', ' class="bhc-mono"' ) + '</div></div>';
		var info = '<div class="bhc-tsection"><h4>Prodotto</h4>' + fld( 'name', 'Nome prodotto *', 'text', ' placeholder="Es. Crema viso idratante 50 ml"' ) +
			'<div class="bhc-row">' + '<div class="bhc-field"><label>Famiglia</label><select data-pf="family_id"></select></div>' + '<div class="bhc-field"><label>Categoria</label><select data-pf="category_id"></select></div>' + '</div>' +
			fld( 'brand', 'Marca' ) +
			'<div class="bhc-need-pick" style="margin-bottom:12px"><label><input type="radio" name="bhc-ptype" value="rivendita"' + ( p.type !== 'consumo' ? ' checked' : '' ) + '><span>🛍 Rivendita</span><small>venduto alle clienti</small></label>' +
			'<label><input type="radio" name="bhc-ptype" value="consumo"' + ( p.type === 'consumo' ? ' checked' : '' ) + '><span>🧴 Consumo in cabina</span><small>usato nei trattamenti</small></label></div>' +
			'<div class="bhc-row">' + '<div class="bhc-field"><label>Fornitore</label><select data-pf="supplier_id">' + supplierOptions( p.supplier_id, false ) + '</select></div>' +
			'<div class="bhc-row" style="grid-template-columns:1fr 1fr;gap:10px">' + fld( 'unit', 'Unità', 'text', ' placeholder="pz, ml, conf."' ) + fld( 'location', 'Ubicazione', 'text', ' placeholder="Es. Scaffale A2"' ) + '</div></div></div>';
		var prices = '<div class="bhc-tsection"><h4>Prezzi</h4><div class="bhc-row" style="grid-template-columns:1fr 1fr 110px">' +
			fld( 'cost_price', 'Prezzo di acquisto (€, netto IVA)', 'number', ' min="0" step="0.01"' ) +
			fld( 'sale_price', 'Prezzo di vendita (€, IVA inclusa)', 'number', ' min="0" step="0.01"' ) +
			'<div class="bhc-field"><label>IVA</label><select data-pf="vat_rate">' + VAT_RATES.map( function ( v ) {
				return '<option value="' + v + '"' + ( +p.vat_rate === v ? ' selected' : '' ) + '>' + v + '%</option>';
			} ).join( '' ) + '</select></div></div><div class="bhc-margin" data-margin></div></div>';
		var stock = '<div class="bhc-tsection"><h4>Magazzino</h4><div class="bhc-row" style="grid-template-columns:1fr 1fr 1fr">' +
			( isNew ? fld( 'stock', 'Giacenza iniziale', 'number', ' min="0" step="1"' ) : '<div class="bhc-field"><label>Quantità a stock</label><div class="bhc-stockbig ' + ( p.out ? 'bhc-stock--out' : p.low ? 'bhc-stock--low' : 'bhc-stock--ok' ) + '">' + qty( p.stock ) + ' <small>' + esc( p.unit ) + '</small></div></div>' ) +
			fld( 'min_stock', 'Scorta minima (riordino)', 'number', ' min="0" step="1"' ) +
			fld( 'reorder_qty', 'Quantità da riordinare', 'number', ' min="0" step="1" placeholder="Suggerita"' ) + '</div>' +
			( ! isNew && p.low ? '<div class="bhc-alert bhc-alert--' + ( p.out ? 'expired' : 'soon' ) + '">' + ICONS.alert + '<span>' + ( p.out ? 'Esaurito' : 'Sotto la scorta minima' ) + ': da ordinare ' + qty( p.to_order ) + ' ' + esc( p.unit ) + ( p.supplier_name ? ' a ' + esc( p.supplier_name ) : '' ) + '.</span></div>' : '' ) +
			( ! isNew ? '<div class="bhc-moveform"><select data-mv-mode><option value="carico">+ Carico</option><option value="vendita">− Vendita</option><option value="consumo">− Consumo in cabina</option><option value="reso">− Reso al fornitore</option><option value="scarico">− Scarico / rettifica</option><option value="inventario">= Inventario (quantità contata)</option></select>' +
				'<input type="number" min="0" step="1" data-mv-qty placeholder="Quantità"><input type="text" data-mv-note placeholder="Nota (facoltativa)" class="bhc-moveform__note"><button type="button" class="bhc-btn bhc-btn--sm" data-mv-save>Registra</button></div>' : '' ) + '</div>';
		var notes = '<div class="bhc-field"><label>Note</label><textarea rows="2" data-pf="notes">' + esc( p.notes ) + '</textarea></div>';
		var moves = isNew ? '' : '<div class="bhc-tsection"><h4>Movimenti di magazzino</h4>' + ( p.moves.length ? '<table class="bhc-table" style="box-shadow:none"><thead><tr><th>Data</th><th>Movimento</th><th class="bhc-r">Quantità</th><th class="bhc-r">Giacenza</th><th>Nota</th></tr></thead><tbody>' + p.moves.map( function ( m ) {
			return '<tr><td>' + esc( m.created_at.substring( 0, 16 ).replace( /(\d{4})-(\d{2})-(\d{2})/, '$3/$2/$1' ) ) + '</td><td>' + esc( MOVE_LABEL[ m.reason ] || m.reason ) + '</td><td class="bhc-r ' + ( m.qty < 0 ? 'bhc-neg' : 'bhc-pos' ) + '">' + ( m.qty > 0 ? '+' : '' ) + qty( m.qty ) + '</td><td class="bhc-r">' + qty( m.stock_after ) + '</td><td class="bhc-muted">' + esc( m.note ) + ( m.user ? ' · ' + esc( m.user ) : '' ) + '</td></tr>';
		} ).join( '' ) + '</tbody></table>' : '<p class="bhc-muted">Nessun movimento.</p>' ) + '</div>';

		var body = '<div class="bhc-pform"><div>' + codes + info + notes + '</div><div>' + prices + stock + '</div></div>' + moves + '<p class="bhc-msg" data-msg></p>';
		var foot = '<div>' + ( ! isNew ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pdel>Elimina</button>' : '' ) + '</div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Chiudi</button><button type="button" class="bhc-btn" data-psave>' + ( isNew ? 'Crea prodotto' : 'Salva' ) + '</button></div>';
		var m = modal( isNew ? 'Nuovo prodotto' : p.name, body, foot, true );
		var msg = m.querySelector( '[data-msg]' );
		var pf = function ( n ) {
			return m.querySelector( '[data-pf="' + n + '"]' );
		};
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
		var pfFam = pf( 'family_id' ), pfCat = pf( 'category_id' );
		function fillProductTree() {
			fillTreeFilters( pfFam, pfCat, p.family_id || ( isNew ? INV.pfam : '' ), p.category_id || ( isNew ? INV.pcat : '' ), true );
		}
		pfFam.addEventListener( 'change', function () {
			p.family_id = +pfFam.value;
			p.category_id = 0;
			fillProductTree();
		} );
		pfCat.addEventListener( 'change', function () {
			p.category_id = +pfCat.value;
		} );
		( INV.tree.length ? Promise.resolve() : loadTree() ).then( fillProductTree );
		( isNew && p.ean ? pf( 'name' ) : pf( 'ean' ) ).focus();

		function eanCheck() {
			var v = pf( 'ean' ).value.replace( /\D/g, '' ), box = m.querySelector( '[data-ean-msg]' );
			if ( ! v ) {
				box.textContent = '';
				return;
			}
			box.innerHTML = eanValid( v ) ? '<span style="color:var(--c-primary-dark)">✓ Codice valido</span>' : '<span style="color:var(--c-danger)">Cifra di controllo non valida: verifica il codice</span>';
		}
		pf( 'ean' ).addEventListener( 'input', eanCheck );
		eanCheck();
		function margin() {
			var cost = parseFloat( pf( 'cost_price' ).value ) || 0, sale = parseFloat( pf( 'sale_price' ).value ) || 0, vat = +pf( 'vat_rate' ).value;
			var type = m.querySelector( 'input[name="bhc-ptype"]:checked' ).value, box = m.querySelector( '[data-margin]' );
			if ( type !== 'rivendita' || ! sale ) {
				box.innerHTML = type === 'consumo' ? '<span class="bhc-muted">Prodotto di consumo: il prezzo di vendita non è necessario.</span>' : '';
				return;
			}
			var net = sale / ( 1 + vat / 100 );
			var mg = cost ? ( ( net - cost ) / net * 100 ) : null;
			box.innerHTML = 'Vendita netto IVA <strong>' + euro( net ) + '</strong>' + ( mg !== null ? ' · Margine <strong class="' + ( mg < 30 ? 'bhc-neg' : 'bhc-pos' ) + '">' + mg.toFixed( 1 ) + '%</strong> · Ricarico <strong>×' + ( net / cost ).toFixed( 2 ) + '</strong>' : '' );
		}
		[ 'cost_price', 'sale_price', 'vat_rate' ].forEach( function ( n ) {
			pf( n ).addEventListener( 'input', margin );
		} );
		m.querySelectorAll( 'input[name="bhc-ptype"]' ).forEach( function ( r ) {
			r.addEventListener( 'change', margin );
		} );
		margin();

		m.querySelector( '[data-psave]' ).addEventListener( 'click', function () {
			var d = {};
			m.querySelectorAll( '[data-pf]' ).forEach( function ( i ) {
				d[ i.dataset.pf ] = i.value;
			} );
			d.type = m.querySelector( 'input[name="bhc-ptype"]:checked' ).value;
			msg.className = 'bhc-msg';
			msg.textContent = '';
			if ( ! d.name.trim() ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Inserisci il nome del prodotto.';
				return;
			}
			d.ean = d.ean.replace( /\D/g, '' );
			if ( d.ean && ! eanValid( d.ean ) && ! window.confirm( 'Il codice EAN non supera il controllo. Salvare comunque?' ) ) {
				return;
			}
			api( isNew ? 'products' : 'products/' + p.id, { method: isNew ? 'POST' : 'PUT', body: d } ).then( function ( saved ) {
				toast( isNew ? 'Prodotto creato' : 'Prodotto salvato' );
				loadProducts();
				productForm( saved );
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );

		var mv = m.querySelector( '[data-mv-save]' );
		if ( mv ) {
			mv.addEventListener( 'click', function () {
				var mode = m.querySelector( '[data-mv-mode]' ).value, q = m.querySelector( '[data-mv-qty]' ).value;
				if ( q === '' ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = 'Inserisci la quantità.';
					return;
				}
				api( 'products/' + p.id + '/stock', { method: 'POST', body: { mode: mode, qty: q, note: m.querySelector( '[data-mv-note]' ).value } } ).then( function ( saved ) {
					toast( 'Giacenza aggiornata: ' + qty( saved.stock ) + ' ' + saved.unit );
					loadProducts();
					productForm( saved );
				} ).catch( function ( e ) {
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		}
		var del = m.querySelector( '[data-pdel]' );
		if ( del ) {
			del.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Eliminare il prodotto "' + p.name + '"? Se compare in fatture verrà solo disattivato.' ) ) {
					return;
				}
				api( 'products/' + p.id, { method: 'DELETE' } ).then( function ( r ) {
					closeModal();
					toast( r.deactivated ? 'Prodotto disattivato (presente in fatture)' : 'Prodotto eliminato' );
					loadProducts();
				} );
			} );
		}
	}

	/** Lista di riordino raggruppata per fornitore (stampabile / email). */
	function reorderList() {
		Promise.all( [ api( 'products?low=1' ), loadSuppliers() ] ).then( function ( r ) {
			var items = r[ 0 ].items, groups = {}, order = [];
			items.forEach( function ( p ) {
				var k = p.supplier_id || 0;
				if ( ! groups[ k ] ) {
					groups[ k ] = [];
					order.push( k );
				}
				groups[ k ].push( p );
			} );
			var sup = {};
			INV.suppliers.forEach( function ( s ) {
				sup[ s.id ] = s;
			} );
			var body = items.length ? order.map( function ( k ) {
				var s = sup[ k ], tot = 0;
				var rows = groups[ k ].map( function ( p ) {
					tot += p.to_order * p.cost_price;
					return '<tr><td class="bhc-mono">' + esc( p.supplier_code || p.sku ) + '</td><td>' + esc( p.name ) + '<div class="bhc-muted bhc-mono" style="font-size:.8rem">' + esc( p.ean ) + '</div></td><td class="bhc-r">' + qty( p.stock ) + ' / ' + qty( p.min_stock ) + '</td><td class="bhc-r"><strong>' + qty( p.to_order ) + ' ' + esc( p.unit ) + '</strong></td><td class="bhc-r">' + euro( p.to_order * p.cost_price ) + '</td></tr>';
				} ).join( '' );
				var warn = s && s.min_order && tot < s.min_order ? '<div class="bhc-alert bhc-alert--soon">' + ICONS.alert + '<span>Ordine minimo del fornitore: ' + euro( s.min_order ) + '</span></div>' : '';
				return '<div class="bhc-tsection" data-rgroup="' + k + '"><h4>' + esc( s ? s.name : 'Senza fornitore' ) + '</h4>' + ( s ? '<p class="bhc-muted" style="margin:-4px 0 8px">' + esc( [ s.contact_name, s.phone, s.email ].filter( Boolean ).join( ' · ' ) ) + ( s.delivery_days ? ' · consegna in ' + s.delivery_days + ' gg' : '' ) + '</p>' : '' ) +
					'<table class="bhc-table" style="box-shadow:none"><thead><tr><th>Codice</th><th>Prodotto</th><th class="bhc-r">Giac. / min.</th><th class="bhc-r">Da ordinare</th><th class="bhc-r">Costo stimato</th></tr></thead><tbody>' + rows + '</tbody><tfoot><tr><td colspan="4" class="bhc-r"><strong>Totale stimato</strong></td><td class="bhc-r"><strong>' + euro( tot ) + '</strong></td></tr></tfoot></table>' + warn +
					'<p style="margin:10px 0 0;display:flex;gap:8px"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-rprint="' + k + '">' + ICONS.print + ' Stampa ordine</button>' + ( s && s.email ? '<button type="button" class="bhc-btn bhc-btn--sm" data-rmail="' + k + '">Prepara email</button>' : '' ) + '</p></div>';
			} ).join( '' ) : '<p class="bhc-muted">Nessun prodotto sotto la scorta minima. 👍</p>';
			var m = modal( 'Lista riordino', body, '<div></div><div><button type="button" class="bhc-btn" data-close>Chiudi</button></div>', true );
			m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
			function lines( k ) {
				return groups[ k ].map( function ( p ) {
					return '- ' + qty( p.to_order ) + ' ' + p.unit + ' × ' + p.name + ( p.supplier_code ? ' (cod. ' + p.supplier_code + ')' : p.ean ? ' (EAN ' + p.ean + ')' : '' );
				} );
			}
			m.querySelectorAll( '[data-rprint]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var k = b.dataset.rprint, s = sup[ k ];
					printHtml( 'Ordine', '<div class="muted">' + esc( B.center ) + '</div><h1>Ordine a ' + esc( s ? s.name : 'fornitore' ) + '</h1><div class="muted">Data ' + new Date().toLocaleDateString( 'it-IT' ) + '</div><h2>Articoli</h2><table><tr><th>Codice</th><th>EAN</th><th>Prodotto</th><th class="r">Quantità</th></tr>' + groups[ k ].map( function ( p ) {
						return '<tr><td>' + esc( p.supplier_code || p.sku ) + '</td><td>' + esc( p.ean ) + '</td><td>' + esc( p.name ) + '</td><td class="r">' + qty( p.to_order ) + ' ' + esc( p.unit ) + '</td></tr>';
					} ).join( '' ) + '</table>' );
				} );
			} );
			m.querySelectorAll( '[data-rmail]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var s = sup[ b.dataset.rmail ];
					var text = 'Buongiorno' + ( s.contact_name ? ' ' + s.contact_name : '' ) + ',\n\nvi chiediamo di inviarci i seguenti articoli:\n\n' + lines( b.dataset.rmail ).join( '\n' ) + '\n\nGrazie, cordiali saluti\n' + B.center;
					window.location.href = 'mailto:' + encodeURIComponent( s.email ) + '?subject=' + encodeURIComponent( 'Ordine ' + B.center ) + '&body=' + encodeURIComponent( text );
				} );
			} );
		} );
	}

	/* ---------- Fornitori ---------- */

	function renderSuppliers() {
		var main = document.getElementById( 'bhc-main' );
		main.innerHTML = '<div class="bhc-top"><h2>Fornitori</h2><div class="bhc-top__actions"><input type="search" data-sq placeholder="Ragione sociale, P.IVA, città, referente…" value="' + esc( INV.sq ) + '" style="min-width:260px">' +
			'<button type="button" class="bhc-btn bhc-btn--sm" data-snew>' + ICONS.suppliers + ' Nuovo fornitore</button></div></div><div data-slist><div class="bhc-loading">Caricamento…</div></div>';
		main.querySelector( '[data-sq]' ).addEventListener( 'input', debounce( function ( e ) {
			INV.sq = e.target.value;
			loadSupplierList();
		}, 250 ) );
		main.querySelector( '[data-snew]' ).addEventListener( 'click', function () {
			supplierForm( null );
		} );
		loadSupplierList();
	}

	function loadSupplierList() {
		var box = document.querySelector( '[data-slist]' );
		if ( ! box ) {
			return;
		}
		api( 'suppliers?q=' + encodeURIComponent( INV.sq ) ).then( function ( d ) {
			box.innerHTML = '<div class="bhc-people">' + d.items.map( function ( s ) {
				return '<button type="button" class="bhc-person" data-sid="' + s.id + '"' + ( s.active ? '' : ' style="opacity:.55"' ) + '><span class="bhc-person__avatar" style="background:#8b6f5a;border-radius:14px">' + esc( s.name.charAt( 0 ).toUpperCase() ) + '</span>' +
					'<span class="bhc-person__body"><strong>' + esc( s.name ) + '</strong><span class="bhc-muted">' + esc( [ s.vat ? 'P.IVA ' + s.vat : '', s.city ].filter( Boolean ).join( ' · ' ) ) + '</span>' +
					'<span class="bhc-person__meta"><span class="bhc-pill">' + s.products + ' prodott' + ( s.products === 1 ? 'o' : 'i' ) + '</span><span class="bhc-pill">' + s.invoices + ' fattur' + ( s.invoices === 1 ? 'a' : 'e' ) + '</span>' + ( s.to_pay ? '<span class="bhc-pill bhc-pill--warn">Da pagare ' + euro( s.to_pay ) + '</span>' : '' ) + ( s.active ? '' : '<span class="bhc-pill bhc-pill--off">Non attivo</span>' ) + '</span>' +
					'<span class="bhc-muted" style="font-size:.85rem">' + esc( [ s.contact_name, s.phone, s.email ].filter( Boolean ).join( ' · ' ) ) + '</span></span></button>';
			} ).join( '' ) + '<button type="button" class="bhc-person bhc-person--add" data-snew><span class="bhc-person__avatar">' + ICONS.suppliers + '<b>+</b></span><span class="bhc-person__body"><strong>Aggiungi fornitore</strong><span class="bhc-muted">Anagrafica, contatti e condizioni</span></span></button></div>';
			box.querySelectorAll( '[data-sid]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					api( 'suppliers/' + b.dataset.sid ).then( supplierForm );
				} );
			} );
			box.querySelectorAll( '[data-snew]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					supplierForm( null );
				} );
			} );
		} ).catch( function ( e ) {
			box.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function supplierForm( s ) {
		var isNew = ! s;
		s = s || { name: '', vat: '', tax_code: '', address: '', city: '', zip: '', province: '', country: 'Italia', phone: '', email: '', pec: '', sdi_code: '', website: '', contact_name: '', contact_phone: '', iban: '', payment_terms: '', min_order: '', delivery_days: '', notes: '', active: 1, product_list: [], invoice_list: [] };
		function fld( n, label, type, extra ) {
			return '<div class="bhc-field"><label>' + label + '</label><input type="' + ( type || 'text' ) + '" data-sf="' + n + '" value="' + esc( s[ n ] === null || s[ n ] === 0 && n !== 'active' ? ( s[ n ] === 0 ? '' : '' ) : s[ n ] ) + '"' + ( extra || '' ) + '></div>';
		}
		var tabs = [ [ 'ana', 'Anagrafica' ], [ 'con', 'Contatti' ], [ 'cond', 'Condizioni' ] ];
		if ( ! isNew ) {
			tabs.push( [ 'prod', 'Prodotti (' + s.product_list.length + ')' ], [ 'fat', 'Fatture (' + s.invoice_list.length + ')' ] );
		}
		var panes = {
			ana: fld( 'name', 'Ragione sociale *' ) +
				'<div class="bhc-row"><div class="bhc-field"><label>Partita IVA</label><input type="text" data-sf="vat" value="' + esc( s.vat ) + '" maxlength="13" class="bhc-mono"><div class="bhc-muted" data-vat-msg style="font-size:.8rem;margin-top:4px"></div></div>' + fld( 'tax_code', 'Codice fiscale', 'text', ' class="bhc-mono" style="text-transform:uppercase"' ) + '</div>' +
				fld( 'address', 'Indirizzo' ) +
				'<div class="bhc-row" style="grid-template-columns:2fr 1fr 1fr 1.2fr">' + fld( 'city', 'Comune' ) + fld( 'zip', 'CAP', 'text', ' maxlength="5"' ) + fld( 'province', 'Prov.', 'text', ' maxlength="2" style="text-transform:uppercase"' ) + fld( 'country', 'Paese' ) + '</div>' +
				'<div class="bhc-row">' + fld( 'sdi_code', 'Codice destinatario SDI', 'text', ' maxlength="7" class="bhc-mono" style="text-transform:uppercase"' ) + fld( 'pec', 'PEC', 'email' ) + '</div>',
			con: '<div class="bhc-row">' + fld( 'phone', 'Telefono', 'tel' ) + fld( 'email', 'Email ordini', 'email' ) + '</div>' + fld( 'website', 'Sito web', 'url', ' placeholder="https://"' ) +
				'<h4 style="margin-top:10px">Referente / agente</h4><div class="bhc-row">' + fld( 'contact_name', 'Nome' ) + fld( 'contact_phone', 'Cellulare', 'tel' ) + '</div>',
			cond: fld( 'iban', 'IBAN', 'text', ' class="bhc-mono" style="text-transform:uppercase" maxlength="34"' ) +
				'<div class="bhc-row">' + fld( 'payment_terms', 'Termini di pagamento', 'text', ' placeholder="Es. Bonifico 30 gg data fattura"' ) + fld( 'min_order', 'Ordine minimo (€)', 'number', ' min="0" step="1"' ) + '</div>' +
				'<div class="bhc-row">' + fld( 'delivery_days', 'Tempi di consegna (giorni)', 'number', ' min="0" step="1"' ) + '<div class="bhc-field"><label>&nbsp;</label><label class="bhc-switch"><input type="checkbox" data-sactive' + ( +s.active ? ' checked' : '' ) + '><span></span> Fornitore attivo</label></div></div>' +
				'<div class="bhc-field"><label>Note</label><textarea rows="3" data-sf="notes">' + esc( s.notes ) + '</textarea></div>',
			prod: isNew ? '' : ( s.product_list.length ? '<table class="bhc-table" style="box-shadow:none"><thead><tr><th>Codice</th><th>Prodotto</th><th class="bhc-r">Acquisto</th><th class="bhc-r">Giacenza</th></tr></thead><tbody>' + s.product_list.map( function ( p ) {
				return '<tr><td class="bhc-mono">' + esc( p.supplier_code || p.sku ) + '</td><td>' + esc( p.name ) + '</td><td class="bhc-r">' + euro( p.cost_price ) + '</td><td class="bhc-r"><span class="bhc-stock ' + ( p.low ? 'bhc-stock--low' : 'bhc-stock--ok' ) + '">' + qty( p.stock ) + '</span></td></tr>';
			} ).join( '' ) + '</tbody></table>' : '<p class="bhc-muted">Nessun prodotto collegato.</p>' ),
			fat: isNew ? '' : ( s.invoice_list.length ? '<table class="bhc-table" style="box-shadow:none"><thead><tr><th>Data</th><th>Numero</th><th class="bhc-r">Totale</th><th>Stato</th></tr></thead><tbody>' + s.invoice_list.map( function ( i ) {
				return '<tr><td>' + esc( i.date.split( '-' ).reverse().join( '/' ) ) + '</td><td>' + esc( i.number ) + '</td><td class="bhc-r">' + euro( i.total ) + '</td><td>' + invStatus( i ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table>' : '<p class="bhc-muted">Nessuna fattura registrata.</p>' )
		};
		var body = ( ! isNew && s.to_pay ? '<div class="bhc-alert bhc-alert--soon">' + ICONS.alert + '<span>Da pagare a questo fornitore: ' + euro( s.to_pay ) + '</span></div>' : '' ) +
			'<div class="bhc-tabs">' + tabs.map( function ( t, i ) {
				return '<button type="button" data-stab="' + t[ 0 ] + '"' + ( i ? '' : ' class="is-active"' ) + '>' + t[ 1 ] + '</button>';
			} ).join( '' ) + '</div>' + tabs.map( function ( t, i ) {
				return '<div data-spane="' + t[ 0 ] + '"' + ( i ? ' hidden' : '' ) + '>' + panes[ t[ 0 ] ] + '</div>';
			} ).join( '' ) + '<p class="bhc-msg" data-msg></p>';
		var foot = '<div>' + ( ! isNew ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-sdel>Elimina</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-sinv>+ Registra fattura</button>' : '' ) + '</div>' +
			'<div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Chiudi</button><button type="button" class="bhc-btn" data-ssave>' + ( isNew ? 'Crea fornitore' : 'Salva' ) + '</button></div>';
		var m = modal( isNew ? 'Nuovo fornitore' : s.name, body, foot, true );
		cfAttach( m, { cf: '[data-sf="tax_code"]' } );
		var msg = m.querySelector( '[data-msg]' );
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
		m.querySelectorAll( '[data-stab]' ).forEach( function ( t ) {
			t.addEventListener( 'click', function () {
				m.querySelectorAll( '[data-stab]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === t );
				} );
				m.querySelectorAll( '[data-spane]' ).forEach( function ( x ) {
					x.hidden = x.dataset.spane !== t.dataset.stab;
				} );
			} );
		} );
		var vat = m.querySelector( '[data-sf="vat"]' );
		function vatCheck() {
			var v = vat.value.replace( /\s/g, '' ), box = m.querySelector( '[data-vat-msg]' );
			box.innerHTML = ! v ? '' : vatValid( v ) ? '<span style="color:var(--c-primary-dark)">✓ Partita IVA formalmente corretta</span>' : '<span style="color:var(--c-danger)">Partita IVA non valida (controlla le 11 cifre)</span>';
		}
		vat.addEventListener( 'input', vatCheck );
		vatCheck();
		m.querySelector( '[data-sf="name"]' ).focus();
		m.querySelector( '[data-ssave]' ).addEventListener( 'click', function () {
			var d = {};
			m.querySelectorAll( '[data-sf]' ).forEach( function ( i ) {
				d[ i.dataset.sf ] = i.value;
			} );
			d.active = m.querySelector( '[data-sactive]' ).checked ? 1 : 0;
			msg.className = 'bhc-msg';
			msg.textContent = '';
			if ( ! d.name.trim() ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Inserisci la ragione sociale.';
				return;
			}
			if ( d.vat && ! vatValid( d.vat.replace( /\s/g, '' ) ) && d.country.toLowerCase() === 'italia' && ! window.confirm( 'La partita IVA non supera il controllo. Salvare comunque?' ) ) {
				return;
			}
			api( isNew ? 'suppliers' : 'suppliers/' + s.id, { method: isNew ? 'POST' : 'PUT', body: d } ).then( function () {
				closeModal();
				toast( isNew ? 'Fornitore creato' : 'Fornitore salvato' );
				INV.suppliers = [];
				loadSupplierList();
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
		var del = m.querySelector( '[data-sdel]' );
		if ( del ) {
			del.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Eliminare il fornitore? Se ha prodotti o fatture verrà solo disattivato.' ) ) {
					return;
				}
				api( 'suppliers/' + s.id, { method: 'DELETE' } ).then( function ( r ) {
					closeModal();
					toast( r.deactivated ? 'Fornitore disattivato' : 'Fornitore eliminato' );
					loadSupplierList();
				} );
			} );
		}
		var ni = m.querySelector( '[data-sinv]' );
		if ( ni ) {
			ni.addEventListener( 'click', function () {
				openInvoice( null, { supplier_id: s.id } );
			} );
		}
	}

	/* ---------- Fatture fornitori ---------- */

	function invStatus( i ) {
		if ( i.status === 'pagata' ) {
			return '<span class="bhc-badge bhc-badge--confirmed">Pagata</span>';
		}
		return i.overdue ? '<span class="bhc-badge bhc-badge--noshow">Scaduta</span>' : '<span class="bhc-badge bhc-badge--booked">Da pagare</span>';
	}

	function renderInvoices() {
		var main = document.getElementById( 'bhc-main' );
		var y = new Date().getFullYear();
		main.innerHTML = '<div class="bhc-top"><h2>Fatture fornitori</h2><div class="bhc-top__actions">' +
			'<input type="search" data-iq placeholder="Numero o fornitore…" value="' + esc( INV.iq ) + '">' +
			'<select data-isup></select>' +
			'<select data-istatus><option value="">Tutte</option><option value="da_pagare">Da pagare</option><option value="pagata">Pagate</option></select>' +
			'<select data-iyear><option value="">Tutti gli anni</option>' + [ y, y - 1, y - 2 ].map( function ( v ) {
				return '<option>' + v + '</option>';
			} ).join( '' ) + '</select>' +
			'<button type="button" class="bhc-btn bhc-btn--sm" data-inew>' + ICONS.invoices + ' Registra fattura</button></div></div><div data-ilist><div class="bhc-loading">Caricamento…</div></div>';
		main.querySelector( '[data-istatus]' ).value = INV.istatus;
		main.querySelector( '[data-iyear]' ).value = INV.iyear;
		main.querySelector( '[data-iq]' ).addEventListener( 'input', debounce( function ( e ) {
			INV.iq = e.target.value;
			loadInvoices();
		}, 250 ) );
		[ [ 'istatus', 'istatus' ], [ 'iyear', 'iyear' ], [ 'isup', 'isup' ] ].forEach( function ( k ) {
			main.querySelector( '[data-' + k[ 0 ] + ']' ).addEventListener( 'change', function ( e ) {
				INV[ k[ 1 ] ] = e.target.value;
				loadInvoices();
			} );
		} );
		main.querySelector( '[data-inew]' ).addEventListener( 'click', function () {
			openInvoice( null );
		} );
		loadSuppliers().then( function () {
			main.querySelector( '[data-isup]' ).innerHTML = supplierOptions( INV.isup, true );
			loadInvoices();
		} );
	}

	function loadInvoices() {
		var box = document.querySelector( '[data-ilist]' );
		if ( ! box ) {
			return;
		}
		api( 'invoices?q=' + encodeURIComponent( INV.iq ) + '&supplier=' + INV.isup + '&status=' + INV.istatus + '&year=' + INV.iyear ).then( function ( d ) {
			INV.methods = d.methods;
			var s = d.summary;
			var tot = d.items.reduce( function ( a, i ) {
				return a + i.total;
			}, 0 );
			var html = '<div class="bhc-kpis">' + kpi( 'Da pagare', euro( s.to_pay ) ) + '<div class="bhc-card' + ( s.overdue ? ' bhc-card--warn' : '' ) + '"><div class="bhc-kpi__label">Scadute</div><div class="bhc-kpi__value">' + euro( s.overdue ) + '</div></div>' + kpi( 'Acquisti anno in corso', euro( s.year_total ) ) + kpi( 'Totale elenco', euro( tot ) ) + '</div>';
			html += d.items.length ? '<table class="bhc-table"><thead><tr><th>Data</th><th>Numero</th><th>Fornitore</th><th>Scadenza</th><th class="bhc-r">Imponibile</th><th class="bhc-r">IVA</th><th class="bhc-r">Totale</th><th>Stato</th><th title="Caricata a magazzino">Mag.</th></tr></thead><tbody>' + d.items.map( function ( i ) {
				return '<tr class="is-click" data-iid="' + i.id + '"><td>' + esc( i.date.split( '-' ).reverse().join( '/' ) ) + '</td><td><strong>' + esc( i.number ) + '</strong></td><td>' + esc( i.supplier_name ) + '</td>' +
					'<td' + ( i.overdue ? ' class="bhc-neg"' : '' ) + '>' + ( i.due_date ? esc( i.due_date.split( '-' ).reverse().join( '/' ) ) : '—' ) + '</td><td class="bhc-r">' + euro( i.taxable ) + '</td><td class="bhc-r">' + euro( i.vat ) + '</td><td class="bhc-r"><strong>' + euro( i.total ) + '</strong></td><td>' + invStatus( i ) + '</td><td>' + ( i.stock_loaded ? '✓' : '<span class="bhc-muted">—</span>' ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table>' : '<div class="bhc-card bhc-muted">Nessuna fattura.</div>';
			box.innerHTML = html;
			box.querySelectorAll( '[data-iid]' ).forEach( function ( r ) {
				r.addEventListener( 'click', function () {
					openInvoice( +r.dataset.iid );
				} );
			} );
		} ).catch( function ( e ) {
			box.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function openInvoice( id, preset ) {
		Promise.all( [ id ? api( 'invoices/' + id ) : Promise.resolve( null ), api( 'products?all=1' ), loadSuppliers(), Object.keys( INV.methods ).length ? Promise.resolve() : api( 'invoices?year=1900' ).then( function ( d ) {
			INV.methods = d.methods;
		} ) ] ).then( function ( r ) {
			invoiceForm( r[ 0 ], r[ 1 ].items, preset || {} );
		} ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	function invoiceForm( inv, products, preset ) {
		var isNew = ! inv;
		var today = ymd( new Date() );
		inv = inv || { supplier_id: preset.supplier_id || ( +INV.isup || 0 ), number: '', date: today, due_date: '', status: 'da_pagare', paid_date: '', payment_method: 'bonifico', shipping: 0, notes: '', stock_loaded: 1, lines: [] };
		var pmap = {};
		products.forEach( function ( p ) {
			pmap[ p.id ] = p;
		} );
		function productOptions( selected, supplierId ) {
			var mine = products.filter( function ( p ) {
				return p.supplier_id === supplierId && ( p.active || p.id === selected );
			} );
			var others = products.filter( function ( p ) {
				return p.supplier_id !== supplierId && ( p.active || p.id === selected );
			} );
			function opt( p ) {
				return '<option value="' + p.id + '"' + ( p.id === selected ? ' selected' : '' ) + '>' + esc( p.name ) + ( p.ean ? ' · ' + esc( p.ean ) : '' ) + '</option>';
			}
			return '<option value="0">— riga libera (non a magazzino) —</option>' + ( mine.length ? '<optgroup label="Prodotti di questo fornitore">' + mine.map( opt ).join( '' ) + '</optgroup>' : '' ) + ( others.length ? '<optgroup label="Altri prodotti">' + others.map( opt ).join( '' ) + '</optgroup>' : '' );
		}
		function lineRow( l ) {
			l = l || { product_id: 0, description: '', qty: 1, unit_price: '', discount: 0, vat_rate: 22 };
			return '<tr data-line><td><select data-l="product_id">' + productOptions( l.product_id, +inv.supplier_id ) + '</select><input type="text" data-l="description" value="' + esc( l.description ) + '" placeholder="Descrizione" style="margin-top:6px"></td>' +
				'<td><input type="number" min="0" step="1" data-l="qty" value="' + esc( l.qty ) + '"></td>' +
				'<td><input type="number" min="0" step="0.01" data-l="unit_price" value="' + esc( l.unit_price ) + '"></td>' +
				'<td><input type="number" min="0" max="100" step="0.5" data-l="discount" value="' + esc( l.discount || 0 ) + '"></td>' +
				'<td><select data-l="vat_rate">' + VAT_RATES.map( function ( v ) {
					return '<option value="' + v + '"' + ( +l.vat_rate === v ? ' selected' : '' ) + '>' + v + '%</option>';
				} ).join( '' ) + '</select></td><td class="bhc-r" data-l-total></td><td><button type="button" class="bhc-rowitem__del" style="position:static" data-l-del aria-label="Rimuovi riga">&times;</button></td></tr>';
		}
		var methods = Object.keys( INV.methods ).map( function ( k ) {
			return '<option value="' + k + '"' + ( inv.payment_method === k ? ' selected' : '' ) + '>' + esc( INV.methods[ k ] ) + '</option>';
		} ).join( '' );
		var head = '<div class="bhc-row" style="grid-template-columns:2fr 1fr 1fr 1fr">' +
			'<div class="bhc-field"><label>Fornitore *</label><select data-if="supplier_id"><option value="0">— scegli —</option>' + supplierOptions( inv.supplier_id, false ).replace( '<option value="0">— nessuno —</option>', '' ) + '</select></div>' +
			'<div class="bhc-field"><label>Numero fattura *</label><input type="text" data-if="number" value="' + esc( inv.number ) + '"></div>' +
			'<div class="bhc-field"><label>Data *</label><input type="date" data-if="date" value="' + esc( inv.date ) + '"></div>' +
			'<div class="bhc-field"><label>Scadenza</label><input type="date" data-if="due_date" value="' + esc( inv.due_date || '' ) + '"></div></div>' +
			'<div class="bhc-row" style="grid-template-columns:1fr 1fr 1fr 1fr">' +
			'<div class="bhc-field"><label>Pagamento</label><select data-if="payment_method"><option value="">—</option>' + methods + '</select></div>' +
			'<div class="bhc-field"><label>Stato</label><select data-if="status"><option value="da_pagare"' + ( inv.status !== 'pagata' ? ' selected' : '' ) + '>Da pagare</option><option value="pagata"' + ( inv.status === 'pagata' ? ' selected' : '' ) + '>Pagata</option></select></div>' +
			'<div class="bhc-field" data-paid-wrap' + ( inv.status === 'pagata' ? '' : ' hidden' ) + '><label>Pagata il</label><input type="date" data-if="paid_date" value="' + esc( inv.paid_date || today ) + '"></div><div></div></div>';
		var lines = '<table class="bhc-lines"><thead><tr><th>Prodotto / descrizione</th><th style="width:80px">Q.tà</th><th style="width:110px">Prezzo unit. €</th><th style="width:80px">Sconto %</th><th style="width:86px">IVA</th><th class="bhc-r" style="width:100px">Totale</th><th style="width:36px"></th></tr></thead><tbody data-lines>' +
			( inv.lines.length ? inv.lines.map( lineRow ).join( '' ) : lineRow() ) + '</tbody></table>' +
			'<p><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-l-add>+ Aggiungi riga</button></p>';
		var totals = '<div class="bhc-invfoot"><div>' +
			'<label class="bhc-check"><input type="checkbox" data-load' + ( isNew || inv.stock_loaded ? ' checked' : '' ) + '> <span><strong>Carica i prodotti a magazzino</strong><br><span class="bhc-muted">Le quantità delle righe collegate a un prodotto vengono aggiunte alla giacenza.</span></span></label>' +
			'<label class="bhc-check"><input type="checkbox" data-costs' + ( isNew ? ' checked' : '' ) + '> <span>Aggiorna il prezzo di acquisto dei prodotti con quello della fattura</span></label>' +
			'<div class="bhc-field" style="margin-top:10px"><label>Note</label><textarea rows="2" data-if="notes">' + esc( inv.notes ) + '</textarea></div></div>' +
			'<div class="bhc-totals"><div><span>Imponibile righe</span><strong data-t-lines></strong></div><div><span>Spese di trasporto</span><input type="number" min="0" step="0.01" data-if="shipping" value="' + esc( inv.shipping || 0 ) + '"></div><div><span>Imponibile</span><strong data-t-taxable></strong></div><div><span>IVA</span><strong data-t-vat></strong></div><div class="bhc-totals__grand"><span>Totale fattura</span><strong data-t-total></strong></div></div></div>';
		var body = head + lines + totals + '<p class="bhc-msg" data-msg></p>';
		var foot = '<div>' + ( ! isNew ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-idel>Elimina</button>' : '' ) + '</div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Chiudi</button><button type="button" class="bhc-btn" data-isave>' + ( isNew ? 'Registra fattura' : 'Salva' ) + '</button></div>';
		var m = modal( isNew ? 'Registra fattura fornitore' : 'Fattura ' + inv.number + ' — ' + inv.supplier_name, body, foot, true );
		m.querySelector( '.bhc-modal__box' ).classList.add( 'bhc-modal__box--xl' );
		var msg = m.querySelector( '[data-msg]' );
		var iff = function ( n ) {
			return m.querySelector( '[data-if="' + n + '"]' );
		};
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );

		function recalc() {
			var taxable = 0, vat = 0;
			m.querySelectorAll( '[data-line]' ).forEach( function ( row ) {
				var q = parseFloat( row.querySelector( '[data-l="qty"]' ).value ) || 0;
				var pr = parseFloat( row.querySelector( '[data-l="unit_price"]' ).value ) || 0;
				var dc = parseFloat( row.querySelector( '[data-l="discount"]' ).value ) || 0;
				var rate = +row.querySelector( '[data-l="vat_rate"]' ).value;
				var t = Math.round( q * pr * ( 1 - dc / 100 ) * 100 ) / 100;
				taxable += t;
				vat += t * rate / 100;
				row.querySelector( '[data-l-total]' ).textContent = euro( t );
			} );
			var ship = parseFloat( iff( 'shipping' ).value ) || 0;
			m.querySelector( '[data-t-lines]' ).textContent = euro( taxable );
			vat += ship * 0.22;
			taxable += ship;
			m.querySelector( '[data-t-taxable]' ).textContent = euro( taxable );
			m.querySelector( '[data-t-vat]' ).textContent = euro( vat );
			m.querySelector( '[data-t-total]' ).textContent = euro( Math.round( ( taxable + vat ) * 100 ) / 100 );
		}
		function bindRow( row ) {
			row.querySelectorAll( 'input,select' ).forEach( function ( i ) {
				i.addEventListener( 'input', recalc );
			} );
			row.querySelector( '[data-l="product_id"]' ).addEventListener( 'change', function () {
				var p = pmap[ +this.value ];
				if ( p ) {
					row.querySelector( '[data-l="description"]' ).value = p.name;
					row.querySelector( '[data-l="unit_price"]' ).value = p.cost_price || '';
					row.querySelector( '[data-l="vat_rate"]' ).value = String( p.vat_rate );
					if ( p.low && p.to_order ) {
						row.querySelector( '[data-l="qty"]' ).value = p.to_order;
					}
				}
				recalc();
			} );
			row.querySelector( '[data-l-del]' ).addEventListener( 'click', function () {
				if ( m.querySelectorAll( '[data-line]' ).length > 1 ) {
					row.remove();
				} else {
					row.querySelectorAll( 'input' ).forEach( function ( i ) {
						i.value = '';
					} );
				}
				recalc();
			} );
		}
		m.querySelectorAll( '[data-line]' ).forEach( bindRow );
		m.querySelector( '[data-l-add]' ).addEventListener( 'click', function () {
			m.querySelector( '[data-lines]' ).insertAdjacentHTML( 'beforeend', lineRow() );
			var rows = m.querySelectorAll( '[data-line]' );
			bindRow( rows[ rows.length - 1 ] );
			recalc();
		} );
		iff( 'shipping' ).addEventListener( 'input', recalc );
		iff( 'status' ).addEventListener( 'change', function () {
			m.querySelector( '[data-paid-wrap]' ).hidden = this.value !== 'pagata';
		} );
		iff( 'supplier_id' ).addEventListener( 'change', function () {
			inv.supplier_id = +this.value;
			m.querySelectorAll( '[data-l="product_id"]' ).forEach( function ( sel ) {
				var v = +sel.value;
				sel.innerHTML = productOptions( v, inv.supplier_id );
			} );
			var s = INV.suppliers.filter( function ( x ) {
				return x.id === inv.supplier_id;
			} )[ 0 ];
			// Scadenza suggerita dai termini di pagamento (es. "30 gg").
			var mt = s && /(\d+)\s*(gg|giorni)/i.exec( s.payment_terms || '' );
			if ( mt && ! iff( 'due_date' ).value && iff( 'date' ).value ) {
				var dd = parseDate( iff( 'date' ).value );
				dd.setDate( dd.getDate() + +mt[ 1 ] );
				iff( 'due_date' ).value = ymd( dd );
			}
		} );
		recalc();
		( isNew ? ( inv.supplier_id ? iff( 'number' ) : iff( 'supplier_id' ) ) : iff( 'number' ) ).focus();

		m.querySelector( '[data-isave]' ).addEventListener( 'click', function () {
			var btn = this;
			var d = {};
			m.querySelectorAll( '[data-if]' ).forEach( function ( i ) {
				d[ i.dataset.if ] = i.value;
			} );
			d.supplier_id = +d.supplier_id;
			d.load_stock = m.querySelector( '[data-load]' ).checked ? 1 : 0;
			d.update_costs = m.querySelector( '[data-costs]' ).checked ? 1 : 0;
			d.lines = [];
			m.querySelectorAll( '[data-line]' ).forEach( function ( row ) {
				var l = {};
				row.querySelectorAll( '[data-l]' ).forEach( function ( i ) {
					l[ i.dataset.l ] = i.value;
				} );
				if ( +l.qty && ( +l.product_id || l.description.trim() ) ) {
					d.lines.push( l );
				}
			} );
			msg.className = 'bhc-msg';
			msg.textContent = '';
			var err = ! d.supplier_id ? 'Scegli il fornitore.' : ! d.number.trim() ? 'Inserisci il numero della fattura.' : ! d.date ? 'Inserisci la data.' : ! d.lines.length ? 'Aggiungi almeno una riga con quantità.' : '';
			if ( err ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = err;
				return;
			}
			btn.disabled = true;
			api( isNew ? 'invoices' : 'invoices/' + inv.id, { method: isNew ? 'POST' : 'PUT', body: d } ).then( function ( saved ) {
				closeModal();
				toast( ( isNew ? 'Fattura registrata' : 'Fattura salvata' ) + ( saved.stock_loaded ? ' e prodotti caricati a magazzino' : '' ) );
				if ( S.view === 'invoices' ) {
					loadInvoices();
				} else if ( S.view === 'suppliers' ) {
					loadSupplierList();
				}
			} ).catch( function ( e ) {
				btn.disabled = false;
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
		var del = m.querySelector( '[data-idel]' );
		if ( del ) {
			del.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Eliminare la fattura? Se era caricata a magazzino, le quantità verranno stornate.' ) ) {
					return;
				}
				api( 'invoices/' + inv.id, { method: 'DELETE' } ).then( function () {
					closeModal();
					toast( 'Fattura eliminata' );
					loadInvoices();
				} );
			} );
		}
	}

	/* ================= Impostazioni (solo amministratore) ================= */

	var SET = { tab: 'perms', data: null };

	function renderSettings() {
		var main = document.getElementById( 'bhc-main' );
		if ( ! B.me.is_admin ) {
			main.innerHTML = '<div class="bhc-card bhc-msg is-error">Le impostazioni sono riservate all\'amministratore.</div>';
			return;
		}
		main.innerHTML = '<div class="bhc-top"><h2>Impostazioni</h2><div class="bhc-top__actions"><span class="bhc-pill">🔒 Visibile solo all\'amministratore</span></div></div><div data-set><div class="bhc-loading">Caricamento…</div></div>';
		api( 'settings' ).then( function ( d ) {
			SET.data = d;
			drawSettings();
		} ).catch( function ( e ) {
			main.querySelector( '[data-set]' ).innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function drawSettings() {
		var d = SET.data, st = d.settings;
		var box = document.querySelector( '[data-set]' );
		var tabs = [ [ 'perms', 'Ruoli e permessi' ], [ 'center', 'Centro' ], [ 'hours', 'Orari e chiusure' ], [ 'booking', 'Prenotazioni online' ], [ 'notify', 'Notifiche' ] ];
		function inp( k, label, type, extra ) {
			return '<div class="bhc-field"><label>' + label + '</label><input type="' + ( type || 'text' ) + '" data-st="' + k + '" value="' + esc( st[ k ] ) + '"' + ( extra || '' ) + '></div>';
		}
		function sw( k, label ) {
			return '<label class="bhc-switch" style="margin:8px 0 !important"><input type="checkbox" data-stc="' + k + '"' + ( +st[ k ] ? ' checked' : '' ) + '><span></span> ' + label + '</label>';
		}

		// Matrice permessi.
		var roles = Object.keys( d.roles );
		var perms = '<p class="bhc-muted" style="max-width:760px">Scegli cosa può vedere e fare ogni ruolo nel gestionale. L\'amministratore del sito ha sempre accesso a tutto, comprese queste impostazioni. Le modifiche valgono subito, al prossimo caricamento della pagina per chi è già collegato.</p>' +
			'<div class="bhc-perm-wrap"><table class="bhc-perm"><thead><tr><th>Funzione</th>' + roles.map( function ( r ) {
				return '<th class="bhc-perm__role"><span>' + esc( d.roles[ r ] ) + '</span><small>' + d.users[ r ] + ' utent' + ( d.users[ r ] === 1 ? 'e' : 'i' ) + '</small><span class="bhc-perm__bulk"><a href="#" data-all="' + r + '">tutto</a> · <a href="#" data-none="' + r + '">niente</a></span></th>';
			} ).join( '' ) + '<th class="bhc-perm__role"><span>Amministratore</span><small>sempre</small></th></tr></thead><tbody>' +
			Object.keys( d.groups ).map( function ( g ) {
				return '<tr class="bhc-perm__group"><td colspan="' + ( roles.length + 2 ) + '">' + esc( g ) + '</td></tr>' + d.groups[ g ].map( function ( p ) {
					return '<tr><td><strong>' + esc( p.label ) + '</strong>' + ( p.desc ? '<div class="bhc-muted" style="font-size:.82rem">' + esc( p.desc ) + '</div>' : '' ) + '</td>' + roles.map( function ( r ) {
						var on = d.perms[ r ].indexOf( p.key ) !== -1;
						return '<td class="bhc-perm__cell"><label class="bhc-tick"><input type="checkbox" data-perm="' + p.key + '" data-role="' + r + '"' + ( on ? ' checked' : '' ) + ' aria-label="' + esc( p.label + ' — ' + d.roles[ r ] ) + '"><span></span></label></td>';
					} ).join( '' ) + '<td class="bhc-perm__cell"><span class="bhc-tick bhc-tick--locked">✓</span></td></tr>';
				} ).join( '' );
			} ).join( '' ) + '</tbody></table></div>' +
			'<p style="margin-top:12px"><a href="#" data-reset-perms>Ripristina i permessi predefiniti</a></p>';

		var center = '<div class="bhc-set-grid">' + inp( 'center_name', 'Nome del centro' ) + inp( 'center_email', 'Email per le notifiche', 'email' ) + inp( 'center_phone', 'Telefono', 'tel' ) + inp( 'privacy_url', 'Link informativa privacy', 'url' ) + '</div>';

		var hours = '<p class="bhc-muted">Formato: 09:00-13:00, 14:00-19:00. Vuoto = chiuso.</p><div class="bhc-set-grid">' + Object.keys( d.weekdays ).map( function ( n ) {
			return inp( 'hours_' + n, d.weekdays[ n ], 'text', ' placeholder="chiuso"' );
		} ).join( '' ) + '</div><div class="bhc-field"><label>Giorni di chiusura (ferie, festivi)</label><textarea rows="3" data-st="closures" placeholder="25/12/2026, 26/12/2026, 01/01/2027">' + esc( st.closures ) + '</textarea></div>';

		var booking = '<div class="bhc-set-grid"><div class="bhc-field"><label>Intervallo della griglia (minuti)</label><select data-st="slot_step">' + [ 5, 10, 15, 20, 30, 60 ].map( function ( v ) {
			return '<option' + ( +st.slot_step === v ? ' selected' : '' ) + '>' + v + '</option>';
		} ).join( '' ) + '</select></div>' + inp( 'lead_hours', 'Preavviso minimo (ore)', 'number', ' min="0"' ) + inp( 'max_days', 'Prenotabile fino a (giorni)', 'number', ' min="1"' ) + inp( 'cancel_hours', 'Annullamento gratuito fino a (ore prima)', 'number', ' min="0"' ) + '</div>' +
			sw( 'auto_confirm', 'Le prenotazioni online sono confermate subito' ) +
			'<div class="bhc-field"><label>Nota mostrata nel modulo di prenotazione</label><textarea rows="2" data-st="booking_note">' + esc( st.booking_note ) + '</textarea></div>';

		var notify = '<div class="bhc-set-grid">' + inp( 'reminder_hours', 'Promemoria email alla cliente (ore prima, 0 = disattivato)', 'number', ' min="0"' ) + '</div>' + sw( 'notify_staff', 'Avvisa il centro via email per ogni prenotazione o annullamento online' );

		var panes = { perms: perms, center: center, hours: hours, booking: booking, notify: notify };
		box.innerHTML = '<div class="bhc-card"><div class="bhc-tabs">' + tabs.map( function ( t ) {
			return '<button type="button" data-settab="' + t[ 0 ] + '"' + ( SET.tab === t[ 0 ] ? ' class="is-active"' : '' ) + '>' + t[ 1 ] + '</button>';
		} ).join( '' ) + '</div>' + tabs.map( function ( t ) {
			return '<div data-setpane="' + t[ 0 ] + '"' + ( SET.tab === t[ 0 ] ? '' : ' hidden' ) + '>' + panes[ t[ 0 ] ] + '</div>';
		} ).join( '' ) +
			'<div class="bhc-set-foot"><p class="bhc-msg" data-msg></p><button type="button" class="bhc-btn" data-set-save>Salva impostazioni</button></div></div>';

		box.querySelectorAll( '[data-settab]' ).forEach( function ( t ) {
			t.addEventListener( 'click', function () {
				SET.tab = t.dataset.settab;
				box.querySelectorAll( '[data-settab]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === t );
				} );
				box.querySelectorAll( '[data-setpane]' ).forEach( function ( x ) {
					x.hidden = x.dataset.setpane !== SET.tab;
				} );
			} );
		} );
		box.querySelectorAll( '[data-all],[data-none]' ).forEach( function ( a ) {
			a.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				var role = a.dataset.all || a.dataset.none, on = !! a.dataset.all;
				box.querySelectorAll( '[data-role="' + role + '"]' ).forEach( function ( c ) {
					c.checked = on;
				} );
			} );
		} );
		// Dipendenze: chi modifica deve poter vedere.
		var needs = { agenda_edit: 'agenda_view', agenda_status: 'agenda_view', appt_delete: 'agenda_view', payments: 'agenda_view', clients_edit: 'clients_view', clients_notes: 'clients_view', clients_delete: 'clients_view', health: 'clients_view' };
		box.querySelectorAll( '[data-perm]' ).forEach( function ( c ) {
			c.addEventListener( 'change', function () {
				var role = c.dataset.role;
				if ( c.checked && needs[ c.dataset.perm ] ) {
					box.querySelector( '[data-perm="' + needs[ c.dataset.perm ] + '"][data-role="' + role + '"]' ).checked = true;
				}
				if ( ! c.checked ) {
					Object.keys( needs ).forEach( function ( k ) {
						if ( needs[ k ] === c.dataset.perm ) {
							box.querySelector( '[data-perm="' + k + '"][data-role="' + role + '"]' ).checked = false;
						}
					} );
				}
			} );
		} );
		box.querySelector( '[data-reset-perms]' ).addEventListener( 'click', function ( e ) {
			e.preventDefault();
			box.querySelectorAll( '[data-perm]' ).forEach( function ( c ) {
				c.checked = d.defaults[ c.dataset.role ].indexOf( c.dataset.perm ) !== -1;
			} );
			toast( 'Predefiniti ripristinati: premi Salva per confermare' );
		} );
		box.querySelector( '[data-set-save]' ).addEventListener( 'click', function () {
			var btn = this, msg = box.querySelector( '[data-msg]' );
			var settings = {};
			box.querySelectorAll( '[data-st]' ).forEach( function ( i ) {
				settings[ i.dataset.st ] = i.value;
			} );
			box.querySelectorAll( '[data-stc]' ).forEach( function ( i ) {
				settings[ i.dataset.stc ] = i.checked ? 1 : 0;
			} );
			var permsOut = {};
			Object.keys( d.roles ).forEach( function ( r ) {
				permsOut[ r ] = [];
			} );
			box.querySelectorAll( '[data-perm]:checked' ).forEach( function ( c ) {
				permsOut[ c.dataset.role ].push( c.dataset.perm );
			} );
			btn.disabled = true;
			msg.className = 'bhc-msg';
			msg.textContent = '';
			api( 'settings', { method: 'PUT', body: { settings: settings, perms: permsOut } } ).then( function ( nd ) {
				btn.disabled = false;
				SET.data = nd;
				B.center = nd.settings.center_name;
				toast( 'Impostazioni salvate' );
				drawSettings();
			} ).catch( function ( e ) {
				btn.disabled = false;
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
	}

	/* ================= Famiglie e categorie prodotti ================= */

	function loadTree() {
		return api( 'product-tree' ).then( function ( d ) {
			INV.tree = d.families;
			INV.locations = d.locations;
			return d;
		} );
	}

	/** Riempie una coppia di select famiglia/categoria. */
	function fillTreeFilters( famSel, catSel, famVal, catVal, forForm ) {
		famVal = String( famVal || '' );
		catVal = String( catVal || '' );
		// Se è indicata solo la categoria, ricava la famiglia.
		if ( catVal && ! famVal ) {
			INV.tree.forEach( function ( f ) {
				f.categories.forEach( function ( c ) {
					if ( String( c.id ) === catVal ) {
						famVal = String( f.id );
					}
				} );
			} );
		}
		famSel.innerHTML = '<option value="' + ( forForm ? '0' : '' ) + '">' + ( forForm ? '— nessuna —' : 'Tutte le famiglie' ) + '</option>' + INV.tree.map( function ( f ) {
			return '<option value="' + f.id + '"' + ( String( f.id ) === famVal ? ' selected' : '' ) + '>' + esc( f.name ) + '</option>';
		} ).join( '' );
		var fam = INV.tree.filter( function ( f ) {
			return String( f.id ) === famVal;
		} )[ 0 ];
		catSel.innerHTML = '<option value="' + ( forForm ? '0' : '' ) + '">' + ( forForm ? ( fam ? '— nessuna —' : 'Scegli prima la famiglia' ) : 'Tutte le categorie' ) + '</option>' + ( fam ? fam.categories : [] ).map( function ( c ) {
			return '<option value="' + c.id + '"' + ( String( c.id ) === catVal ? ' selected' : '' ) + '>' + esc( c.name ) + '</option>';
		} ).join( '' );
		catSel.disabled = ! fam;
	}

	/** Finestra di gestione famiglie e categorie. */
	function treeManager() {
		var editing = null;
		var m = modal( 'Famiglie e categorie dei prodotti', '<div data-tree-body><div class="bhc-loading">Caricamento…</div></div>', '<div></div><div><button type="button" class="bhc-btn" data-close>Fatto</button></div>', true );
		m.querySelector( '[data-close]' ).addEventListener( 'click', function () {
			closeModal();
			if ( S.view === 'products' ) {
				renderProducts();
			}
		} );
		function draw() {
			var body = m.querySelector( '[data-tree-body]' );
			body.innerHTML = '<p class="bhc-muted">La <strong>famiglia</strong> è il gruppo principale (es. Viso, Corpo, Mani e piedi); le <strong>categorie</strong> la suddividono (es. Creme, Sieri, Maschere). Servono per filtrare i prodotti, stampare lo stock e fare inventari parziali.</p>' +
				'<div class="bhc-tree">' + INV.tree.map( function ( f ) {
					return '<div class="bhc-tree__fam" style="--fam:' + esc( f.color ) + '"><div class="bhc-tree__head"><i></i><strong>' + esc( f.name ) + '</strong><span class="bhc-muted">' + f.products + ' prodott' + ( f.products === 1 ? 'o' : 'i' ) + '</span>' +
						'<span class="bhc-tree__actions"><button type="button" class="bhc-icon-btn bhc-icon-btn--sm" data-fam-edit="' + f.id + '" title="Modifica famiglia">' + ICONS.edit + '</button><button type="button" class="bhc-icon-btn bhc-icon-btn--sm" data-fam-del="' + f.id + '" title="Elimina famiglia">&times;</button></span></div>' +
						( f.description ? '<p class="bhc-muted bhc-tree__desc">' + esc( f.description ) + '</p>' : '' ) +
						'<div class="bhc-tree__cats">' + f.categories.map( function ( c ) {
							return '<span class="bhc-tree__cat">' + esc( c.name ) + ' <small>' + c.products + '</small><button type="button" data-cat-edit="' + c.id + '" data-fam="' + f.id + '" title="Rinomina">' + ICONS.edit + '</button><button type="button" data-cat-del="' + c.id + '" title="Elimina">&times;</button></span>';
						} ).join( '' ) +
						'<form class="bhc-tree__add" data-cat-add="' + f.id + '"><input type="text" placeholder="+ Nuova categoria in ' + esc( f.name ) + '" required><button type="submit" class="bhc-btn bhc-btn--sm">Aggiungi</button></form></div></div>';
				} ).join( '' ) + '</div>' +
				'<div class="bhc-tsection" style="margin-top:16px"><h4 data-fam-form-title>' + ( editing ? 'Modifica famiglia' : 'Nuova famiglia' ) + '</h4><div class="bhc-row" style="grid-template-columns:1fr 2fr auto"><div class="bhc-field"><label>Nome</label><input type="text" data-fam-name value="' + esc( editing ? editing.name : '' ) + '" placeholder="Es. Capelli, Monouso"></div>' +
				'<div class="bhc-field"><label>Descrizione (facoltativa)</label><input type="text" data-fam-desc value="' + esc( editing ? editing.description || '' : '' ) + '"></div>' +
				'<div class="bhc-field"><label>Colore</label><input type="color" data-fam-color value="' + esc( editing ? editing.color : CABIN_COLORS[ INV.tree.length % CABIN_COLORS.length ] ) + '" style="width:60px;height:42px;padding:3px"></div></div>' +
				'<p style="display:flex;gap:8px"><button type="button" class="bhc-btn bhc-btn--sm" data-fam-save>' + ( editing ? 'Salva famiglia' : '+ Crea famiglia' ) + '</button>' + ( editing ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-fam-cancel>Annulla</button>' : '' ) + '</p><p class="bhc-msg" data-tmsg></p></div>';
			bind( body );
		}
		function fail( e ) {
			var msg = m.querySelector( '[data-tmsg]' );
			msg.className = 'bhc-msg is-error';
			msg.textContent = e.message;
		}
		function done( d, text ) {
			INV.tree = d.families;
			editing = null;
			toast( text );
			draw();
		}
		function bind( body ) {
			body.querySelector( '[data-fam-save]' ).addEventListener( 'click', function () {
				var name = body.querySelector( '[data-fam-name]' ).value.trim();
				if ( ! name ) {
					return fail( { message: 'Inserisci il nome della famiglia.' } );
				}
				api( editing ? 'product-families/' + editing.id : 'product-families', { method: editing ? 'PUT' : 'POST', body: { name: name, description: body.querySelector( '[data-fam-desc]' ).value, color: body.querySelector( '[data-fam-color]' ).value } } ).then( function ( d ) {
					done( d, editing ? 'Famiglia salvata' : 'Famiglia creata' );
				} ).catch( fail );
			} );
			var cancel = body.querySelector( '[data-fam-cancel]' );
			if ( cancel ) {
				cancel.addEventListener( 'click', function () {
					editing = null;
					draw();
				} );
			}
			body.querySelectorAll( '[data-fam-edit]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					editing = INV.tree.filter( function ( f ) {
						return f.id === +b.dataset.famEdit;
					} )[ 0 ];
					draw();
					m.querySelector( '[data-fam-name]' ).focus();
				} );
			} );
			body.querySelectorAll( '[data-fam-del]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					if ( window.confirm( 'Eliminare la famiglia e le sue categorie?' ) ) {
						api( 'product-families/' + b.dataset.famDel, { method: 'DELETE' } ).then( function ( d ) {
							done( d, 'Famiglia eliminata' );
						} ).catch( fail );
					}
				} );
			} );
			body.querySelectorAll( '[data-cat-add]' ).forEach( function ( f ) {
				f.addEventListener( 'submit', function ( e ) {
					e.preventDefault();
					var name = f.querySelector( 'input' ).value.trim();
					if ( name ) {
						api( 'product-categories', { method: 'POST', body: { family_id: +f.dataset.catAdd, name: name } } ).then( function ( d ) {
							done( d, 'Categoria aggiunta' );
						} ).catch( fail );
					}
				} );
			} );
			body.querySelectorAll( '[data-cat-edit]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var cur = b.parentNode.firstChild.textContent.trim();
					var name = window.prompt( 'Nuovo nome della categoria:', cur );
					if ( name && name.trim() && name.trim() !== cur ) {
						api( 'product-categories/' + b.dataset.catEdit, { method: 'PUT', body: { family_id: +b.dataset.fam, name: name.trim() } } ).then( function ( d ) {
							done( d, 'Categoria rinominata' );
						} ).catch( fail );
					}
				} );
			} );
			body.querySelectorAll( '[data-cat-del]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					if ( window.confirm( 'Eliminare la categoria?' ) ) {
						api( 'product-categories/' + b.dataset.catDel, { method: 'DELETE' } ).then( function ( d ) {
							done( d, 'Categoria eliminata' );
						} ).catch( fail );
					}
				} );
			} );
		}
		loadTree().then( draw ).catch( fail );
	}

	/* ================= Stampa stock per inventario ================= */

	function stockPrintDialog() {
		var body = '<p class="bhc-muted">Stampa l\'elenco dei prodotti con la giacenza a sistema e le colonne vuote per scrivere la quantità contata. Puoi stamparla anche a fine conta per controllare il valore del magazzino.</p>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Famiglia</label><select data-sp-fam></select></div><div class="bhc-field"><label>Categoria</label><select data-sp-cat></select></div></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Tipo</label><select data-sp-type><option value="">Tutti</option><option value="rivendita">Rivendita</option><option value="consumo">Consumo in cabina</option></select></div>' +
			'<div class="bhc-field"><label>Ubicazione</label><select data-sp-loc><option value="">Tutte</option>' + INV.locations.map( function ( l ) {
				return '<option>' + esc( l ) + '</option>';
			} ).join( '' ) + '</select></div></div>' +
			'<div class="bhc-field"><label>Ordina e raggruppa per</label><select data-sp-group><option value="family">Famiglia › categoria</option><option value="location">Ubicazione (giro di conta)</option><option value="supplier">Fornitore</option><option value="none">Nome prodotto</option></select></div>' +
			'<label class="bhc-check"><input type="checkbox" data-sp-count checked> <span>Colonne vuote "Contato" e "Differenza" per la conta</span></label>' +
			'<label class="bhc-check"><input type="checkbox" data-sp-value> <span>Mostra prezzo di acquisto e valore della giacenza</span></label>' +
			'<label class="bhc-check"><input type="checkbox" data-sp-zero> <span>Escludi i prodotti con giacenza zero</span></label>';
		var m = modal( 'Stampa stock', body, '<div></div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Annulla</button><button type="button" class="bhc-btn" data-sp-go>' + ICONS.print + ' Stampa</button></div>' );
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
		var fs = m.querySelector( '[data-sp-fam]' ), cs = m.querySelector( '[data-sp-cat]' );
		fillTreeFilters( fs, cs, INV.pfam, INV.pcat );
		fs.addEventListener( 'change', function () {
			fillTreeFilters( fs, cs, fs.value, '' );
		} );
		m.querySelector( '[data-sp-go]' ).addEventListener( 'click', function () {
			var opt = {
				family: fs.value, category: cs.value, type: m.querySelector( '[data-sp-type]' ).value, location: m.querySelector( '[data-sp-loc]' ).value,
				group: m.querySelector( '[data-sp-group]' ).value, count: m.querySelector( '[data-sp-count]' ).checked,
				value: m.querySelector( '[data-sp-value]' ).checked, zero: m.querySelector( '[data-sp-zero]' ).checked,
				label: [ fs.value ? fs.options[ fs.selectedIndex ].text : '', cs.value ? cs.options[ cs.selectedIndex ].text : '' ].filter( Boolean ).join( ' › ' )
			};
			api( 'products?family=' + opt.family + '&category=' + opt.category + '&type=' + opt.type + '&location=' + encodeURIComponent( opt.location ) ).then( function ( d ) {
				var items = d.items.filter( function ( p ) {
					return ! opt.zero || p.stock !== 0;
				} );
				closeModal();
				printStock( items, opt );
			} ).catch( function ( e ) {
				toast( e.message, true );
			} );
		} );
	}

	function groupKey( p, g ) {
		if ( g === 'family' ) {
			return ( p.family || 'Senza famiglia' ) + ( p.category ? ' › ' + p.category : '' );
		}
		if ( g === 'location' ) {
			return p.location || 'Ubicazione non indicata';
		}
		if ( g === 'supplier' ) {
			return p.supplier_name || 'Senza fornitore';
		}
		return '';
	}

	function printStock( items, opt ) {
		var groups = {}, order = [];
		items.slice().sort( function ( a, b ) {
			var ka = groupKey( a, opt.group ), kb = groupKey( b, opt.group );
			return ka === kb ? a.name.localeCompare( b.name ) : ka.localeCompare( kb );
		} ).forEach( function ( p ) {
			var k = groupKey( p, opt.group );
			if ( ! groups[ k ] ) {
				groups[ k ] = [];
				order.push( k );
			}
			groups[ k ].push( p );
		} );
		var totQty = 0, totVal = 0;
		var head = '<tr><th>Codice</th><th>EAN</th><th>Prodotto</th><th>Ubic.</th><th class="r">Giacenza</th>' + ( opt.value ? '<th class="r">Costo</th><th class="r">Valore</th>' : '' ) + ( opt.count ? '<th class="r" style="width:80px">Contato</th><th class="r" style="width:70px">Diff.</th>' : '' ) + '</tr>';
		var html = order.map( function ( k ) {
			var sq = 0, sv = 0;
			var rows = groups[ k ].map( function ( p ) {
				sq += p.stock;
				sv += p.stock * p.cost_price;
				return '<tr><td>' + esc( p.sku ) + '</td><td>' + esc( p.ean ) + '</td><td>' + esc( p.name ) + '</td><td>' + esc( p.location ) + '</td><td class="r"><b>' + qty( p.stock ) + '</b> ' + esc( p.unit ) + '</td>' +
					( opt.value ? '<td class="r">' + euro( p.cost_price ) + '</td><td class="r">' + euro( p.stock * p.cost_price ) + '</td>' : '' ) +
					( opt.count ? '<td class="box"></td><td class="box"></td>' : '' ) + '</tr>';
			} ).join( '' );
			totQty += sq;
			totVal += sv;
			return ( k ? '<h2>' + esc( k ) + '</h2>' : '' ) + '<table>' + head + rows + ( opt.value ? '<tr class="sub"><td colspan="4">Totale ' + esc( k ) + '</td><td class="r">' + qty( sq ) + '</td><td></td><td class="r">' + euro( sv ) + '</td>' + ( opt.count ? '<td></td><td></td>' : '' ) + '</tr>' : '' ) + '</table>';
		} ).join( '' );
		var filters = [];
		if ( opt.label ) {
			filters.push( opt.label );
		}
		if ( opt.type ) {
			filters.push( opt.type === 'consumo' ? 'Consumo in cabina' : 'Rivendita' );
		}
		if ( opt.location ) {
			filters.push( 'Ubicazione: ' + opt.location );
		}
		printHtml( 'Stock magazzino', '<style>td.box{border:1px solid #999;height:22px}tr.sub td{font-weight:bold;border-top:2px solid #ccc}.sign{display:flex;gap:40px;margin-top:40px}.sign div{flex:1;border-top:1px solid #999;padding-top:4px;color:#7a776f}</style>' +
			'<div class="muted">' + esc( B.center ) + '</div><h1>Stock di magazzino' + ( opt.count ? ' – foglio di conta' : '' ) + '</h1><div class="muted">Stampato il ' + new Date().toLocaleString( 'it-IT' ) + ' · ' + items.length + ' prodotti' + ( filters.length ? ' · ' + esc( filters.join( ' · ' ) ) : '' ) + '</div>' +
			( items.length ? html : '<p>Nessun prodotto.</p>' ) +
			( opt.value ? '<h2>Totale generale</h2><table><tr><td>Quantità</td><td class="r">' + qty( totQty ) + '</td><td>Valore al costo</td><td class="r"><b>' + euro( totVal ) + '</b></td></tr></table>' : '' ) +
			( opt.count ? '<div class="sign"><div>Contato da</div><div>Data e ora</div><div>Firma</div></div>' : '' ) );
	}

	/* ================= Inventario ================= */

	var INVT = { current: null, zone: null, auto1: false, sound: true, onlyTodo: false, onlyDiff: false, q: '', scan: true, pending: {}, timer: null };

	function renderInventory() {
		var main = document.getElementById( 'bhc-main' );
		if ( INVT.current && INVT.zone ) {
			return renderZone( INVT.current, INVT.zone );
		}
		if ( INVT.current ) {
			return renderInventorySheet( INVT.current );
		}
		main.innerHTML = '<div class="bhc-top"><h2>Inventario</h2><div class="bhc-top__actions">' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-stockprint>' + ICONS.print + ' Stampa stock</button>' +
			'<button type="button" class="bhc-btn bhc-btn--sm" data-inv-new>' + ICONS.inventory + ' Nuovo inventario</button></div></div><div data-invlist><div class="bhc-loading">Caricamento…</div></div>';
		main.querySelector( '[data-inv-new]' ).addEventListener( 'click', newInventoryDialog );
		main.querySelector( '[data-stockprint]' ).addEventListener( 'click', function () {
			( INV.tree.length ? Promise.resolve() : loadTree() ).then( stockPrintDialog );
		} );
		api( 'inventories' ).then( function ( d ) {
			var box = main.querySelector( '[data-invlist]' );
			if ( ! d.items.length ) {
				box.innerHTML = '<div class="bhc-card"><h3>Nessun inventario</h3><p class="bhc-muted">Crea una scheda inventario: il gestionale fotografa le giacenze dei prodotti scelti (tutti, una famiglia, una categoria, un\'ubicazione). Poi conti i prodotti, anche con il lettore di codici a barre, e alla chiusura le giacenze vengono corrette in automatico.</p><button type="button" class="bhc-btn" data-inv-new2>' + ICONS.inventory + ' Crea il primo inventario</button></div>';
				box.querySelector( '[data-inv-new2]' ).addEventListener( 'click', newInventoryDialog );
				return;
			}
			box.innerHTML = '<table class="bhc-table"><thead><tr><th>Data</th><th>Inventario</th><th>Prodotti</th><th>Avanzamento</th><th class="bhc-r">Differenze</th><th class="bhc-r">Valore differenze</th><th>Stato</th></tr></thead><tbody>' + d.items.map( function ( i ) {
				var pct = i.items ? Math.round( i.counted_items / i.items * 100 ) : 0;
				return '<tr class="is-click" data-invid="' + i.id + '"><td>' + esc( i.date.split( '-' ).reverse().join( '/' ) ) + '</td><td><strong>' + esc( i.title ) + '</strong><div class="bhc-muted" style="font-size:.82rem">' + esc( i.scope ) + '</div></td><td>' + i.items + '</td>' +
					'<td style="min-width:150px"><div class="bhc-bar"><span style="width:' + pct + '%"></span></div><span class="bhc-muted" style="font-size:.8rem">' + i.counted_items + ' / ' + i.items + ' contati</span></td>' +
					'<td class="bhc-r">' + i.diff_items + '</td><td class="bhc-r ' + ( i.diff_value < 0 ? 'bhc-neg' : i.diff_value > 0 ? 'bhc-pos' : '' ) + '">' + ( i.diff_value > 0 ? '+' : '' ) + euro( i.diff_value ) + '</td>' +
					'<td>' + ( i.status === 'chiuso' ? '<span class="bhc-badge bhc-badge--done">Chiuso</span>' : '<span class="bhc-badge bhc-badge--booked">In corso</span>' ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table>';
			box.querySelectorAll( '[data-invid]' ).forEach( function ( r ) {
				r.addEventListener( 'click', function () {
					INVT.current = +r.dataset.invid;
					renderInventory();
				} );
			} );
		} );
	}

	function newInventoryDialog() {
		( INV.tree.length ? Promise.resolve() : loadTree() ).then( function () {
			var today = ymd( new Date() );
			var body = '<div class="bhc-row"><div class="bhc-field"><label>Titolo</label><input type="text" data-ni-title placeholder="Inventario del ' + today.split( '-' ).reverse().join( '/' ) + '"></div><div class="bhc-field"><label>Data</label><input type="date" data-ni-date value="' + today + '"></div></div>' +
				'<h4>Prodotti da contare</h4><p class="bhc-muted" style="margin-top:-6px">Lascia "Tutte" per un inventario completo, oppure scegli una parte del magazzino per un inventario parziale.</p>' +
				'<div class="bhc-row"><div class="bhc-field"><label>Famiglia</label><select data-ni-fam></select></div><div class="bhc-field"><label>Categoria</label><select data-ni-cat></select></div></div>' +
				'<div class="bhc-row"><div class="bhc-field"><label>Tipo</label><select data-ni-type><option value="">Tutti</option><option value="rivendita">Rivendita</option><option value="consumo">Consumo in cabina</option></select></div><div class="bhc-field"><label>Ubicazione</label><select data-ni-loc><option value="">Tutte</option>' + INV.locations.map( function ( l ) {
					return '<option>' + esc( l ) + '</option>';
				} ).join( '' ) + '</select></div></div>' +
				'<div class="bhc-tsection"><h4>Zone di conta</h4><p class="bhc-muted" style="margin-top:-4px">Dividi il magazzino in zone (es. reception, scaffali, cabine): in ogni zona si spara il codice EAN con la pistola e si inserisce la quantità. Il totale di ogni prodotto è la somma di tutte le zone.</p>' +
				'<div class="bhc-row" style="grid-template-columns:180px 1fr;align-items:end"><div class="bhc-field"><label>Numero di zone</label><input type="number" min="0" max="99" step="1" data-ni-zones value="3"></div><p class="bhc-muted" style="margin:0 0 18px">0 = nessuna zona (conta direttamente sulla scheda)</p></div>' +
				'<div class="bhc-zone-names" data-ni-names></div></div>' +
				'<div class="bhc-field"><label>Note</label><textarea rows="2" data-ni-notes placeholder="Es. inventario di fine anno, contato da…"></textarea></div><p class="bhc-msg" data-msg></p>';
			var m = modal( 'Nuovo inventario', body, '<div></div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Annulla</button><button type="button" class="bhc-btn" data-ni-go>Crea scheda inventario</button></div>' );
			m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
			var fs = m.querySelector( '[data-ni-fam]' ), cs = m.querySelector( '[data-ni-cat]' );
			fillTreeFilters( fs, cs, '', '' );
			var zn = m.querySelector( '[data-ni-zones]' ), names = m.querySelector( '[data-ni-names]' );
			function drawNames() {
				var n = Math.min( 99, Math.max( 0, parseInt( zn.value, 10 ) || 0 ) );
				var old = Array.prototype.map.call( names.querySelectorAll( 'input' ), function ( i ) {
					return i.value;
				} );
				var html = '';
				for ( var i = 0; i < n; i++ ) {
					html += '<label><span>' + ( i + 1 ) + '</span><input type="text" value="' + esc( old[ i ] || '' ) + '" placeholder="Zona ' + ( i + 1 ) + ' (nome facoltativo)"></label>';
				}
				names.innerHTML = html;
			}
			zn.addEventListener( 'input', drawNames );
			drawNames();
			fs.addEventListener( 'change', function () {
				fillTreeFilters( fs, cs, fs.value, '' );
			} );
			m.querySelector( '[data-ni-go]' ).addEventListener( 'click', function () {
				var btn = this;
				btn.disabled = true;
				api( 'inventories', { method: 'POST', body: { title: m.querySelector( '[data-ni-title]' ).value, date: m.querySelector( '[data-ni-date]' ).value, family_id: fs.value, category_id: cs.value, product_type: m.querySelector( '[data-ni-type]' ).value, location: m.querySelector( '[data-ni-loc]' ).value, notes: m.querySelector( '[data-ni-notes]' ).value, zones: parseInt( zn.value, 10 ) || 0, zone_names: Array.prototype.map.call( names.querySelectorAll( 'input' ), function ( i ) {
					return i.value;
				} ) } } ).then( function ( inv ) {
					closeModal();
					toast( 'Scheda creata con ' + inv.items + ' prodotti' + ( inv.zones.length ? ' e ' + inv.zones.length + ' zone' : '' ) + ( inv.other_open ? ' (ci sono altri inventari in corso)' : '' ) );
					INVT.current = inv.id;
					S.view = 'inventory';
					render();
				} ).catch( function ( e ) {
					btn.disabled = false;
					var msg = m.querySelector( '[data-msg]' );
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		} );
	}

	/** Scheda inventario: conta con salvataggio automatico. */
	function renderInventorySheet( id ) {
		var main = document.getElementById( 'bhc-main' );
		main.innerHTML = '<div class="bhc-loading">Caricamento scheda…</div>';
		api( 'inventories/' + id ).then( function ( inv ) {
			drawSheet( inv );
		} ).catch( function ( e ) {
			INVT.current = null;
			toast( e.message, true );
			renderInventory();
		} );
	}

	function drawSheet( inv ) {
		var main = document.getElementById( 'bhc-main' );
		var open = inv.status === 'bozza';
		var byPid = {};
		inv.lines.forEach( function ( l ) {
			byPid[ l.product_id ] = l;
		} );

		main.innerHTML = '<div class="bhc-top"><div><a href="#" data-inv-back class="bhc-muted">&larr; Tutti gli inventari</a><h2 style="margin-top:4px">' + esc( inv.title ) + '</h2><div class="bhc-muted">' + esc( inv.date.split( '-' ).reverse().join( '/' ) ) + ' · ' + esc( inv.scope ) + ( inv.author ? ' · creato da ' + esc( inv.author ) : '' ) + '</div></div>' +
			'<div class="bhc-top__actions"><span data-savestate class="bhc-muted" style="font-size:.85rem"></span>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-inv-print>' + ICONS.print + ' Stampa scheda</button>' +
			( open ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-inv-del>Elimina</button><button type="button" class="bhc-btn bhc-btn--sm" data-inv-close>Chiudi e aggiorna giacenze</button>' : '<span class="bhc-badge bhc-badge--done">Chiuso il ' + esc( ( inv.closed_at || '' ).substring( 0, 10 ).split( '-' ).reverse().join( '/' ) ) + '</span>' ) + '</div></div>' +
			'<div class="bhc-kpis" data-inv-kpis></div>' +
			( inv.has_zones ? zonesPanel( inv ) : '' ) +
			( open && ! inv.has_zones ? '<div class="bhc-scan"><span class="bhc-scan__icon">' + ICONS.products + '</span><input type="search" data-scan placeholder="Scansiona il codice a barre o cerca per nome / codice e premi Invio" autocomplete="off">' +
				'<label class="bhc-switch"><input type="checkbox" data-scanmode' + ( INVT.scan ? ' checked' : '' ) + '><span></span> Ogni scansione aggiunge +1</label></div>' : '' ) +
			'<div class="bhc-inv-filters"><label class="bhc-check"><input type="checkbox" data-only-todo' + ( INVT.onlyTodo ? ' checked' : '' ) + '> <span>Solo da contare</span></label><label class="bhc-check"><input type="checkbox" data-only-diff' + ( INVT.onlyDiff ? ' checked' : '' ) + '> <span>Solo con differenze</span></label></div>' +
			'<div data-inv-table></div>' +
			( inv.notes ? '<p class="bhc-muted" style="margin-top:12px"><strong>Note:</strong> ' + esc( inv.notes ) + '</p>' : '' );

		function kpis() {
			var counted = 0, diffItems = 0, diffVal = 0, todo = 0;
			inv.lines.forEach( function ( l ) {
				if ( l.counted === null ) {
					todo++;
					return;
				}
				counted++;
				var d = l.counted - l.expected;
				if ( Math.abs( d ) > 0.001 ) {
					diffItems++;
					diffVal += d * l.cost_price;
				}
			} );
			var pct = inv.lines.length ? Math.round( counted / inv.lines.length * 100 ) : 0;
			main.querySelector( '[data-inv-kpis]' ).innerHTML =
				'<div class="bhc-card"><div class="bhc-kpi__label">Avanzamento</div><div class="bhc-kpi__value">' + pct + '%</div><div class="bhc-bar"><span style="width:' + pct + '%"></span></div><div class="bhc-muted" style="font-size:.8rem;margin-top:4px">' + counted + ' contati · ' + todo + ' da contare</div></div>' +
				kpi( 'Prodotti con differenze', diffItems ) +
				'<div class="bhc-card"><div class="bhc-kpi__label">Valore differenze (al costo)</div><div class="bhc-kpi__value ' + ( diffVal < 0 ? 'bhc-neg' : diffVal > 0 ? 'bhc-pos' : '' ) + '">' + ( diffVal > 0 ? '+' : '' ) + euro( diffVal ) + '</div></div>' +
				kpi( 'Valore teorico', euro( inv.lines.reduce( function ( a, l ) {
					return a + l.expected * l.cost_price;
				}, 0 ) ) );
		}

		function table() {
			var q = INVT.q.trim().toLowerCase();
			var rows = inv.lines.filter( function ( l ) {
				if ( INVT.onlyTodo && l.counted !== null ) {
					return false;
				}
				if ( INVT.onlyDiff && ( l.counted === null || Math.abs( l.counted - l.expected ) < 0.001 ) ) {
					return false;
				}
				return ! q || ( l.name + ' ' + l.ean + ' ' + l.sku ).toLowerCase().indexOf( q ) !== -1;
			} );
			var groups = {}, order = [];
			rows.forEach( function ( l ) {
				var k = ( l.family || 'Senza famiglia' ) + ( l.category ? ' › ' + l.category : '' );
				if ( ! groups[ k ] ) {
					groups[ k ] = [];
					order.push( k );
				}
				groups[ k ].push( l );
			} );
			order.sort();
			var html = rows.length ? '<table class="bhc-table bhc-invtable"><thead><tr><th>Codice / EAN</th><th>Prodotto</th><th class="bhc-r">A sistema</th><th class="bhc-r" style="width:120px">' + ( inv.has_zones ? 'Contato (somma zone)' : 'Contato' ) + '</th><th class="bhc-r">Differenza</th><th class="bhc-r">Valore</th><th>Nota</th></tr></thead><tbody>' + order.map( function ( k ) {
				return '<tr class="bhc-invtable__group"><td colspan="7">' + esc( k ) + '</td></tr>' + groups[ k ].map( function ( l ) {
					var d = l.counted === null ? null : l.counted - l.expected;
					var cls = d === null ? '' : Math.abs( d ) < 0.001 ? 'is-ok' : 'is-diff';
					return '<tr data-row="' + l.product_id + '" class="' + cls + '"><td><strong>' + esc( l.sku ) + '</strong><div class="bhc-muted bhc-mono">' + esc( l.ean || '' ) + '</div></td>' +
						'<td>' + esc( l.name ) + ( l.location ? '<div class="bhc-muted" style="font-size:.8rem">📍 ' + esc( l.location ) + '</div>' : '' ) + ( open && l.moved_since ? '<div class="bhc-moved">Movimenti dopo l\'apertura: ' + ( l.moved_since > 0 ? '+' : '' ) + qty( l.moved_since ) + '</div>' : '' ) + '</td>' +
						'<td class="bhc-r">' + qty( l.expected ) + ' ' + esc( l.unit ) + '</td>' +
						'<td class="bhc-r">' + ( open && ! inv.has_zones ? '<input type="number" min="0" step="1" inputmode="decimal" class="bhc-count" data-count="' + l.product_id + '" value="' + ( l.counted === null ? '' : l.counted ) + '" placeholder="—">' : ( l.counted === null ? '<span class="bhc-muted">—</span>' : '<strong>' + qty( l.counted ) + '</strong>' ) ) +
							( inv.has_zones && l.counted !== null ? '<div class="bhc-zonebits">' + inv.zones.filter( function ( z ) {
								return l.by_zone[ z.id ];
							} ).map( function ( z ) {
								return '<span title="' + esc( z.name ) + '">Z' + z.number + ': ' + qty( l.by_zone[ z.id ] ) + '</span>';
							} ).join( '' ) + '</div>' : '' ) + '</td>' +
						'<td class="bhc-r" data-diff="' + l.product_id + '">' + diffHtml( d, '' ) + '</td>' +
						'<td class="bhc-r" data-dval="' + l.product_id + '">' + diffHtml( d === null ? null : d * l.cost_price, 'eur' ) + '</td>' +
						'<td>' + ( open ? '<input type="text" class="bhc-countnote" data-note="' + l.product_id + '" value="' + esc( l.note ) + '" placeholder="es. 2 danneggiati">' : esc( l.note ) ) + '</td></tr>';
				} ).join( '' );
			} ).join( '' ) + '</tbody></table>' : '<div class="bhc-card bhc-muted">Nessun prodotto da mostrare con questi filtri.</div>';
			main.querySelector( '[data-inv-table]' ).innerHTML = html;
			if ( open ) {
				main.querySelectorAll( '[data-count]' ).forEach( function ( i ) {
					i.addEventListener( 'input', function () {
						setCount( +i.dataset.count, i.value === '' ? null : Math.max( 0, parseFloat( i.value ) ), false );
					} );
					i.addEventListener( 'keydown', function ( e ) {
						if ( e.key === 'Enter' ) {
							e.preventDefault();
							var all = Array.prototype.slice.call( main.querySelectorAll( '[data-count]' ) );
							var next = all[ all.indexOf( i ) + 1 ];
							( next || main.querySelector( '[data-scan]' ) ).focus();
							if ( next ) {
								next.select();
							}
						}
					} );
				} );
				main.querySelectorAll( '[data-note]' ).forEach( function ( i ) {
					i.addEventListener( 'input', function () {
						byPid[ i.dataset.note ].note = i.value;
						queue( +i.dataset.note );
					} );
				} );
			}
		}

		function diffHtml( v, type ) {
			if ( v === null ) {
				return '<span class="bhc-muted">—</span>';
			}
			if ( Math.abs( v ) < 0.001 ) {
				return '<span class="bhc-pos">✓</span>';
			}
			return '<span class="' + ( v < 0 ? 'bhc-neg' : 'bhc-pos' ) + '">' + ( v > 0 ? '+' : '' ) + ( type === 'eur' ? euro( v ) : qty( v ) ) + '</span>';
		}

		function setCount( pid, value, rerender ) {
			var l = byPid[ pid ];
			if ( ! l ) {
				return;
			}
			l.counted = value;
			queue( pid );
			if ( rerender ) {
				table();
			} else {
				var d = value === null ? null : value - l.expected;
				var row = main.querySelector( '[data-row="' + pid + '"]' );
				row.className = d === null ? '' : Math.abs( d ) < 0.001 ? 'is-ok' : 'is-diff';
				main.querySelector( '[data-diff="' + pid + '"]' ).innerHTML = diffHtml( d, '' );
				main.querySelector( '[data-dval="' + pid + '"]' ).innerHTML = diffHtml( d === null ? null : d * l.cost_price, 'eur' );
			}
			kpis();
		}

		// Salvataggio automatico (raggruppa le modifiche).
		function queue( pid ) {
			INVT.pending[ pid ] = true;
			main.querySelector( '[data-savestate]' ).textContent = 'Modifiche da salvare…';
			clearTimeout( INVT.timer );
			INVT.timer = setTimeout( flush, 700 );
		}
		function flush() {
			var pids = Object.keys( INVT.pending );
			if ( ! pids.length ) {
				return Promise.resolve();
			}
			INVT.pending = {};
			var lines = pids.map( function ( pid ) {
				var l = byPid[ pid ];
				return { product_id: +pid, counted: l.counted, note: l.note || '' };
			} );
			var st = main.querySelector( '[data-savestate]' );
			if ( st ) {
				st.textContent = 'Salvataggio…';
			}
			return api( 'inventories/' + inv.id, { method: 'PUT', body: { lines: lines } } ).then( function () {
				if ( st ) {
					st.textContent = '✓ Salvato alle ' + new Date().toLocaleTimeString( 'it-IT', { hour: '2-digit', minute: '2-digit' } );
				}
			} ).catch( function ( e ) {
				pids.forEach( function ( pid ) {
					INVT.pending[ pid ] = true;
				} );
				if ( st ) {
					st.innerHTML = '<span class="bhc-neg">Non salvato: ' + esc( e.message ) + '</span>';
				}
			} );
		}

		// Lettore barcode / ricerca.
		var scan = main.querySelector( '[data-scan]' );
		if ( scan ) {
			scan.focus();
			scan.addEventListener( 'input', function () {
				INVT.q = /^\d{6,}$/.test( scan.value.trim() ) ? '' : scan.value;
				if ( ! /^\d{6,}$/.test( scan.value.trim() ) ) {
					table();
				}
			} );
			scan.addEventListener( 'keydown', function ( e ) {
				if ( e.key !== 'Enter' ) {
					return;
				}
				e.preventDefault();
				var code = scan.value.trim();
				if ( ! code ) {
					return;
				}
				var hit = inv.lines.filter( function ( l ) {
					return l.ean === code || ( l.sku || '' ).toUpperCase() === code.toUpperCase();
				} )[ 0 ];
				if ( ! hit ) {
					var matches = inv.lines.filter( function ( l ) {
						return l.name.toLowerCase().indexOf( code.toLowerCase() ) !== -1;
					} );
					if ( matches.length === 1 ) {
						hit = matches[ 0 ];
					}
				}
				if ( ! hit ) {
					// Prodotto non presente nella scheda: lo cerca in anagrafica e lo aggiunge.
					api( 'products?q=' + encodeURIComponent( code ) + '&all=1' ).then( function ( d ) {
						var p = d.items.filter( function ( x ) {
							return x.ean === code || x.sku === code.toUpperCase();
						} )[ 0 ];
						if ( p && window.confirm( '"' + p.name + '" non è in questa scheda. Aggiungerlo all\'inventario?' ) ) {
							var line = { product_id: p.id, name: p.name, ean: p.ean, sku: p.sku, unit: p.unit, location: p.location, family: p.family, category: p.category, expected: p.stock, current_stock: p.stock, moved_since: 0, cost_price: p.cost_price, counted: INVT.scan ? 1 : null, note: '' };
							inv.lines.push( line );
							byPid[ p.id ] = line;
							queue( p.id );
							scan.value = '';
							table();
							kpis();
							toast( 'Aggiunto: ' + p.name );
						} else if ( ! p ) {
							toast( 'Codice non trovato: ' + code, true );
						}
					} );
					return;
				}
				scan.value = '';
				INVT.q = '';
				if ( INVT.scan ) {
					setCount( hit.product_id, ( hit.counted || 0 ) + 1, true );
					var row = main.querySelector( '[data-row="' + hit.product_id + '"]' );
					if ( row ) {
						row.scrollIntoView( { block: 'center', behavior: 'smooth' } );
						row.classList.add( 'is-flash' );
						setTimeout( function () {
							row.classList.remove( 'is-flash' );
						}, 900 );
					}
					toast( hit.name + ': ' + qty( hit.counted ) + ' ' + hit.unit );
				} else {
					table();
					var input = main.querySelector( '[data-count="' + hit.product_id + '"]' );
					if ( input ) {
						input.scrollIntoView( { block: 'center' } );
						input.focus();
						input.select();
					}
				}
			} );
			main.querySelector( '[data-scanmode]' ).addEventListener( 'change', function ( e ) {
				INVT.scan = e.target.checked;
				scan.focus();
			} );
		}

		main.querySelectorAll( '[data-zone]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				flush().then( function () {
					INVT.zone = +b.dataset.zone;
					renderInventory();
				} );
			} );
		} );
		var za = main.querySelector( '[data-zone-add]' );
		if ( za ) {
			za.addEventListener( 'click', function () {
				var name = window.prompt( 'Nome della nuova zona (facoltativo):', '' );
				if ( name === null ) {
					return;
				}
				api( 'inventories/' + inv.id + '/zones', { method: 'POST', body: { name: name } } ).then( function () {
					toast( 'Zona aggiunta' );
					renderInventorySheet( inv.id );
				} ).catch( function ( e ) {
					toast( e.message, true );
				} );
			} );
		}
		main.querySelector( '[data-only-todo]' ).addEventListener( 'change', function ( e ) {
			INVT.onlyTodo = e.target.checked;
			table();
		} );
		main.querySelector( '[data-only-diff]' ).addEventListener( 'change', function ( e ) {
			INVT.onlyDiff = e.target.checked;
			table();
		} );
		main.querySelector( '[data-inv-back]' ).addEventListener( 'click', function ( e ) {
			e.preventDefault();
			flush().then( function () {
				INVT.current = null;
				INVT.zone = null;
				renderInventory();
			} );
		} );
		main.querySelector( '[data-inv-print]' ).addEventListener( 'click', function () {
			flush();
			printInventory( inv );
		} );
		var del = main.querySelector( '[data-inv-del]' );
		if ( del ) {
			del.addEventListener( 'click', function () {
				if ( window.confirm( 'Eliminare questa scheda inventario? Le quantità contate andranno perse.' ) ) {
					api( 'inventories/' + inv.id, { method: 'DELETE' } ).then( function () {
						INVT.current = null;
						toast( 'Inventario eliminato' );
						renderInventory();
					} );
				}
			} );
		}
		var cl = main.querySelector( '[data-inv-close]' );
		if ( cl ) {
			cl.addEventListener( 'click', function () {
				flush().then( function () {
					closeInventoryDialog( inv );
				} );
			} );
		}
		kpis();
		table();
	}

	function closeInventoryDialog( inv ) {
		var todo = inv.lines.filter( function ( l ) {
			return l.counted === null;
		} ).length;
		var moved = inv.lines.filter( function ( l ) {
			return l.counted !== null && l.moved_since;
		} ).length;
		var diffs = inv.lines.filter( function ( l ) {
			return l.counted !== null && Math.abs( l.counted - l.expected ) > 0.001;
		} );
		var val = diffs.reduce( function ( a, l ) {
			return a + ( l.counted - l.expected ) * l.cost_price;
		}, 0 );
		var openZones = ( inv.zones || [] ).filter( function ( z ) {
			return z.status !== 'completata';
		} );
		var body = ( openZones.length ? '<div class="bhc-alert bhc-alert--soon">' + ICONS.alert + '<span>Zone non ancora completate: ' + openZones.map( function ( z ) {
			return esc( z.name ) + ( z.reads ? '' : ' (nessuna lettura)' );
		} ).join( ', ' ) + '.</span></div>' : '' ) + '<p>Alla chiusura le giacenze dei prodotti contati vengono allineate alle quantità contate, con un movimento "Inventario" nello storico di ogni prodotto. L\'inventario chiuso non si potrà più modificare.</p>' +
			'<div class="bhc-kpis">' + kpi( 'Rettifiche', diffs.length ) + kpi( 'Valore rettifiche', ( val > 0 ? '+' : '' ) + euro( val ) ) + kpi( 'Non contati', todo ) + '</div>' +
			( todo ? '<div class="bhc-field"><label>Prodotti non contati (' + todo + ')</label><label class="bhc-check"><input type="radio" name="bhc-unc" value="keep" checked> <span>Lascia invariata la giacenza</span></label><label class="bhc-check"><input type="radio" name="bhc-unc" value="zero"> <span>Considerali a zero (non trovati)</span></label></div>' : '' ) +
			( moved ? '<div class="bhc-alert bhc-alert--soon">' + ICONS.alert + '<span>' + moved + ' prodotti hanno avuto movimenti (vendite, carichi) dopo l\'apertura della scheda.</span></div><label class="bhc-check"><input type="checkbox" data-keep-moves checked> <span>Tieni conto di questi movimenti (consigliato se hai contato prima delle vendite)</span></label>' : '' ) +
			'<p class="bhc-msg" data-msg></p>';
		var m = modal( 'Chiudi inventario', body, '<div></div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Annulla</button><button type="button" class="bhc-btn" data-do-close>Chiudi e aggiorna giacenze</button></div>' );
		m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
		m.querySelector( '[data-do-close]' ).addEventListener( 'click', function () {
			var btn = this;
			var unc = m.querySelector( 'input[name="bhc-unc"]:checked' );
			var km = m.querySelector( '[data-keep-moves]' );
			btn.disabled = true;
			api( 'inventories/' + inv.id + '/close', { method: 'POST', body: { uncounted: unc ? unc.value : 'keep', keep_moves: km ? ( km.checked ? 1 : 0 ) : 1 } } ).then( function ( closed ) {
				closeModal();
				toast( 'Inventario chiuso: giacenze aggiornate' );
				drawSheet( closed );
			} ).catch( function ( e ) {
				btn.disabled = false;
				var msg = m.querySelector( '[data-msg]' );
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
	}

	function printInventory( inv ) {
		var open = inv.status === 'bozza';
		var groups = {}, order = [];
		inv.lines.slice().sort( function ( a, b ) {
			return a.name.localeCompare( b.name );
		} ).forEach( function ( l ) {
			var k = ( l.family || 'Senza famiglia' ) + ( l.category ? ' › ' + l.category : '' );
			if ( ! groups[ k ] ) {
				groups[ k ] = [];
				order.push( k );
			}
			groups[ k ].push( l );
		} );
		order.sort();
		var totDiff = 0, totCount = 0;
		var html = order.map( function ( k ) {
			return '<h2>' + esc( k ) + '</h2><table><tr><th>Codice</th><th>EAN</th><th>Prodotto</th><th class="r">A sistema</th><th class="r">Contato</th><th class="r">Diff.</th><th class="r">Valore diff.</th><th>Nota</th></tr>' + groups[ k ].map( function ( l ) {
				var d = l.counted === null ? null : l.counted - l.expected;
				if ( d !== null ) {
					totDiff += d * l.cost_price;
					totCount += l.counted * l.cost_price;
				}
				return '<tr><td>' + esc( l.sku ) + '</td><td>' + esc( l.ean ) + '</td><td>' + esc( l.name ) + '</td><td class="r">' + qty( l.expected ) + ' ' + esc( l.unit ) + '</td>' +
					'<td class="r' + ( l.counted === null ? ' box' : '' ) + '">' + ( l.counted === null ? '' : '<b>' + qty( l.counted ) + '</b>' ) + '</td>' +
					'<td class="r">' + ( d === null ? '' : ( d > 0 ? '+' : '' ) + qty( d ) ) + '</td><td class="r">' + ( d === null || ! d ? '' : euro( d * l.cost_price ) ) + '</td><td>' + esc( l.note ) + '</td></tr>';
			} ).join( '' ) + '</table>';
		} ).join( '' );
		var zoneSummary = inv.has_zones ? '<h2>Zone</h2><table><tr><th>Zona</th><th>Operatore</th><th class="r">Letture</th><th class="r">Pezzi</th><th>Stato</th></tr>' + inv.zones.map( function ( z ) {
			return '<tr><td>' + z.number + ' · ' + esc( z.name ) + '</td><td>' + esc( z.assigned_to ) + '</td><td class="r">' + z.reads + '</td><td class="r">' + qty( z.pieces ) + '</td><td>' + ( z.status === 'completata' ? 'Completata' : 'Aperta' ) + '</td></tr>';
		} ).join( '' ) + '</table>' : '';
		printHtml( inv.title, '<style>td.box{border:1px solid #999}</style><div class="muted">' + esc( B.center ) + ' — Scheda inventario n. ' + inv.id + '</div><h1>' + esc( inv.title ) + '</h1>' +
			'<div class="muted">Data ' + esc( inv.date.split( '-' ).reverse().join( '/' ) ) + ' · ' + esc( inv.scope ) + ' · ' + inv.lines.length + ' prodotti · ' + ( open ? 'IN CORSO' : 'CHIUSO il ' + esc( ( inv.closed_at || '' ).substring( 0, 10 ).split( '-' ).reverse().join( '/' ) ) ) + '</div>' +
			zoneSummary + html + '<h2>Riepilogo</h2><table><tr><td>Valore contato (al costo)</td><td class="r"><b>' + euro( totCount ) + '</b></td><td>Valore differenze</td><td class="r"><b>' + ( totDiff > 0 ? '+' : '' ) + euro( totDiff ) + '</b></td></tr></table>' +
			( inv.notes ? '<p><b>Note:</b> ' + esc( inv.notes ) + '</p>' : '' ) +
			'<div style="display:flex;gap:40px;margin-top:40px"><div style="flex:1;border-top:1px solid #999;padding-top:4px" class="muted">Contato da</div><div style="flex:1;border-top:1px solid #999;padding-top:4px" class="muted">Verificato da</div><div style="flex:1;border-top:1px solid #999;padding-top:4px" class="muted">Firma</div></div>' );
	}

	/* ================= Inventario per zone (pistola barcode) ================= */

	/** Segnale acustico breve: ok = acuto, errore = grave e doppio. */
	var beepCtx = null;
	function beep( ok ) {
		try {
			beepCtx = beepCtx || new ( window.AudioContext || window.webkitAudioContext )();
			var play = function ( freq, at, dur ) {
				var o = beepCtx.createOscillator(), g = beepCtx.createGain();
				o.type = 'square';
				o.frequency.value = freq;
				g.gain.value = 0.06;
				o.connect( g );
				g.connect( beepCtx.destination );
				o.start( beepCtx.currentTime + at );
				o.stop( beepCtx.currentTime + at + dur );
			};
			if ( ok ) {
				play( 1500, 0, 0.08 );
			} else {
				play( 300, 0, 0.15 );
				play( 300, 0.2, 0.15 );
			}
		} catch ( e ) {}
	}

	/** Pannello zone nella scheda inventario. */
	function zonesPanel( inv ) {
		var open = inv.status === 'bozza';
		var done = inv.zones.filter( function ( z ) {
			return z.status === 'completata';
		} ).length;
		return '<div class="bhc-zones-head"><h3>Zone di conta <span class="bhc-muted">(' + done + ' / ' + inv.zones.length + ' completate)</span></h3>' + ( open ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-zone-add>+ Aggiungi zona</button>' : '' ) + '</div>' +
			'<div class="bhc-zones">' + inv.zones.map( function ( z ) {
				return '<button type="button" class="bhc-zone' + ( z.status === 'completata' ? ' is-done' : z.reads ? ' is-active' : '' ) + '" data-zone="' + z.id + '">' +
					'<span class="bhc-zone__num">' + z.number + '</span>' +
					'<span class="bhc-zone__body"><strong>' + esc( z.name ) + '</strong>' +
					'<span class="bhc-muted">' + ( z.reads ? z.reads + ' letture · ' + qty( z.pieces ) + ' pezzi · ' + z.products + ' prodotti' : 'Da contare' ) + '</span>' +
					( z.assigned_to ? '<span class="bhc-muted">👤 ' + esc( z.assigned_to ) + '</span>' : '' ) + '</span>' +
					'<span class="bhc-zone__state">' + ( z.status === 'completata' ? '✓ Completata' : open ? ( z.reads ? 'Continua ›' : 'Inizia ›' ) : 'Vedi ›' ) + '</span></button>';
			} ).join( '' ) + '</div>';
	}

	function renderZone( invId, zoneId ) {
		var main = document.getElementById( 'bhc-main' );
		main.innerHTML = '<div class="bhc-loading">Caricamento zona…</div>';
		Promise.all( [ api( 'inventories/' + invId ), api( 'inventories/' + invId + '/zones/' + zoneId ) ] ).then( function ( r ) {
			drawZone( r[ 0 ], r[ 1 ] );
		} ).catch( function ( e ) {
			INVT.zone = null;
			toast( e.message, true );
			renderInventory();
		} );
	}

	function drawZone( inv, data ) {
		var main = document.getElementById( 'bhc-main' );
		var zone = data.zone;
		var open = inv.status === 'bozza' && zone.status !== 'completata';
		var pending = null; // prodotto letto in attesa della quantità
		var busy = false;

		main.innerHTML = '<div class="bhc-top"><div><a href="#" data-zone-back class="bhc-muted">&larr; ' + esc( inv.title ) + '</a>' +
			'<h2 style="margin-top:4px"><span class="bhc-zone__num bhc-zone__num--lg">' + zone.number + '</span> ' + esc( zone.name ) + '</h2>' +
			'<div class="bhc-muted" data-zone-stats></div></div><div class="bhc-top__actions">' +
			( inv.status === 'bozza' ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-zone-rename>' + ICONS.edit + ' Nome / operatore</button>' : '' ) +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-zone-print>' + ICONS.print + ' Stampa letture</button>' +
			( inv.status === 'bozza' ? ( zone.status === 'completata' ? '<button type="button" class="bhc-btn bhc-btn--sm" data-zone-reopen>Riapri zona</button>' : '<button type="button" class="bhc-btn bhc-btn--sm" data-zone-done>✓ Zona completata</button>' ) : '' ) + '</div></div>' +
			( open ? '<div class="bhc-gun">' +
				'<div class="bhc-gun__step" data-step="scan"><label for="bhc-gun-ean">1 · Spara il codice EAN</label><input type="text" id="bhc-gun-ean" data-gun-ean inputmode="numeric" autocomplete="off" placeholder="In attesa della lettura…"></div>' +
				'<div class="bhc-gun__step bhc-gun__step--qty" data-step="qty" hidden><div class="bhc-gun__product" data-gun-product></div><label for="bhc-gun-qty">2 · Quantità</label>' +
				'<div class="bhc-gun__qty"><button type="button" data-gun-minus aria-label="Meno">−</button><input type="number" id="bhc-gun-qty" data-gun-qty min="0.01" step="1" inputmode="decimal" value="1"><button type="button" data-gun-plus aria-label="Più">+</button></div>' +
				'<div class="bhc-gun__keys"><button type="button" class="bhc-btn" data-gun-save>Registra (Invio)</button><button type="button" class="bhc-btn bhc-btn--ghost" data-gun-cancel>Annulla (Esc)</button></div></div>' +
				'<div class="bhc-gun__opts"><label class="bhc-switch"><input type="checkbox" data-gun-auto' + ( INVT.auto1 ? ' checked' : '' ) + '><span></span> Quantità 1 automatica (registra a ogni lettura)</label>' +
				'<label class="bhc-switch"><input type="checkbox" data-gun-sound' + ( INVT.sound !== false ? ' checked' : '' ) + '><span></span> Segnale acustico</label></div>' +
				'<div class="bhc-gun__msg" data-gun-msg aria-live="polite"></div></div>' : ( zone.status === 'completata' ? '<div class="bhc-alert bhc-alert--soon">' + ICONS.alert + '<span>Zona completata' + ( zone.completed_name ? ' da ' + esc( zone.completed_name ) : '' ) + '. Riaprila per aggiungere o correggere letture.</span></div>' : '' ) ) +
			'<h3 style="margin-top:18px">Letture della zona</h3><div data-reads></div>';

		function stats() {
			var z = data.zone;
			main.querySelector( '[data-zone-stats]' ).textContent = z.reads + ' letture · ' + qty( z.pieces ) + ' pezzi · ' + z.products + ' prodotti' + ( z.assigned_to ? ' · operatore: ' + z.assigned_to : '' );
		}
		function readsTable() {
			var box = main.querySelector( '[data-reads]' );
			if ( ! data.reads.length ) {
				box.innerHTML = '<div class="bhc-card bhc-muted">Nessuna lettura in questa zona.</div>';
				return;
			}
			// Riepilogo per prodotto + elenco cronologico.
			var sum = {}, order = [];
			data.reads.forEach( function ( r ) {
				if ( ! sum[ r.product_id ] ) {
					sum[ r.product_id ] = { name: r.name, sku: r.sku, unit: r.unit, q: 0, n: 0 };
					order.push( r.product_id );
				}
				sum[ r.product_id ].q += r.qty;
				sum[ r.product_id ].n++;
			} );
			box.innerHTML = '<div class="bhc-zone-cols"><div><h4>Totale per prodotto</h4><table class="bhc-table"><thead><tr><th>Prodotto</th><th class="bhc-r">Letture</th><th class="bhc-r">Quantità</th></tr></thead><tbody>' + order.map( function ( pid ) {
				var s = sum[ pid ];
				return '<tr><td>' + esc( s.name ) + '<div class="bhc-muted bhc-mono">' + esc( s.sku ) + '</div></td><td class="bhc-r">' + s.n + '</td><td class="bhc-r"><strong>' + qty( s.q ) + '</strong> ' + esc( s.unit ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table></div>' +
				'<div><h4>Ultime letture</h4><table class="bhc-table"><thead><tr><th>Ora</th><th>Prodotto</th><th class="bhc-r">Q.tà</th>' + ( open ? '<th></th>' : '' ) + '</tr></thead><tbody>' + data.reads.slice( 0, 100 ).map( function ( r ) {
					return '<tr><td>' + esc( r.time ) + '</td><td>' + esc( r.name ) + '<div class="bhc-muted bhc-mono">' + esc( r.ean || r.sku ) + '</div></td>' +
						'<td class="bhc-r">' + ( open ? '<input type="number" min="0.01" step="1" class="bhc-count" style="width:80px" data-read-qty="' + r.id + '" value="' + r.qty + '">' : qty( r.qty ) ) + '</td>' +
						( open ? '<td><button type="button" class="bhc-rowitem__del" style="position:static" data-read-del="' + r.id + '" aria-label="Elimina lettura">&times;</button></td>' : '' ) + '</tr>';
				} ).join( '' ) + '</tbody></table></div></div>';
			box.querySelectorAll( '[data-read-qty]' ).forEach( function ( i ) {
				i.addEventListener( 'change', function () {
					var v = parseFloat( i.value );
					if ( ! v || v <= 0 ) {
						toast( 'Quantità non valida: per togliere la lettura usa ×', true );
						return;
					}
					api( 'inventories/' + inv.id + '/reads/' + i.dataset.readQty, { method: 'PUT', body: { qty: v } } ).then( function ( d ) {
						data = d;
						stats();
						readsTable();
						toast( 'Lettura corretta' );
					} ).catch( function ( e ) {
						toast( e.message, true );
					} );
				} );
			} );
			box.querySelectorAll( '[data-read-del]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					if ( window.confirm( 'Eliminare questa lettura?' ) ) {
						api( 'inventories/' + inv.id + '/reads/' + b.dataset.readDel, { method: 'DELETE' } ).then( function ( d ) {
							data = d;
							stats();
							readsTable();
							toast( 'Lettura eliminata' );
							focusEan();
						} );
					}
				} );
			} );
		}
		function msg( text, ok ) {
			var el = main.querySelector( '[data-gun-msg]' );
			if ( el ) {
				el.className = 'bhc-gun__msg ' + ( ok ? 'is-ok' : 'is-err' );
				el.innerHTML = text;
			}
			if ( INVT.sound !== false ) {
				beep( ok );
			}
		}
		function focusEan() {
			var e = main.querySelector( '[data-gun-ean]' );
			if ( e ) {
				e.value = '';
				e.focus();
			}
		}
		function showStep( step ) {
			main.querySelectorAll( '[data-step]' ).forEach( function ( s ) {
				s.hidden = s.dataset.step !== step;
			} );
			if ( step === 'qty' ) {
				var q = main.querySelector( '[data-gun-qty]' );
				q.value = '1';
				q.focus();
				q.select();
			} else {
				focusEan();
			}
		}
		function save( code, productId, q ) {
			if ( busy ) {
				return;
			}
			busy = true;
			api( 'inventories/' + inv.id + '/zones/' + zone.id + '/reads', { method: 'POST', body: { code: code, product_id: productId, qty: q } } ).then( function ( d ) {
				busy = false;
				data = d;
				stats();
				readsTable();
				msg( '✓ <strong>' + esc( d.last.product ) + '</strong> +' + qty( d.last.qty ) + ' ' + esc( d.last.unit ) + ' · in questa zona ' + qty( d.last.zone_total ) + ' · totale inventario ' + qty( d.last.total ), true );
				pending = null;
				showStep( 'scan' );
			} ).catch( function ( e ) {
				busy = false;
				msg( '✗ ' + esc( e.message ), false );
				pending = null;
				showStep( 'scan' );
			} );
		}

		var ean = main.querySelector( '[data-gun-ean]' );
		if ( ean ) {
			ean.addEventListener( 'keydown', function ( e ) {
				if ( e.key !== 'Enter' ) {
					return;
				}
				e.preventDefault();
				var code = ean.value.trim();
				if ( ! code || busy ) {
					return;
				}
				if ( INVT.auto1 ) {
					save( code, 0, 1 );
					ean.value = '';
					return;
				}
				busy = true;
				api( 'inventories/' + inv.id + '/lookup?code=' + encodeURIComponent( code ) ).then( function ( d ) {
					busy = false;
					pending = { code: code, product: d.product };
					main.querySelector( '[data-gun-product]' ).innerHTML = '<strong>' + esc( d.product.name ) + '</strong><div class="bhc-muted bhc-mono">' + esc( d.product.ean || d.product.sku ) + ( d.product.family ? ' · ' + esc( d.product.family + ( d.product.category ? ' › ' + d.product.category : '' ) ) : '' ) + '</div>' +
						'<div class="bhc-muted">Già contati in inventario: ' + qty( d.counted ) + ' ' + esc( d.product.unit ) + ( d.in_sheet ? '' : ' · <span class="bhc-neg">non era nella scheda: verrà aggiunto</span>' ) + '</div>';
					if ( INVT.sound !== false ) {
						beep( true );
					}
					showStep( 'qty' );
				} ).catch( function ( e2 ) {
					busy = false;
					msg( '✗ Codice <span class="bhc-mono">' + esc( code ) + '</span>: ' + esc( e2.message ), false );
					focusEan();
				} );
			} );
			var qIn = main.querySelector( '[data-gun-qty]' );
			qIn.addEventListener( 'keydown', function ( e ) {
				if ( e.key === 'Enter' ) {
					e.preventDefault();
					main.querySelector( '[data-gun-save]' ).click();
				} else if ( e.key === 'Escape' ) {
					e.preventDefault();
					pending = null;
					msg( 'Lettura annullata', false );
					showStep( 'scan' );
				}
			} );
			main.querySelector( '[data-gun-save]' ).addEventListener( 'click', function () {
				var v = parseFloat( qIn.value );
				if ( ! pending ) {
					return showStep( 'scan' );
				}
				if ( ! v || v <= 0 ) {
					msg( 'Inserisci una quantità maggiore di zero', false );
					qIn.focus();
					return;
				}
				if ( v > 999 && ! window.confirm( 'Quantità ' + v + ': confermi? (Forse è stato letto un codice nel campo quantità)' ) ) {
					qIn.select();
					return;
				}
				save( pending.code, pending.product.id, v );
			} );
			main.querySelector( '[data-gun-cancel]' ).addEventListener( 'click', function () {
				pending = null;
				showStep( 'scan' );
			} );
			main.querySelector( '[data-gun-minus]' ).addEventListener( 'click', function () {
				qIn.value = Math.max( 1, ( parseFloat( qIn.value ) || 1 ) - 1 );
				qIn.focus();
			} );
			main.querySelector( '[data-gun-plus]' ).addEventListener( 'click', function () {
				qIn.value = ( parseFloat( qIn.value ) || 0 ) + 1;
				qIn.focus();
			} );
			main.querySelector( '[data-gun-auto]' ).addEventListener( 'change', function ( e ) {
				INVT.auto1 = e.target.checked;
				focusEan();
			} );
			main.querySelector( '[data-gun-sound]' ).addEventListener( 'change', function ( e ) {
				INVT.sound = e.target.checked;
				focusEan();
			} );
			// Clic in un punto vuoto: torna sul campo di lettura (la pistola scrive dove c'è il cursore).
			main.addEventListener( 'click', function ( e ) {
				if ( ! e.target.closest( 'input,button,a,select,label,textarea' ) && main.querySelector( '[data-step="scan"]' ) && ! main.querySelector( '[data-step="scan"]' ).hidden ) {
					focusEan();
				}
			} );
			focusEan();
		}

		main.querySelector( '[data-zone-back]' ).addEventListener( 'click', function ( e ) {
			e.preventDefault();
			INVT.zone = null;
			renderInventory();
		} );
		var dn = main.querySelector( '[data-zone-done]' ), ro = main.querySelector( '[data-zone-reopen]' );
		[ [ dn, 'completata' ], [ ro, 'aperta' ] ].forEach( function ( x ) {
			if ( x[ 0 ] ) {
				x[ 0 ].addEventListener( 'click', function () {
					if ( x[ 1 ] === 'completata' && ! data.reads.length && ! window.confirm( 'La zona non ha letture. Segnarla comunque come completata (vuota)?' ) ) {
						return;
					}
					api( 'inventories/' + inv.id + '/zones/' + zone.id, { method: 'PUT', body: { status: x[ 1 ] } } ).then( function () {
						toast( x[ 1 ] === 'completata' ? 'Zona completata' : 'Zona riaperta' );
						if ( x[ 1 ] === 'completata' ) {
							INVT.zone = null;
							renderInventory();
						} else {
							renderZone( inv.id, zone.id );
						}
					} ).catch( function ( e ) {
						toast( e.message, true );
					} );
				} );
			}
		} );
		var rn = main.querySelector( '[data-zone-rename]' );
		if ( rn ) {
			rn.addEventListener( 'click', function () {
				var m = modal( 'Zona ' + zone.number, '<div class="bhc-field"><label>Nome della zona</label><input type="text" data-zn value="' + esc( zone.name ) + '" placeholder="Es. Reception, Scaffale A, Cabina 2"></div><div class="bhc-field"><label>Operatore che conta</label><input type="text" data-zo value="' + esc( zone.assigned_to ) + '" placeholder="Es. Marta"></div>', '<div></div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-close>Annulla</button><button type="button" class="bhc-btn" data-zs>Salva</button></div>' );
				m.querySelector( '[data-close]' ).addEventListener( 'click', closeModal );
				m.querySelector( '[data-zs]' ).addEventListener( 'click', function () {
					api( 'inventories/' + inv.id + '/zones/' + zone.id, { method: 'PUT', body: { name: m.querySelector( '[data-zn]' ).value, assigned_to: m.querySelector( '[data-zo]' ).value } } ).then( function () {
						closeModal();
						renderZone( inv.id, zone.id );
					} );
				} );
			} );
		}
		main.querySelector( '[data-zone-print]' ).addEventListener( 'click', function () {
			var sum = {}, order = [];
			data.reads.slice().reverse().forEach( function ( r ) {
				if ( ! sum[ r.product_id ] ) {
					sum[ r.product_id ] = { name: r.name, sku: r.sku, ean: r.ean, unit: r.unit, q: 0, n: 0 };
					order.push( r.product_id );
				}
				sum[ r.product_id ].q += r.qty;
				sum[ r.product_id ].n++;
			} );
			printHtml( zone.name, '<div class="muted">' + esc( B.center ) + ' — ' + esc( inv.title ) + '</div><h1>Zona ' + zone.number + ': ' + esc( zone.name ) + '</h1><div class="muted">' + data.zone.reads + ' letture · ' + qty( data.zone.pieces ) + ' pezzi' + ( zone.assigned_to ? ' · operatore ' + esc( zone.assigned_to ) : '' ) + ' · stampato il ' + new Date().toLocaleString( 'it-IT' ) + '</div>' +
				'<h2>Totale per prodotto</h2><table><tr><th>Codice</th><th>EAN</th><th>Prodotto</th><th class="r">Letture</th><th class="r">Quantità</th></tr>' + order.map( function ( pid ) {
					var s = sum[ pid ];
					return '<tr><td>' + esc( s.sku ) + '</td><td>' + esc( s.ean ) + '</td><td>' + esc( s.name ) + '</td><td class="r">' + s.n + '</td><td class="r"><b>' + qty( s.q ) + '</b> ' + esc( s.unit ) + '</td></tr>';
				} ).join( '' ) + '</table>' +
				'<h2>Dettaglio letture</h2><table><tr><th>Ora</th><th>Prodotto</th><th class="r">Q.tà</th></tr>' + data.reads.slice().reverse().map( function ( r ) {
					return '<tr><td>' + esc( r.time ) + '</td><td>' + esc( r.name ) + '</td><td class="r">' + qty( r.qty ) + '</td></tr>';
				} ).join( '' ) + '</table><div style="display:flex;gap:40px;margin-top:40px"><div style="flex:1;border-top:1px solid #999;padding-top:4px" class="muted">Operatore</div><div style="flex:1;border-top:1px solid #999;padding-top:4px" class="muted">Firma</div></div>' );
		} );
		stats();
		readsTable();
	}

	/* ================= Card: gift card, fedeltà, carte trattamenti ================= */

	var CARDS = { tab: 'gift', q: '', status: '', packages: null, loyalty: null };
	var CARD_STATUS = { attiva: 'Attiva', sospesa: 'Sospesa', esaurita: 'Esaurita', scaduta: 'Scaduta', annullata: 'Annullata' };
	var CARD_TYPES = { gift: 'Gift card', loyalty: 'Carta fedeltà', package: 'Carta trattamenti' };
	var CARD_ACTIONS = { emissione: 'Emissione', scarico: 'Scarico', ricarica: 'Ricarica', accredito: 'Punti accreditati', utilizzo: 'Punti usati', pacchetto: 'Pacchetto caricato', seduta: 'Seduta usata', storno: 'Storno', stato: 'Cambio stato' };

	/** Codice a barre EAN-13 (o EAN-8) in SVG, senza librerie. */
	function eanSvg( code, h ) {
		code = String( code || '' ).replace( /\D/g, '' );
		h = h || 46;
		var L = [ '0001101', '0011001', '0010011', '0111101', '0100011', '0110001', '0101111', '0111011', '0110111', '0001011' ];
		var G = [ '0100111', '0110011', '0011011', '0100001', '0011101', '0111001', '0000101', '0010001', '0001001', '0010111' ];
		var R = [ '1110010', '1100110', '1101100', '1000010', '1011100', '1001110', '1010000', '1000100', '1001000', '1110100' ];
		var P = [ 'LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG', 'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL' ];
		var bits = '', guards = [], i, left, right, digitsTxt;
		function add( s, guard ) {
			for ( var k = 0; k < s.length; k++ ) {
				guards.push( !! guard );
			}
			bits += s;
		}
		if ( code.length === 13 ) {
			var par = P[ +code[ 0 ] ];
			add( '101', true );
			for ( i = 1; i <= 6; i++ ) {
				add( par[ i - 1 ] === 'L' ? L[ +code[ i ] ] : G[ +code[ i ] ] );
			}
			add( '01010', true );
			for ( i = 7; i <= 12; i++ ) {
				add( R[ +code[ i ] ] );
			}
			add( '101', true );
			left = code.substring( 1, 7 );
			right = code.substring( 7 );
			digitsTxt = code[ 0 ];
		} else if ( code.length === 8 ) {
			add( '101', true );
			for ( i = 0; i < 4; i++ ) {
				add( L[ +code[ i ] ] );
			}
			add( '01010', true );
			for ( i = 4; i < 8; i++ ) {
				add( R[ +code[ i ] ] );
			}
			add( '101', true );
			left = code.substring( 0, 4 );
			right = code.substring( 4 );
			digitsTxt = '';
		} else {
			return '<span class="bhc-mono">' + esc( code ) + '</span>';
		}
		var q = code.length === 13 ? 11 : 7; // zona di rispetto sinistra
		var W = bits.length + q + 7;
		var rects = '';
		for ( i = 0; i < bits.length; i++ ) {
			if ( bits[ i ] === '1' ) {
				rects += '<rect x="' + ( q + i ) + '" y="0" width="1" height="' + ( guards[ i ] ? h + 5 : h ) + '"/>';
			}
		}
		var fs = 9;
		var half = code.length === 13 ? 21 : 14;
		var midL = q + 3 + half;
		var midR = q + 3 + half * 2 + 5 + half;
		var txt = ( digitsTxt ? '<text x="' + ( q - 2 ) + '" y="' + ( h + 10 ) + '" text-anchor="end">' + digitsTxt + '</text>' : '' ) +
			'<text x="' + midL + '" y="' + ( h + 10 ) + '" text-anchor="middle" letter-spacing="1.6">' + left + '</text>' +
			'<text x="' + midR + '" y="' + ( h + 10 ) + '" text-anchor="middle" letter-spacing="1.6">' + right + '</text>';
		return '<svg class="bhc-ean" viewBox="0 0 ' + W + ' ' + ( h + 12 ) + '" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="EAN ' + code + '"><g fill="#1f1e1b">' + rects + '</g><g font-family="Helvetica,Arial,sans-serif" font-size="' + fs + '" fill="#1f1e1b">' + txt + '</g></svg>';
	}

	/** Controllo cifra EAN lato browser (per avviso immediato). */
	function eanOk( s ) {
		s = String( s || '' ).replace( /\D/g, '' );
		if ( [ 8, 12, 13 ].indexOf( s.length ) === -1 ) {
			return false;
		}
		var d = s.split( '' ).map( Number ), chk = d.pop(), sum = 0;
		d.reverse().forEach( function ( v, i ) {
			sum += v * ( i % 2 === 0 ? 3 : 1 );
		} );
		return ( 10 - sum % 10 ) % 10 === chk;
	}

	function cardDate( s ) {
		return s ? String( s ).substring( 0, 10 ).split( '-' ).reverse().join( '/' ) : '';
	}

	function cardValueText( c ) {
		if ( c.type === 'gift' ) {
			return euro( c.balance ) + ( c.initial_value && c.initial_value !== c.balance ? ' <span class="bhc-muted">di ' + euro( c.initial_value ) + '</span>' : '' );
		}
		if ( c.type === 'loyalty' ) {
			return qtyPts( c.points ) + ' punti <span class="bhc-muted">= ' + euro( c.points_value ) + '</span>';
		}
		return c.sessions_left + ' / ' + c.sessions_total + ' sedute';
	}
	function qtyPts( v ) {
		return String( Math.round( v * 100 ) / 100 ).replace( '.', ',' );
	}

	function cardStatusPill( c ) {
		var st = c.expired && c.status === 'attiva' ? 'scaduta' : c.status;
		var cls = st === 'attiva' ? 'bhc-pill--ok' : ( st === 'sospesa' || st === 'scaduta' ? 'bhc-pill--warn' : 'bhc-pill--off' );
		return '<span class="bhc-pill ' + cls + '">' + esc( CARD_STATUS[ st ] || st ) + '</span>';
	}

	/** La card "plastica" con codice e barcode. */
	function cardVisual( c ) {
		var big = c.type === 'gift' ? euro( c.balance ) : ( c.type === 'loyalty' ? qtyPts( c.points ) + ' pt' : c.sessions_left + ' sedute' );
		return '<div class="bhc-pcard bhc-pcard--' + c.type + '">' +
			'<div class="bhc-pcard__top"><span class="bhc-pcard__brand">' + esc( B.center ) + '</span><span class="bhc-pcard__type">' + esc( CARD_TYPES[ c.type ] ) + '</span></div>' +
			'<div class="bhc-pcard__value">' + big + '</div>' +
			'<div class="bhc-pcard__holder"><small>Intestata a</small>' + esc( c.holder || '—' ) + '</div>' +
			'<div class="bhc-pcard__foot"><span class="bhc-mono">' + esc( c.code ) + '</span>' + ( c.expires_at ? '<span>Scade ' + esc( cardDate( c.expires_at ) ) + '</span>' : '' ) + '</div>' +
			'<div class="bhc-pcard__ean">' + eanSvg( c.ean, 38 ) + '</div></div>';
	}

	function loadCardMeta() {
		return Promise.all( [
			CARDS.packages ? Promise.resolve( { items: CARDS.packages } ) : api( 'card-packages' ),
			CARDS.loyalty ? Promise.resolve( CARDS.loyalty ) : api( 'card-settings' )
		] ).then( function ( r ) {
			CARDS.packages = r[ 0 ].items;
			CARDS.loyalty = r[ 1 ];
		} );
	}

	/* ---------- Vista principale ---------- */

	function renderCards() {
		var main = document.getElementById( 'bhc-main' );
		var tabs = [ [ 'gift', 'Gift card' ], [ 'loyalty', 'Fedeltà' ], [ 'package', 'Carte trattamenti' ], [ 'listino', 'Listino pacchetti' ] ];
		main.innerHTML = '<div class="bhc-top"><h2>Card</h2><div class="bhc-top__actions">' +
			'<input type="search" data-cq placeholder="Codice, EAN, nome o telefono… (anche lettore barcode)" value="' + esc( CARDS.q ) + '" style="min-width:280px">' +
			'<select data-cst><option value="">Tutti gli stati</option>' + Object.keys( CARD_STATUS ).filter( function ( k ) {
				return k !== 'scaduta';
			} ).map( function ( k ) {
				return '<option value="' + k + '"' + ( CARDS.status === k ? ' selected' : '' ) + '>' + CARD_STATUS[ k ] + '</option>';
			} ).join( '' ) + '</select>' +
			( can( 'cards' ) ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-loyset>Regole fedeltà</button><button type="button" class="bhc-btn bhc-btn--sm" data-cnew>' + ICONS.cards + ' Nuova card</button>' : '' ) +
			'</div></div><div data-ckpi></div>' +
			'<div class="bhc-tabs">' + tabs.map( function ( t ) {
				return '<button type="button" data-ctab="' + t[ 0 ] + '"' + ( CARDS.tab === t[ 0 ] ? ' class="is-active"' : '' ) + '>' + t[ 1 ] + '</button>';
			} ).join( '' ) + '</div><div data-clist><div class="bhc-loading">Caricamento…</div></div>';

		var cq = main.querySelector( '[data-cq]' );
		cq.addEventListener( 'input', debounce( function () {
			CARDS.q = cq.value;
			loadCards();
		}, 250 ) );
		cq.addEventListener( 'keydown', function ( e ) {
			if ( e.key !== 'Enter' || ! cq.value.trim() ) {
				return;
			}
			e.preventDefault();
			api( 'cards/lookup?code=' + encodeURIComponent( cq.value.trim() ) ).then( function ( c ) {
				cq.value = '';
				CARDS.q = '';
				beepOk();
				cardDetail( c );
				loadCards();
			} ).catch( function () {
				loadCards();
			} );
		} );
		main.querySelector( '[data-cst]' ).addEventListener( 'change', function ( e ) {
			CARDS.status = e.target.value;
			loadCards();
		} );
		main.querySelectorAll( '[data-ctab]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				CARDS.tab = b.dataset.ctab;
				main.querySelectorAll( '[data-ctab]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === b );
				} );
				loadCards();
			} );
		} );
		var nb = main.querySelector( '[data-cnew]' );
		if ( nb ) {
			nb.addEventListener( 'click', function () {
				newCardDialog( CARDS.tab === 'listino' ? 'package' : CARDS.tab );
			} );
		}
		var ls = main.querySelector( '[data-loyset]' );
		if ( ls ) {
			ls.addEventListener( 'click', loyaltySettingsDialog );
		}
		loadCards();
	}

	function beepOk() {
		try {
			if ( typeof beep === 'function' ) {
				beep( true );
			}
		} catch ( e ) {}
	}

	function loadCards() {
		var box = document.querySelector( '[data-clist]' );
		if ( ! box ) {
			return;
		}
		if ( CARDS.tab === 'listino' ) {
			CARDS.packages = null;
			loadCardMeta().then( function () {
				drawPackages( box );
			} );
			api( 'cards?type=none' ).then( drawCardKpis ).catch( function () {} );
			return;
		}
		api( 'cards?type=' + CARDS.tab + '&status=' + CARDS.status + '&q=' + encodeURIComponent( CARDS.q ) ).then( function ( d ) {
			CARDS.loyalty = d.loyalty;
			drawCardKpis( d );
			var add = can( 'cards' ) ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cnew2>+ ' + esc( CARD_TYPES[ CARDS.tab ] ) + '</button>' : '';
			if ( ! d.items.length ) {
				box.innerHTML = '<div class="bhc-card"><p class="bhc-muted">Nessuna ' + esc( CARD_TYPES[ CARDS.tab ].toLowerCase() ) + ( CARDS.q ? ' per «' + esc( CARDS.q ) + '»' : '' ) + '.</p>' + add + '</div>';
			} else {
				var col = CARDS.tab === 'gift' ? 'Saldo' : ( CARDS.tab === 'loyalty' ? 'Punti' : 'Sedute residue' );
				box.innerHTML = '<table class="bhc-table bhc-cards-table"><thead><tr><th>Codice</th><th>Intestataria</th><th>' + col + '</th>' + ( CARDS.tab === 'package' ? '<th>Trattamenti</th>' : '' ) + '<th>Emessa</th><th>Scadenza</th><th>Stato</th></tr></thead><tbody>' + d.items.map( function ( c ) {
					return '<tr class="is-click" data-card="' + c.id + '"><td><span class="bhc-card-dot bhc-card-dot--' + c.type + '"></span><strong class="bhc-mono">' + esc( c.code ) + '</strong><br><small class="bhc-muted bhc-mono">' + esc( c.ean ) + '</small></td>' +
						'<td>' + esc( c.holder ) + '<br><small class="bhc-muted">' + esc( c.holder_phone || c.holder_email ) + '</small></td>' +
						'<td>' + cardValueText( c ) + '</td>' +
						( CARDS.tab === 'package' ? '<td><small>' + c.items.map( function ( it ) {
							return esc( it.treatment ) + ' <b>' + it.sessions_left + '/' + it.sessions_total + '</b>';
						} ).join( '<br>' ) + '</small></td>' : '' ) +
						'<td>' + esc( cardDate( c.created_at ) ) + '</td><td>' + esc( cardDate( c.expires_at ) || '—' ) + '</td><td>' + cardStatusPill( c ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table><p style="margin-top:12px">' + add + '</p>';
			}
			box.querySelectorAll( '[data-card]' ).forEach( function ( r ) {
				r.addEventListener( 'click', function () {
					openCard( r.dataset.card );
				} );
			} );
			var a2 = box.querySelector( '[data-cnew2]' );
			if ( a2 ) {
				a2.addEventListener( 'click', function () {
					newCardDialog( CARDS.tab );
				} );
			}
		} ).catch( function ( e ) {
			box.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function drawCardKpis( d ) {
		var k = document.querySelector( '[data-ckpi]' );
		if ( ! k || ! d.summary ) {
			return;
		}
		var s = d.summary;
		k.innerHTML = '<div class="bhc-kpis">' + kpi( 'Gift card attive', s.gift_active ) + kpi( 'Credito gift card', euro( s.gift_balance ) ) +
			kpi( 'Carte fedeltà', s.loyalty_active ) + kpi( 'Punti in circolo', qtyPts( s.loyalty_points ) ) +
			kpi( 'Sedute da erogare', s.sessions_left ) + ( s.expiring ? kpi( 'In scadenza (30 gg)', s.expiring ) : '' ) + '</div>';
	}

	/* ---------- Campo ricerca cliente riutilizzabile ---------- */

	function clientPickerHtml( label, current ) {
		return '<div class="bhc-field"><label>' + label + '</label><input type="search" data-cp-search placeholder="Cerca per nome, telefono o email…" autocomplete="off" value="' + esc( current ? current.name : '' ) + '"><input type="hidden" data-cp-id value="' + ( current ? current.id : 0 ) + '"><div data-cp-results></div></div>';
	}
	function bindClientPicker( m, onPick ) {
		var search = m.querySelector( '[data-cp-search]' ), results = m.querySelector( '[data-cp-results]' ), cid = m.querySelector( '[data-cp-id]' );
		search.addEventListener( 'input', debounce( function () {
			cid.value = '0';
			var q = search.value.trim();
			if ( q.length < 2 ) {
				results.innerHTML = '';
				return;
			}
			api( 'clients?q=' + encodeURIComponent( q ) ).then( function ( data ) {
				results.innerHTML = data.items.length ? '<div class="bhc-search-results">' + data.items.slice( 0, 8 ).map( function ( c ) {
					return '<button type="button" data-cid="' + c.id + '" data-name="' + esc( c.first_name + ' ' + c.last_name ) + '">' + esc( c.first_name + ' ' + c.last_name ) + ' <span class="bhc-muted">' + esc( c.phone || c.email ) + '</span></button>';
				} ).join( '' ) + '</div>' : '<p class="bhc-muted">Nessuna cliente trovata: creala prima dalla sezione Clienti.</p>';
				results.querySelectorAll( '[data-cid]' ).forEach( function ( b ) {
					b.addEventListener( 'click', function () {
						cid.value = b.dataset.cid;
						search.value = b.dataset.name;
						results.innerHTML = '';
						if ( onPick ) {
							onPick( +b.dataset.cid );
						}
					} );
				} );
			} );
		}, 250 ) );
		return function () {
			return +cid.value;
		};
	}

	function methodOptions() {
		return Object.keys( B.methods ).filter( function ( k ) {
			return k !== 'giftcard';
		} ).map( function ( k ) {
			return '<option value="' + k + '">' + esc( B.methods[ k ] ) + '</option>';
		} ).join( '' );
	}

	function treatmentOptions( sel ) {
		return '<option value="">— trattamento —</option>' + B.treatments.map( function ( t ) {
			return '<option value="' + t.id + '"' + ( +sel === t.id ? ' selected' : '' ) + '>' + esc( t.name ) + ' (' + euro( t.price ) + ')</option>';
		} ).join( '' );
	}

	/** Righe trattamento + sedute (pacchetto personalizzato o listino). */
	function itemRowsHtml( items ) {
		return ( items.length ? items : [ { treatment_id: '', sessions: 5 } ] ).map( function ( it ) {
			return '<div class="bhc-pkg-row"><select data-it-t>' + treatmentOptions( it.treatment_id ) + '</select><input type="number" min="1" max="999" data-it-n value="' + ( it.sessions || 1 ) + '" aria-label="Sedute"><span class="bhc-muted">sedute</span><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-it-del aria-label="Rimuovi">&times;</button></div>';
		} ).join( '' );
	}
	function bindItemRows( box, onChange ) {
		function wire() {
			box.querySelectorAll( '[data-it-del]' ).forEach( function ( b ) {
				b.onclick = function () {
					if ( box.querySelectorAll( '.bhc-pkg-row' ).length > 1 ) {
						b.parentNode.remove();
					}
					onChange();
				};
			} );
			box.querySelectorAll( 'select,input' ).forEach( function ( i ) {
				i.oninput = onChange;
				i.onchange = onChange;
			} );
		}
		wire();
		return {
			add: function () {
				box.insertAdjacentHTML( 'beforeend', itemRowsHtml( [ { treatment_id: '', sessions: 1 } ] ) );
				wire();
				onChange();
			},
			read: function () {
				var out = [];
				box.querySelectorAll( '.bhc-pkg-row' ).forEach( function ( r ) {
					var t = +r.querySelector( '[data-it-t]' ).value, n = +r.querySelector( '[data-it-n]' ).value;
					if ( t && n > 0 ) {
						out.push( { treatment_id: t, sessions: n } );
					}
				} );
				return out;
			},
			list: function () {
				return this.read().reduce( function ( s, it ) {
					var t = treatmentById( it.treatment_id );
					return s + ( t ? t.price * it.sessions : 0 );
				}, 0 );
			}
		};
	}

	/* ---------- Nuova card ---------- */

	function newCardDialog( type, preset ) {
		preset = preset || {};
		loadCardMeta().then( function () {
			drawNewCard( type || 'gift', preset );
		} ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	function drawNewCard( type, preset ) {
		var inYear = new Date();
		inYear.setFullYear( inYear.getFullYear() + 1 );
		var pk = CARDS.packages.filter( function ( p ) {
			return p.active;
		} );
		var body = '<div class="bhc-seg" data-ntype>' + Object.keys( CARD_TYPES ).map( function ( k ) {
			return '<button type="button" data-t="' + k + '"' + ( k === type ? ' class="is-active"' : '' ) + '><span class="bhc-card-dot bhc-card-dot--' + k + '"></span>' + CARD_TYPES[ k ] + '</button>';
		} ).join( '' ) + '</div>' +
			clientPickerHtml( 'Intestataria * <span class="bhc-muted">(la card è nominale)</span>', preset.client ) +
			// Gift card
			'<div data-for="gift"><div class="bhc-field"><label>Valore (€) *</label><div class="bhc-amounts">' + [ 25, 50, 100, 150, 200 ].map( function ( v ) {
				return '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-amt="' + v + '">' + v + ' €</button>';
			} ).join( '' ) + '<input type="number" min="1" step="1" data-n="value" placeholder="Importo libero" style="max-width:150px"></div></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Acquistata da</label><input type="text" data-n="buyer_name" placeholder="Se è un regalo: chi la regala"></div><div class="bhc-field"><label>Dedica</label><input type="text" data-n="message" maxlength="120" placeholder="Es. Buon compleanno!"></div></div></div>' +
			// Fedeltà
			'<div data-for="loyalty"><div class="bhc-field"><label>Punti di benvenuto</label><input type="number" min="0" step="1" data-n="points" value="0" style="max-width:160px"><div class="bhc-muted" style="font-size:.85rem;margin-top:4px">Regola attuale: ' + esc( qtyPts( CARDS.loyalty.points_per_euro ) ) + ' punti per ogni € incassato · 1 punto = ' + euro( CARDS.loyalty.point_value ) + ' · utilizzabili da ' + esc( qtyPts( CARDS.loyalty.min_redeem ) ) + ' punti.</div></div></div>' +
			// Carta trattamenti
			'<div data-for="package"><div class="bhc-field"><label>Pacchetto</label><select data-n="package_id"><option value="0">Personalizzato…</option>' + pk.map( function ( p ) {
				return '<option value="' + p.id + '">' + esc( p.name ) + ' — ' + euro( p.price ) + ( p.discount > 0 ? ' (−' + String( p.discount ).replace( '.', ',' ) + '%)' : '' ) + '</option>';
			} ).join( '' ) + '</select></div>' +
			'<div data-pk-info class="bhc-muted" style="margin:-4px 0 10px"></div>' +
			'<div data-custom><label class="bhc-label">Trattamenti e sedute</label><div data-items>' + itemRowsHtml( [] ) + '</div><p style="margin:6px 0 10px"><a href="#" data-it-add>+ Aggiungi trattamento</a></p>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Prezzo pacchetto (€)</label><input type="number" min="0" step="0.5" data-n="price"></div><div class="bhc-field"><label>Valore di listino</label><div data-listval style="padding:10px 0;font-weight:600">—</div></div></div></div></div>' +
			// Comuni
			'<div class="bhc-row"><div class="bhc-field" data-not="loyalty"><label>Incassato con</label><select data-n="payment_method">' + methodOptions() + '</select></div>' +
			'<div class="bhc-field"><label>Scadenza</label><input type="date" data-n="expires_at" value="' + ymd( inYear ) + '"><div class="bhc-muted" style="font-size:.8rem;margin-top:4px" data-exp-hint></div></div></div>' +
			'<div class="bhc-field"><label>Codice EAN</label><div class="bhc-seg bhc-seg--sm" data-eanmode><button type="button" data-m="auto" class="is-active">Automatico</button><button type="button" data-m="custom">Personalizzato</button></div>' +
			'<div data-ean-custom hidden style="margin-top:8px"><input type="text" data-n="ean" inputmode="numeric" maxlength="13" class="bhc-mono" placeholder="Digita o leggi con il lettore (8 o 13 cifre)"><div data-ean-prev style="margin-top:6px"></div></div>' +
			'<div data-ean-auto class="bhc-muted" style="font-size:.85rem;margin-top:6px">Verrà generato un EAN-13 ad uso interno (prefisso 29) da stampare sulla card.</div></div>' +
			'<div class="bhc-field"><label>Note</label><textarea rows="2" data-n="notes"></textarea></div><p class="bhc-msg" data-msg></p>';
		var m = modal( 'Nuova card', body, '<div></div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn" data-go>Emetti card</button></div>' );
		var n = function ( k ) {
			return m.querySelector( '[data-n="' + k + '"]' );
		};
		var getClient = bindClientPicker( m );
		var rows = bindItemRows( m.querySelector( '[data-items]' ), updPkg );
		m.querySelector( '[data-it-add]' ).addEventListener( 'click', function ( e ) {
			e.preventDefault();
			rows.add();
		} );
		var priceTouched = false;
		n( 'price' ).addEventListener( 'input', function () {
			priceTouched = true;
			updPkg();
		} );
		function updPkg() {
			var pid = +n( 'package_id' ).value;
			var custom = m.querySelector( '[data-custom]' );
			var info = m.querySelector( '[data-pk-info]' );
			custom.hidden = !! pid;
			if ( pid ) {
				var p = CARDS.packages.filter( function ( x ) {
					return x.id === pid;
				} )[ 0 ];
				info.innerHTML = p.items.map( function ( it ) {
					return it.sessions + ' × ' + esc( it.treatment );
				} ).join( ' + ' ) + ' · listino ' + euro( p.list_price ) + ' → <b>' + euro( p.price ) + '</b>' + ( p.validity_days ? ' · validità ' + p.validity_days + ' giorni' : '' );
				if ( p.validity_days ) {
					var d = new Date();
					d.setDate( d.getDate() + p.validity_days );
					n( 'expires_at' ).value = ymd( d );
				}
			} else {
				info.textContent = '';
				var list = rows.list();
				m.querySelector( '[data-listval]' ).textContent = list ? euro( list ) : '—';
				if ( ! priceTouched ) {
					n( 'price' ).value = list ? list.toFixed( 2 ) : '';
				}
				var pr = parseFloat( n( 'price' ).value );
				if ( list && pr && pr < list ) {
					m.querySelector( '[data-listval]' ).innerHTML = euro( list ) + ' <span class="bhc-pill bhc-pill--ok">sconto ' + String( Math.round( ( 1 - pr / list ) * 1000 ) / 10 ).replace( '.', ',' ) + '%</span>';
				}
			}
		}
		n( 'package_id' ).addEventListener( 'change', updPkg );
		function setType( t ) {
			type = t;
			m.querySelectorAll( '[data-ntype] [data-t]' ).forEach( function ( b ) {
				b.classList.toggle( 'is-active', b.dataset.t === t );
			} );
			m.querySelectorAll( '[data-for]' ).forEach( function ( x ) {
				x.hidden = x.dataset.for !== t;
			} );
			m.querySelector( '[data-not="loyalty"]' ).hidden = t === 'loyalty';
			if ( t === 'loyalty' ) {
				n( 'expires_at' ).value = '';
				m.querySelector( '[data-exp-hint]' ).textContent = 'Lascia vuoto: la carta fedeltà non scade.';
			} else {
				m.querySelector( '[data-exp-hint]' ).textContent = '';
				if ( ! n( 'expires_at' ).value ) {
					n( 'expires_at' ).value = ymd( inYear );
				}
			}
			if ( t === 'package' ) {
				updPkg();
			}
		}
		m.querySelectorAll( '[data-ntype] [data-t]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				setType( b.dataset.t );
			} );
		} );
		setType( type );
		m.querySelectorAll( '[data-amt]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				n( 'value' ).value = b.dataset.amt;
				m.querySelectorAll( '[data-amt]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-on', x === b );
				} );
			} );
		} );
		var eanMode = 'auto';
		m.querySelectorAll( '[data-eanmode] [data-m]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				eanMode = b.dataset.m;
				m.querySelectorAll( '[data-eanmode] [data-m]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === b );
				} );
				m.querySelector( '[data-ean-custom]' ).hidden = eanMode !== 'custom';
				m.querySelector( '[data-ean-auto]' ).hidden = eanMode === 'custom';
				if ( eanMode === 'custom' ) {
					n( 'ean' ).focus();
				}
			} );
		} );
		n( 'ean' ).addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Enter' ) {
				e.preventDefault();
			}
		} );
		n( 'ean' ).addEventListener( 'input', function () {
			var v = n( 'ean' ).value.replace( /\D/g, '' );
			var prev = m.querySelector( '[data-ean-prev]' );
			if ( v.length === 8 || v.length === 13 ) {
				prev.innerHTML = eanOk( v ) ? '<div style="max-width:220px">' + eanSvg( v, 40 ) + '</div><span class="bhc-pill bhc-pill--ok">EAN valido</span>' : '<span class="bhc-pill bhc-pill--warn">Cifra di controllo errata</span>';
			} else {
				prev.innerHTML = v ? '<span class="bhc-muted">' + v.length + ' cifre</span>' : '';
			}
		} );
		m.querySelector( '[data-x]' ).addEventListener( 'click', closeModal );
		var msg = m.querySelector( '[data-msg]' );
		m.querySelector( '[data-go]' ).addEventListener( 'click', function () {
			var p = {
				type: type,
				client_id: getClient(),
				expires_at: n( 'expires_at' ).value,
				notes: n( 'notes' ).value,
				payment_method: type === 'loyalty' ? '' : n( 'payment_method' ).value,
				ean: eanMode === 'custom' ? n( 'ean' ).value.trim() : ''
			};
			if ( type === 'gift' ) {
				p.value = n( 'value' ).value;
				p.buyer_name = n( 'buyer_name' ).value;
				p.message = n( 'message' ).value;
			} else if ( type === 'loyalty' ) {
				p.points = n( 'points' ).value;
			} else {
				p.package_id = +n( 'package_id' ).value;
				if ( ! p.package_id ) {
					p.items = rows.read();
					p.price = n( 'price' ).value;
				}
			}
			if ( eanMode === 'custom' && ! p.ean ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Inserisci il codice EAN personalizzato o scegli «Automatico».';
				return;
			}
			api( 'cards', { method: 'POST', body: p } ).then( function ( c ) {
				toast( CARD_TYPES[ c.type ] + ' ' + c.code + ' emessa' );
				CARDS.tab = c.type;
				if ( S.view === 'cards' ) {
					renderCards();
				}
				cardDetail( c );
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
	}

	/* ---------- Scheda card ---------- */

	function openCard( id ) {
		api( 'cards/' + id ).then( cardDetail ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	function cardAction( c, body ) {
		return api( 'cards/' + c.id + '/action', { method: 'POST', body: body } );
	}

	function cardDetail( c ) {
		if ( ! CARDS.packages || ! CARDS.loyalty ) {
			loadCardMeta().then( function () {
				drawCardDetail( c );
			} ).catch( function () {
				drawCardDetail( c );
			} );
		} else {
			drawCardDetail( c );
		}
	}

	function drawCardDetail( c ) {
		var manage = can( 'cards' );
		var ops = '';
		if ( ! c.usable && c.status !== 'esaurita' ) {
			ops += '<div class="bhc-alert bhc-alert--soon">' + ICONS.alert + ' ' + ( c.expired ? 'Card scaduta il ' + esc( cardDate( c.expires_at ) ) + '.' : 'Card ' + esc( ( CARD_STATUS[ c.status ] || c.status ).toLowerCase() ) + '.' ) + ( manage ? ' Puoi modificarne stato o scadenza in «Dati card».' : '' ) + '</div>';
		}
		if ( c.type === 'gift' ) {
			ops += '<div class="bhc-op"><h4>Scala importo</h4><p class="bhc-muted">Utilizzo anche parziale: il resto rimane sulla card.</p><div class="bhc-op__row"><input type="number" min="0.01" step="0.01" data-o="amount" placeholder="€" max="' + c.balance + '"><input type="text" data-o="note" placeholder="Causale (es. trattamento, prodotti)"><button type="button" class="bhc-btn bhc-btn--sm" data-do="redeem"' + ( c.usable && c.balance > 0 ? '' : ' disabled' ) + '>Scala</button></div></div>' +
				( manage ? '<div class="bhc-op"><h4>Ricarica</h4><div class="bhc-op__row"><input type="number" min="1" step="1" data-o="topup" placeholder="€"><select data-o="method">' + methodOptions() + '</select><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-do="topup"' + ( c.status === 'annullata' ? ' disabled' : '' ) + '>Ricarica</button></div></div>' : '' );
		} else if ( c.type === 'loyalty' ) {
			var L = CARDS.loyalty || { point_value: 0.1, min_redeem: 0, points_per_euro: 1 };
			ops += '<p class="bhc-muted">' + esc( qtyPts( L.points_per_euro ) ) + ' punti per ogni € incassato (accredito automatico sugli incassi della cliente) · 1 punto = ' + euro( L.point_value ) + ' · utilizzabili da ' + esc( qtyPts( L.min_redeem ) ) + ' punti.</p>' +
				'<div class="bhc-op"><h4>Usa punti</h4><div class="bhc-op__row"><input type="number" min="1" step="1" data-o="use" placeholder="Punti" max="' + c.points + '"><span class="bhc-muted" data-use-val></span><input type="text" data-o="note" placeholder="Causale"><button type="button" class="bhc-btn bhc-btn--sm" data-do="points_use"' + ( c.can_redeem && c.status === 'attiva' ? '' : ' disabled' ) + '>Usa</button></div></div>' +
				( manage ? '<div class="bhc-op"><h4>Accredita punti</h4><div class="bhc-op__row"><input type="number" min="1" step="1" data-o="add" placeholder="Punti"><input type="text" data-o="note2" placeholder="Causale (es. bonus, acquisto prodotti)"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-do="points_add"' + ( c.status === 'attiva' ? '' : ' disabled' ) + '>Accredita</button></div></div>' : '' );
		} else {
			ops += '<table class="bhc-table bhc-pkg-items"><thead><tr><th>Trattamento</th><th>Sedute</th><th>Valore seduta</th><th></th></tr></thead><tbody>' + c.items.map( function ( it ) {
				var pct = it.sessions_total ? Math.round( it.sessions_used / it.sessions_total * 100 ) : 0;
				return '<tr><td>' + esc( it.treatment ) + '</td><td><div class="bhc-progress"><i style="width:' + pct + '%"></i></div><small><b>' + it.sessions_left + '</b> rimaste · ' + it.sessions_used + ' usate su ' + it.sessions_total + '</small></td><td>' + euro( it.session_value ) + '</td>' +
					'<td><button type="button" class="bhc-btn bhc-btn--sm" data-session="' + it.id + '"' + ( c.usable && it.sessions_left > 0 ? '' : ' disabled' ) + '>Usa seduta</button></td></tr>';
			} ).join( '' ) + '</tbody></table>' +
				( manage ? '<div class="bhc-op" style="margin-top:14px"><h4>Carica un altro pacchetto</h4><div class="bhc-op__row"><select data-o="pkg"><option value="">— dal listino —</option>' + ( CARDS.packages || [] ).filter( function ( p ) {
					return p.active;
				} ).map( function ( p ) {
					return '<option value="' + p.id + '">' + esc( p.name ) + ' — ' + euro( p.price ) + '</option>';
				} ).join( '' ) + '</select><select data-o="method">' + methodOptions() + '</select><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-do="add_package">Carica</button></div></div>' : '' );
		}

		var moves = c.moves.length ? '<table class="bhc-table"><thead><tr><th>Data</th><th>Operazione</th><th>Importo</th><th>Dopo</th><th>Note</th><th></th></tr></thead><tbody>' + c.moves.map( function ( mv, i ) {
			var amt = c.type === 'gift' || mv.action === 'pacchetto' ? euro( mv.amount ) : ( mv.amount > 0 ? '+' : '' ) + qtyPts( mv.amount );
			var after = c.type === 'gift' ? euro( mv.balance_after ) : qtyPts( mv.balance_after ) + ( c.type === 'loyalty' ? ' pt' : ' sed.' );
			var undo = i === 0 && [ 'scarico', 'ricarica', 'accredito', 'utilizzo', 'seduta' ].indexOf( mv.action ) !== -1 && ( manage || [ 'scarico', 'seduta', 'utilizzo' ].indexOf( mv.action ) !== -1 );
			return '<tr><td>' + esc( cardDate( mv.created_at ) + ' ' + mv.created_at.substring( 11, 16 ) ) + '</td><td>' + esc( CARD_ACTIONS[ mv.action ] || mv.action ) + ( mv.appointment_id ? ' <a href="#" data-mappt="' + mv.appointment_id + '" class="bhc-muted">appt.</a>' : '' ) + '</td><td class="nw">' + amt + '</td><td class="nw">' + after + '</td><td><small>' + esc( mv.note ) + ( mv.payment_method ? ' · ' + esc( B.methods[ mv.payment_method ] || mv.payment_method ) : '' ) + ( mv.user ? ' <span class="bhc-muted">· ' + esc( mv.user ) + '</span>' : '' ) + '</small></td>' +
				'<td>' + ( undo ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-undo="' + mv.id + '">Storna</button>' : '' ) + '</td></tr>';
		} ).join( '' ) + '</tbody></table>' : '<p class="bhc-muted">Nessun movimento.</p>';

		var data = '<div data-cdata>' + clientPickerHtml( 'Intestataria', { id: c.client_id, name: c.holder } ) +
			'<div class="bhc-row"><div class="bhc-field"><label>Stato</label><select data-d="status"' + ( manage ? '' : ' disabled' ) + '>' + [ 'attiva', 'sospesa', 'annullata' ].map( function ( k ) {
				return '<option value="' + k + '"' + ( c.status === k || ( k === 'attiva' && c.status === 'esaurita' ) ? ' selected' : '' ) + '>' + CARD_STATUS[ k ] + '</option>';
			} ).join( '' ) + '</select></div><div class="bhc-field"><label>Scadenza</label><input type="date" data-d="expires_at" value="' + esc( c.expires_at || '' ) + '"></div></div>' +
			( c.type === 'gift' ? '<div class="bhc-row"><div class="bhc-field"><label>Acquistata da</label><input type="text" data-d="buyer_name" value="' + esc( c.buyer_name ) + '"></div><div class="bhc-field"><label>Dedica</label><input type="text" data-d="message" value="' + esc( c.message ) + '"></div></div>' : '' ) +
			'<div class="bhc-field"><label>Codice EAN</label><div class="bhc-op__row"><input type="text" data-d="ean" class="bhc-mono" inputmode="numeric" maxlength="13" value="' + esc( c.ean ) + '"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-ean-auto>Rigenera interno</button></div><div class="bhc-muted" style="font-size:.8rem;margin-top:4px">Puoi sostituirlo con un EAN tuo (es. card prestampate): digitalo o leggilo con il lettore.</div></div>' +
			'<div class="bhc-field"><label>Note</label><textarea rows="2" data-d="notes">' + esc( c.notes || '' ) + '</textarea></div>' +
			( manage ? '<p><button type="button" class="bhc-btn bhc-btn--sm" data-dsave>Salva dati</button></p>' : '' ) + '</div>';

		var body = '<div class="bhc-card-detail"><div class="bhc-card-detail__side">' + cardVisual( c ) +
			'<dl class="bhc-dl"><dt>Codice</dt><dd class="bhc-mono">' + esc( c.code ) + '</dd><dt>EAN</dt><dd class="bhc-mono">' + esc( c.ean ) + '</dd><dt>Stato</dt><dd>' + cardStatusPill( c ) + '</dd><dt>Emessa</dt><dd>' + esc( cardDate( c.created_at ) ) + '</dd>' +
			( c.holder_phone ? '<dt>Telefono</dt><dd>' + esc( c.holder_phone ) + '</dd>' : '' ) + ( c.buyer_name ? '<dt>Acquistata da</dt><dd>' + esc( c.buyer_name ) + '</dd>' : '' ) + ( c.message ? '<dt>Dedica</dt><dd><em>' + esc( c.message ) + '</em></dd>' : '' ) + '</dl></div>' +
			'<div class="bhc-card-detail__main"><div class="bhc-tabs"><button type="button" class="is-active" data-tab="ops">Operazioni</button><button type="button" data-tab="mov">Movimenti (' + c.moves.length + ')</button>' + ( manage ? '<button type="button" data-tab="dati">Dati card</button>' : '' ) + '</div>' +
			'<div data-pane="ops">' + ops + '</div><div data-pane="mov" hidden>' + moves + '</div>' + ( manage ? '<div data-pane="dati" hidden>' + data + '</div>' : '' ) + '<p class="bhc-msg" data-msg></p></div></div>';

		var foot = '<div><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cprint>' + ICONS.print + ' Stampa card</button>' + ( c.client_id && can( 'clients_view' ) ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cclient>Scheda cliente</button>' : '' ) + '</div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-x>Chiudi</button></div>';
		var m = modal( CARD_TYPES[ c.type ] + ' ' + c.code, body, foot, true );
		var msg = m.querySelector( '[data-msg]' );
		var o = function ( k ) {
			return m.querySelector( '[data-o="' + k + '"]' );
		};
		m.querySelector( '[data-x]' ).addEventListener( 'click', closeModal );
		m.querySelector( '[data-cprint]' ).addEventListener( 'click', function () {
			printCard( c );
		} );
		var cc = m.querySelector( '[data-cclient]' );
		if ( cc ) {
			cc.addEventListener( 'click', function () {
				openClient( c.client_id );
			} );
		}
		m.querySelectorAll( '[data-tab]' ).forEach( function ( t ) {
			t.addEventListener( 'click', function () {
				m.querySelectorAll( '[data-tab]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === t );
				} );
				m.querySelectorAll( '[data-pane]' ).forEach( function ( p ) {
					p.hidden = p.dataset.pane !== t.dataset.tab;
				} );
			} );
		} );
		m.querySelectorAll( '[data-mappt]' ).forEach( function ( a ) {
			a.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				openAppointment( +a.dataset.mappt );
			} );
		} );
		function done( upd, text ) {
			toast( text );
			if ( S.view === 'cards' ) {
				loadCards();
			}
			cardDetail( upd );
		}
		function fail( e ) {
			msg.className = 'bhc-msg is-error';
			msg.textContent = e.message;
		}
		if ( o( 'use' ) ) {
			o( 'use' ).addEventListener( 'input', function () {
				var v = parseFloat( o( 'use' ).value ) || 0;
				m.querySelector( '[data-use-val]' ).textContent = v ? '= ' + euro( v * ( CARDS.loyalty ? CARDS.loyalty.point_value : 0 ) ) : '';
			} );
		}
		m.querySelectorAll( '[data-do]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var act = b.dataset.do, body2 = { action: act }, text = '';
				if ( act === 'redeem' ) {
					body2.amount = parseFloat( o( 'amount' ).value );
					body2.note = o( 'note' ).value;
					if ( ! body2.amount ) {
						return fail( { message: 'Indica l\'importo da scalare.' } );
					}
					text = 'Scalati ' + euro( body2.amount ) + ' dalla gift card';
				} else if ( act === 'topup' ) {
					body2.amount = parseFloat( o( 'topup' ).value );
					body2.payment_method = o( 'method' ).value;
					text = 'Gift card ricaricata di ' + euro( body2.amount || 0 );
				} else if ( act === 'points_use' ) {
					body2.amount = parseFloat( o( 'use' ).value );
					body2.note = o( 'note' ).value;
					text = 'Punti usati: ' + qtyPts( body2.amount || 0 );
				} else if ( act === 'points_add' ) {
					body2.amount = parseFloat( o( 'add' ).value );
					body2.note = o( 'note2' ).value;
					text = 'Punti accreditati: ' + qtyPts( body2.amount || 0 );
				} else if ( act === 'add_package' ) {
					body2.package_id = +o( 'pkg' ).value;
					body2.payment_method = o( 'method' ).value;
					if ( ! body2.package_id ) {
						return fail( { message: 'Scegli il pacchetto dal listino.' } );
					}
					text = 'Pacchetto caricato sulla card';
				}
				cardAction( c, body2 ).then( function ( upd ) {
					done( upd, text );
				} ).catch( fail );
			} );
		} );
		m.querySelectorAll( '[data-session]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				cardAction( c, { action: 'session', item_id: +b.dataset.session } ).then( function ( upd ) {
					done( upd, 'Seduta scalata dalla carta' );
				} ).catch( fail );
			} );
		} );
		m.querySelectorAll( '[data-undo]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				if ( ! window.confirm( 'Stornare questo movimento?' ) ) {
					return;
				}
				cardAction( c, { action: 'undo', move_id: +b.dataset.undo } ).then( function ( upd ) {
					done( upd, 'Movimento stornato' );
				} ).catch( fail );
			} );
		} );
		if ( manage ) {
			var getHolder = bindClientPicker( m.querySelector( '[data-cdata]' ) );
			var dv = function ( k ) {
				var el = m.querySelector( '[data-d="' + k + '"]' );
				return el ? el.value : null;
			};
			m.querySelector( '[data-ean-auto]' ).addEventListener( 'click', function () {
				api( 'cards/' + c.id, { method: 'PUT', body: { ean: 'auto' } } ).then( function ( upd ) {
					done( upd, 'EAN interno rigenerato' );
				} ).catch( fail );
			} );
			m.querySelector( '[data-d="ean"]' ).addEventListener( 'keydown', function ( e ) {
				if ( e.key === 'Enter' ) {
					e.preventDefault();
				}
			} );
			m.querySelector( '[data-dsave]' ).addEventListener( 'click', function () {
				var p = { status: dv( 'status' ), expires_at: dv( 'expires_at' ), notes: dv( 'notes' ) };
				if ( getHolder() && getHolder() !== c.client_id ) {
					p.client_id = getHolder();
				}
				if ( dv( 'ean' ).trim() !== c.ean ) {
					p.ean = dv( 'ean' ).trim();
				}
				if ( c.type === 'gift' ) {
					p.buyer_name = dv( 'buyer_name' );
					p.message = dv( 'message' );
				}
				api( 'cards/' + c.id, { method: 'PUT', body: p } ).then( function ( upd ) {
					done( upd, 'Dati card salvati' );
				} ).catch( fail );
			} );
		}
	}

	/** Stampa formato carta di credito (85,6 × 54 mm) fronte + riepilogo. */
	function printCard( c ) {
		var col = { gift: '#b0735a', loyalty: '#7d8c6f', package: '#5f6b7a' }[ c.type ];
		var big = c.type === 'gift' ? euro( c.balance ) : ( c.type === 'loyalty' ? qtyPts( c.points ) + ' punti' : c.sessions_left + ' sedute' );
		var items = c.type === 'package' ? '<ul style="margin:6px 0 0;padding-left:16px">' + c.items.map( function ( it ) {
			return '<li>' + esc( it.treatment ) + ': ' + it.sessions_left + ' / ' + it.sessions_total + '</li>';
		} ).join( '' ) + '</ul>' : '';
		printHtml( CARD_TYPES[ c.type ] + ' ' + c.code, '<style>.pc{width:85.6mm;height:54mm;border-radius:3.5mm;border:1px solid #ccc;box-sizing:border-box;padding:4mm 5mm;position:relative;overflow:hidden;color:#fff;background:' + col + ';-webkit-print-color-adjust:exact;print-color-adjust:exact;display:inline-block;vertical-align:top;margin:0 6mm 6mm 0}.pc .b{font-family:Georgia,serif;font-size:13px}.pc .t{float:right;font-size:8px;text-transform:uppercase;letter-spacing:.12em;opacity:.9}.pc .v{font-family:Georgia,serif;font-size:22px;margin-top:5mm}.pc .h{font-size:10px;margin-top:2mm}.pc .h small{display:block;font-size:7px;opacity:.8;text-transform:uppercase;letter-spacing:.1em}.pc .e{position:absolute;right:4mm;bottom:3mm;background:#fff;border-radius:2mm;padding:1.5mm 2mm;width:34mm}.pc .e svg{width:100%;height:auto;display:block}.pc .c{position:absolute;left:5mm;bottom:4mm;font-family:monospace;font-size:9px}.back{background:#fff;color:#3b3a36}.back p{font-size:8px;margin:2px 0}</style>' +
			'<div class="pc"><span class="b">' + esc( B.center ) + '</span><span class="t">' + esc( CARD_TYPES[ c.type ] ) + '</span><div class="v">' + big + '</div><div class="h"><small>Intestata a</small>' + esc( c.holder ) + '</div><div class="c">' + esc( c.code ) + ( c.expires_at ? '<br>Scade ' + esc( cardDate( c.expires_at ) ) : '' ) + '</div><div class="e">' + eanSvg( c.ean, 34 ) + '</div></div>' +
			'<div class="pc back"><span class="b" style="color:' + col + '">' + esc( B.center ) + '</span>' + ( c.message ? '<p style="font-family:Georgia,serif;font-size:11px;margin:4mm 0 2mm"><em>«' + esc( c.message ) + '»</em></p>' : '' ) + ( c.buyer_name ? '<p>Con affetto da ' + esc( c.buyer_name ) + '</p>' : '' ) + items +
			'<p style="margin-top:3mm">Card nominativa, utilizzabile solo dall\'intestataria. Presentala alla reception. ' + ( c.type === 'gift' ? 'Il credito può essere usato anche in più volte.' : '' ) + ( c.type === 'loyalty' ? 'Accumuli punti a ogni visita.' : '' ) + '</p></div>' +
			'<h2>Riepilogo</h2><table><tr><th>Codice</th><td>' + esc( c.code ) + '</td><th>EAN</th><td>' + esc( c.ean ) + '</td></tr><tr><th>Intestataria</th><td>' + esc( c.holder ) + '</td><th>Emessa</th><td>' + esc( cardDate( c.created_at ) ) + '</td></tr><tr><th>Valore</th><td>' + big + '</td><th>Scadenza</th><td>' + esc( cardDate( c.expires_at ) || '—' ) + '</td></tr></table>' );
	}

	/* ---------- Listino pacchetti ---------- */

	function drawPackages( box ) {
		var manage = can( 'cards' );
		box.innerHTML = '<p class="bhc-muted" style="margin-top:0">Pacchetti di sedute a prezzo scontato da caricare sulle carte trattamenti.</p>' + ( CARDS.packages.length ? '<table class="bhc-table"><thead><tr><th>Pacchetto</th><th>Contenuto</th><th>Listino</th><th>Prezzo</th><th>Sconto</th><th>Validità</th><th></th></tr></thead><tbody>' + CARDS.packages.map( function ( p ) {
			return '<tr class="' + ( manage ? 'is-click' : '' ) + '" data-pkg="' + p.id + '"' + ( p.active ? '' : ' style="opacity:.55"' ) + '><td><strong>' + esc( p.name ) + '</strong><br><small class="bhc-muted">' + esc( p.description ) + '</small></td><td><small>' + p.items.map( function ( it ) {
				return it.sessions + ' × ' + esc( it.treatment );
			} ).join( '<br>' ) + '</small></td><td><s class="bhc-muted">' + euro( p.list_price ) + '</s></td><td><b>' + euro( p.price ) + '</b></td><td>' + ( p.discount > 0 ? '<span class="bhc-pill bhc-pill--ok">−' + String( p.discount ).replace( '.', ',' ) + '%</span>' : '—' ) + '</td><td>' + ( p.validity_days ? p.validity_days + ' gg' : 'Illimitata' ) + '</td><td>' + ( p.active ? '' : '<span class="bhc-pill bhc-pill--off">Non attivo</span>' ) + '</td></tr>';
		} ).join( '' ) + '</tbody></table>' : '<div class="bhc-card"><p class="bhc-muted">Nessun pacchetto a listino.</p></div>' ) +
			( manage ? '<p style="margin-top:12px"><button type="button" class="bhc-btn bhc-btn--sm" data-pkgnew>+ Nuovo pacchetto</button></p>' : '' );
		if ( manage ) {
			box.querySelector( '[data-pkgnew]' ).addEventListener( 'click', function () {
				packageEditor( null );
			} );
			box.querySelectorAll( '[data-pkg]' ).forEach( function ( r ) {
				r.addEventListener( 'click', function () {
					packageEditor( CARDS.packages.filter( function ( p ) {
						return p.id === +r.dataset.pkg;
					} )[ 0 ] );
				} );
			} );
		}
	}

	function packageEditor( p ) {
		var isNew = ! p;
		p = p || { name: '', description: '', items: [], price: '', validity_days: 365, active: 1 };
		var body = '<div class="bhc-field"><label>Nome pacchetto *</label><input type="text" data-k="name" value="' + esc( p.name ) + '" placeholder="Es. 10 sedute pressoterapia"></div>' +
			'<div class="bhc-field"><label>Descrizione breve</label><input type="text" data-k="description" value="' + esc( p.description ) + '" placeholder="Es. Paghi 8, ne fai 10"></div>' +
			'<label class="bhc-label">Trattamenti e sedute *</label><div data-items>' + itemRowsHtml( p.items ) + '</div><p style="margin:6px 0 12px"><a href="#" data-it-add>+ Aggiungi trattamento</a></p>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Prezzo scontato (€) *</label><input type="number" min="0" step="0.5" data-k="price" value="' + esc( p.price ) + '"></div><div class="bhc-field"><label>Valore di listino</label><div data-listval style="padding:10px 0;font-weight:600">—</div></div></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Validità (giorni dall\'acquisto)</label><input type="number" min="0" step="1" data-k="validity_days" value="' + esc( p.validity_days ) + '"><div class="bhc-muted" style="font-size:.8rem;margin-top:4px">0 = senza scadenza</div></div><div class="bhc-field"><label>&nbsp;</label><label class="bhc-switch"><input type="checkbox" data-k="active"' + ( p.active ? ' checked' : '' ) + '><span></span> In vendita</label></div></div><p class="bhc-msg" data-msg></p>';
		var m = modal( isNew ? 'Nuovo pacchetto' : 'Pacchetto', body, '<div></div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn" data-go>Salva</button></div>' );
		var k = function ( n ) {
			return m.querySelector( '[data-k="' + n + '"]' );
		};
		var rows = bindItemRows( m.querySelector( '[data-items]' ), upd );
		function upd() {
			var list = rows.list(), pr = parseFloat( k( 'price' ).value );
			m.querySelector( '[data-listval]' ).innerHTML = list ? euro( list ) + ( pr && pr < list ? ' <span class="bhc-pill bhc-pill--ok">sconto ' + String( Math.round( ( 1 - pr / list ) * 1000 ) / 10 ).replace( '.', ',' ) + '%</span>' : '' ) : '—';
		}
		k( 'price' ).addEventListener( 'input', upd );
		upd();
		m.querySelector( '[data-it-add]' ).addEventListener( 'click', function ( e ) {
			e.preventDefault();
			rows.add();
		} );
		m.querySelector( '[data-x]' ).addEventListener( 'click', closeModal );
		m.querySelector( '[data-go]' ).addEventListener( 'click', function () {
			api( isNew ? 'card-packages' : 'card-packages/' + p.id, { method: isNew ? 'POST' : 'PUT', body: { name: k( 'name' ).value, description: k( 'description' ).value, items: rows.read(), price: k( 'price' ).value, validity_days: k( 'validity_days' ).value, active: k( 'active' ).checked ? 1 : 0 } } ).then( function () {
				closeModal();
				toast( 'Pacchetto salvato' );
				CARDS.packages = null;
				loadCards();
			} ).catch( function ( e ) {
				var msg = m.querySelector( '[data-msg]' );
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
	}

	function loyaltySettingsDialog() {
		api( 'card-settings' ).then( function ( s ) {
			var body = '<p class="bhc-muted" style="margin-top:0">Regole delle carte fedeltà, valide per tutte le clienti.</p><div class="bhc-row"><div class="bhc-field"><label>Punti per ogni € incassato</label><input type="number" min="0" step="0.1" data-k="points_per_euro" value="' + s.points_per_euro + '"></div><div class="bhc-field"><label>Valore di 1 punto (€)</label><input type="number" min="0" step="0.01" data-k="point_value" value="' + s.point_value + '"></div></div>' +
				'<div class="bhc-row"><div class="bhc-field"><label>Punti minimi per l\'utilizzo</label><input type="number" min="0" step="1" data-k="min_redeem" value="' + s.min_redeem + '"></div><div class="bhc-field"><label>&nbsp;</label><label class="bhc-switch"><input type="checkbox" data-k="auto"' + ( +s.auto ? ' checked' : '' ) + '><span></span> Accredito automatico sugli incassi</label></div></div>' +
				'<p class="bhc-muted" data-ex></p><p class="bhc-msg" data-msg></p>';
			var m = modal( 'Regole fedeltà', body, '<div></div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn" data-go>Salva</button></div>' );
			var k = function ( n ) {
				return m.querySelector( '[data-k="' + n + '"]' );
			};
			function ex() {
				var ppe = parseFloat( k( 'points_per_euro' ).value ) || 0, pv = parseFloat( k( 'point_value' ).value ) || 0;
				var pts = Math.floor( 100 * ppe );
				m.querySelector( '[data-ex]' ).textContent = 'Esempio: su 100 € incassati la cliente riceve ' + pts + ' punti, pari a ' + euro( pts * pv ) + ' di sconto (' + ( Math.round( ppe * pv * 1000 ) / 10 ) + '% di ritorno).';
			}
			m.querySelectorAll( 'input' ).forEach( function ( i ) {
				i.addEventListener( 'input', ex );
			} );
			ex();
			m.querySelector( '[data-x]' ).addEventListener( 'click', closeModal );
			m.querySelector( '[data-go]' ).addEventListener( 'click', function () {
				api( 'card-settings', { method: 'PUT', body: { points_per_euro: k( 'points_per_euro' ).value, point_value: k( 'point_value' ).value, min_redeem: k( 'min_redeem' ).value, auto: k( 'auto' ).checked ? 1 : 0 } } ).then( function ( s2 ) {
					CARDS.loyalty = s2;
					closeModal();
					toast( 'Regole fedeltà salvate' );
					loadCards();
				} ).catch( function ( e ) {
					var msg = m.querySelector( '[data-msg]' );
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			} );
		} );
	}

	/* ---------- Card nella scheda cliente ---------- */

	function clientCardsPane( m, clientId, clientName ) {
		var box = m.querySelector( '[data-client-cards]' );
		if ( ! box ) {
			return;
		}
		api( 'cards?client=' + clientId ).then( function ( d ) {
			var tabBtn = m.querySelector( '[data-tab="card"]' );
			if ( tabBtn ) {
				tabBtn.textContent = 'Card (' + d.items.length + ')';
			}
			box.innerHTML = ( d.items.length ? '<div class="bhc-mini-cards">' + d.items.map( function ( c ) {
				return '<button type="button" class="bhc-mini-card bhc-mini-card--' + c.type + '" data-card="' + c.id + '"><small>' + esc( CARD_TYPES[ c.type ] ) + ' · <span class="bhc-mono">' + esc( c.code ) + '</span></small><strong>' + cardValueText( c ) + '</strong>' + cardStatusPill( c ) + '</button>';
			} ).join( '' ) + '</div>' : '<p class="bhc-muted">Nessuna card intestata.</p>' ) +
				( can( 'cards' ) ? '<p style="margin-top:12px"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cnew-client>+ Nuova card per questa cliente</button></p>' : '' );
			box.querySelectorAll( '[data-card]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					openCard( b.dataset.card );
				} );
			} );
			var nb = box.querySelector( '[data-cnew-client]' );
			if ( nb ) {
				nb.addEventListener( 'click', function () {
					newCardDialog( 'gift', { client: { id: clientId, name: clientName } } );
				} );
			}
		} ).catch( function () {
			box.innerHTML = '';
		} );
	}

	/* ---------- Card nell'incasso dell'appuntamento ---------- */

	function cardsPanel( m, a ) {
		var box = m.querySelector( '[data-cards-panel]' );
		if ( ! box ) {
			return;
		}
		var payInput = m.querySelector( '[data-pay-amount]' );
		var due = function () {
			return Math.max( 0, parseFloat( payInput.value ) || 0 );
		};
		var base = [], extra = [];
		function drawAll() {
			var seen = {};
			draw( base.concat( extra ).filter( function ( x ) {
				if ( seen[ x.id ] ) {
					return false;
				}
				seen[ x.id ] = 1;
				return true;
			} ) );
		}
		function reload() {
			return api( 'cards?client=' + a.client_id ).then( function ( d ) {
				CARDS.loyalty = d.loyalty;
				base = d.items;
				drawAll();
			} );
		}
		function after( text ) {
			closeModal();
			toast( text );
			if ( S.view === 'agenda' ) {
				loadAgenda();
			}
		}
		function draw( items ) {
			var L = CARDS.loyalty || { point_value: 0.1 };
			var html = '';
			var ord = { package: 0, gift: 1, loyalty: 2 };
			items.slice().sort( function ( x, y ) {
				return ord[ x.type ] - ord[ y.type ];
			} ).forEach( function ( c ) {
				if ( ! c.usable && c.type !== 'loyalty' ) {
					return;
				}
				if ( c.type === 'package' ) {
					c.items.filter( function ( it ) {
						return it.treatment_id === a.treatment_id && it.sessions_left > 0;
					} ).forEach( function ( it ) {
						html += '<div class="bhc-cp bhc-cp--package"><span><span class="bhc-card-dot bhc-card-dot--package"></span><b>Carta trattamenti</b> <span class="bhc-mono">' + esc( c.code ) + '</span><br><small>' + esc( it.treatment ) + ': <b>' + it.sessions_left + '</b> sedute rimaste su ' + it.sessions_total + '</small></span>' +
							'<button type="button" class="bhc-btn bhc-btn--sm" data-cp-session="' + c.id + ':' + it.id + '">Scala 1 seduta e chiudi</button></div>';
					} );
				} else if ( c.type === 'gift' && c.balance > 0 ) {
					html += '<div class="bhc-cp bhc-cp--gift"><span><span class="bhc-card-dot bhc-card-dot--gift"></span><b>Gift card</b> <span class="bhc-mono">' + esc( c.code ) + '</span>' + ( c.holder && c.client_id !== a.client_id ? ' <small class="bhc-muted">(' + esc( c.holder ) + ')</small>' : '' ) + '<br><small>Saldo ' + euro( c.balance ) + '</small></span>' +
						'<span class="bhc-cp__act"><input type="number" min="0.01" step="0.01" data-cp-amt="' + c.id + '" value="' + Math.min( c.balance, due() ).toFixed( 2 ) + '"><button type="button" class="bhc-btn bhc-btn--sm" data-cp-gift="' + c.id + '">Paga con gift card</button></span></div>';
				} else if ( c.type === 'loyalty' && c.status === 'attiva' ) {
					var maxPts = Math.min( c.points, L.point_value > 0 ? Math.floor( due() / L.point_value ) : 0 );
					html += '<div class="bhc-cp bhc-cp--loyalty"><span><span class="bhc-card-dot bhc-card-dot--loyalty"></span><b>Fedeltà</b> <span class="bhc-mono">' + esc( c.code ) + '</span><br><small>' + qtyPts( c.points ) + ' punti = ' + euro( c.points_value ) + ( c.can_redeem ? '' : ' · utilizzabili da ' + qtyPts( L.min_redeem ) + ' punti' ) + '</small></span>' +
						( c.can_redeem && maxPts > 0 ? '<span class="bhc-cp__act"><input type="number" min="1" step="1" data-cp-pts="' + c.id + '" value="' + maxPts + '"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cp-loy="' + c.id + '">Usa come sconto</button></span>' : '<small class="bhc-muted">I punti si accreditano con l\'incasso</small>' ) + '</div>';
				}
			} );
			box.innerHTML = '<div class="bhc-cp-head"><strong>Card</strong><input type="search" data-cp-scan placeholder="Leggi o digita codice card…" autocomplete="off"></div>' + ( html || '<p class="bhc-muted" style="margin:4px 0 0;font-size:.88rem">Nessuna card utilizzabile per questo trattamento.</p>' );
			var scan = box.querySelector( '[data-cp-scan]' );
			scan.addEventListener( 'keydown', function ( e ) {
				if ( e.key !== 'Enter' || ! scan.value.trim() ) {
					return;
				}
				e.preventDefault();
				api( 'cards/lookup?code=' + encodeURIComponent( scan.value.trim() ) ).then( function ( c ) {
					extra = extra.filter( function ( x ) {
						return x.id !== c.id;
					} ).concat( [ c ] );
					if ( ! c.usable && c.type !== 'loyalty' ) {
						toast( 'Card ' + c.code + ': ' + ( c.expired ? 'scaduta' : ( CARD_STATUS[ c.status ] || c.status ).toLowerCase() ), true );
					}
					drawAll();
				} ).catch( function ( err ) {
					toast( err.message, true );
				} );
			} );
			box.querySelectorAll( '[data-cp-session]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var p = b.dataset.cpSession.split( ':' );
					api( 'cards/' + p[ 0 ] + '/action', { method: 'POST', body: { action: 'session', item_id: +p[ 1 ], appointment_id: a.id } } ).then( function ( c ) {
						after( 'Seduta scalata da ' + c.code + ' (' + c.sessions_left + ' rimaste)' );
					} ).catch( function ( e ) {
						toast( e.message, true );
					} );
				} );
			} );
			box.querySelectorAll( '[data-cp-gift]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var id = b.dataset.cpGift;
					var amt = parseFloat( box.querySelector( '[data-cp-amt="' + id + '"]' ).value );
					if ( ! amt || amt <= 0 ) {
						return toast( 'Indica l\'importo da scalare.', true );
					}
					var full = amt >= due() - 0.001;
					api( 'cards/' + id + '/action', { method: 'POST', body: { action: 'redeem', amount: amt, appointment_id: a.id, register_payment: 1, complete: full ? 1 : 0, note: a.treatment_name } } ).then( function ( c ) {
						if ( full ) {
							after( 'Pagato ' + euro( amt ) + ' con gift card · saldo residuo ' + euro( c.balance ) );
						} else {
							toast( 'Scalati ' + euro( amt ) + ' dalla gift card: registra il resto (' + euro( due() - amt ) + ')' );
							payInput.value = ( due() - amt ).toFixed( 2 );
							refreshExtra().then( reload );
						}
					} ).catch( function ( e ) {
						toast( e.message, true );
					} );
				} );
			} );
			box.querySelectorAll( '[data-cp-loy]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var id = b.dataset.cpLoy;
					var pts = parseFloat( box.querySelector( '[data-cp-pts="' + id + '"]' ).value );
					if ( ! pts ) {
						return;
					}
					api( 'cards/' + id + '/action', { method: 'POST', body: { action: 'points_use', amount: pts, appointment_id: a.id, note: a.treatment_name } } ).then( function () {
						var disc = pts * ( L.point_value || 0 );
						payInput.value = Math.max( 0, due() - disc ).toFixed( 2 );
						toast( 'Usati ' + qtyPts( pts ) + ' punti: sconto ' + euro( disc ) + ' applicato all\'importo' );
						refreshExtra().then( reload );
					} ).catch( function ( e ) {
						toast( e.message, true );
					} );
				} );
			} );
		}
		function refreshExtra() {
			return Promise.all( extra.map( function ( x ) {
				return api( 'cards/' + x.id );
			} ) ).then( function ( list ) {
				extra = list;
			} ).catch( function () {} );
		}
		reload().catch( function () {
			box.innerHTML = '';
		} );
	}

	/* ================= Cassa ================= */

	var POS = { data: null, client: null, cards: [], extraCards: [], lines: [], tab: 'todo', pq: '', pfam: '', gift: {}, points: null, bonus: 0, seq: 0, ctab: 'gift' };

	function posReset() {
		POS.client = null;
		POS.cards = [];
		POS.extraCards = [];
		POS.lines = [];
		POS.gift = {};
		POS.points = null;
		POS.bonus = 0;
		POS.coupon = null;
		POS.issue = null;
	}

	function renderPos() {
		var main = document.getElementById( 'bhc-main' );
		main.innerHTML = '<div class="bhc-top"><h2>Cassa</h2><div class="bhc-top__actions"><span class="bhc-muted" data-pos-date></span>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pos-day>Vendite e chiusura cassa</button>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pos-clear>Svuota scontrino</button></div></div>' +
			'<div class="bhc-pos"><section class="bhc-pos__left">' +
			'<div class="bhc-pos__scan">' + ICONS.scan + '<input type="search" data-pos-scan placeholder="Leggi il codice a barre di un prodotto o di una card…" autocomplete="off"></div>' +
			'<div class="bhc-tabs" data-pos-tabs>' + [ [ 'todo', 'Da incassare' ], [ 'treat', 'Trattamenti' ], [ 'prod', 'Prodotti' ], [ 'card', 'Card e pacchetti' ] ].map( function ( t ) {
				return '<button type="button" data-ptab="' + t[ 0 ] + '"' + ( POS.tab === t[ 0 ] ? ' class="is-active"' : '' ) + '>' + t[ 1 ] + '</button>';
			} ).join( '' ) + '</div><div data-pos-cat><div class="bhc-loading">Caricamento…</div></div></section>' +
			'<section class="bhc-pos__right"><div class="bhc-receipt"><div data-pos-client></div><div data-pos-lines></div><div data-pos-cards></div><div data-pos-totals></div>' +
			'<div class="bhc-pos__pay"><button type="button" class="bhc-paybtn" data-paym="cash">' + ICONS.cash + 'Contanti</button><button type="button" class="bhc-paybtn" data-paym="card">' + ICONS.cardpay + 'Carta</button><button type="button" class="bhc-paybtn" data-paym="mixed">' + ICONS.mixed + 'Misto</button></div></div></section></div>';

		main.querySelector( '[data-pos-day]' ).addEventListener( 'click', posDayDialog );
		main.querySelector( '[data-pos-clear]' ).addEventListener( 'click', function () {
			if ( ! POS.lines.length || window.confirm( 'Svuotare lo scontrino?' ) ) {
				posReset();
				posDraw();
			}
		} );
		main.querySelectorAll( '[data-ptab]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				POS.tab = b.dataset.ptab;
				main.querySelectorAll( '[data-ptab]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === b );
				} );
				posCatalog();
			} );
		} );
		main.querySelectorAll( '[data-paym]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				posPayDialog( b.dataset.paym );
			} );
		} );
		var scan = main.querySelector( '[data-pos-scan]' );
		scan.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Enter' && scan.value.trim() ) {
				e.preventDefault();
				posScan( scan.value.trim() );
				scan.value = '';
			}
		} );
		scan.addEventListener( 'input', function () {
			if ( POS.tab === 'prod' ) {
				POS.pq = scan.value;
				posCatalog();
			}
		} );
		api( 'pos/bootstrap' ).then( function ( d ) {
			POS.data = d;
			CARDS.loyalty = d.loyalty;
			main.querySelector( '[data-pos-date]' ).textContent = fmtDate( d.date, { weekday: 'long', day: 'numeric', month: 'long' } );
			posCatalog();
			posDraw();
			scan.focus();
		} ).catch( function ( e ) {
			main.querySelector( '[data-pos-cat]' ).innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function posRefreshTodo() {
		return api( 'pos/todo' ).then( function ( d ) {
			POS.data.todo = d.todo;
			POS.data.products = d.products;
			if ( S.view === 'pos' ) {
				posCatalog();
			}
		} );
	}

	/* ---------- Cliente ---------- */

	function posSetClient( id, then ) {
		if ( ! id ) {
			POS.client = null;
			POS.cards = [];
			posDraw();
			return Promise.resolve();
		}
		return api( 'pos/client/' + id ).then( function ( d ) {
			if ( ! POS.client || POS.client.id !== d.client.id ) {
				POS.gift = {};
				POS.points = null;
			}
			POS.client = d.client;
			POS.cards = d.cards;
			// Le righe card senza intestataria diventano della cliente scelta.
			POS.lines.forEach( function ( l ) {
				if ( l.holder && ! l.holder.id ) {
					l.holder = { id: d.client.id, name: d.client.name };
				}
			} );
			posDraw();
			if ( then ) {
				then();
			}
		} ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	/** Cambio cliente: se lo scontrino contiene righe di un'altra cliente chiede conferma. */
	function posEnsureClient( id, name, then ) {
		if ( POS.client && POS.client.id === id ) {
			then();
			return;
		}
		var other = POS.lines.some( function ( l ) {
			return l.type === 'appointment' || l.type === 'gift_topup' || ( l.session );
		} );
		if ( POS.client && other ) {
			if ( ! window.confirm( 'Lo scontrino è di ' + POS.client.name + '. Svuotarlo e iniziare quello di ' + name + '?' ) ) {
				return;
			}
			posReset();
		}
		posSetClient( id, then );
	}

	function posClientBox() {
		var box = document.querySelector( '[data-pos-client]' );
		if ( ! box ) {
			return;
		}
		if ( POS.client ) {
			var loy = POS.cards.filter( function ( c ) {
				return c.type === 'loyalty' && c.status === 'attiva';
			} )[ 0 ];
			box.innerHTML = '<div class="bhc-pos-client"><span class="bhc-person__avatar">' + esc( POS.client.name.charAt( 0 ).toUpperCase() ) + '</span><div><strong>' + esc( POS.client.name ) + '</strong><small class="bhc-muted">' + esc( [ POS.client.phone, loy ? loy.code + ' · ' + qtyPts( loy.points ) + ' punti' : '' ].filter( Boolean ).join( ' · ' ) ) + '</small></div>' +
				'<button type="button" class="bhc-modal__close" data-pos-noclient title="Togli cliente" aria-label="Togli cliente">&times;</button></div>';
			box.querySelector( '[data-pos-noclient]' ).addEventListener( 'click', function () {
				POS.gift = {};
				POS.points = null;
				POS.lines = POS.lines.filter( function ( l ) {
					return l.type !== 'appointment' && ! l.session;
				} );
				posSetClient( 0 );
			} );
			return;
		}
		box.innerHTML = '<div class="bhc-pos-client bhc-pos-client--empty"><input type="search" data-pos-csearch placeholder="Cliente: cerca nome o telefono (facoltativo)" autocomplete="off"><div data-pos-cres></div></div>';
		var inp = box.querySelector( '[data-pos-csearch]' ), res = box.querySelector( '[data-pos-cres]' );
		inp.addEventListener( 'input', debounce( function () {
			var q = inp.value.trim();
			if ( q.length < 2 ) {
				res.innerHTML = '';
				return;
			}
			api( 'pos/clients?q=' + encodeURIComponent( q ) ).then( function ( d ) {
				res.innerHTML = d.items.length ? '<div class="bhc-search-results">' + d.items.map( function ( c ) {
					return '<button type="button" data-pcid="' + c.id + '">' + esc( c.name ) + ' <span class="bhc-muted">' + esc( c.phone || c.email ) + '</span></button>';
				} ).join( '' ) + '</div>' : '<p class="bhc-muted" style="margin:6px 0 0">Nessuna cliente trovata.</p>';
				res.querySelectorAll( '[data-pcid]' ).forEach( function ( b ) {
					b.addEventListener( 'click', function () {
						posSetClient( +b.dataset.pcid );
					} );
				} );
			} );
		}, 250 ) );
	}

	/* ---------- Catalogo (colonna sinistra) ---------- */

	function posCatalog() {
		var box = document.querySelector( '[data-pos-cat]' );
		if ( ! box || ! POS.data ) {
			return;
		}
		if ( POS.tab === 'todo' ) {
			var list = POS.data.todo;
			box.innerHTML = list.length ? '<div class="bhc-pos-todo">' + list.map( function ( a ) {
				var inCart = POS.lines.some( function ( l ) {
					return l.appointment_id === a.id;
				} );
				var state = a.session ? '<span class="bhc-pill bhc-pill--ok">Seduta da carta</span>' : ( a.settled ? '<span class="bhc-pill bhc-pill--ok">Incassato</span>' : '<b>' + euro( a.due ) + '</b>' );
				return '<button type="button" class="bhc-pos-appt' + ( a.settled ? ' is-settled' : '' ) + ( inCart ? ' is-in' : '' ) + '" data-pappt="' + a.id + '"' + ( a.settled ? ' disabled' : '' ) + '><span class="bhc-pos-appt__time" style="border-color:' + esc( a.staff_color ) + '">' + esc( a.start ) + '</span>' +
					'<span class="bhc-pos-appt__body"><strong>' + esc( a.client_name || 'Cliente' ) + '</strong><small>' + esc( a.treatment_name ) + ( a.operators && a.operators.length ? ' · ' + esc( a.operators.map( function ( o ) {
						return o.name;
					} ).join( ' + ' ) ) : '' ) + ( a.staff_name ? ' · ' + esc( a.staff_name ) : '' ) + '</small></span><span class="bhc-pos-appt__due">' + ( inCart ? '<span class="bhc-pill">Nello scontrino</span>' : state ) + '</span></button>';
			} ).join( '' ) + '</div>' : '<div class="bhc-card"><p class="bhc-muted">Nessun appuntamento oggi. Puoi aggiungere trattamenti e prodotti dalle altre schede.</p></div>';
			box.querySelectorAll( '[data-pappt]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var a = POS.data.todo.filter( function ( x ) {
						return x.id === +b.dataset.pappt;
					} )[ 0 ];
					posAddAppointment( a );
				} );
			} );
		} else if ( POS.tab === 'treat' ) {
			var cats = {};
			B.treatments.forEach( function ( t ) {
				var k = t.category || 'Trattamenti';
				( cats[ k ] = cats[ k ] || [] ).push( t );
			} );
			box.innerHTML = Object.keys( cats ).map( function ( k ) {
				return '<h4 class="bhc-pos-h">' + esc( k ) + '</h4><div class="bhc-tiles">' + cats[ k ].map( function ( t ) {
					return '<button type="button" class="bhc-tile" data-ptreat="' + t.id + '"><strong>' + esc( t.name ) + '</strong><span>' + euro( t.price ) + '<small> · ' + t.duration + ' min</small></span></button>';
				} ).join( '' ) + '</div>';
			} ).join( '' );
			box.querySelectorAll( '[data-ptreat]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var t = treatmentById( +b.dataset.ptreat );
					posAddLine( { type: 'treatment', treatment_id: t.id, label: t.name, sub: 'Senza appuntamento', unit_price: t.price } );
				} );
			} );
		} else if ( POS.tab === 'prod' ) {
			var fams = [];
			POS.data.products.forEach( function ( p ) {
				if ( p.family && fams.indexOf( p.family ) === -1 ) {
					fams.push( p.family );
				}
			} );
			var q = POS.pq.trim().toLowerCase();
			var items = POS.data.products.filter( function ( p ) {
				return ( ! POS.pfam || p.family === POS.pfam ) && ( ! q || ( p.name + ' ' + p.brand + ' ' + p.ean + ' ' + p.sku ).toLowerCase().indexOf( q ) !== -1 );
			} );
			box.innerHTML = '<div class="bhc-chips-row"><button type="button" class="bhc-fchip' + ( POS.pfam ? '' : ' is-active' ) + '" data-pfam="">Tutti</button>' + fams.sort().map( function ( f ) {
				return '<button type="button" class="bhc-fchip' + ( POS.pfam === f ? ' is-active' : '' ) + '" data-pfam="' + esc( f ) + '">' + esc( f ) + '</button>';
			} ).join( '' ) + '</div>' + ( items.length ? '<div class="bhc-tiles">' + items.map( function ( p ) {
				return '<button type="button" class="bhc-tile bhc-tile--prod" data-pprod="' + p.id + '"><strong>' + esc( p.name ) + '</strong><small class="bhc-muted">' + esc( p.brand ) + '</small><span>' + euro( p.sale_price ) + '<small class="' + ( p.stock <= 0 ? 'is-out' : '' ) + '"> · ' + ( p.stock <= 0 ? 'esaurito' : qtyPts( p.stock ) + ' ' + esc( p.unit ) ) + '</small></span></button>';
			} ).join( '' ) + '</div>' : '<p class="bhc-muted">Nessun prodotto da rivendita' + ( q ? ' per «' + esc( POS.pq ) + '»' : '' ) + '.</p>' );
			box.querySelectorAll( '[data-pfam]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					POS.pfam = b.dataset.pfam;
					posCatalog();
				} );
			} );
			box.querySelectorAll( '[data-pprod]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					posAddProduct( POS.data.products.filter( function ( p ) {
						return p.id === +b.dataset.pprod;
					} )[ 0 ] );
				} );
			} );
		} else {
			posCardCatalog( box );
		}
	}

	function posCardCatalog( box ) {
		var gifts = POS.cards.filter( function ( c ) {
			return c.type === 'gift' && c.status !== 'annullata';
		} );
		var pkCards = POS.cards.filter( function ( c ) {
			return c.type === 'package' && c.status !== 'annullata';
		} );
		var loy = POS.cards.filter( function ( c ) {
			return c.type === 'loyalty' && c.status === 'attiva';
		} )[ 0 ];
		var noClient = POS.client ? '' : '<p class="bhc-muted bhc-pos-hint">Scegli prima la cliente: le card sono nominali.</p>';
		box.innerHTML = '<div class="bhc-pos-cardsec"><h4 class="bhc-pos-h"><span class="bhc-card-dot bhc-card-dot--gift"></span>Nuova gift card</h4>' + noClient +
			'<div class="bhc-amounts">' + [ 25, 50, 75, 100, 150, 200 ].map( function ( v ) {
				return '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pgv="' + v + '">' + v + ' €</button>';
			} ).join( '' ) + '<input type="number" min="1" step="1" data-pgfree placeholder="Altro €" style="max-width:110px"><button type="button" class="bhc-btn bhc-btn--sm" data-pgfree-add>Aggiungi</button></div>' +
			'<label class="bhc-check" style="margin-top:8px"><input type="checkbox" data-pgother> <span>È un regalo per un\'altra persona (scegli l\'intestataria)</span></label>' +
			'<div data-pgother-box hidden>' + clientPickerHtml( 'Intestataria della gift card', null ) + '<div class="bhc-row"><div class="bhc-field"><label>Dedica</label><input type="text" data-pgmsg maxlength="120"></div><div class="bhc-field"><label>EAN card prestampata (facoltativo)</label><input type="text" data-pgean class="bhc-mono" maxlength="13" inputmode="numeric"></div></div></div></div>' +

			'<div class="bhc-pos-cardsec"><h4 class="bhc-pos-h"><span class="bhc-card-dot bhc-card-dot--package"></span>Pacchetti di trattamenti</h4>' + noClient +
			( POS.data.packages.length ? '<div class="bhc-tiles">' + POS.data.packages.map( function ( p ) {
				return '<button type="button" class="bhc-tile" data-ppkg="' + p.id + '"><strong>' + esc( p.name ) + '</strong><small class="bhc-muted">' + p.items.map( function ( it ) {
					return it.sessions + '× ' + esc( it.treatment );
				} ).join( ', ' ) + '</small><span>' + euro( p.price ) + ( p.discount > 0 ? ' <s class="bhc-muted">' + euro( p.list_price ) + '</s>' : '' ) + '</span></button>';
			} ).join( '' ) + '</div>' : '<p class="bhc-muted">Nessun pacchetto a listino: crealo in Card › Listino pacchetti.</p>' ) + '</div>' +

			'<div class="bhc-pos-cardsec"><h4 class="bhc-pos-h"><span class="bhc-card-dot bhc-card-dot--gift"></span>Ricarica gift card</h4>' + ( gifts.length ? gifts.map( function ( c ) {
				return '<div class="bhc-cp"><span><b class="bhc-mono">' + esc( c.code ) + '</b><br><small>Saldo ' + euro( c.balance ) + '</small></span><span class="bhc-cp__act"><input type="number" min="1" step="1" data-ptopv="' + c.id + '" placeholder="€"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-ptop="' + c.id + '">Ricarica</button></span></div>';
			} ).join( '' ) : '<p class="bhc-muted">' + ( POS.client ? 'La cliente non ha gift card. Puoi leggerne una con il lettore.' : 'Scegli la cliente o leggi la gift card con il lettore.' ) + '</p>' ) + '</div>' +

			'<div class="bhc-pos-cardsec"><h4 class="bhc-pos-h"><span class="bhc-card-dot bhc-card-dot--loyalty"></span>Carta fedeltà</h4>' + ( POS.client ? ( loy ? '<p><b class="bhc-mono">' + esc( loy.code ) + '</b> · ' + qtyPts( loy.points ) + ' punti (= ' + euro( loy.points_value ) + '). I punti si caricano in automatico con l\'incasso; puoi aggiungere punti bonus nello scontrino.</p>' : '<button type="button" class="bhc-btn bhc-btn--sm" data-ployal>+ Emetti carta fedeltà</button>' ) : noClient ) + '</div>';

		function holder() {
			var other = box.querySelector( '[data-pgother]' ).checked;
			if ( other ) {
				var id = getOther();
				if ( ! id ) {
					toast( 'Scegli l\'intestataria della gift card.', true );
					return null;
				}
				return { id: id, name: box.querySelector( '[data-cp-search]' ).value };
			}
			if ( ! POS.client ) {
				toast( 'Scegli la cliente: la gift card è nominale.', true );
				return null;
			}
			return { id: POS.client.id, name: POS.client.name };
		}
		var getOther = bindClientPicker( box.querySelector( '[data-pgother-box]' ) );
		box.querySelector( '[data-pgother]' ).addEventListener( 'change', function ( e ) {
			box.querySelector( '[data-pgother-box]' ).hidden = ! e.target.checked;
		} );
		function addGift( v ) {
			var h = holder();
			if ( ! h || ! v || v <= 0 ) {
				return;
			}
			var ean = box.querySelector( '[data-pgean]' ).value.replace( /\D/g, '' );
			if ( ean && ! eanOk( ean ) ) {
				toast( 'EAN della card non valido.', true );
				return;
			}
			posAddLine( { type: 'gift_new', label: 'Gift card ' + euro( v ), sub: 'Intestata a ' + h.name, unit_price: v, holder: h, message: box.querySelector( '[data-pgmsg]' ).value, ean: ean } );
		}
		box.querySelectorAll( '[data-pgv]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				addGift( +b.dataset.pgv );
			} );
		} );
		box.querySelector( '[data-pgfree-add]' ).addEventListener( 'click', function () {
			addGift( parseFloat( box.querySelector( '[data-pgfree]' ).value ) );
		} );
		box.querySelectorAll( '[data-ppkg]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				if ( ! POS.client ) {
					toast( 'Scegli la cliente: la carta trattamenti è nominale.', true );
					return;
				}
				var p = POS.data.packages.filter( function ( x ) {
					return x.id === +b.dataset.ppkg;
				} )[ 0 ];
				var target = pkCards.filter( function ( c ) {
					return c.usable;
				} )[ 0 ];
				var onCard = target && window.confirm( 'Caricare il pacchetto sulla carta trattamenti ' + target.code + ' della cliente?\n\nOK = carica sulla carta esistente · Annulla = emetti una nuova carta' );
				posAddLine( { type: 'package', package_id: p.id, label: p.name, sub: ( onCard ? 'Su carta ' + target.code : 'Nuova carta trattamenti' ) + ' · ' + p.sessions + ' sedute', unit_price: p.price, card_id: onCard ? target.id : 0, holder: { id: POS.client.id, name: POS.client.name }, fixed: true } );
			} );
		} );
		box.querySelectorAll( '[data-ptop]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var c = gifts.filter( function ( x ) {
					return x.id === +b.dataset.ptop;
				} )[ 0 ];
				var v = parseFloat( box.querySelector( '[data-ptopv="' + c.id + '"]' ).value );
				if ( ! v || v <= 0 ) {
					toast( 'Indica l\'importo della ricarica.', true );
					return;
				}
				delete POS.gift[ c.id ];
				posAddLine( { type: 'gift_topup', card_id: c.id, label: 'Ricarica gift card', sub: c.code, unit_price: v } );
			} );
		} );
		var ly = box.querySelector( '[data-ployal]' );
		if ( ly ) {
			ly.addEventListener( 'click', function () {
				if ( POS.lines.some( function ( l ) {
					return l.type === 'loyalty_new';
				} ) ) {
					return;
				}
				posAddLine( { type: 'loyalty_new', label: 'Carta fedeltà', sub: 'Punti caricati già da questo scontrino', unit_price: 0, holder: { id: POS.client.id, name: POS.client.name }, fixed: true } );
			} );
		}
	}

	/* ---------- Righe ---------- */

	function posAddLine( l ) {
		l.k = ++POS.seq;
		l.qty = l.qty || 1;
		l.discount = l.discount || 0;
		POS.lines.push( l );
		posDraw();
		if ( POS.tab === 'todo' ) {
			posCatalog();
		}
	}

	function posAddAppointment( a ) {
		if ( POS.lines.some( function ( l ) {
			return l.appointment_id === a.id;
		} ) ) {
			toast( 'L\'appuntamento è già nello scontrino.' );
			return;
		}
		var add = function () {
			var line = { type: 'appointment', appointment_id: a.id, treatment_id: a.treatment_id, label: a.treatment_name, sub: a.start + ( a.operators && a.operators.length ? ' · ' + a.operators.map( function ( o ) {
				return o.name;
			} ).join( ' + ' ) : '' ) + ( a.paid > 0 ? ' · già pagati ' + euro( a.paid ) : '' ), unit_price: a.due };
			posAddLine( line );
			// Se c'è una seduta disponibile la propone subito.
			var s = posSessionOptions( line )[ 0 ];
			if ( s ) {
				toast( 'La cliente ha ' + s.left + ' sedute di ' + a.treatment_name + ' sulla carta ' + s.code + ': spunta «Usa seduta» per scalarla.' );
			}
		};
		if ( a.client_id ) {
			posEnsureClient( a.client_id, a.client_name, add );
		} else {
			add();
		}
	}

	function posAddProduct( p ) {
		if ( ! p ) {
			return;
		}
		var ex = POS.lines.filter( function ( l ) {
			return l.type === 'product' && l.product_id === p.id;
		} )[ 0 ];
		if ( ex ) {
			ex.qty++;
			posDraw();
		} else {
			posAddLine( { type: 'product', product_id: p.id, label: p.name, sub: [ p.brand, p.ean ].filter( Boolean ).join( ' · ' ), unit_price: p.sale_price, stock: p.stock } );
		}
		if ( p.stock - ( ex ? ex.qty : 1 ) < 0 ) {
			toast( 'Attenzione: giacenza a magazzino insufficiente (' + qtyPts( p.stock ) + ').', true );
		}
	}

	function posScan( code ) {
		var digits = code.replace( /\s/g, '' );
		var local = POS.data && POS.data.products.filter( function ( p ) {
			return p.ean && p.ean === digits;
		} )[ 0 ];
		if ( local ) {
			beepOk();
			posAddProduct( local );
			return;
		}
		api( 'pos/scan?code=' + encodeURIComponent( code ) ).then( function ( r ) {
			beepOk();
			if ( r.kind === 'product' ) {
				posAddProduct( r.product );
				return;
			}
			if ( r.kind === 'coupon' ) {
				posApplyCoupon( r.coupon.code );
				return;
			}
			var c = r.card;
			if ( ! POS.client ) {
				posSetClient( c.client_id, function () {
					toast( CARD_TYPES[ c.type ] + ' ' + c.code + ' di ' + c.holder );
				} );
			} else if ( c.client_id === POS.client.id ) {
				toast( CARD_TYPES[ c.type ] + ' ' + c.code + ' della cliente' );
				posDraw();
			} else {
				// Card di un'altra persona (es. gift card ricevuta): utilizzabile in questo scontrino.
				POS.extraCards = POS.extraCards.filter( function ( x ) {
					return x.id !== c.id;
				} ).concat( [ c ] );
				toast( CARD_TYPES[ c.type ] + ' ' + c.code + ' intestata a ' + c.holder );
				posDraw();
			}
		} ).catch( function ( e ) {
			try {
				if ( typeof beep === 'function' ) {
					beep( false );
				}
			} catch ( x ) {}
			toast( e.message, true );
		} );
	}

	function posApplyCoupon( code ) {
		code = String( code || '' ).trim();
		if ( ! code ) {
			return;
		}
		var t = posTotals();
		api( 'coupons/check?code=' + encodeURIComponent( code ) + '&amount=' + Math.max( 0, t.revenue - t.points ) ).then( function ( c ) {
			POS.coupon = c;
			toast( 'Buono ' + c.code + ' applicato: ' + c.label );
			posDraw();
		} ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	/** Sedute disponibili per una riga (tenendo conto delle altre righe dello scontrino). */
	function posSessionOptions( line ) {
		var out = [];
		posAllCards().forEach( function ( c ) {
			if ( c.type !== 'package' || ! c.usable ) {
				return;
			}
			c.items.forEach( function ( it ) {
				if ( it.treatment_id !== line.treatment_id ) {
					return;
				}
				var used = POS.lines.filter( function ( l ) {
					return l !== line && l.session && l.session.item_id === it.id;
				} ).length;
				if ( it.sessions_left - used > 0 || ( line.session && line.session.item_id === it.id ) ) {
					out.push( { card_id: c.id, item_id: it.id, code: c.code, left: it.sessions_left - used } );
				}
			} );
		} );
		return out;
	}

	function posAllCards() {
		var ids = {};
		return POS.cards.concat( POS.extraCards ).filter( function ( c ) {
			if ( ids[ c.id ] ) {
				return false;
			}
			ids[ c.id ] = 1;
			return true;
		} );
	}

	function posLineNet( l ) {
		if ( l.session ) {
			return 0;
		}
		return Math.max( 0, Math.round( ( l.qty * l.unit_price - l.discount ) * 100 ) / 100 );
	}

	function posTotals() {
		var REV = [ 'appointment', 'treatment', 'product', 'package' ];
		var t = { gross: 0, disc: 0, sessions: 0, revenue: 0, prepaid: 0, points: 0, gift: 0, total: 0, earn: 0 };
		POS.lines.forEach( function ( l ) {
			var g = Math.round( l.qty * l.unit_price * 100 ) / 100, n = posLineNet( l );
			t.gross += g;
			if ( l.session ) {
				t.sessions += g;
			} else {
				t.disc += g - n;
			}
			if ( REV.indexOf( l.type ) !== -1 ) {
				t.revenue += n;
			} else {
				t.prepaid += n;
			}
		} );
		var L = CARDS.loyalty || POS.data.loyalty;
		if ( POS.points && POS.points.pts > 0 ) {
			t.points = Math.min( t.revenue, Math.round( POS.points.pts * L.point_value * 100 ) / 100 );
		}
		t.coupon = 0;
		t.couponShort = false;
		if ( POS.coupon ) {
			var cb = Math.max( 0, t.revenue - t.points );
			if ( POS.coupon.min_spend > 0 && cb + 0.001 < POS.coupon.min_spend ) {
				t.couponShort = true;
			} else {
				t.coupon = Math.round( Math.min( cb, Math.max( 0, POS.coupon.type === 'percent' ? cb * POS.coupon.value / 100 : POS.coupon.value ) ) * 100 ) / 100;
			}
		}
		var room = Math.round( ( t.revenue - t.points - t.coupon ) * 100 ) / 100;
		Object.keys( POS.gift ).forEach( function ( id ) {
			var v = Math.min( POS.gift[ id ], Math.max( 0, room - t.gift ) );
			POS.gift[ id ] = Math.round( v * 100 ) / 100;
			t.gift += POS.gift[ id ];
		} );
		t.gift = Math.round( t.gift * 100 ) / 100;
		t.total = Math.max( 0, Math.round( ( t.revenue + t.prepaid - t.points - t.coupon - t.gift ) * 100 ) / 100 );
		var base = Math.max( 0, t.revenue - t.points - t.coupon - t.gift );
		t.spent = Math.max( 0, t.revenue - t.points - t.coupon );
		var CP = POS.data && POS.data.coupon;
		t.issueOn = !! ( CP && +CP.coupon_enabled );
		t.issue = t.issueOn && ( POS.issue !== null && POS.issue !== undefined ? POS.issue : ( +CP.coupon_auto && t.spent + 0.001 >= +CP.coupon_threshold ) );
		t.earn = +L.auto ? Math.floor( base * L.points_per_euro ) : 0;
		return t;
	}

	function posDraw() {
		posClientBox();
		var box = document.querySelector( '[data-pos-lines]' );
		if ( ! box ) {
			return;
		}
		if ( ! POS.lines.length ) {
			box.innerHTML = '<div class="bhc-receipt__empty">' + ICONS.pos + '<p>Lo scontrino è vuoto.<br><small>Scegli un appuntamento da incassare, un trattamento, un prodotto o una card, oppure leggi un codice a barre.</small></p></div>';
		} else {
			box.innerHTML = POS.lines.map( function ( l ) {
				var sess = ( l.type === 'appointment' || l.type === 'treatment' ) ? posSessionOptions( l ) : [];
				var sessHtml = sess.length ? '<label class="bhc-check bhc-line__sess"><input type="checkbox" data-lsess="' + l.k + '"' + ( l.session ? ' checked' : '' ) + '> <span>Usa seduta della carta ' + esc( ( l.session ? l.session.code : sess[ 0 ].code ) ) + ' (' + ( l.session ? sess.filter( function ( s ) {
					return s.item_id === l.session.item_id;
				} ).map( function ( s ) {
					return s.left;
				} )[ 0 ] : sess[ 0 ].left ) + ' rimaste)</span></label>' : '';
				var priceEditable = ! l.fixed && ! l.session && l.type !== 'loyalty_new';
				return '<div class="bhc-line' + ( l.session ? ' is-session' : '' ) + '" data-line="' + l.k + '"><div class="bhc-line__main"><strong>' + esc( l.label ) + '</strong><small class="bhc-muted">' + esc( l.sub || '' ) + '</small>' + sessHtml + '</div>' +
					'<div class="bhc-line__qty">' + ( l.type === 'product' ? '<button type="button" data-lq="-1" aria-label="Meno">−</button><span>' + qtyPts( l.qty ) + '</span><button type="button" data-lq="1" aria-label="Più">+</button>' : '' ) + '</div>' +
					'<div class="bhc-line__price">' + ( priceEditable ? '<input type="number" min="0" step="0.5" data-lp value="' + l.unit_price.toFixed( 2 ) + '" aria-label="Prezzo">' + ( l.type !== 'gift_new' && l.type !== 'gift_topup' ? '<button type="button" class="bhc-line__disc" data-ld>' + ( l.discount ? '−' + euro( l.discount ) : 'Sconto' ) + '</button>' : '' ) : '' ) + '</div>' +
					'<div class="bhc-line__tot">' + ( l.session ? '<span class="bhc-pill bhc-pill--ok">Seduta</span>' : euro( posLineNet( l ) ) ) + '</div>' +
					'<button type="button" class="bhc-line__del" data-ldel aria-label="Rimuovi">&times;</button></div>';
			} ).join( '' );
		}
		box.querySelectorAll( '[data-line]' ).forEach( function ( row ) {
			var l = POS.lines.filter( function ( x ) {
				return x.k === +row.dataset.line;
			} )[ 0 ];
			row.querySelector( '[data-ldel]' ).addEventListener( 'click', function () {
				POS.lines = POS.lines.filter( function ( x ) {
					return x !== l;
				} );
				posDraw();
				posCatalog();
			} );
			row.querySelectorAll( '[data-lq]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					l.qty = Math.max( 1, l.qty + ( +b.dataset.lq ) );
					posDraw();
				} );
			} );
			var lp = row.querySelector( '[data-lp]' );
			if ( lp ) {
				lp.addEventListener( 'change', function () {
					l.unit_price = Math.max( 0, parseFloat( lp.value ) || 0 );
					posDraw();
				} );
			}
			var ld = row.querySelector( '[data-ld]' );
			if ( ld ) {
				ld.addEventListener( 'click', function () {
					var v = window.prompt( 'Sconto su questa riga: importo in € (es. 5) oppure percentuale (es. 10%)', l.discount ? String( l.discount ) : '' );
					if ( v === null ) {
						return;
					}
					v = String( v ).replace( ',', '.' ).trim();
					var gross = l.qty * l.unit_price;
					var d = /%$/.test( v ) ? gross * ( parseFloat( v ) || 0 ) / 100 : parseFloat( v ) || 0;
					l.discount = Math.min( gross, Math.max( 0, Math.round( d * 100 ) / 100 ) );
					posDraw();
				} );
			}
			var ls = row.querySelector( '[data-lsess]' );
			if ( ls ) {
				ls.addEventListener( 'change', function () {
					if ( ls.checked ) {
						var o = posSessionOptions( l )[ 0 ];
						l.session = o ? { card_id: o.card_id, item_id: o.item_id, code: o.code } : null;
					} else {
						l.session = null;
					}
					posDraw();
				} );
			}
		} );
		posCardsBox();
		posTotalsBox();
	}

	/** Card della cliente utilizzabili nello scontrino: gift card e punti. */
	function posCardsBox() {
		var box = document.querySelector( '[data-pos-cards]' );
		if ( ! box ) {
			return;
		}
		var L = CARDS.loyalty || POS.data.loyalty;
		var t = posTotals();
		var html = '';
		if ( POS.lines.length ) {
			html += POS.coupon ? '<div class="bhc-cp bhc-cp--coupon is-on"><span><span class="bhc-card-dot bhc-card-dot--coupon"></span><b>Buono sconto</b> <span class="bhc-mono">' + esc( POS.coupon.code ) + '</span><br><small>' + esc( POS.coupon.label ) + ( t.couponShort ? ' · <span class="bhc-warn-txt">spesa minima ' + euro( POS.coupon.min_spend ) + ' non raggiunta</span>' : '' ) + '</small></span><span class="bhc-cp__act"><b>−' + euro( t.coupon ) + '</b><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cpn-off>Togli</button></span></div>' :
				'<div class="bhc-cp bhc-cp--coupon"><span><span class="bhc-card-dot bhc-card-dot--coupon"></span><b>Buono sconto</b><br><small>Leggilo con il lettore o digita il codice</small></span><span class="bhc-cp__act"><input type="text" data-cpn-code placeholder="BS26-…" style="width:110px !important"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cpn-on>Applica</button></span></div>';
		}
		posAllCards().forEach( function ( c ) {
			if ( c.type === 'gift' && c.usable && c.balance > 0 && ! POS.lines.some( function ( l ) {
				return l.type === 'gift_topup' && l.card_id === c.id;
			} ) ) {
				var on = POS.gift[ c.id ] > 0;
				html += '<div class="bhc-cp bhc-cp--gift' + ( on ? ' is-on' : '' ) + '"><span><span class="bhc-card-dot bhc-card-dot--gift"></span><b>Gift card</b> <span class="bhc-mono">' + esc( c.code ) + '</span>' + ( POS.client && c.client_id !== POS.client.id ? ' <small class="bhc-muted">(' + esc( c.holder ) + ')</small>' : '' ) + '<br><small>Saldo ' + euro( c.balance ) + ( on ? ' · resteranno ' + euro( c.balance - POS.gift[ c.id ] ) : '' ) + '</small></span>' +
					'<span class="bhc-cp__act">' + ( on ? '<b>−' + euro( POS.gift[ c.id ] ) + '</b><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-gift-off="' + c.id + '">Togli</button>' : '<input type="number" min="0.01" step="0.01" data-gift-amt="' + c.id + '" value="' + Math.min( c.balance, Math.max( 0, t.revenue - t.points - t.gift ) ).toFixed( 2 ) + '"><button type="button" class="bhc-btn bhc-btn--sm" data-gift-on="' + c.id + '">Scala</button>' ) + '</span></div>';
			}
			if ( c.type === 'loyalty' && c.status === 'attiva' && POS.client && c.client_id === POS.client.id ) {
				var on2 = POS.points && POS.points.card_id === c.id;
				var maxPts = Math.min( c.points, L.point_value > 0 ? Math.floor( Math.max( 0, t.revenue - t.gift + t.points ) / L.point_value ) : 0 );
				html += '<div class="bhc-cp bhc-cp--loyalty' + ( on2 ? ' is-on' : '' ) + '"><span><span class="bhc-card-dot bhc-card-dot--loyalty"></span><b>Fedeltà</b> <span class="bhc-mono">' + esc( c.code ) + '</span><br><small>' + qtyPts( c.points ) + ' punti = ' + euro( c.points_value ) + ( c.can_redeem ? '' : ' · utilizzabili da ' + qtyPts( L.min_redeem ) ) + '</small></span>' +
					'<span class="bhc-cp__act">' + ( on2 ? '<b>' + qtyPts( POS.points.pts ) + ' pt = −' + euro( t.points ) + '</b><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pts-off>Togli</button>' : ( c.can_redeem && maxPts > 0 ? '<input type="number" min="1" step="1" data-pts-amt value="' + maxPts + '"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pts-on="' + c.id + '">Usa punti</button>' : '' ) ) + '</span>' +
					'<span class="bhc-cp__earn">+ <b>' + qtyPts( t.earn + ( POS.bonus || 0 ) ) + '</b> punti con questo scontrino · bonus <input type="number" min="0" step="1" data-pts-bonus value="' + ( POS.bonus || '' ) + '" placeholder="0"></span></div>';
			}
		} );
		if ( POS.client && ! posAllCards().some( function ( c ) {
			return c.type === 'loyalty' && c.status === 'attiva';
		} ) && ! POS.lines.some( function ( l ) {
			return l.type === 'loyalty_new';
		} ) ) {
			html += '<p class="bhc-muted bhc-pos-hint">La cliente non ha la carta fedeltà. <a href="#" data-pos-newloy>Emettila ora</a>: i punti di questo scontrino verranno caricati subito.</p>';
		}
		box.innerHTML = html ? '<div class="bhc-pos-cards">' + html + '</div>' : '';
		var cpOn = box.querySelector( '[data-cpn-on]' ), cpCode = box.querySelector( '[data-cpn-code]' );
		if ( cpOn ) {
			cpOn.addEventListener( 'click', function () {
				posApplyCoupon( cpCode.value );
			} );
			cpCode.addEventListener( 'keydown', function ( e ) {
				if ( e.key === 'Enter' ) {
					e.preventDefault();
					posApplyCoupon( cpCode.value );
				}
			} );
		}
		var cpOff = box.querySelector( '[data-cpn-off]' );
		if ( cpOff ) {
			cpOff.addEventListener( 'click', function () {
				POS.coupon = null;
				posDraw();
			} );
		}
		box.querySelectorAll( '[data-gift-on]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var id = +b.dataset.giftOn;
				var c = posAllCards().filter( function ( x ) {
					return x.id === id;
				} )[ 0 ];
				var v = Math.min( c.balance, parseFloat( box.querySelector( '[data-gift-amt="' + id + '"]' ).value ) || 0 );
				if ( v <= 0 ) {
					toast( 'Nello scontrino non ci sono trattamenti o prodotti da pagare con la gift card.', true );
					return;
				}
				POS.gift[ id ] = v;
				posDraw();
			} );
		} );
		box.querySelectorAll( '[data-gift-off]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				delete POS.gift[ +b.dataset.giftOff ];
				posDraw();
			} );
		} );
		var pon = box.querySelector( '[data-pts-on]' );
		if ( pon ) {
			pon.addEventListener( 'click', function () {
				var v = parseFloat( box.querySelector( '[data-pts-amt]' ).value ) || 0;
				if ( v > 0 ) {
					POS.points = { card_id: +pon.dataset.ptsOn, pts: v };
					posDraw();
				}
			} );
		}
		var poff = box.querySelector( '[data-pts-off]' );
		if ( poff ) {
			poff.addEventListener( 'click', function () {
				POS.points = null;
				posDraw();
			} );
		}
		var pb = box.querySelector( '[data-pts-bonus]' );
		if ( pb ) {
			pb.addEventListener( 'change', function () {
				POS.bonus = Math.max( 0, parseFloat( pb.value ) || 0 );
				posDraw();
			} );
		}
		var nl = box.querySelector( '[data-pos-newloy]' );
		if ( nl ) {
			nl.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				posAddLine( { type: 'loyalty_new', label: 'Carta fedeltà', sub: 'Punti caricati già da questo scontrino', unit_price: 0, holder: { id: POS.client.id, name: POS.client.name }, fixed: true } );
			} );
		}
	}

	function posTotalsBox() {
		var box = document.querySelector( '[data-pos-totals]' );
		if ( ! box ) {
			return;
		}
		var t = posTotals();
		var row = function ( label, v, cls ) {
			return '<div class="bhc-tot__row' + ( cls ? ' ' + cls : '' ) + '"><span>' + label + '</span><span>' + v + '</span></div>';
		};
		box.innerHTML = '<div class="bhc-tot">' + row( 'Subtotale', euro( t.gross ) ) +
			( t.sessions ? row( 'Sedute da carta', '−' + euro( t.sessions ) ) : '' ) +
			( t.disc ? row( 'Sconti', '−' + euro( t.disc ) ) : '' ) +
			( t.points ? row( 'Sconto punti fedeltà', '−' + euro( t.points ) ) : '' ) +
			( t.coupon ? row( 'Buono sconto', '−' + euro( t.coupon ) ) : '' ) +
			( t.gift ? row( 'Gift card', '−' + euro( t.gift ) ) : '' ) +
			row( 'Totale da pagare', euro( t.total ), 'is-total' ) + '</div>' +
			( t.issueOn && POS.lines.length ? '<label class="bhc-check bhc-issue"><input type="checkbox" data-pissue' + ( t.issue ? ' checked' : '' ) + '> <span>Stampa un buono sconto di <b>' + esc( couponLabel( POS.data.coupon.coupon_type, +POS.data.coupon.coupon_value ) ) + '</b> per il prossimo acquisto</span></label>' : '' );
		var pi = box.querySelector( '[data-pissue]' );
		if ( pi ) {
			pi.addEventListener( 'change', function () {
				POS.issue = pi.checked;
			} );
		}
		document.querySelectorAll( '[data-paym]' ).forEach( function ( b ) {
			b.disabled = ! POS.lines.length;
		} );
	}

	/* ---------- Pagamento con tastierino ---------- */

	function posPayDialog( mode ) {
		if ( ! POS.lines.length ) {
			return;
		}
		var t = posTotals();
		var total = t.total;
		var st = { mode: total > 0 ? mode : 'cash', recv: '', fresh: false };
		var body = '<div class="bhc-pay"><div class="bhc-pay__due"><small>Totale da pagare</small><strong>' + euro( total ) + '</strong>' + ( POS.client ? '<span class="bhc-muted">' + esc( POS.client.name ) + '</span>' : '' ) + '</div>' +
			( total > 0 ? '<div class="bhc-seg" data-pmode>' + [ [ 'cash', 'Contanti' ], [ 'card', 'Carta' ], [ 'mixed', 'Misto' ] ].map( function ( m ) {
				return '<button type="button" data-pm="' + m[ 0 ] + '">' + m[ 1 ] + '</button>';
			} ).join( '' ) + '</div>' : '<p class="bhc-muted">Tutto coperto da sedute, gift card o punti: nessun importo da incassare.</p>' ) +
			'<div data-pmixed class="bhc-field"><label>Quota con carta (€)</label><input type="number" min="0" step="0.01" data-pcard inputmode="decimal"><div class="bhc-muted" data-pcash-part style="margin-top:4px"></div></div>' +
			'<div data-pcashbox><div class="bhc-pay__screen"><div><small>Ricevuto in contanti</small><span data-precv>€ 0,00</span></div><div class="bhc-pay__change"><small>Resto</small><span data-pchange>—</span></div></div>' +
			'<div class="bhc-pay__quick">' + [ 5, 10, 20, 50, 100 ].map( function ( v ) {
				return '<button type="button" data-pq="' + v + '">' + v + ' €</button>';
			} ).join( '' ) + '<button type="button" data-pq="exact">Importo esatto</button></div>' +
			'<div class="bhc-keypad">' + [ '7', '8', '9', '4', '5', '6', '1', '2', '3', ',', '0', '00' ].map( function ( k ) {
				return '<button type="button" data-pk="' + k + '">' + k + '</button>';
			} ).join( '' ) + '<button type="button" data-pk="C" class="is-fn">C</button><button type="button" data-pk="back" class="is-fn" aria-label="Cancella">⌫</button></div></div>' +
			'<div data-pcardbox class="bhc-pay__cardmsg">' + ICONS.cardpay + '<p>Fai pagare <b data-pcardamt></b> sul POS, poi conferma.</p></div>' +
			'<p class="bhc-msg" data-msg></p></div>';
		var m = modal( 'Incasso', body, '<div></div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn bhc-btn--lg" data-pconfirm>Conferma incasso</button></div>' );
		var recvEl = m.querySelector( '[data-precv]' ), chEl = m.querySelector( '[data-pchange]' ), ok = m.querySelector( '[data-pconfirm]' );
		function cashDue() {
			if ( st.mode === 'card' ) {
				return 0;
			}
			if ( st.mode === 'mixed' ) {
				return Math.max( 0, Math.round( ( total - ( parseFloat( m.querySelector( '[data-pcard]' ).value ) || 0 ) ) * 100 ) / 100 );
			}
			return total;
		}
		function recvVal() {
			return parseFloat( st.recv.replace( ',', '.' ) ) || 0;
		}
		function upd() {
			m.querySelectorAll( '[data-pm]' ).forEach( function ( b ) {
				b.classList.toggle( 'is-active', b.dataset.pm === st.mode );
			} );
			m.querySelector( '[data-pmixed]' ).hidden = st.mode !== 'mixed';
			m.querySelector( '[data-pcashbox]' ).hidden = st.mode === 'card' || total <= 0;
			m.querySelector( '[data-pcardbox]' ).hidden = st.mode === 'cash' || total <= 0;
			var cd = cashDue();
			var cardPart = Math.round( ( total - cd ) * 100 ) / 100;
			m.querySelector( '[data-pcardamt]' ).textContent = euro( cardPart );
			m.querySelector( '[data-pcash-part]' ).textContent = st.mode === 'mixed' ? 'In contanti: ' + euro( cd ) : '';
			recvEl.textContent = st.recv ? '€ ' + st.recv : '€ 0,00';
			var r = recvVal();
			var valid = true;
			if ( st.mode !== 'card' && cd > 0 ) {
				if ( ! st.recv ) {
					chEl.textContent = '—';
					chEl.className = '';
				} else if ( r + 0.001 < cd ) {
					chEl.textContent = 'mancano ' + euro( cd - r );
					chEl.className = 'is-short';
					valid = false;
				} else {
					chEl.textContent = euro( r - cd );
					chEl.className = 'is-ok';
				}
			}
			if ( st.mode === 'mixed' && ( cardPart <= 0 || cardPart > total ) ) {
				valid = false;
			}
			ok.disabled = ! valid;
			ok.textContent = total <= 0 ? 'Conferma' : ( st.mode !== 'card' && cd > 0 && st.recv && r > cd ? 'Incassa · resto ' + euro( r - cd ) : 'Incassa ' + euro( total ) );
		}
		function key( k ) {
			var wasFresh = st.fresh;
			st.fresh = false;
			if ( k === ',' && wasFresh ) {
				st.recv = '';
			}
			if ( k === 'C' ) {
				st.recv = '';
			} else if ( k === 'back' ) {
				st.recv = st.recv.slice( 0, -1 );
			} else if ( k === ',' ) {
				if ( st.recv.indexOf( ',' ) === -1 ) {
					st.recv = ( st.recv || '0' ) + ',';
				}
			} else {
				if ( wasFresh ) {
					st.recv = '';
				}
				var dec = st.recv.split( ',' )[ 1 ];
				if ( dec !== undefined && dec.length + k.length > 2 ) {
					return;
				}
				if ( ! wasFresh && st.recv.replace( ',', '' ).length >= 7 ) {
					return;
				}
				st.recv = ( st.recv === '0' ? '' : st.recv ) + k;
			}
			upd();
		}
		m.querySelectorAll( '[data-pm]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				st.mode = b.dataset.pm;
				if ( st.mode === 'mixed' && ! m.querySelector( '[data-pcard]' ).value ) {
					m.querySelector( '[data-pcard]' ).focus();
				}
				upd();
			} );
		} );
		m.querySelector( '[data-pcard]' ).addEventListener( 'input', upd );
		m.querySelectorAll( '[data-pk]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				key( b.dataset.pk );
			} );
		} );
		m.querySelectorAll( '[data-pq]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				if ( b.dataset.pq === 'exact' ) {
					st.recv = cashDue().toFixed( 2 ).replace( '.', ',' );
				} else {
					// Banconote: si sommano a quanto già ricevuto.
					st.recv = String( Math.round( ( recvVal() + ( +b.dataset.pq ) ) * 100 ) / 100 ).replace( '.', ',' );
				}
				st.fresh = true;
				upd();
			} );
		} );
		// Tastiera fisica / tastierino numerico del PC.
		function onKey( e ) {
			if ( ! document.body.contains( m ) ) {
				document.removeEventListener( 'keydown', onKey );
				return;
			}
			if ( e.target && e.target.matches && e.target.matches( '[data-pcard]' ) ) {
				return;
			}
			if ( st.mode === 'card' ) {
				if ( e.key === 'Enter' && ! ok.disabled ) {
					e.preventDefault();
					ok.click();
				}
				return;
			}
			if ( /^[0-9]$/.test( e.key ) ) {
				key( e.key );
			} else if ( e.key === ',' || e.key === '.' || e.key === 'Decimal' ) {
				key( ',' );
			} else if ( e.key === 'Backspace' ) {
				key( 'back' );
			} else if ( e.key === 'Delete' ) {
				key( 'C' );
			} else if ( e.key === 'Enter' && ! ok.disabled ) {
				e.preventDefault();
				ok.click();
			} else {
				return;
			}
			e.preventDefault();
		}
		document.addEventListener( 'keydown', onKey );
		m.querySelector( '[data-x]' ).addEventListener( 'click', closeModal );
		ok.addEventListener( 'click', function () {
			var cd = cashDue();
			var payload = {
				client_id: POS.client ? POS.client.id : 0,
				lines: POS.lines.map( function ( l ) {
					return {
						type: l.type, appointment_id: l.appointment_id, treatment_id: l.treatment_id, product_id: l.product_id, card_id: l.card_id, package_id: l.package_id,
						qty: l.qty, unit_price: l.unit_price, discount: l.discount, amount: l.unit_price, holder_id: l.holder ? l.holder.id : 0, message: l.message || '', ean: l.ean || '',
						session: l.session ? { card_id: l.session.card_id, item_id: l.session.item_id } : null
					};
				} ),
				use: {
					gift: Object.keys( POS.gift ).filter( function ( id ) {
						return POS.gift[ id ] > 0;
					} ).map( function ( id ) {
						return { card_id: +id, amount: POS.gift[ id ] };
					} ),
					points: POS.points ? { card_id: POS.points.card_id, points: POS.points.pts } : null,
					bonus_points: POS.bonus || 0,
					coupon: POS.coupon ? { code: POS.coupon.code } : null
				},
				issue_coupon: POS.issue === null || POS.issue === undefined ? null : !! POS.issue,
				pay: { cash: cd, card: Math.round( ( total - cd ) * 100 ) / 100, tendered: st.mode !== 'card' && st.recv ? recvVal() : cd }
			};
			ok.disabled = true;
			api( 'pos/checkout', { method: 'POST', body: payload } ).then( function ( sale ) {
				document.removeEventListener( 'keydown', onKey );
				posReset();
				posDraw();
				posRefreshTodo();
				CARDS.packages = null;
				posReceiptDialog( sale, true );
			} ).catch( function ( e ) {
				ok.disabled = false;
				var msg = m.querySelector( '[data-msg]' );
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
		upd();
	}

	/* ---------- Scontrino ---------- */

	function posReceiptDialog( s, fresh ) {
		var body = ( fresh && s.change_given > 0 ? '<div class="bhc-pay__bigchange"><small>Resto da dare</small><strong>' + euro( s.change_given ) + '</strong><span class="bhc-muted">ricevuti ' + euro( s.tendered ) + ' in contanti</span></div>' : ( fresh ? '<div class="bhc-pay__bigchange is-ok"><strong>' + ICONS.check + ' Incassato</strong></div>' : '' ) ) +
			posReceiptHtml( s );
		var m = modal( 'Scontrino ' + s.number, body, '<div><button type="button" class="bhc-btn bhc-btn--ghost" data-rprint>' + ICONS.print + ' Stampa scontrino</button></div><div><button type="button" class="bhc-btn" data-rnew>' + ( fresh ? 'Nuova vendita' : 'Chiudi' ) + '</button></div>' );
		m.querySelector( '[data-rprint]' ).addEventListener( 'click', function () {
			posPrintReceipt( s );
		} );
		m.querySelector( '[data-rnew]' ).addEventListener( 'click', function () {
			closeModal();
			var sc = document.querySelector( '[data-pos-scan]' );
			if ( sc ) {
				sc.focus();
			}
		} );
	}

	function posReceiptHtml( s ) {
		var R = ( POS.data && POS.data.receipt ) || { name: B.center };
		var lines = s.lines.map( function ( l ) {
			return '<tr><td>' + esc( l.description ) + ( l.qty !== 1 ? '<br><small>' + qtyPts( l.qty ) + ' × ' + euro( l.unit_price ) + '</small>' : '' ) + ( l.discount > 0 && l.note.indexOf( 'Seduta' ) !== 0 ? '<br><small>sconto −' + euro( l.discount ) + '</small>' : '' ) + ( l.note ? '<br><small>' + esc( l.note ) + '</small>' : '' ) + '</td><td class="r">' + ( l.note.indexOf( 'Seduta' ) === 0 ? 'seduta' : euro( l.total ) ) + '</td></tr>';
		} ).join( '' );
		var r = function ( a, b, cls ) {
			return '<tr' + ( cls ? ' class="' + cls + '"' : '' ) + '><td>' + a + '</td><td class="r">' + b + '</td></tr>';
		};
		var cards = ( s.cards || [] ).map( function ( c ) {
			return c.code + ': ' + ( c.type === 'gift' ? 'saldo ' + euro( c.balance ) : ( c.type === 'loyalty' ? qtyPts( c.points ) + ' punti' : c.sessions_left + ' sedute' ) );
		} );
		return '<div class="bhc-rcpt"><div class="bhc-rcpt__head"><strong>' + esc( R.name ) + '</strong>' + ( R.phone ? '<span>Tel. ' + esc( R.phone ) + '</span>' : '' ) + '<span>' + esc( cardDate( s.created_at ) + ' ' + s.created_at.substring( 11, 16 ) ) + ' · ' + esc( s.number ) + '</span>' + ( s.client_name ? '<span>Cliente: ' + esc( s.client_name ) + '</span>' : '' ) + '</div>' +
			'<table>' + lines + '</table><table class="bhc-rcpt__tot">' +
			( s.points_discount ? r( 'Sconto punti (' + qtyPts( s.points_used ) + ' pt)', '−' + euro( s.points_discount ) ) : '' ) +
			( s.coupon_discount ? r( 'Buono sconto' + ( s.coupon_used_c ? ' ' + esc( s.coupon_used_c.code ) : '' ), '−' + euro( s.coupon_discount ) ) : '' ) +
			( s.gift_used ? r( 'Pagato con gift card', '−' + euro( s.gift_used ) ) : '' ) +
			r( 'TOTALE', euro( s.total ), 'big' ) +
			( s.cash ? r( 'Contanti', euro( s.cash ) ) : '' ) + ( s.card ? r( 'Carta', euro( s.card ) ) : '' ) +
			( s.change_given ? r( 'Ricevuti', euro( s.tendered ) ) + r( 'Resto', euro( s.change_given ) ) : '' ) + '</table>' +
			( s.points_earned ? '<p>Punti fedeltà guadagnati: <b>+' + qtyPts( s.points_earned ) + '</b></p>' : '' ) +
			( cards.length ? '<p class="bhc-rcpt__cards">' + cards.map( esc ).join( '<br>' ) + '</p>' : '' ) +
			( s.coupon ? couponBlockHtml( s.coupon, s.coupon_text ) : '' ) +
			( s.footer ? '<p class="bhc-rcpt__msg">' + esc( s.footer ).replace( /\n/g, '<br>' ) + '</p>' : '' ) +
			'<p class="bhc-rcpt__foot">Documento non fiscale · Operatore: ' + esc( s.user ) + '</p></div>';
	}

	function posPrintReceipt( s ) {
		var w = window.open( '', '_blank', 'width=420,height=700' );
		if ( ! w ) {
			toast( 'Consenti le finestre popup per stampare.', true );
			return;
		}
		w.document.open();
		w.document.write( '<!doctype html><html lang="it"><head><meta charset="utf-8"><title>' + esc( s.number ) + '</title><style>@page{size:80mm auto;margin:4mm}body{font-family:"Courier New",monospace;font-size:12px;color:#000;width:72mm;margin:0 auto}.bhc-rcpt__head{text-align:center;display:flex;flex-direction:column;gap:2px;border-bottom:1px dashed #000;padding-bottom:6px;margin-bottom:6px}.bhc-rcpt__head strong{font-size:15px}table{width:100%;border-collapse:collapse}td{padding:2px 0;vertical-align:top}.r{text-align:right;white-space:nowrap;padding-left:8px}.bhc-rcpt__tot{border-top:1px dashed #000;margin-top:6px;padding-top:4px}.big td{font-size:16px;font-weight:bold;padding:6px 0}small{font-size:10px}p{margin:6px 0}.bhc-rcpt__foot{text-align:center;border-top:1px dashed #000;padding-top:6px;font-size:10px}.bhc-rcpt__msg{text-align:center;margin:8px 0;font-size:12px}.bhc-coupon{border:2px dashed #000;padding:6px;margin:10px 0;text-align:center}.bhc-coupon__head{font-weight:bold;letter-spacing:.15em;font-size:11px}.bhc-coupon__val{font-size:24px;font-weight:bold;margin:2px 0}.bhc-coupon__txt{font-size:11px}.bhc-coupon__ean{width:70%;margin:6px auto 2px}.bhc-coupon__ean svg{width:100%;height:auto;display:block}.bhc-coupon__meta{font-size:10px}</style></head><body>' + posReceiptHtml( s ) + '<script>window.onload=function(){window.print();}<\/script></body></html>' );
		w.document.close();
	}

	/* ---------- Vendite del giorno e chiusura ---------- */

	function posDayDialog( date ) {
		date = typeof date === 'string' ? date : ( POS.data ? POS.data.date : ymd( new Date() ) );
		api( 'pos/sales?date=' + date ).then( function ( d ) {
			var T = d.totals;
			var TYPES = { appointment: 'Appuntamenti', treatment: 'Trattamenti senza appuntamento', product: 'Prodotti', package: 'Pacchetti', gift_new: 'Gift card vendute', gift_topup: 'Ricariche gift card', loyalty_new: 'Carte fedeltà emesse' };
			var body = '<div class="bhc-row" style="align-items:end"><div class="bhc-field"><label>Giorno</label><input type="date" data-dday value="' + esc( d.date ) + '"></div><div class="bhc-field"></div></div>' +
				'<div class="bhc-kpis">' + kpi( 'Incasso cassa', euro( T.takings ) ) + kpi( 'Contanti', euro( T.cash ) ) + kpi( 'Carta', euro( T.card ) ) + kpi( 'Scontrini', T.count ) + '</div>' +
				'<div class="bhc-day-grid"><table class="bhc-table"><tbody>' +
				'<tr><td>Gift card usate</td><td class="r">' + euro( T.gift_used ) + '</td></tr><tr><td>Sconti punti fedeltà</td><td class="r">' + euro( T.points_discount ) + '</td></tr><tr><td>Buoni sconto usati</td><td class="r">' + euro( T.coupon_discount ) + '</td></tr><tr><td>Buoni sconto emessi</td><td class="r">' + T.coupons_issued + '</td></tr><tr><td>Sconti su righe</td><td class="r">' + euro( T.discount ) + '</td></tr><tr><td>Sedute scalate da carte</td><td class="r">' + T.sessions + '</td></tr><tr><td>Resti dati</td><td class="r">' + euro( T.change ) + '</td></tr></tbody></table>' +
				'<table class="bhc-table"><tbody>' + ( d.by_type.length ? d.by_type.map( function ( b ) {
					return '<tr><td>' + esc( TYPES[ b.type ] || b.type ) + '</td><td class="r">' + qtyPts( b.qty ) + '</td><td class="r">' + euro( b.total ) + '</td></tr>';
				} ).join( '' ) : '<tr><td class="bhc-muted">Nessuna vendita</td></tr>' ) + '</tbody></table></div>' +
				'<h4 style="margin:16px 0 8px">Scontrini</h4>' + ( d.sales.length ? '<table class="bhc-table"><thead><tr><th>Ora</th><th>N.</th><th>Cliente</th><th>Pagamento</th><th class="r">Totale</th></tr></thead><tbody>' + d.sales.map( function ( s ) {
					return '<tr class="is-click" data-sale="' + s.id + '"><td>' + esc( s.created_at.substring( 11, 16 ) ) + '</td><td class="bhc-mono">' + esc( s.number ) + '</td><td>' + esc( s.client_name || '—' ) + '</td><td><small>' + [ s.cash ? 'Contanti ' + euro( s.cash ) : '', s.card ? 'Carta ' + euro( s.card ) : '', s.gift_used ? 'Gift ' + euro( s.gift_used ) : '', s.sessions_used ? s.sessions_used + ( s.sessions_used === 1 ? ' seduta' : ' sedute' ) : '' ].filter( Boolean ).join( ' · ' ) + '</small></td><td class="r"><b>' + euro( s.total ) + '</b></td></tr>';
				} ).join( '' ) + '</tbody></table>' : '<p class="bhc-muted">Nessuno scontrino.</p>' );
			var m = modal( 'Vendite e chiusura cassa', body, '<div><button type="button" class="bhc-btn bhc-btn--ghost" data-dprint>' + ICONS.print + ' Stampa chiusura</button></div><div><button type="button" class="bhc-btn" data-x>Chiudi</button></div>', true );
			m.querySelector( '[data-x]' ).addEventListener( 'click', closeModal );
			m.querySelector( '[data-dday]' ).addEventListener( 'change', function ( e ) {
				posDayDialog( e.target.value );
			} );
			m.querySelectorAll( '[data-sale]' ).forEach( function ( r ) {
				r.addEventListener( 'click', function () {
					api( 'pos/sales/' + r.dataset.sale ).then( function ( s ) {
						posReceiptDialog( s, false );
					} );
				} );
			} );
			m.querySelector( '[data-dprint]' ).addEventListener( 'click', function () {
				printHtml( 'Chiusura cassa ' + d.date, '<h1>Chiusura cassa</h1><p class="muted">' + esc( B.center ) + ' · ' + esc( fmtDate( d.date, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' } ) ) + '</p>' +
					'<h2>Incassi</h2><table><tr><td>Contanti</td><td class="r">' + euro( T.cash ) + '</td></tr><tr><td>Carta / POS</td><td class="r">' + euro( T.card ) + '</td></tr><tr><td><b>Totale cassa</b></td><td class="r"><b>' + euro( T.takings ) + '</b></td></tr><tr><td>Scontrini</td><td class="r">' + T.count + '</td></tr></table>' +
					'<h2>Card e sconti</h2><table><tr><td>Gift card usate</td><td class="r">' + euro( T.gift_used ) + '</td></tr><tr><td>Sconti punti fedeltà</td><td class="r">' + euro( T.points_discount ) + '</td></tr><tr><td>Sconti su righe</td><td class="r">' + euro( T.discount ) + '</td></tr><tr><td>Sedute scalate</td><td class="r">' + T.sessions + '</td></tr></table>' +
					'<h2>Per tipo</h2><table>' + d.by_type.map( function ( b ) {
						return '<tr><td>' + esc( TYPES[ b.type ] || b.type ) + '</td><td class="r">' + qtyPts( b.qty ) + '</td><td class="r">' + euro( b.total ) + '</td></tr>';
					} ).join( '' ) + '</table>' +
					'<h2>Scontrini</h2><table><tr><th>Ora</th><th>N.</th><th>Cliente</th><th class="r">Contanti</th><th class="r">Carta</th><th class="r">Totale</th></tr>' + d.sales.slice().reverse().map( function ( s ) {
						return '<tr><td>' + esc( s.created_at.substring( 11, 16 ) ) + '</td><td>' + esc( s.number ) + '</td><td>' + esc( s.client_name ) + '</td><td class="r">' + euro( s.cash ) + '</td><td class="r">' + euro( s.card ) + '</td><td class="r">' + euro( s.total ) + '</td></tr>';
					} ).join( '' ) + '</table><p class="muted" style="margin-top:30px">Riepilogo gestionale, non sostituisce la chiusura fiscale del registratore telematico.</p>' );
			} );
		} ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	/* ================= Messaggi: promemoria WhatsApp, scontrino, buoni ================= */

	var MSG = { tab: 'rem', date: '', cfg: null };

	function tomorrow() {
		var d = new Date();
		d.setDate( d.getDate() + 1 );
		return ymd( d );
	}

	function renderMessages() {
		var main = document.getElementById( 'bhc-main' );
		if ( ! MSG.date ) {
			MSG.date = tomorrow();
		}
		var tabs = [ [ 'rem', 'Promemoria' ], [ 'tpl', 'Messaggio promemoria' ], [ 'rcpt', 'Scontrino e buono sconto' ], [ 'coupons', 'Buoni emessi' ] ];
		main.innerHTML = '<div class="bhc-top"><h2>Messaggi</h2></div><div class="bhc-tabs">' + tabs.map( function ( t ) {
			return '<button type="button" data-mtab="' + t[ 0 ] + '"' + ( MSG.tab === t[ 0 ] ? ' class="is-active"' : '' ) + '>' + t[ 1 ] + '</button>';
		} ).join( '' ) + '</div><div data-mbox><div class="bhc-loading">Caricamento…</div></div>';
		main.querySelectorAll( '[data-mtab]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				MSG.tab = b.dataset.mtab;
				main.querySelectorAll( '[data-mtab]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-active', x === b );
				} );
				msgPane();
			} );
		} );
		api( 'messages/settings' ).then( function ( c ) {
			MSG.cfg = c;
			msgPane();
		} ).catch( function ( e ) {
			main.querySelector( '[data-mbox]' ).innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function msgPane() {
		var box = document.querySelector( '[data-mbox]' );
		if ( ! box || ! MSG.cfg ) {
			return;
		}
		if ( MSG.tab === 'rem' ) {
			msgReminders( box );
		} else if ( MSG.tab === 'tpl' ) {
			msgTemplate( box );
		} else if ( MSG.tab === 'rcpt' ) {
			msgReceipt( box );
		} else {
			msgCoupons( box );
		}
	}

	function msgSave( part, data, okText ) {
		var body = {};
		body[ part ] = data;
		return api( 'messages/settings', { method: 'PUT', body: body } ).then( function ( c ) {
			MSG.cfg = c;
			if ( POS.data ) {
				POS.data.coupon = c.receipt;
			}
			toast( okText || 'Impostazioni salvate' );
			return c;
		} );
	}

	/* ---------- Promemoria del giorno ---------- */

	function msgReminders( box ) {
		var W = MSG.cfg.whatsapp;
		box.innerHTML = '<div class="bhc-msgbar"><label class="bhc-inline">Appuntamenti del <input type="date" data-mdate value="' + esc( MSG.date ) + '"></label>' +
			'<span class="bhc-muted" data-mcount></span><span class="bhc-grow"></span>' +
			( W.mode === 'auto' ? '<span class="bhc-pill bhc-pill--ok">Invio automatico alle ' + pad( W.send_hour ) + ':00</span><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-msendall>Invia ora quelli mancanti</button>' : '<span class="bhc-pill">Invio manuale con WhatsApp</span>' ) +
			'</div><div data-mlist><div class="bhc-loading">Caricamento…</div></div>' +
			( W.mode !== 'auto' ? '<p class="bhc-muted bhc-note">Con «Apri WhatsApp» si apre WhatsApp (app o WhatsApp Web) con il messaggio già scritto: premi Invia e il promemoria viene segnato come inviato. Per l\'invio automatico serve WhatsApp Business: vedi la scheda «Messaggio promemoria».</p>' : '' );
		box.querySelector( '[data-mdate]' ).addEventListener( 'change', function ( e ) {
			MSG.date = e.target.value;
			msgLoadReminders();
		} );
		var sa = box.querySelector( '[data-msendall]' );
		if ( sa ) {
			sa.addEventListener( 'click', function () {
				sa.disabled = true;
				api( 'messages/reminders/send?date=' + MSG.date, { method: 'POST', body: {} } ).then( function ( r ) {
					toast( 'Inviati ' + r.sent + ( r.errors ? ' · errori ' + r.errors + ( r.details[ 0 ] ? ': ' + r.details[ 0 ].error : '' ) : '' ), r.errors > 0 );
					msgLoadReminders();
				} ).catch( function ( e ) {
					toast( e.message, true );
				} ).then( function () {
					sa.disabled = false;
				} );
			} );
		}
		msgLoadReminders();
	}

	function msgLoadReminders() {
		var list = document.querySelector( '[data-mlist]' );
		if ( ! list ) {
			return;
		}
		api( 'messages/reminders?date=' + MSG.date ).then( function ( d ) {
			var sent = d.items.filter( function ( r ) {
				return r.sent;
			} ).length;
			var cnt = document.querySelector( '[data-mcount]' );
			if ( cnt ) {
				cnt.textContent = d.items.length ? sent + ' di ' + d.items.length + ' inviati' : '';
			}
			if ( ! d.items.length ) {
				list.innerHTML = '<div class="bhc-card"><p class="bhc-muted" style="margin:0">Nessun appuntamento da ricordare per ' + esc( fmtDate( d.date, { weekday: 'long', day: 'numeric', month: 'long' } ) ) + '.</p></div>';
				return;
			}
			list.innerHTML = '<table class="bhc-table bhc-remtable"><thead><tr><th>Ora</th><th>Cliente</th><th>Trattamento</th><th>Messaggio</th><th>Stato</th><th></th></tr></thead><tbody>' + d.items.map( function ( r ) {
				var state = r.sent ? '<span class="bhc-pill bhc-pill--ok">' + ICONS.check + ' Inviato' + ( r.log && r.log.mode === 'auto' ? ' (auto)' : '' ) + '</span>' : ( r.log && r.log.status === 'error' ? '<span class="bhc-pill bhc-pill--warn" title="' + esc( r.log.error ) + '">Errore</span>' : '<span class="bhc-pill">Da inviare</span>' );
				return '<tr data-rem="' + r.id + '"' + ( r.sent ? ' class="is-done"' : '' ) + '><td class="nw"><b>' + esc( r.start ) + '</b></td><td>' + esc( r.client_name ) + '<br><small class="bhc-muted">' + ( r.phone ? esc( r.phone ) : '<span class="bhc-warn-txt">telefono mancante</span>' ) + '</small></td><td>' + esc( r.treatment ) + '</td>' +
					'<td><div class="bhc-wa-preview">' + esc( r.message ) + '</div></td><td>' + state + '</td>' +
					'<td class="nw">' + ( r.url ? '<a class="bhc-btn bhc-btn--sm bhc-btn--wa" href="' + esc( r.url ) + '" target="_blank" rel="noopener" data-wa="' + r.id + '">' + ICONS.whatsapp + ( r.sent ? 'Riapri' : 'Apri WhatsApp' ) + '</a>' : '' ) +
					( r.sent ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-unmark="' + r.id + '">Annulla</button>' : ( r.url ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-mark="' + r.id + '">Segna inviato</button>' : '' ) ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table>';
			function mark( id, undo ) {
				return api( 'messages/reminders/' + id + '/mark', { method: 'POST', body: { undo: undo ? 1 : 0 } } ).then( msgLoadReminders );
			}
			list.querySelectorAll( '[data-wa]' ).forEach( function ( a ) {
				a.addEventListener( 'click', function () {
					var row = a.closest( 'tr' );
					if ( ! row.classList.contains( 'is-done' ) ) {
						setTimeout( function () {
							mark( a.dataset.wa, false );
						}, 400 );
					}
				} );
			} );
			list.querySelectorAll( '[data-mark]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					mark( b.dataset.mark, false );
				} );
			} );
			list.querySelectorAll( '[data-unmark]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					mark( b.dataset.unmark, true );
				} );
			} );
		} ).catch( function ( e ) {
			list.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	/* ---------- Testo del promemoria ---------- */

	function msgSample( tpl ) {
		var ex = { '{nome}': 'Giulia', '{cognome}': 'Bianchi', '{data}': fmtDate( tomorrow(), { weekday: 'long', day: 'numeric', month: 'long' } ), '{ora}': '15:30', '{trattamento}': 'Pulizia viso profonda', '{operatrice}': 'Sara', '{cabina}': 'Cabina Viso', '{centro}': MSG.cfg.center.name, '{telefono}': MSG.cfg.center.phone || '0123 456789', '{link}': location.origin + '/gestisci-prenotazione/?bh=…' };
		return String( tpl || '' ).replace( /\{[a-z_]+\}/g, function ( k ) {
			return ex[ k ] !== undefined ? ex[ k ] : k;
		} );
	}

	function msgTemplate( box ) {
		var W = MSG.cfg.whatsapp;
		var HELP = { '{nome}': 'Nome', '{cognome}': 'Cognome', '{data}': 'Data', '{ora}': 'Ora', '{trattamento}': 'Trattamento', '{operatrice}': 'Operatrice', '{cabina}': 'Cabina', '{centro}': 'Nome centro', '{telefono}': 'Telefono centro', '{link}': 'Link per spostare/annullare' };
		var st = B.statuses;
		box.innerHTML = '<div class="bhc-msggrid"><div class="bhc-card"><h4>Messaggio base</h4>' +
			'<div class="bhc-chips-row">' + MSG.cfg.placeholders.map( function ( p ) {
				return '<button type="button" class="bhc-fchip" data-ph="' + esc( p ) + '" title="Inserisci ' + esc( HELP[ p ] || p ) + '">' + esc( HELP[ p ] || p ) + '</button>';
			} ).join( '' ) + '</div>' +
			'<textarea rows="8" data-wtpl>' + esc( W.template ) + '</textarea>' +
			'<p class="bhc-muted bhc-note">Clicca un campo per inserirlo nel punto del cursore: verrà sostituito con i dati di ogni appuntamento. Puoi usare le emoji e *grassetto* come su WhatsApp.</p>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Prefisso internazionale per i numeri senza prefisso</label><input type="text" data-wcc value="' + esc( W.country ) + '" maxlength="4" style="max-width:90px"></div>' +
			'<div class="bhc-field"><label>Promemoria per gli appuntamenti</label><div class="bhc-checks-inline">' + Object.keys( st ).filter( function ( k ) {
				return [ 'booked', 'confirmed', 'arrived' ].indexOf( k ) !== -1;
			} ).map( function ( k ) {
				return '<label class="bhc-check"><input type="checkbox" data-wst value="' + k + '"' + ( W.statuses.indexOf( k ) !== -1 ? ' checked' : '' ) + '> <span>' + esc( st[ k ] ) + '</span></label>';
			} ).join( '' ) + '</div></div></div>' +

			'<h4 style="margin-top:6px">Invio</h4><div class="bhc-seg" data-wmode><button type="button" data-m="manual">Manuale (WhatsApp / WhatsApp Web)</button><button type="button" data-m="auto">Automatico (WhatsApp Business API)</button></div>' +
			'<div data-wauto><div class="bhc-field"><label>Ora di invio dei promemoria per il giorno dopo</label><select data-whour style="max-width:120px">' + Array.from( { length: 15 }, function ( _, i ) {
				var h = i + 7;
				return '<option value="' + h + '"' + ( +W.send_hour === h ? ' selected' : '' ) + '>' + pad( h ) + ':00</option>';
			} ).join( '' ) + '</select></div>' +
			( W.last_result && W.last_result.result ? '<p class="bhc-muted bhc-note">Ultimo invio automatico: ' + esc( cardDate( W.last_result.date ) ) + ' · inviati ' + W.last_result.result.sent + ( W.last_result.result.errors ? ', errori ' + W.last_result.result.errors : '' ) + '</p>' : '' ) +
			( W.can_api ? '<div class="bhc-apibox"><h4>WhatsApp Business Cloud API <span class="bhc-pill ' + ( W.api_configured ? 'bhc-pill--ok">configurata' : 'bhc-pill--warn">da configurare' ) + '</span></h4>' +
				'<p class="bhc-muted bhc-note">Serve un account WhatsApp Business su Meta (developers.facebook.com) con un numero dedicato e un <b>modello di messaggio approvato</b> (categoria «Utility»). Nel modello usa le variabili {{1}} nome, {{2}} data, {{3}} ora, {{4}} trattamento, {{5}} nome del centro. Il testo del modello lo approva Meta: il messaggio base qui accanto vale per l\'invio manuale.</p>' +
				'<div class="bhc-row"><div class="bhc-field"><label>Token di accesso</label><input type="password" data-wtoken value="' + esc( W.api_token ) + '" autocomplete="off" placeholder="EAAG…"></div><div class="bhc-field"><label>ID numero di telefono</label><input type="text" data-wpid value="' + esc( W.phone_number_id || '' ) + '"></div></div>' +
				'<div class="bhc-row"><div class="bhc-field"><label>Nome del modello</label><input type="text" data-wtname value="' + esc( W.template_name ) + '" placeholder="promemoria_appuntamento"></div><div class="bhc-field"><label>Lingua del modello</label><input type="text" data-wtlang value="' + esc( W.template_lang ) + '" style="max-width:90px"></div></div>' +
				'<div class="bhc-op__row"><input type="tel" data-wtest placeholder="Numero per la prova"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-wtestgo>Invia prova</button></div></div>' : '<p class="bhc-muted bhc-note">Le credenziali di WhatsApp Business le imposta l\'amministratore. Stato: ' + ( W.api_configured ? 'configurato' : 'non configurato' ) + '.</p>' ) + '</div>' +
			'<p style="margin-top:12px"><button type="button" class="bhc-btn" data-wsave>Salva</button></p></div>' +

			'<div class="bhc-card bhc-phone"><div class="bhc-phone__head">' + ICONS.whatsapp + '<div><b>' + esc( MSG.cfg.center.name ) + '</b><small>Anteprima</small></div></div><div class="bhc-phone__chat"><div class="bhc-bubble" data-wprev></div></div></div></div>';

		var ta = box.querySelector( '[data-wtpl]' ), prev = box.querySelector( '[data-wprev]' );
		var mode = W.mode;
		function upd() {
			prev.innerHTML = esc( msgSample( ta.value ) ).replace( /\*([^*\n]+)\*/g, '<b>$1</b>' ).replace( /_([^_\n]+)_/g, '<i>$1</i>' ).replace( /\n/g, '<br>' ) + '<span class="bhc-bubble__time">' + pad( new Date().getHours() ) + ':' + pad( new Date().getMinutes() ) + '</span>';
			box.querySelectorAll( '[data-wmode] [data-m]' ).forEach( function ( b ) {
				b.classList.toggle( 'is-active', b.dataset.m === mode );
			} );
			box.querySelector( '[data-wauto] .bhc-field' ).hidden = mode !== 'auto';
		}
		ta.addEventListener( 'input', upd );
		box.querySelectorAll( '[data-ph]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var s = ta.selectionStart || ta.value.length, e = ta.selectionEnd || s;
				ta.value = ta.value.slice( 0, s ) + b.dataset.ph + ta.value.slice( e );
				ta.focus();
				ta.selectionStart = ta.selectionEnd = s + b.dataset.ph.length;
				upd();
			} );
		} );
		box.querySelectorAll( '[data-wmode] [data-m]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				mode = b.dataset.m;
				upd();
			} );
		} );
		var q = function ( s ) {
			var el = box.querySelector( s );
			return el ? el.value : undefined;
		};
		box.querySelector( '[data-wsave]' ).addEventListener( 'click', function () {
			var data = {
				template: ta.value, country: q( '[data-wcc]' ), mode: mode, send_hour: q( '[data-whour]' ),
				statuses: Array.prototype.map.call( box.querySelectorAll( '[data-wst]:checked' ), function ( c ) {
					return c.value;
				} )
			};
			if ( W.can_api ) {
				data.api_token = q( '[data-wtoken]' );
				data.phone_number_id = q( '[data-wpid]' );
				data.template_name = q( '[data-wtname]' );
				data.template_lang = q( '[data-wtlang]' );
			}
			msgSave( 'whatsapp', data, 'Messaggio promemoria salvato' ).then( function () {
				msgPane();
			} ).catch( function ( e ) {
				toast( e.message, true );
			} );
		} );
		var tg = box.querySelector( '[data-wtestgo]' );
		if ( tg ) {
			tg.addEventListener( 'click', function () {
				api( 'messages/test', { method: 'POST', body: { phone: q( '[data-wtest]' ) } } ).then( function () {
					toast( 'Messaggio di prova inviato' );
				} ).catch( function ( e ) {
					toast( e.message, true );
				} );
			} );
		}
		upd();
	}

	/* ---------- Scontrino: messaggio in fondo e buono sconto ---------- */

	function couponLabel( type, value ) {
		return type === 'fixed' ? euro( value ) : String( value ).replace( '.', ',' ) + '%';
	}

	function couponBlockHtml( c, text ) {
		return '<div class="bhc-coupon"><div class="bhc-coupon__head">BUONO SCONTO</div><div class="bhc-coupon__val">' + esc( c.label ) + '</div><div class="bhc-coupon__txt">' + esc( text || '' ) + '</div>' +
			'<div class="bhc-coupon__ean">' + eanSvg( c.ean, 34 ) + '</div><div class="bhc-coupon__meta">' + esc( c.code ) + ( c.expires_at ? ' · valido fino al ' + esc( cardDate( c.expires_at ) ) : '' ) + ( c.min_spend > 0 ? '<br>con una spesa minima di ' + euro( c.min_spend ) : '' ) + '</div></div>';
	}

	function msgReceipt( box ) {
		var R = MSG.cfg.receipt;
		box.innerHTML = '<div class="bhc-msggrid"><div class="bhc-card"><h4>Messaggio in fondo allo scontrino</h4><textarea rows="4" data-rfoot placeholder="Es. Grazie! Ti aspettiamo, ricordati di prenotare il prossimo trattamento.">' + esc( R.footer ) + '</textarea>' +
			'<h4 style="margin-top:14px">Buono sconto per l\'acquisto successivo</h4>' +
			'<label class="bhc-switch"><input type="checkbox" data-rk="coupon_enabled"' + ( +R.coupon_enabled ? ' checked' : '' ) + '><span></span> Attiva i buoni sconto</label>' +
			'<div data-rcoup><div class="bhc-row" style="margin-top:10px"><div class="bhc-field"><label>Sconto</label><div class="bhc-op__row"><input type="number" min="0" step="0.5" data-rk="coupon_value" value="' + esc( R.coupon_value ) + '"><select data-rk="coupon_type"><option value="percent"' + ( R.coupon_type === 'percent' ? ' selected' : '' ) + '>%</option><option value="fixed"' + ( R.coupon_type === 'fixed' ? ' selected' : '' ) + '>€</option></select></div></div>' +
			'<div class="bhc-field"><label>Valido per (giorni)</label><input type="number" min="0" step="1" data-rk="coupon_days" value="' + esc( R.coupon_days ) + '"></div></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Spesa minima per usarlo (€)</label><input type="number" min="0" step="1" data-rk="coupon_min_spend" value="' + esc( R.coupon_min_spend ) + '"></div><div class="bhc-field"><label>Testo sul buono</label><input type="text" data-rk="coupon_text" value="' + esc( R.coupon_text ) + '"></div></div>' +
			'<label class="bhc-switch"><input type="checkbox" data-rk="coupon_auto"' + ( +R.coupon_auto ? ' checked' : '' ) + '><span></span> Emetti in automatico quando la spesa supera</label> <input type="number" min="0" step="1" data-rk="coupon_threshold" value="' + esc( R.coupon_threshold ) + '" style="max-width:100px;display:inline-block"> €' +
			'<p class="bhc-muted bhc-note">In cassa puoi sempre decidere scontrino per scontrino se emettere il buono. Il buono si usa leggendo il codice a barre in cassa, una sola volta.</p></div>' +
			'<p style="margin-top:12px"><button type="button" class="bhc-btn" data-rsave>Salva</button></p></div>' +
			'<div class="bhc-card"><h4>Anteprima fondo scontrino</h4><div class="bhc-rcpt" data-rprev></div></div></div>';
		var k = function ( n ) {
			return box.querySelector( '[data-rk="' + n + '"]' );
		};
		function upd() {
			var on = k( 'coupon_enabled' ).checked;
			box.querySelector( '[data-rcoup]' ).style.opacity = on ? 1 : 0.45;
			var d = new Date();
			d.setDate( d.getDate() + ( +k( 'coupon_days' ).value || 0 ) );
			var fake = { label: couponLabel( k( 'coupon_type' ).value, +k( 'coupon_value' ).value || 0 ), ean: '2940000000014', code: 'BS26-00001', expires_at: +k( 'coupon_days' ).value ? ymd( d ) : '', min_spend: +k( 'coupon_min_spend' ).value || 0 };
			box.querySelector( '[data-rprev]' ).innerHTML = '<table class="bhc-rcpt__tot"><tr class="big"><td>TOTALE</td><td class="r">' + euro( 65 ) + '</td></tr><tr><td>Carta</td><td class="r">' + euro( 65 ) + '</td></tr></table>' +
				( on ? couponBlockHtml( fake, k( 'coupon_text' ).value ) : '' ) +
				( box.querySelector( '[data-rfoot]' ).value.trim() ? '<p class="bhc-rcpt__msg">' + esc( box.querySelector( '[data-rfoot]' ).value ).replace( /\n/g, '<br>' ) + '</p>' : '' ) +
				'<p class="bhc-rcpt__foot">Documento non fiscale</p>';
		}
		box.querySelectorAll( 'input,select,textarea' ).forEach( function ( i ) {
			i.addEventListener( 'input', upd );
			i.addEventListener( 'change', upd );
		} );
		box.querySelector( '[data-rsave]' ).addEventListener( 'click', function () {
			var data = { footer: box.querySelector( '[data-rfoot]' ).value };
			[ 'coupon_value', 'coupon_type', 'coupon_days', 'coupon_min_spend', 'coupon_text', 'coupon_threshold' ].forEach( function ( n ) {
				data[ n ] = k( n ).value;
			} );
			data.coupon_enabled = k( 'coupon_enabled' ).checked ? 1 : 0;
			data.coupon_auto = k( 'coupon_auto' ).checked ? 1 : 0;
			msgSave( 'receipt', data, 'Scontrino salvato' ).catch( function ( e ) {
				toast( e.message, true );
			} );
		} );
		upd();
	}

	function msgCoupons( box ) {
		box.innerHTML = '<div class="bhc-msgbar"><input type="search" data-cq2 placeholder="Codice, EAN o cliente…" style="max-width:260px"><select data-cst2 style="max-width:160px"><option value="">Tutti</option><option value="attivo">Attivi</option><option value="usato">Usati</option><option value="annullato">Annullati</option></select></div><div data-clist2></div>';
		function load() {
			api( 'coupons?q=' + encodeURIComponent( box.querySelector( '[data-cq2]' ).value ) + '&status=' + box.querySelector( '[data-cst2]' ).value ).then( function ( d ) {
				var l = box.querySelector( '[data-clist2]' );
				l.innerHTML = d.items.length ? '<table class="bhc-table"><thead><tr><th>Codice</th><th>Cliente</th><th>Sconto</th><th>Emesso</th><th>Scadenza</th><th>Stato</th><th></th></tr></thead><tbody>' + d.items.map( function ( c ) {
					var st = c.status === 'attivo' && c.expired ? 'scaduto' : c.status;
					return '<tr><td><b class="bhc-mono">' + esc( c.code ) + '</b><br><small class="bhc-muted bhc-mono">' + esc( c.ean ) + '</small></td><td>' + esc( c.holder || '—' ) + '</td><td>' + esc( c.label ) + ( c.min_spend > 0 ? '<br><small class="bhc-muted">min. ' + euro( c.min_spend ) + '</small>' : '' ) + '</td><td>' + esc( cardDate( c.created_at ) ) + '</td><td>' + esc( cardDate( c.expires_at ) || '—' ) + '</td>' +
						'<td><span class="bhc-pill ' + ( st === 'attivo' ? 'bhc-pill--ok' : ( st === 'usato' ? '' : 'bhc-pill--off' ) ) + '">' + esc( st ) + '</span>' + ( c.status === 'usato' ? '<br><small class="bhc-muted">−' + euro( c.used_amount ) + ' il ' + esc( cardDate( c.used_at ) ) + '</small>' : '' ) + '</td>' +
						'<td>' + ( c.status === 'attivo' ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cvoid="' + c.id + '">Annulla</button>' : ( c.status === 'annullato' ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cact="' + c.id + '">Riattiva</button>' : '' ) ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table>' : '<div class="bhc-card"><p class="bhc-muted" style="margin:0">Nessun buono sconto.</p></div>';
				l.querySelectorAll( '[data-cvoid],[data-cact]' ).forEach( function ( b ) {
					b.addEventListener( 'click', function () {
						api( 'coupons/' + ( b.dataset.cvoid || b.dataset.cact ), { method: 'PUT', body: { status: b.dataset.cvoid ? 'annullato' : 'attivo' } } ).then( load );
					} );
				} );
			} );
		}
		box.querySelector( '[data-cq2]' ).addEventListener( 'input', debounce( load, 250 ) );
		box.querySelector( '[data-cst2]' ).addEventListener( 'change', load );
		load();
	}

	/* ================= Codice fiscale: estrazione e calcolo ================= */

	var CF = { list: null, byCode: null, loading: null };
	var CF_MONTHS = 'ABCDEHLMPRST';
	var CF_ODD = { 0: 1, 1: 0, 2: 5, 3: 7, 4: 9, 5: 13, 6: 15, 7: 17, 8: 19, 9: 21, A: 1, B: 0, C: 5, D: 7, E: 9, F: 13, G: 15, H: 17, I: 19, J: 21, K: 2, L: 4, M: 18, N: 20, O: 11, P: 3, Q: 6, R: 8, S: 12, T: 14, U: 16, V: 10, W: 22, X: 25, Y: 24, Z: 23 };
	var CF_OMO = 'LMNPQRSTUV'; // cifre sostituite in caso di omocodia (0-9)

	/** Elenco comuni e stati esteri (codici catastali), caricato solo quando serve. */
	function cfLoad() {
		if ( CF.list ) {
			return Promise.resolve( CF.list );
		}
		if ( ! CF.loading ) {
			CF.loading = fetch( ( cfg.data || '' ) + 'comuni-cf.json' ).then( function ( r ) {
				return r.json();
			} ).then( function ( list ) {
				CF.list = list;
				CF.byCode = {};
				list.forEach( function ( r ) {
					// Preferisce il nome attuale del comune.
					if ( ! CF.byCode[ r[ 0 ] ] || r[ 3 ] ) {
						CF.byCode[ r[ 0 ] ] = r;
					}
				} );
				return list;
			} ).catch( function () {
				CF.loading = null;
				return [];
			} );
		}
		return CF.loading;
	}

	function cfClean( s ) {
		return String( s || '' ).normalize( 'NFD' ).replace( /[̀-ͯ]/g, '' ).toUpperCase().replace( /[^A-Z]/g, '' );
	}
	function cfPart( s, isName ) {
		s = cfClean( s );
		var cons = s.replace( /[AEIOU]/g, '' ), vow = s.replace( /[^AEIOU]/g, '' );
		if ( isName && cons.length >= 4 ) {
			return cons[ 0 ] + cons[ 2 ] + cons[ 3 ];
		}
		return ( cons + vow + 'XXX' ).substring( 0, 3 );
	}
	function cfCheckChar( s15 ) {
		var sum = 0;
		for ( var i = 0; i < 15; i++ ) {
			var ch = s15[ i ];
			sum += i % 2 === 0 ? CF_ODD[ ch ] : ( /[0-9]/.test( ch ) ? +ch : ch.charCodeAt( 0 ) - 65 );
		}
		return String.fromCharCode( 65 + sum % 26 );
	}

	/** Calcola il codice fiscale. birth = 'YYYY-MM-DD', gender = 'F' | 'M', code = codice catastale. */
	function cfCompute( last, first, birth, gender, code ) {
		var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec( birth || '' );
		if ( ! m || ! code || ( gender !== 'F' && gender !== 'M' ) || ! cfClean( last ) || ! cfClean( first ) ) {
			return '';
		}
		var day = +m[ 3 ] + ( gender === 'F' ? 40 : 0 );
		var s = cfPart( last ) + cfPart( first, true ) + m[ 1 ].substring( 2 ) + CF_MONTHS[ +m[ 2 ] - 1 ] + pad( day ) + code.toUpperCase();
		return s + cfCheckChar( s );
	}

	/** Estrae data di nascita, sesso e luogo dal codice fiscale (gestisce l'omocodia). */
	function cfParse( cf ) {
		cf = String( cf || '' ).toUpperCase().replace( /\s/g, '' );
		if ( ! /^[A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]$/.test( cf ) ) {
			return { ok: false, error: cf.length === 16 ? 'Formato non valido' : '' };
		}
		if ( cfCheckChar( cf.substring( 0, 15 ) ) !== cf[ 15 ] ) {
			return { ok: false, error: 'Carattere di controllo errato: controlla di averlo scritto bene' };
		}
		var n = cf.split( '' );
		[ 6, 7, 9, 10, 12, 13, 14 ].forEach( function ( i ) {
			var k = CF_OMO.indexOf( n[ i ] );
			if ( k !== -1 ) {
				n[ i ] = String( k );
			}
		} );
		var yy = +( n[ 6 ] + n[ 7 ] ), mm = CF_MONTHS.indexOf( n[ 8 ] ) + 1, dd = +( n[ 9 ] + n[ 10 ] );
		var gender = dd > 40 ? 'F' : 'M';
		if ( dd > 40 ) {
			dd -= 40;
		}
		var nowYY = new Date().getFullYear() % 100;
		var year = ( yy > nowYY ? 1900 : 2000 ) + yy;
		var date = new Date( Date.UTC( year, mm - 1, dd ) );
		if ( date.getUTCMonth() !== mm - 1 || dd < 1 ) {
			return { ok: false, error: 'Data di nascita non valida' };
		}
		var code = n[ 11 ] + n[ 12 ] + n[ 13 ] + n[ 14 ];
		var place = CF.byCode && CF.byCode[ code ];
		return {
			ok: true, cf: cf, gender: gender, birth_date: year + '-' + pad( mm ) + '-' + pad( dd ), code: code,
			place: place ? place[ 2 ] : '', prov: place ? place[ 1 ] : '', foreign: code[ 0 ] === 'Z',
			last3: cf.substring( 0, 3 ), first3: cf.substring( 3, 6 )
		};
	}

	function cfPlaceLabel( r ) {
		return r[ 1 ] === 'EE' ? r[ 2 ] + ' (estero)' : r[ 2 ] + ' (' + r[ 1 ] + ')';
	}

	/** Trova il codice catastale da "Roma", "Roma (RM)", "Germania (estero)". */
	function cfFindPlace( txt ) {
		if ( ! CF.list ) {
			return null;
		}
		var t = String( txt || '' ).trim().toLowerCase();
		if ( ! t ) {
			return null;
		}
		var prov = '';
		var mm = /^(.*?)\s*\(([^)]+)\)\s*$/.exec( t );
		if ( mm ) {
			t = mm[ 1 ];
			prov = mm[ 2 ] === 'estero' ? 'ee' : mm[ 2 ];
		}
		var hits = CF.list.filter( function ( r ) {
			return r[ 2 ].toLowerCase() === t && ( ! prov || r[ 1 ].toLowerCase() === prov );
		} );
		hits.sort( function ( a, b ) {
			return b[ 3 ] - a[ 3 ];
		} );
		return hits[ 0 ] || null;
	}

	/**
	 * Collega i campi di un modulo al codice fiscale.
	 * f = { cf, first, last, birth, gender, place } (selettori; gender e place facoltativi)
	 */
	function cfAttach( m, f ) {
		var q = function ( k ) {
			return f[ k ] ? m.querySelector( f[ k ] ) : null;
		};
		var cfIn = q( 'cf' );
		if ( ! cfIn ) {
			return;
		}
		cfIn.classList.add( 'bhc-mono' );
		cfIn.setAttribute( 'maxlength', '16' );
		cfIn.style.textTransform = 'uppercase';
		var wrap = document.createElement( 'div' );
		wrap.className = 'bhc-cf';
		wrap.innerHTML = '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cf-calc title="Calcola dal nome, cognome, data e luogo di nascita">Calcola</button><span class="bhc-cf__msg" data-cf-msg></span>';
		cfIn.parentNode.appendChild( wrap );
		var msg = wrap.querySelector( '[data-cf-msg]' );
		if ( ! f.first ) {
			wrap.querySelector( '[data-cf-calc]' ).remove();
		}
		var placeIn = q( 'place' );
		// Suggerimenti per il luogo di nascita.
		if ( placeIn ) {
			var dl = document.createElement( 'datalist' );
			dl.id = 'bhc-cf-places-' + Math.random().toString( 36 ).slice( 2 );
			placeIn.setAttribute( 'list', dl.id );
			placeIn.setAttribute( 'autocomplete', 'off' );
			placeIn.parentNode.appendChild( dl );
			placeIn.addEventListener( 'input', function () {
				var t = placeIn.value.trim().toLowerCase();
				if ( t.length < 2 || ! CF.list ) {
					dl.innerHTML = '';
					return;
				}
				var seen = {};
				dl.innerHTML = CF.list.filter( function ( r ) {
					return r[ 2 ].toLowerCase().indexOf( t ) === 0;
				} ).sort( function ( a, b ) {
					return b[ 3 ] - a[ 3 ] || a[ 2 ].localeCompare( b[ 2 ] );
				} ).filter( function ( r ) {
					var k = cfPlaceLabel( r );
					if ( seen[ k ] ) {
						return false;
					}
					seen[ k ] = 1;
					return true;
				} ).slice( 0, 15 ).map( function ( r ) {
					return '<option value="' + esc( cfPlaceLabel( r ) ) + '">';
				} ).join( '' );
			} );
		}
		function show( text, cls ) {
			msg.className = 'bhc-cf__msg' + ( cls ? ' ' + cls : '' );
			msg.innerHTML = text;
		}
		function setVal( el, v ) {
			if ( el && v && el.value !== v ) {
				el.value = v;
				el.classList.add( 'bhc-cf-filled' );
				setTimeout( function () {
					el.classList.remove( 'bhc-cf-filled' );
				}, 1500 );
				return true;
			}
			return false;
		}
		function check( fill ) {
			var v = cfIn.value.toUpperCase().replace( /\s/g, '' );
			if ( cfIn.value !== v ) {
				cfIn.value = v;
			}
			var cb = wrap.querySelector( '[data-cf-calc]' );
			if ( cb ) {
				cb.hidden = v.length > 0 && v.length < 16;
			}
			if ( ! v ) {
				show( '' );
				return;
			}
			if ( v.length < 16 ) {
				show( v.length + '/16', 'is-muted' );
				return;
			}
			if ( /^\d{11}$/.test( v ) ) {
				show( 'Codice fiscale numerico (azienda)', 'is-muted' );
				return;
			}
			var r = cfParse( v );
			if ( ! r.ok ) {
				show( '✕ ' + esc( r.error || 'Codice fiscale non valido' ), 'is-err' );
				return;
			}
			var filled = [];
			if ( fill ) {
				if ( setVal( q( 'birth' ), r.birth_date ) ) {
					filled.push( 'data di nascita' );
				}
				var g = q( 'gender' );
				if ( g && g.value !== r.gender ) {
					g.value = r.gender;
					filled.push( 'sesso' );
				}
				if ( r.place && setVal( placeIn, r.foreign ? r.place + ' (estero)' : r.place + ' (' + r.prov + ')' ) ) {
					filled.push( 'luogo di nascita' );
				}
			}
			// Coerenza con nome e cognome.
			var warn = '';
			var fn = q( 'first' ), ln = q( 'last' );
			if ( ln && cfClean( ln.value ) && cfPart( ln.value ) !== r.last3 ) {
				warn = ' · <b>il cognome non corrisponde</b>';
			} else if ( fn && cfClean( fn.value ) && cfPart( fn.value, true ) !== r.first3 ) {
				warn = ' · <b>il nome non corrisponde</b>';
			}
			show( '✓ ' + ( r.gender === 'F' ? 'Nata' : 'Nato' ) + ' il ' + esc( r.birth_date.split( '-' ).reverse().join( '/' ) ) + ( r.place ? ' a ' + esc( r.foreign ? r.place + ' (estero)' : r.place + ' (' + r.prov + ')' ) : ' · codice luogo ' + esc( r.code ) ) + warn + ( filled.length ? ' <span class="bhc-cf__done">· compilati: ' + filled.join( ', ' ) + '</span>' : '' ), warn ? 'is-warn' : 'is-ok' );
		}
		cfIn.addEventListener( 'input', function () {
			cfLoad().then( function () {
				check( true );
			} );
		} );
		[ 'first', 'last' ].forEach( function ( k ) {
			var el = q( k );
			if ( el ) {
				el.addEventListener( 'change', function () {
					if ( cfIn.value.length === 16 ) {
						check( false );
					}
				} );
			}
		} );
		var calcBtn = wrap.querySelector( '[data-cf-calc]' );
		if ( calcBtn ) calcBtn.addEventListener( 'click', function () {
			cfLoad().then( function () {
				var g = q( 'gender' ), b = q( 'birth' ), fn = q( 'first' ), ln = q( 'last' );
				var miss = [];
				if ( ! ln || ! cfClean( ln.value ) ) {
					miss.push( 'cognome' );
				}
				if ( ! fn || ! cfClean( fn.value ) ) {
					miss.push( 'nome' );
				}
				if ( ! b || ! b.value ) {
					miss.push( 'data di nascita' );
				}
				if ( ! g || ( g.value !== 'F' && g.value !== 'M' ) ) {
					miss.push( 'sesso (F o M)' );
				}
				var pl = placeIn ? cfFindPlace( placeIn.value ) : null;
				if ( ! pl ) {
					miss.push( placeIn && placeIn.value ? 'luogo di nascita riconosciuto (scegli dall\'elenco)' : 'luogo di nascita' );
				}
				if ( miss.length ) {
					show( 'Per calcolarlo servono: ' + esc( miss.join( ', ' ) ), 'is-warn' );
					return;
				}
				var code = cfCompute( ln.value, fn.value, b.value, g.value, pl[ 0 ] );
				cfIn.value = code;
				check( false );
				show( '✓ Calcolato: ' + esc( code ) + ' <span class="bhc-muted">(in caso di omocodia il codice reale può differire: verifica con la tessera sanitaria)</span>', 'is-ok' );
			} );
		} );
		if ( cfIn.value ) {
			cfLoad().then( function () {
				check( false );
			} );
		} else {
			cfLoad();
		}
	}

	/* ================= Schede cliente (anamnesi, massaggi, laser) ================= */

	var FORMS = { tpl: null, loading: null };

	function formsLoad() {
		if ( FORMS.tpl ) {
			return Promise.resolve( FORMS.tpl );
		}
		if ( ! FORMS.loading ) {
			FORMS.loading = api( 'forms/templates' ).then( function ( t ) {
				FORMS.tpl = t;
				return t;
			} );
		}
		return FORMS.loading;
	}

	/* ---------- Sagome per le mappe ---------- */

	var SIL = {
		face_f: { vb: '0 0 100 125', d: '<ellipse cx="50" cy="50" rx="27" ry="35"/><path d="M23 46q-7 1-5 10q2 7 7 6M77 46q7 1 5 10q-2 7-7 6"/><path d="M37 81q1 12-1 23M63 81q-1 12 1 23"/><path d="M36 104q-18 4-30 16M64 104q18 4 30 16"/><path d="M33 42q6-3 12-1M55 41q6-2 12 1"/><path d="M34 48q5-3 10 0M56 48q5-3 10 0"/><path d="M50 50l-3 13q3 2 6 0"/><path d="M42 72q8 4 16 0"/>' },
		face_r: { vb: '0 0 100 125', d: '<path d="M38 15c22-5 38 10 38 28l4 11-4 2 2 6-3 2 2 6q-3 6-11 7l-4 9-1 18q14 4 30 16"/><path d="M38 15c-18 4-22 28-16 46 4 10 10 18 12 26l1 17q-14 4-28 16"/><ellipse cx="45" cy="54" rx="5" ry="8"/><path d="M63 44q5-2 8 1"/><path d="M68 70q4 1 6-1"/>' },
		body_f: { vb: '0 0 100 210', d: '<circle cx="50" cy="15" r="10"/><path d="M45 25v5q-12 2-16 7l-6 36-4 32h4l6-30 4-22 1 48 3 40 1 56h8l3-56 1-28 1 28 3 56h8l1-56 3-40 1-48 4 22 6 30h4l-4-32-6-36q-4-5-16-7v-5"/><path d="M42 50q8 4 16 0M50 92v14"/>' },
		body_b: { vb: '0 0 100 210', d: '<circle cx="50" cy="15" r="10"/><path d="M45 25v5q-12 2-16 7l-6 36-4 32h4l6-30 4-22 1 48 3 40 1 56h8l3-56 1-28 1 28 3 56h8l1-56 3-40 1-48 4 22 6 30h4l-4-32-6-36q-4-5-16-7v-5"/><path d="M50 32v62M38 44q4 6 2 12M62 44q-4 6-2 12M40 100q10 6 20 0"/>' },
		body_s: { vb: '0 0 100 210', d: '<circle cx="50" cy="15" r="10"/><path d="M47 25v5q-7 3-7 10l2 30 2 30q-1 20 2 40l-2 56h11l1-56 2-38q4-14 0-30 4-14 2-32-1-7-7-10v-5"/><path d="M50 40l2 32 2 32"/>' }
	};
	SIL.face_l = { vb: SIL.face_r.vb, d: '<g transform="translate(100 0) scale(-1 1)">' + SIL.face_r.d + '</g>' };

	function mapSvg( view, marks, cls ) {
		var s = SIL[ view ];
		var vb = s.vb.split( ' ' ).map( Number );
		var mk = ( marks || [] ).filter( function ( m ) {
			return m.v === view;
		} ).map( function ( m, i ) {
			var x = m.x * vb[ 2 ] / 100, y = m.y * vb[ 3 ] / 100;
			return m.n === 'X'
				? '<g class="bhc-mk bhc-mk--x" data-mi="' + i + '"><circle cx="' + x + '" cy="' + y + '" r="4.2"/><path d="M' + ( x - 2.2 ) + ' ' + ( y - 2.2 ) + 'l4.4 4.4m0-4.4l-4.4 4.4"/></g>'
				: '<g class="bhc-mk" data-mi="' + i + '"><circle cx="' + x + '" cy="' + y + '" r="4.2"/><text x="' + x + '" y="' + ( y + 2 ) + '" text-anchor="middle">' + esc( m.n ) + '</text></g>';
		} ).join( '' );
		return '<svg class="' + ( cls || 'bhc-sil' ) + '" viewBox="' + s.vb + '" xmlns="http://www.w3.org/2000/svg" data-view="' + view + '"><g class="bhc-sil__line" fill="none" stroke="#6b6860" stroke-width=".8" stroke-linecap="round" stroke-linejoin="round">' + s.d + '</g>' + mk + '</svg>';
	}

	/* ---------- Campi ---------- */

	function fVal( data, id ) {
		return data && data[ id ] !== undefined ? data[ id ] : '';
	}

	function gridRows( f, v ) {
		var rows = Array.isArray( v ) ? v.slice() : [];
		var min = Array.isArray( f.rows ) ? f.rows.length : ( f.rows || 3 );
		while ( rows.length < min ) {
			rows.push( [] );
		}
		if ( f.grow && rows.length && rows[ rows.length - 1 ].join( '' ) !== '' ) {
			rows.push( [] );
		}
		return rows;
	}

	function fieldHtml( f, v, ro ) {
		var dis = ro ? ' disabled' : '';
		var lab = f.label ? '<label>' + esc( f.label ) + '</label>' : '';
		var w = 'bhc-ff bhc-ff--' + ( f.w || ( [ 'checks', 'grid', 'measures', 'map', 'yesno' ].indexOf( f.type ) !== -1 ? 'full' : 'half' ) );
		var h = '';
		switch ( f.type ) {
			case 'textarea':
				h = lab + '<textarea rows="3" data-ff="' + f.id + '"' + dis + '>' + esc( v ) + '</textarea>';
				break;
			case 'number':
				h = lab + '<input type="number" step="0.1" data-ff="' + f.id + '" value="' + esc( v ) + '"' + dis + '>';
				break;
			case 'radio':
				h = lab + '<div class="bhc-ff__opts" data-ff="' + f.id + '" data-kind="radio">' + f.options.map( function ( o ) {
					return '<button type="button" class="bhc-chipbtn' + ( v === o ? ' is-on' : '' ) + '" data-o="' + esc( o ) + '"' + dis + '>' + esc( o ) + '</button>';
				} ).join( '' ) + '</div>';
				break;
			case 'checks':
				var arr = Array.isArray( v ) ? v : [];
				h = lab + '<div class="bhc-ff__checks" style="--cols:' + ( f.cols || 3 ) + '" data-ff="' + f.id + '" data-kind="checks">' + f.options.map( function ( o ) {
					return '<label class="bhc-check"><input type="checkbox" value="' + esc( o ) + '"' + ( arr.indexOf( o ) !== -1 ? ' checked' : '' ) + dis + '> <span>' + esc( o ) + '</span></label>';
				} ).join( '' ) + '</div>';
				break;
			case 'yesno':
				var yv = v || {};
				h = '<div class="bhc-yn" data-ff="' + f.id + '" data-kind="yesno"><span class="bhc-yn__q">' + esc( f.label ) + '</span><span class="bhc-yn__btns"><button type="button" class="bhc-chipbtn' + ( yv.v === 'si' ? ' is-on is-yes' : '' ) + '" data-o="si"' + dis + '>Sì</button><button type="button" class="bhc-chipbtn' + ( yv.v === 'no' ? ' is-on' : '' ) + '" data-o="no"' + dis + '>No</button></span>' +
					'<input type="text" placeholder="' + esc( f.detail || 'Dettagli' ) + '" value="' + esc( yv.d || '' ) + '"' + dis + '></div>';
				break;
			case 'scale':
				h = lab + '<div class="bhc-ff__opts" data-ff="' + f.id + '" data-kind="radio">' + Array.from( { length: f.max - f.min + 1 }, function ( _, i ) {
					var n = String( f.min + i );
					return '<button type="button" class="bhc-chipbtn bhc-chipbtn--n' + ( String( v ) === n ? ' is-on' : '' ) + '" data-o="' + n + '"' + dis + '>' + n + '</button>';
				} ).join( '' ) + '</div>' + ( f.hint ? '<small class="bhc-muted">' + esc( f.hint ) + '</small>' : '' );
				break;
			case 'grid':
				var rows = gridRows( f, v );
				h = lab + '<div class="bhc-gridwrap"><table class="bhc-fgrid" data-ff="' + f.id + '" data-kind="grid"><thead><tr>' + ( f.numbered ? '<th class="n">N.</th>' : '' ) + f.columns.map( function ( c ) {
					return '<th>' + esc( c ) + '</th>';
				} ).join( '' ) + '</tr></thead><tbody>' + rows.map( function ( r, i ) {
					return '<tr>' + ( f.numbered ? '<td class="n">' + ( i + 1 ) + '</td>' : '' ) + f.columns.map( function ( c, j ) {
						var cell = r[ j ] !== undefined ? r[ j ] : ( j === 0 && Array.isArray( f.rows ) && f.rows[ i ] ? f.rows[ i ] : '' );
						if ( f.check === j ) {
							return '<td class="c"><input type="checkbox"' + ( cell ? ' checked' : '' ) + dis + '></td>';
						}
						return '<td><input type="text" value="' + esc( cell ) + '"' + dis + '></td>';
					} ).join( '' ) + '</tr>';
				} ).join( '' ) + '</tbody></table></div>' + ( f.grow && ! ro ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-addrow="' + f.id + '">+ Riga</button>' : '' );
				break;
			case 'measures':
				var mv = v || {}, dates = mv.dates || [], cells = mv.cells || [];
				h = lab + '<div class="bhc-gridwrap"><table class="bhc-fgrid bhc-fgrid--m" data-ff="' + f.id + '" data-kind="measures"><thead><tr><th>Misura</th><th>Rif. cm*</th>' + Array.from( { length: f.dates }, function ( _, i ) {
					return '<th><input type="date" value="' + esc( dates[ i ] || '' ) + '"' + dis + ' aria-label="Data controllo ' + ( i + 1 ) + '"></th>';
				} ).join( '' ) + '</tr></thead><tbody>' + f.rows.map( function ( r, i ) {
					var row = cells[ i ] || [];
					return '<tr><th>' + esc( r ) + '</th>' + Array.from( { length: f.dates + 1 }, function ( _, j ) {
						return '<td><input type="text" inputmode="decimal" value="' + esc( row[ j ] || '' ) + '"' + dis + '></td>';
					} ).join( '' ) + '</tr>';
				} ).join( '' ) + '</tbody></table></div>' + ( f.note ? '<small class="bhc-muted">' + esc( f.note ) + '</small>' : '' );
				break;
			case 'map':
				var marks = Array.isArray( v ) ? v : [];
				h = '<p class="bhc-muted bhc-map__help">' + esc( f.label ) + '</p>' + ( ro ? '' : '<div class="bhc-map__tools" data-maptools="' + f.id + '">Segna: ' + [ '1', '2', '3', '4', '5', '6', 'X' ].map( function ( n, i ) {
					return '<button type="button" class="bhc-chipbtn bhc-chipbtn--n' + ( i === 0 ? ' is-on' : '' ) + ( n === 'X' ? ' is-x' : '' ) + '" data-mn="' + n + '" title="' + ( n === 'X' ? 'Zona da evitare' : 'Zona ' + n ) + '">' + ( n === 'X' ? '✕ evita' : n ) + '</button>';
				} ).join( '' ) + '<span class="bhc-muted">Tocca la sagoma per aggiungere, tocca un segno per toglierlo.</span></div>' ) +
					'<div class="bhc-map" data-ff="' + f.id + '" data-kind="map" data-marks="' + esc( JSON.stringify( marks ) ) + '">' + Object.keys( f.views ).map( function ( k ) {
						return '<figure>' + mapSvg( k, marks ) + '<figcaption>' + esc( f.views[ k ] ) + '</figcaption></figure>';
					} ).join( '' ) + '</div>';
				break;
			case 'consent':
				h = '<label class="bhc-check"><input type="checkbox" data-ff="' + f.id + '"' + ( v ? ' checked' : '' ) + dis + '> <span>' + esc( f.label ) + '</span></label>';
				break;
			case 'info':
				h = '<p class="bhc-muted bhc-note">' + esc( f.label ) + '</p>';
				break;
			case 'sign':
				w = 'bhc-ff bhc-ff--full';
				h = lab + '<div class="bhc-fsig" data-ff="' + f.id + '" data-kind="sign" data-val="' + esc( v || '' ) + '">' + ( v ? '<img src="' + esc( v ) + '" alt="Firma">' + ( ro ? '' : '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-sig-redo>Rifai la firma</button>' ) : ( ro ? '<span class="bhc-muted">Non firmata</span>' : '<canvas></canvas><span class="bhc-fsig__hint">Firma qui</span><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-sig-clear>Cancella</button>' ) ) + '</div>';
				break;
			default:
				var it = { date: 'date', email: 'email', tel: 'tel', number: 'number' }[ f.type ] || 'text';
				h = lab + '<input type="' + it + '" data-ff="' + f.id + '" value="' + esc( v ) + '"' + dis + '>';
		}
		return '<div class="' + w + '">' + h + '</div>';
	}

	function fieldRead( box, f ) {
		var el = box.querySelector( '[data-ff="' + f.id + '"]' );
		if ( ! el ) {
			return undefined;
		}
		switch ( f.type ) {
			case 'radio':
			case 'scale':
				var on = el.querySelector( '.is-on' );
				return on ? on.dataset.o : '';
			case 'checks':
				return Array.prototype.map.call( el.querySelectorAll( 'input:checked' ), function ( i ) {
					return i.value;
				} );
			case 'yesno':
				var y = el.querySelector( '.is-on' );
				return { v: y ? y.dataset.o : '', d: el.querySelector( 'input' ).value };
			case 'grid':
				return Array.prototype.map.call( el.querySelectorAll( 'tbody tr' ), function ( tr ) {
					return Array.prototype.map.call( tr.querySelectorAll( 'input' ), function ( i ) {
						return i.type === 'checkbox' ? ( i.checked ? '✓' : '' ) : i.value;
					} );
				} );
			case 'measures':
				return {
					dates: Array.prototype.map.call( el.querySelectorAll( 'thead input' ), function ( i ) {
						return i.value;
					} ),
					cells: Array.prototype.map.call( el.querySelectorAll( 'tbody tr' ), function ( tr ) {
						return Array.prototype.map.call( tr.querySelectorAll( 'input' ), function ( i ) {
							return i.value;
						} );
					} )
				};
			case 'map':
				return JSON.parse( el.dataset.marks || '[]' );
			default:
				if ( f.type === 'consent' ) {
					return el.checked ? 1 : 0;
				}
				if ( f.type === 'info' ) {
					return undefined;
				}
				if ( f.type === 'sign' ) {
					return el._pad && ! el._pad.empty() ? el._pad.data() : ( el.dataset.val || '' );
				}
				return el.value;
		}
	}

	/** Comportamenti interattivi dei campi (pulsanti, righe, mappe). */
	function bindFields( box, tpl ) {
		box.querySelectorAll( '[data-kind="radio"]' ).forEach( function ( g ) {
			g.addEventListener( 'click', function ( e ) {
				var b = e.target.closest( '[data-o]' );
				if ( ! b || b.disabled ) {
					return;
				}
				var was = b.classList.contains( 'is-on' );
				g.querySelectorAll( '[data-o]' ).forEach( function ( x ) {
					x.classList.remove( 'is-on' );
				} );
				if ( ! was ) {
					b.classList.add( 'is-on' );
				}
			} );
		} );
		box.querySelectorAll( '[data-kind="yesno"]' ).forEach( function ( g ) {
			g.addEventListener( 'click', function ( e ) {
				var b = e.target.closest( '[data-o]' );
				if ( ! b || b.disabled ) {
					return;
				}
				var was = b.classList.contains( 'is-on' );
				g.querySelectorAll( '[data-o]' ).forEach( function ( x ) {
					x.classList.remove( 'is-on', 'is-yes' );
				} );
				if ( ! was ) {
					b.classList.add( 'is-on' );
					if ( b.dataset.o === 'si' ) {
						b.classList.add( 'is-yes' );
						g.querySelector( 'input' ).focus();
					}
				}
			} );
		} );
		// Righe dei registri: data e operatrice compilate da sole alla prima scrittura.
		var allF = [];
		tpl.pages.forEach( function ( p ) {
			p.sections.forEach( function ( s ) {
				allF = allF.concat( s.fields );
			} );
		} );
		box.querySelectorAll( '[data-kind="grid"]' ).forEach( function ( t ) {
			var f = allF.filter( function ( x ) {
				return x.id === t.dataset.ff;
			} )[ 0 ];
			if ( ! f || ! f.auto ) {
				return;
			}
			t.addEventListener( 'focusin', function ( e ) {
				var tr = e.target.closest( 'tr' );
				if ( ! tr || ! tr.parentNode.matches( 'tbody' ) ) {
					return;
				}
				var ins = tr.querySelectorAll( 'input[type=text]' );
				var empty = Array.prototype.every.call( ins, function ( i ) {
					return ! i.value;
				} );
				if ( empty ) {
					if ( f.auto.indexOf( 'date' ) !== -1 && ins[ 0 ] && e.target !== ins[ 0 ] ) {
						ins[ 0 ].value = new Date().toLocaleDateString( 'it-IT' );
					}
					if ( f.auto.indexOf( 'user' ) !== -1 && ins[ 1 ] && e.target !== ins[ 1 ] ) {
						ins[ 1 ].value = B.me.name;
					}
				}
			} );
		} );
		box.querySelectorAll( '[data-addrow]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var t = box.querySelector( '[data-ff="' + b.dataset.addrow + '"] tbody' );
				var last = t.lastElementChild;
				var tr = last.cloneNode( true );
				tr.querySelectorAll( 'input' ).forEach( function ( i ) {
					i.value = '';
					i.checked = false;
				} );
				var n = tr.querySelector( '.n' );
				if ( n ) {
					n.textContent = t.children.length + 1;
				}
				t.appendChild( tr );
				tr.querySelector( 'input' ).focus();
			} );
		} );
		box.querySelectorAll( '[data-kind="sign"]' ).forEach( function ( sg ) {
			function mk() {
				var cv = sg.querySelector( 'canvas' );
				if ( ! cv ) {
					return;
				}
				sg._pad = signaturePad( cv );
				var cl = sg.querySelector( '[data-sig-clear]' );
				if ( cl ) {
					cl.addEventListener( 'click', function () {
						sg._pad.clear();
					} );
				}
			}
			var redo = sg.querySelector( '[data-sig-redo]' );
			if ( redo ) {
				redo.addEventListener( 'click', function () {
					sg.dataset.val = '';
					sg.innerHTML = '<canvas></canvas><span class="bhc-fsig__hint">Firma qui</span><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-sig-clear>Cancella</button>';
					mk();
				} );
			}
			// Il pannello si prepara quando la pagina è visibile (le misure servono al disegno).
			if ( sg.offsetParent ) {
				mk();
			} else {
				sg._init = mk;
			}
		} );
		box.querySelectorAll( '[data-kind="map"]' ).forEach( function ( mp ) {
			var tools = box.querySelector( '[data-maptools="' + mp.dataset.ff + '"]' );
			if ( ! tools ) {
				return;
			}
			var cur = '1';
			tools.addEventListener( 'click', function ( e ) {
				var b = e.target.closest( '[data-mn]' );
				if ( ! b ) {
					return;
				}
				cur = b.dataset.mn;
				tools.querySelectorAll( '[data-mn]' ).forEach( function ( x ) {
					x.classList.toggle( 'is-on', x === b );
				} );
			} );
			function redraw( marks ) {
				mp.dataset.marks = JSON.stringify( marks );
				mp.querySelectorAll( 'svg' ).forEach( function ( svg ) {
					svg.outerHTML = mapSvg( svg.dataset.view, marks );
				} );
			}
			mp.addEventListener( 'click', function ( e ) {
				var svg = e.target.closest( 'svg' );
				if ( ! svg ) {
					return;
				}
				var marks = JSON.parse( mp.dataset.marks || '[]' );
				var g = e.target.closest( '.bhc-mk' );
				if ( g ) {
					var mine = marks.filter( function ( m ) {
						return m.v === svg.dataset.view;
					} );
					var rm = mine[ +g.dataset.mi ];
					redraw( marks.filter( function ( m ) {
						return m !== rm;
					} ) );
					return;
				}
				var r = svg.getBoundingClientRect();
				marks.push( { v: svg.dataset.view, x: Math.round( ( e.clientX - r.left ) / r.width * 1000 ) / 10, y: Math.round( ( e.clientY - r.top ) / r.height * 1000 ) / 10, n: cur } );
				redraw( marks );
			} );
		} );
	}

	/** Pannello della firma (dito, penna o mouse). */
	function signaturePad( canvas ) {
		var ctx = canvas.getContext( '2d' ), drawing = false, dirty = false, last = null;
		function size() {
			var r = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
			canvas.width = r.width * dpr;
			canvas.height = r.height * dpr;
			ctx.scale( dpr, dpr );
			ctx.lineWidth = 2.2;
			ctx.lineCap = 'round';
			ctx.lineJoin = 'round';
			ctx.strokeStyle = '#1f2a44';
		}
		size();
		function pos( e ) {
			var r = canvas.getBoundingClientRect();
			return { x: e.clientX - r.left, y: e.clientY - r.top };
		}
		canvas.addEventListener( 'pointerdown', function ( e ) {
			drawing = true;
			dirty = true;
			last = pos( e );
			canvas.setPointerCapture( e.pointerId );
			ctx.beginPath();
			ctx.arc( last.x, last.y, 0.6, 0, Math.PI * 2 );
			ctx.stroke();
		} );
		canvas.addEventListener( 'pointermove', function ( e ) {
			if ( ! drawing ) {
				return;
			}
			var p = pos( e );
			ctx.beginPath();
			ctx.moveTo( last.x, last.y );
			ctx.lineTo( p.x, p.y );
			ctx.stroke();
			last = p;
		} );
		[ 'pointerup', 'pointercancel', 'pointerleave' ].forEach( function ( ev ) {
			canvas.addEventListener( ev, function () {
				drawing = false;
			} );
		} );
		return {
			clear: function () {
				ctx.clearRect( 0, 0, canvas.width, canvas.height );
				dirty = false;
			},
			empty: function () {
				return ! dirty;
			},
			data: function () {
				return canvas.toDataURL( 'image/png' );
			}
		};
	}

	/* ---------- Scheda cliente › Schede ---------- */

	function clientFormsPane( m, c ) {
		var box = m.querySelector( '[data-client-forms]' );
		if ( ! box ) {
			return;
		}
		Promise.all( [ formsLoad(), api( 'clients/' + c.id + '/forms' ) ] ).then( function ( r ) {
			var T = r[ 0 ], list = r[ 1 ].items;
			var tab = m.querySelector( '[data-tab="schede"]' );
			if ( tab ) {
				tab.textContent = 'Schede (' + list.length + ')';
			}
			box.innerHTML = '<div class="bhc-formnew">' + Object.keys( T ).map( function ( k ) {
				var last = list.filter( function ( f ) {
					return f.type === k;
				} )[ 0 ];
				return '<div class="bhc-formcard" style="--fc:' + esc( T[ k ].color ) + '"><strong>' + esc( T[ k ].title.replace( /^Scheda (cliente )?/i, '' ) ) + '</strong>' +
					'<small class="bhc-muted">' + ( last ? ( last.signed ? 'Firmata il ' + esc( cardDate( last.signed_at ) ) : 'Bozza del ' + esc( cardDate( last.updated_at ) ) ) + ( last.expired ? ' · <span class="bhc-warn-txt">da aggiornare</span>' : '' ) : 'Mai compilata' ) + '</small>' +
					'<div class="bhc-formcard__act">' + ( last ? '<button type="button" class="bhc-btn bhc-btn--sm" data-fopen="' + last.id + '">Apri</button>' : '<button type="button" class="bhc-btn bhc-btn--sm" data-fnew="' + k + '">Compila</button>' ) +
					'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-ftab="' + k + '" title="La cliente compila e firma sul tablet">Tablet</button>' +
					'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-fblank="' + k + '" title="Stampa da compilare a penna">' + ICONS.print + '</button></div></div>';
			} ).join( '' ) + '</div>' +
				( list.length ? '<h4 style="margin:14px 0 6px">Storico</h4><table class="bhc-table"><thead><tr><th>Scheda</th><th>Codice</th><th>Stato</th><th>Aggiornata</th><th>Da</th><th></th></tr></thead><tbody>' + list.map( function ( f ) {
					return '<tr class="is-click" data-fopen="' + f.id + '"><td>' + esc( f.title ) + '</td><td class="bhc-mono">' + esc( f.code ) + '</td><td>' + ( f.signed ? '<span class="bhc-pill bhc-pill--ok">Firmata ' + esc( cardDate( f.signed_at ) ) + '</span>' : '<span class="bhc-pill">Bozza</span>' ) + ( f.source === 'tablet' ? ' <span class="bhc-pill">tablet</span>' : '' ) + '</td><td>' + esc( cardDate( f.updated_at ) ) + '</td><td>' + esc( f.user ) + '</td><td><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-fprint="' + f.id + '">' + ICONS.print + '</button></td></tr>';
				} ).join( '' ) + '</tbody></table>' : '' );
			box.querySelectorAll( '[data-fnew]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					formEditor( c, b.dataset.fnew, null );
				} );
			} );
			box.querySelectorAll( '[data-fopen]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function ( e ) {
					if ( e.target.closest( '[data-fprint]' ) ) {
						return;
					}
					api( 'forms/' + b.dataset.fopen ).then( function ( f ) {
						formEditor( c, f.type, f );
					} );
				} );
			} );
			box.querySelectorAll( '[data-fprint]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					api( 'forms/' + b.dataset.fprint ).then( function ( f ) {
						printForm( c, f.type, f );
					} );
				} );
			} );
			box.querySelectorAll( '[data-fblank]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					printForm( c, b.dataset.fblank, null );
				} );
			} );
			box.querySelectorAll( '[data-ftab]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					var k = b.dataset.ftab;
					var last = list.filter( function ( f ) {
						return f.type === k && ! f.signed;
					} )[ 0 ];
					( last ? api( 'forms/' + last.id ) : Promise.resolve( null ) ).then( function ( f ) {
						formKiosk( c, k, f );
					} );
				} );
			} );
		} ).catch( function ( e ) {
			box.innerHTML = '<p class="bhc-msg is-error">' + esc( e.message ) + '</p>';
		} );
	}

	function clientHeaderRows( c, keys ) {
		var L = { name: [ 'Cognome e nome', ( c.last_name + ' ' + c.first_name ).trim() ], last_name: [ 'Cognome', c.last_name ], first_name: [ 'Nome', c.first_name ], birth_date: [ 'Data di nascita', cardDate( c.birth_date ) ], birth: [ 'Luogo e data di nascita', [ c.birth_place, cardDate( c.birth_date ) ].filter( Boolean ).join( ', ' ) ], phone: [ 'Telefono', c.phone ], email: [ 'Email', c.email ], address: [ 'Indirizzo', c.address ] };
		return keys.map( function ( k ) {
			return L[ k ];
		} ).filter( Boolean );
	}

	/* ---------- Voce di menu «Schede anamnesi» ---------- */

	function renderFormsView() {
		var main = document.getElementById( 'bhc-main' );
		main.innerHTML = '<div class="bhc-top"><h2>Schede anamnesi</h2></div>' +
			'<div class="bhc-card"><div class="bhc-field" style="margin:0"><label>Cerca la cliente</label><input type="search" data-fv-q placeholder="Nome, cognome o telefono…" autocomplete="off" style="max-width:420px"><div data-fv-res></div></div>' +
			'<div data-client-forms style="margin-top:12px"></div></div>' +
			'<h4 style="margin:18px 0 8px">Ultime schede compilate</h4><div data-fv-recent><div class="bhc-loading">Caricamento…</div></div>';
		var q = main.querySelector( '[data-fv-q]' ), res = main.querySelector( '[data-fv-res]' ), holder = main.querySelector( '.bhc-card' );
		function pick( id ) {
			api( 'clients/' + id ).then( function ( d ) {
				var c = d.client;
				q.value = c.first_name + ' ' + c.last_name;
				res.innerHTML = '';
				holder.querySelector( '[data-client-forms]' ).innerHTML = '<p style="margin:0 0 8px"><b>' + esc( c.first_name + ' ' + c.last_name ) + '</b> <span class="bhc-muted">' + esc( [ c.phone, c.email ].filter( Boolean ).join( ' · ' ) ) + '</span> · <a href="#" data-fv-open>scheda cliente</a></p><div data-client-forms-inner></div>';
				var inner = holder.querySelector( '[data-client-forms-inner]' );
				inner.setAttribute( 'data-client-forms', '' );
				clientFormsPane( { querySelector: function ( s ) {
					return s === '[data-client-forms]' ? inner : null;
				} }, c );
				holder.querySelector( '[data-fv-open]' ).addEventListener( 'click', function ( e ) {
					e.preventDefault();
					openClient( c.id, 'schede' );
				} );
			} );
		}
		q.addEventListener( 'input', debounce( function () {
			var t = q.value.trim();
			if ( t.length < 2 ) {
				res.innerHTML = '';
				return;
			}
			api( 'clients?q=' + encodeURIComponent( t ) ).then( function ( d ) {
				res.innerHTML = d.items.length ? '<div class="bhc-search-results" style="max-width:420px">' + d.items.slice( 0, 8 ).map( function ( c ) {
					return '<button type="button" data-fv-c="' + c.id + '">' + esc( c.first_name + ' ' + c.last_name ) + ' <span class="bhc-muted">' + esc( c.phone || c.email ) + '</span></button>';
				} ).join( '' ) + '</div>' : '<p class="bhc-muted">Nessuna cliente trovata.</p>';
				res.querySelectorAll( '[data-fv-c]' ).forEach( function ( b ) {
					b.addEventListener( 'click', function () {
						pick( +b.dataset.fvC );
					} );
				} );
			} );
		}, 250 ) );
		api( 'forms/recent' ).then( function ( d ) {
			var box = main.querySelector( '[data-fv-recent]' );
			box.innerHTML = d.items.length ? '<table class="bhc-table"><thead><tr><th>Cliente</th><th>Scheda</th><th>Codice</th><th>Stato</th><th>Aggiornata</th></tr></thead><tbody>' + d.items.map( function ( f ) {
				return '<tr class="is-click" data-fv-f="' + f.id + '" data-fv-cid="' + f.client_id + '"><td><b>' + esc( f.client ) + '</b></td><td>' + esc( f.title ) + '</td><td class="bhc-mono">' + esc( f.code ) + '</td><td>' + ( f.signed ? '<span class="bhc-pill bhc-pill--ok">Firmata</span>' : '<span class="bhc-pill">Bozza</span>' ) + ( f.expired ? ' <span class="bhc-pill bhc-pill--warn">da aggiornare</span>' : '' ) + '</td><td>' + esc( cardDate( f.updated_at ) ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table>' : '<div class="bhc-card"><p class="bhc-muted" style="margin:0">Ancora nessuna scheda: cerca una cliente qui sopra e scegli quale compilare.</p></div>';
			box.querySelectorAll( '[data-fv-f]' ).forEach( function ( r ) {
				r.addEventListener( 'click', function () {
					Promise.all( [ api( 'clients/' + r.dataset.fvCid ), api( 'forms/' + r.dataset.fvF ) ] ).then( function ( x ) {
						formEditor( x[ 0 ].client, x[ 1 ].type, x[ 1 ] );
					} );
				} );
			} );
		} );
	}

	/* ---------- Compilazione dal personale ---------- */

	/**
	 * Editor delle schede. opts (facoltativo, per riusarlo con i colloqui del personale):
	 * tpl, base (es. 'hr/interviews'), create (url per la creazione), createBody (campi extra), onClose,
	 * noCopy, who ('della cliente'), staffLabel, extraFoot(html), bindExtra(m, f, collect).
	 */
	function formEditor( c, type, f, opts ) {
		opts = opts || {};
		( opts.tpl ? Promise.resolve( null ) : formsLoad() ).then( function ( T ) {
			var tpl = opts.tpl || T[ type ];
			var base = opts.base || 'forms';
			var createUrl = opts.create || 'clients/' + c.id + '/forms';
			var onClose = opts.onClose || function () {
				openClient( c.id, 'schede' );
			};
			var who = opts.who || 'della cliente';
			var data = f ? f.data || {} : {};
			var signed = f && f.signed;
			var head = '<div class="bhc-fhead" style="--fc:' + esc( tpl.color ) + '"><div><b>' + esc( c.first_name + ' ' + c.last_name ) + '</b><small class="bhc-muted">' + clientHeaderRows( c, tpl.client ).filter( function ( r ) {
				return r[ 1 ] && r[ 0 ] !== 'Cognome' && r[ 0 ] !== 'Nome' && r[ 0 ] !== 'Cognome e nome';
			} ).map( function ( r ) {
				return esc( r[ 0 ] ) + ': ' + esc( r[ 1 ] );
			} ).join( ' · ' ) + '</small></div><div class="bhc-fhead__st">' + ( f ? '<span class="bhc-mono">' + esc( f.code ) + '</span> ' : '' ) + ( signed ? '<span class="bhc-pill bhc-pill--ok">Firmata il ' + esc( cardDate( f.signed_at ) ) + ( f.signed_name ? ' da ' + esc( f.signed_name ) : '' ) + '</span>' : '<span class="bhc-pill">' + ( f ? 'Bozza' : 'Nuova' ) + '</span>' ) + '</div></div>' +
				( signed ? '<div class="bhc-alert bhc-alert--soon">' + ICONS.alert + '<span>Scheda firmata: le risposte ' + esc( who ) + ' sono bloccate, puoi aggiornare le parti ' + ( opts.staffLabel ? esc( opts.staffLabel ) : 'dell\'operatore (analisi, mappe, registri)' ) + '.' + ( opts.noCopy ? '' : ' Per cambiare le risposte crea una nuova compilazione.' ) + '</span></div>' : '' ) +
				( f && f.expired ? '<div class="bhc-alert bhc-alert--expired">' + ICONS.alert + '<span>Scheda compilata da più di ' + tpl.renew + ' mesi: è consigliato aggiornarla con la cliente.</span></div>' : '' );
			var pagesTabs = '<div class="bhc-tabs">' + tpl.pages.map( function ( p, i ) {
				return '<button type="button" data-fpg="' + i + '"' + ( i === 0 ? ' class="is-active"' : '' ) + '>' + ( i + 1 ) + '. ' + esc( p.subtitle.split( /,| e /i )[ 0 ] ) + '</button>';
			} ).join( '' ) + '</div>';
			var pages = tpl.pages.map( function ( p, i ) {
				return '<div class="bhc-fpage" data-fpage="' + i + '"' + ( i ? ' hidden' : '' ) + '><p class="bhc-fpage__sub">' + esc( p.subtitle ) + '</p>' + ( p.intro ? '<p class="bhc-muted bhc-note">' + esc( p.intro ) + '</p>' : '' ) + p.sections.map( function ( s ) {
					var staff = s.staff || p.staff;
					return ( s.title ? '<h4 class="bhc-fsec' + ( staff ? ' is-staff' : '' ) + '">' + esc( s.title ) + ( staff ? ' <small>' + esc( opts.staffNote || 'a cura dell\'operatore' ) + '</small>' : '' ) + '</h4>' : '' ) + ( s.note ? '<p class="bhc-muted bhc-note">' + esc( s.note ) + '</p>' : '' ) +
						'<div class="bhc-fgridlay' + ( s.table ? ' is-table' : '' ) + '">' + s.fields.map( function ( fl ) {
							return fieldHtml( fl, fVal( data, fl.id ), signed && ! staff );
						} ).join( '' ) + '</div>';
				} ).join( '' ) + ( p.sign ? '<div class="bhc-fsign">' + ( signed ? '<p>' + esc( tpl.declaration ) + '</p><div class="bhc-fsign__img"><img src="' + esc( f.signature || '' ) + '" alt="Firma"><small>' + esc( cardDate( f.signed_at ) ) + ( f.signed_name ? ' · ' + esc( f.signed_name ) : '' ) + '</small></div>' : '<p class="bhc-muted">La firma ' + esc( who ) + ' si raccoglie in modalità tablet (o sulla stampa).</p>' ) + '</div>' : '' ) + '</div>';
			} ).join( '' );
			var foot = '<div>' + ( f ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-fdel>Elimina</button>' : '' ) + '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-fprint>' + ICONS.print + ' Stampa</button>' +
				( signed ? ( opts.noCopy ? '' : '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-fcopy>Nuova compilazione</button>' ) : '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-fkiosk>Fai firmare sul tablet</button>' ) + ( opts.extraFoot ? opts.extraFoot( f ) : '' ) + '</div>' +
				'<div><button type="button" class="bhc-btn bhc-btn--ghost" data-fclose>Chiudi</button><button type="button" class="bhc-btn" data-fsave>Salva</button></div>';
			var m = modal( tpl.title + ' – ' + c.first_name + ' ' + c.last_name, head + pagesTabs + pages + '<p class="bhc-msg" data-msg></p>', foot, true );
			m.querySelector( '.bhc-modal__box' ).classList.add( 'bhc-modal__box--xl' );
			bindFields( m, tpl );
			m.querySelectorAll( '[data-fpg]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					m.querySelectorAll( '[data-fpg]' ).forEach( function ( x ) {
						x.classList.toggle( 'is-active', x === b );
					} );
					m.querySelectorAll( '[data-fpage]' ).forEach( function ( x ) {
						x.hidden = x.dataset.fpage !== b.dataset.fpg;
					} );
					m.querySelectorAll( '[data-kind="sign"]' ).forEach( function ( sg ) {
						if ( sg._init && sg.offsetParent ) {
							sg._init();
							sg._init = null;
						}
					} );
				} );
			} );
			function collect() {
				var out = {};
				tpl.pages.forEach( function ( p ) {
					p.sections.forEach( function ( s ) {
						s.fields.forEach( function ( fl ) {
							var v = fieldRead( m, fl );
							if ( v !== undefined ) {
								out[ fl.id ] = v;
							}
						} );
					} );
				} );
				return out;
			}
			function save( then ) {
				var payload = { type: type, data: collect() };
				if ( ! f && opts.createBody ) {
					Object.keys( opts.createBody ).forEach( function ( kk ) {
						payload[ kk ] = opts.createBody[ kk ];
					} );
				}
				return api( f ? base + '/' + f.id : createUrl, { method: f ? 'PUT' : 'POST', body: payload } ).then( function ( saved ) {
					f = saved;
					toast( 'Scheda salvata' );
					if ( then ) {
						then( saved );
					}
					return saved;
				} ).catch( function ( e ) {
					var msg = m.querySelector( '[data-msg]' );
					msg.className = 'bhc-msg is-error';
					msg.textContent = e.message;
				} );
			}
			m.querySelector( '[data-fclose]' ).addEventListener( 'click', function () {
				closeModal();
				onClose();
			} );
			m.querySelector( '[data-fsave]' ).addEventListener( 'click', function () {
				save( function () {
					closeModal();
					onClose();
				} );
			} );
			if ( opts.bindExtra ) {
				opts.bindExtra( m, f, collect, save );
			}
			m.querySelector( '[data-fprint]' ).addEventListener( 'click', function () {
				var cd = collect();
				if ( f && f.data && f.data._consent ) {
					cd._consent = 1;
				}
				var cur = { id: f ? f.id : 0, code: f ? f.code : '', data: cd, signed: signed, signature: f ? f.signature : '', signed_at: f ? f.signed_at : '', signed_name: f ? f.signed_name : '', updated_at: f ? f.updated_at : '' };
				printForm( c, type, cur, opts.tpl );
			} );
			var k = m.querySelector( '[data-fkiosk]' );
			if ( k ) {
				k.addEventListener( 'click', function () {
					save( function ( saved ) {
						formKiosk( c, type, saved, opts );
					} );
				} );
			}
			var cp = m.querySelector( '[data-fcopy]' );
			if ( cp ) {
				cp.addEventListener( 'click', function () {
					var d = JSON.parse( JSON.stringify( f.data || {} ) );
					delete d._consent;
					api( 'clients/' + c.id + '/forms', { method: 'POST', body: { type: type, data: d } } ).then( function ( n ) {
						toast( 'Nuova compilazione creata: aggiorna le risposte e falla firmare' );
						formEditor( c, type, n );
					} ).catch( function ( e ) {
						toast( e.message, true );
					} );
				} );
			}
			var del = m.querySelector( '[data-fdel]' );
			if ( del ) {
				del.addEventListener( 'click', function () {
					if ( ! window.confirm( 'Eliminare definitivamente questa scheda?' ) ) {
						return;
					}
					api( base + '/' + f.id, { method: 'DELETE' } ).then( function () {
						toast( 'Scheda eliminata' );
						closeModal();
						onClose();
					} ).catch( function ( e ) {
						toast( e.message, true );
					} );
				} );
			}
		} );
	}

	/* ---------- Modalità tablet (compila e firma la cliente) ---------- */

	function formKiosk( c, type, f, opts ) {
		opts = opts || {};
		( opts.tpl ? Promise.resolve( null ) : formsLoad() ).then( function ( T ) {
			closeModal();
			var tpl = opts.tpl || T[ type ];
			var base = opts.base || 'forms';
			var createUrl = opts.kioskCreate || opts.create || 'clients/' + c.id + '/forms';
			var onClose = opts.onClose || function () {
				openClient( c.id, 'schede' );
			};
			var data = f ? JSON.parse( JSON.stringify( f.data || {} ) ) : {};
			// Passi: sezioni della cliente, raggruppate per pagina; poi firma.
			var steps = [];
			tpl.pages.forEach( function ( p ) {
				if ( p.staff ) {
					return;
				}
				var secs = p.sections.filter( function ( s ) {
					return ! s.staff;
				} );
				if ( secs.length ) {
					steps.push( { title: p.subtitle, intro: p.intro, sections: secs } );
				}
			} );
			var k = document.createElement( 'div' );
			k.className = 'bhc bhc-pro bhc-kiosk';
			document.body.appendChild( k );
			try {
				if ( k.requestFullscreen ) {
					k.requestFullscreen().catch( function () {} );
				}
			} catch ( e ) {}
			var step = 0, pad = null;
			function collectStep() {
				var cur = steps[ step ];
				if ( ! cur ) {
					return;
				}
				cur.sections.forEach( function ( s ) {
					s.fields.forEach( function ( fl ) {
						var v = fieldRead( k, fl );
						if ( v !== undefined ) {
							data[ fl.id ] = v;
						}
					} );
				} );
			}
			function exit() {
				try {
					if ( document.fullscreenElement ) {
						document.exitFullscreen();
					}
				} catch ( e ) {}
				k.remove();
			}
			function draw() {
				var total = steps.length + 1;
				var bar = '<div class="bhc-kiosk__bar"><div><b>' + esc( B.center ) + '</b><span>' + esc( tpl.title ) + '</span></div><div class="bhc-kiosk__prog"><i style="width:' + Math.round( ( step + 1 ) / total * 100 ) + '%"></i></div><span>' + ( step + 1 ) + ' / ' + total + '</span></div>';
				var body;
				if ( step < steps.length ) {
					var st = steps[ step ];
					body = '<h2>' + ( step === 0 ? ( tpl.kiosk_title ? esc( tpl.kiosk_title ) + ( c.first_name ? ', ' + esc( c.first_name ) : '' ) : 'Ciao ' + esc( c.first_name ) + '!' ) : esc( st.title ) ) + '</h2>' + ( step === 0 ? '<p class="bhc-kiosk__lead">' + esc( tpl.kiosk_intro || 'Ti chiediamo qualche informazione per personalizzare il trattamento in sicurezza.' ) + ' ' + esc( st.intro || '' ) + '</p>' : ( st.intro ? '<p class="bhc-kiosk__lead">' + esc( st.intro ) + '</p>' : '' ) ) +
						st.sections.map( function ( s ) {
							return ( s.title ? '<h3>' + esc( s.title ) + '</h3>' : '' ) + '<div class="bhc-fgridlay' + ( s.table ? ' is-table' : '' ) + '">' + s.fields.map( function ( fl ) {
								return fieldHtml( fl, fVal( data, fl.id ), false );
							} ).join( '' ) + '</div>';
						} ).join( '' );
				} else {
					var nm = ( ( data.first_name || c.first_name || '' ) + ' ' + ( data.last_name || c.last_name || '' ) ).trim();
					body = '<h2>Conferma e firma</h2>' + ( tpl.privacy ? '<div class="bhc-kiosk__privacy"><b>Informativa sul trattamento dei dati personali</b><p>' + esc( tpl.privacy ) + '</p></div>' : '' ) + '<p class="bhc-kiosk__lead">' + esc( tpl.declaration ) + '</p>' +
						( tpl.consent ? '<label class="bhc-check bhc-kiosk__consent"><input type="checkbox" data-kconsent' + ( data._consent ? ' checked' : '' ) + '> <span>' + esc( tpl.consent ) + '</span></label>' : '' ) +
						'<div class="bhc-field"><label>Nome e cognome</label><input type="text" data-kname value="' + esc( nm ) + '"></div>' +
						'<div class="bhc-kiosk__sig"><canvas data-ksig></canvas><span>Firma qui con il dito</span><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-kclear>Cancella firma</button></div>';
				}
				k.innerHTML = bar + '<div class="bhc-kiosk__body">' + body + '<p class="bhc-msg" data-msg></p></div>' +
					'<div class="bhc-kiosk__nav"><button type="button" class="bhc-btn bhc-btn--ghost" data-kback>' + ( step === 0 ? 'Esci' : '‹ Indietro' ) + '</button><button type="button" class="bhc-btn bhc-btn--lg" data-knext>' + ( step < steps.length ? 'Avanti ›' : 'Conferma e firma' ) + '</button></div>';
				bindFields( k, tpl );
				k.querySelector( '.bhc-kiosk__body' ).scrollTop = 0;
				if ( step >= steps.length ) {
					pad = signaturePad( k.querySelector( '[data-ksig]' ) );
					k.querySelector( '[data-kclear]' ).addEventListener( 'click', function () {
						pad.clear();
					} );
				}
				k.querySelector( '[data-kback]' ).addEventListener( 'click', function () {
					if ( step === 0 ) {
						if ( window.confirm( 'Uscire dalla compilazione? Le risposte non firmate non vengono salvate.' ) ) {
							exit();
							onClose();
						}
						return;
					}
					collectStep();
					step--;
					draw();
				} );
				k.querySelector( '[data-knext]' ).addEventListener( 'click', function () {
					if ( step < steps.length ) {
						collectStep();
						// Campi obbligatori del passo.
						var miss = [];
						steps[ step ].sections.forEach( function ( s2 ) {
							s2.fields.forEach( function ( fl ) {
								var v = data[ fl.id ];
								if ( fl.required && ( v === undefined || v === '' || ( Array.isArray( v ) && ! v.length ) ) ) {
									miss.push( fl.label.replace( / \*$/, '' ) );
								}
							} );
						} );
						if ( miss.length ) {
							var mm = k.querySelector( '[data-msg]' );
							mm.className = 'bhc-msg is-error';
							mm.textContent = 'Compila: ' + miss.join( ', ' );
							return;
						}
						step++;
						draw();
						return;
					}
					var msg = k.querySelector( '[data-msg]' );
					var kc = k.querySelector( '[data-kconsent]' );
					data._consent = ! kc || kc.checked ? 1 : 0;
					if ( ! data._consent ) {
						msg.className = 'bhc-msg is-error';
						msg.textContent = 'Per continuare spunta il consenso al trattamento dei dati.';
						return;
					}
					if ( pad.empty() ) {
						msg.className = 'bhc-msg is-error';
						msg.textContent = 'Manca la firma.';
						return;
					}
					var payload = { type: type, data: data, signature: pad.data(), signed_name: k.querySelector( '[data-kname]' ).value, source: 'tablet' };
					var btn = k.querySelector( '[data-knext]' );
					btn.disabled = true;
					if ( ! f && opts.createBody ) {
						Object.keys( opts.createBody ).forEach( function ( kk ) {
							payload[ kk ] = opts.createBody[ kk ];
						} );
					}
					api( f ? base + '/' + f.id : createUrl, { method: f ? 'PUT' : 'POST', body: payload } ).then( function ( saved ) {
						f = saved;
						k.innerHTML = '<div class="bhc-kiosk__done">' + ICONS.check + '<h2>Grazie ' + esc( data.first_name || c.first_name || '' ) + '!</h2><p>La scheda è stata firmata e salvata.<br>Ora puoi restituire il tablet ' + esc( opts.giveBack || 'all\'operatrice' ) + '.</p><button type="button" class="bhc-btn bhc-btn--ghost" data-kend>Torna al gestionale</button></div>';
						k.querySelector( '[data-kend]' ).addEventListener( 'click', function () {
							exit();
							if ( opts.onDone ) {
								opts.onDone( saved );
							} else {
								formEditor( c, type, saved, opts );
							}
						} );
					} ).catch( function ( e ) {
						btn.disabled = false;
						msg.className = 'bhc-msg is-error';
						msg.textContent = e.message;
					} );
				} );
			}
			draw();
		} );
	}

	/* ---------- Stampa (compilata o in bianco), impaginata come le schede cartacee ---------- */

	function printForm( c, type, f, tplOverride ) {
		( tplOverride ? Promise.resolve( null ) : formsLoad() ).then( function ( T ) {
			var tpl = tplOverride || T[ type ];
			var data = f ? f.data || {} : {};
			var blank = ! f;
			var name = c ? ( c.last_name + ' ' + c.first_name ).trim() : '';
			var code = f && f.code ? f.code : '';
			var dateStr = f ? cardDate( f.signed_at || f.updated_at ) : '';
			var box = function ( label, val, cls ) {
				return '<div class="pf ' + ( cls || '' ) + '"><div class="pl">' + esc( label ) + '</div><div class="pv">' + ( val ? esc( val ).replace( /\n/g, '<br>' ) : '&nbsp;' ) + '</div></div>';
			};
			var sq = function ( on ) {
				return '<span class="sq">' + ( on ? '✕' : '' ) + '</span>';
			};
			function fieldPrint( fl ) {
				var v = fVal( data, fl.id ), wc = 'w-' + ( fl.w || ( [ 'textarea' ].indexOf( fl.type ) !== -1 ? 'full' : 'half' ) );
				switch ( fl.type ) {
					case 'textarea':
						return box( fl.label, v, wc + ' tall' );
					case 'radio':
						if ( blank || ! v ) {
							return fl.options.length > 4 ? box( fl.label, '', wc ) : '<div class="pf ' + wc + '"><div class="pl">' + esc( fl.label ) + '</div><div class="popts">' + fl.options.map( function ( o ) {
								return sq( false ) + ' ' + esc( o );
							} ).join( ' &nbsp; ' ) + '</div></div>';
						}
						return box( fl.label, v, wc );
					case 'checks':
						return '<div class="pf w-full">' + ( fl.label ? '<div class="pl">' + esc( fl.label ) + '</div>' : '' ) + '<div class="pchecks" style="--cols:' + ( fl.cols || 3 ) + '">' + fl.options.map( function ( o ) {
							return '<span>' + sq( Array.isArray( v ) && v.indexOf( o ) !== -1 ) + ' ' + esc( o ) + '</span>';
						} ).join( '' ) + '</div></div>';
					case 'yesno':
						var y = v || {};
						return '<tr><td>' + esc( fl.label ) + '</td><td class="c">' + sq( y.v === 'si' ) + '</td><td class="c">' + sq( y.v === 'no' ) + '</td><td class="d">' + esc( y.d || '' ) + '</td></tr>';
					case 'grid':
						var rows = blank ? gridRows( fl, [] ) : gridRows( fl, v );
						if ( ! blank && fl.grow ) {
							while ( rows.length < ( fl.rows || 0 ) + 0 ) {
								rows.push( [] );
							}
						}
						return '<div class="pf w-full">' + ( fl.label ? '<div class="pl">' + esc( fl.label ) + '</div>' : '' ) + '<table class="pgrid"><tr>' + ( fl.numbered ? '<th class="n">N.</th>' : '' ) + fl.columns.map( function ( col ) {
							return '<th>' + esc( col ) + '</th>';
						} ).join( '' ) + '</tr>' + rows.map( function ( r, i ) {
							return '<tr>' + ( fl.numbered ? '<td class="n">' + ( i + 1 ) + '</td>' : '' ) + fl.columns.map( function ( col, j ) {
								var cell = r[ j ] !== undefined && r[ j ] !== '' ? r[ j ] : ( j === 0 && Array.isArray( fl.rows ) && fl.rows[ i ] ? fl.rows[ i ] : '' );
								return '<td>' + ( fl.check === j ? sq( !! cell ) : esc( cell ) ) + '</td>';
							} ).join( '' ) + '</tr>';
						} ).join( '' ) + '</table></div>';
					case 'measures':
						var mv = v || {}, dts = mv.dates || [], cl = mv.cells || [];
						return '<div class="pf w-full"><div class="pl">' + esc( fl.label ) + '</div><table class="pgrid"><tr><th>Misura</th><th>Rif. cm*</th>' + Array.from( { length: fl.dates }, function ( _, i ) {
							return '<th>Data ' + esc( dts[ i ] ? cardDate( dts[ i ] ) : '' ) + '</th>';
						} ).join( '' ) + '</tr>' + fl.rows.map( function ( r, i ) {
							return '<tr><td>' + esc( r ) + '</td>' + Array.from( { length: fl.dates + 1 }, function ( _, j ) {
								return '<td>' + esc( ( cl[ i ] || [] )[ j ] || '' ) + '</td>';
							} ).join( '' ) + '</tr>';
						} ).join( '' ) + '</table><div class="pnote">' + esc( fl.note || '' ) + '</div></div>';
					case 'map':
						return '<div class="pf w-full"><div class="pnote">' + esc( fl.label ) + '</div><div class="pmap">' + Object.keys( fl.views ).map( function ( vk ) {
							return '<figure>' + mapSvg( vk, Array.isArray( v ) ? v : [], 'psil' ) + '<figcaption>' + esc( fl.views[ vk ] ) + '</figcaption></figure>';
						} ).join( '' ) + '</div></div>';
					case 'scale':
						return '<div class="pf ' + wc + '"><div class="pl">' + esc( fl.label ) + '</div><div class="popts">' + Array.from( { length: fl.max - fl.min + 1 }, function ( _, i ) {
							var n = fl.min + i;
							return sq( String( v ) === String( n ) ) + ' ' + n;
						} ).join( ' &nbsp; ' ) + '</div></div>';
					case 'consent':
						return '<div class="pf w-full">' + sq( !! v ) + ' ' + esc( fl.label ) + '</div>';
					case 'info':
						return '<p class="pintro w-full">' + esc( fl.label ) + '</p>';
					case 'sign':
						return '<div class="pf w-half"><div class="pl">' + esc( fl.label ) + '</div><div class="pv sig">' + ( v ? '<img src="' + esc( v ) + '" alt="">' : '&nbsp;' ) + '</div></div>';
					default:
						return box( fl.label.replace( / \*$/, '' ), v && fl.type === 'date' ? cardDate( v ) : v, wc );
				}
			}
			var nPages = tpl.pages.length;
			var html = tpl.pages.map( function ( p, pi ) {
				var top = '<div class="ph"><h1>' + esc( tpl.title.toUpperCase() ) + '</h1><div class="psub">' + esc( p.subtitle ) + '</div></div>' +
					'<div class="prow">' + box( pi === 0 && tpl.client.indexOf( 'name' ) === -1 && tpl.client.indexOf( 'last_name' ) !== -1 ? 'Centro' : ( tpl.subject === 'candidato' ? 'Candidato/a' : ( tpl.subject === 'dipendente' ? 'Dipendente' : 'Cliente' ) ), pi === 0 && tpl.client.indexOf( 'last_name' ) !== -1 ? B.center : name, 'w-twothird' ) + box( 'Data / Codice scheda', [ dateStr, code ].filter( Boolean ).join( ' · ' ), 'w-third' ) + '</div>';
				if ( pi === 0 ) {
					var cr = clientHeaderRows( c || {}, tpl.client );
					top += '<div class="prow">' + cr.map( function ( r ) {
						return box( r[ 0 ], blank && ! c ? '' : r[ 1 ], r[ 0 ] === 'Email' || r[ 0 ] === 'Indirizzo' ? 'w-half' : 'w-half' );
					} ).join( '' ) + '</div>';
				}
				var body = ( p.intro ? '<p class="pintro">' + esc( p.intro ) + '</p>' : '' ) + p.sections.map( function ( s ) {
					var yn = s.fields.filter( function ( x ) {
						return x.type === 'yesno';
					} );
					var other = s.fields.filter( function ( x ) {
						return x.type !== 'yesno';
					} );
					return ( s.title ? '<div class="psec">' + esc( s.title.toUpperCase() ) + '</div>' : '' ) + ( s.note ? '<p class="pintro">' + esc( s.note ) + '</p>' : '' ) +
						( function () {
							var ynHtml = yn.length ? '<table class="pyn"><tr><th>' + ( s.table ? 'Condizione' : '' ) + '</th><th class="c">Sì</th><th class="c">No</th><th>' + esc( yn[ 0 ].detail || 'Dettagli' ) + '</th></tr>' + yn.map( fieldPrint ).join( '' ) + '</table>' : '';
							var otherHtml = '<div class="prow">' + other.map( fieldPrint ).join( '' ) + '</div>';
							return s.table ? ynHtml + otherHtml : otherHtml + ynHtml;
						} )();
				} ).join( '' );
				if ( p.sign ) {
					body += ( tpl.privacy ? '<div class="pprivacy"><b>Informativa sul trattamento dei dati personali</b><br>' + esc( tpl.privacy ) + '</div>' : '' ) + '<p class="pdecl">' + esc( tpl.declaration ) + '</p><div class="prow psign">' + box( 'Data', f && f.signed ? cardDate( f.signed_at ) : '', 'w-third' ) +
						'<div class="pf w-twothird"><div class="pl">' + ( tpl.subject === 'candidato' ? 'Firma del candidato/a' : ( tpl.subject === 'dipendente' ? 'Firma del dipendente' : 'Firma cliente' ) ) + '</div><div class="pv sig">' + ( f && f.signed && f.signature ? '<img src="' + esc( f.signature ) + '" alt="">' : '&nbsp;' ) + '</div></div></div>' +
						( tpl.consent ? '<p class="pcons">' + sq( !! ( f && f.data && f.data._consent ) ) + ' ' + esc( tpl.consent ) + '</p>' : '' );
				}
				return '<section class="pp">' + top + body + '<div class="pfoot"><span>' + esc( tpl.footer ) + '</span><span>' + ( pi + 1 ) + '/' + nPages + '</span></div></section>';
			} ).join( '' );
			var w = window.open( '', '_blank' );
			if ( ! w ) {
				toast( 'Consenti le finestre popup per stampare.', true );
				return;
			}
			var css = '@page{size:A4;margin:12mm 13mm}*{box-sizing:border-box}body{font-family:"DejaVu Sans",Helvetica,Arial,sans-serif;color:#222;margin:0;font-size:9.5pt}' +
				'.pp{page-break-after:always;min-height:270mm;position:relative;padding-bottom:12mm}.pp:last-child{page-break-after:auto}' +
				'.ph h1{font-size:17pt;margin:0;letter-spacing:.02em}.psub{font-size:9.5pt;color:#555;margin:2px 0 12px}' +
				'.prow{display:flex;flex-wrap:wrap;gap:6px 4%;margin-bottom:4px}.pf{margin-bottom:6px}.w-full{width:100%}.w-half{width:48%}.w-third{width:30.6%}.w-twothird{width:65.4%}' +
				'.pl{font-size:7.5pt;color:#444;margin-bottom:2px}.pv{border:1px solid #c9c4b8;border-radius:2px;min-height:6.5mm;padding:3px 5px;font-size:9pt}.tall .pv{min-height:13mm}.pv.sig{min-height:16mm}.pv.sig img{max-height:15mm}' +
				'.psec{background:#f2efe8;font-weight:bold;font-size:8.5pt;letter-spacing:.04em;padding:5px 8px;margin:10px 0 8px;border-left:3px solid ' + tpl.color + '}' +
				'.sq{display:inline-block;width:3.2mm;height:3.2mm;border:1px solid #777;vertical-align:-1px;text-align:center;font-size:7pt;line-height:3mm}' +
				'.pchecks{display:grid;grid-template-columns:repeat(var(--cols),1fr);gap:4px 10px;font-size:8.5pt;padding:2px 0}.popts{font-size:8.5pt;padding:3px 0}' +
				'table{width:100%;border-collapse:collapse}.pyn th,.pgrid th{font-size:7.5pt;text-align:left;color:#444;border-bottom:1px solid #aaa;padding:3px 4px}.pyn td,.pgrid td{border-bottom:1px solid #d5d0c5;padding:4px;font-size:8.5pt;height:6.5mm;vertical-align:middle}.pgrid td{border:1px solid #d5d0c5}.pyn .c,.pgrid .n{width:9mm;text-align:center}.pyn .d{width:45%}' +
				'.pmap{display:flex;justify-content:space-around;align-items:flex-end;gap:10px;margin:6px 0}.pmap figure{margin:0;text-align:center;flex:1}.psil{height:55mm;width:100%}.pmap figcaption{font-size:7.5pt;font-weight:bold;margin-top:4px}' +
				'.bhc-mk circle{fill:#fff;stroke:#b0735a;stroke-width:.8}.bhc-mk text{font-size:5px;font-weight:bold;fill:#b0735a;font-family:Arial}.bhc-mk--x circle{stroke:#c0392b}.bhc-mk--x path{stroke:#c0392b;stroke-width:.9}' +
				'.pprivacy{font-size:7pt;color:#444;border:1px solid #ddd;padding:5px 7px;margin:10px 0 4px;line-height:1.35}.pintro,.pnote{font-size:8pt;color:#444;margin:2px 0 6px}.pdecl{font-size:8.5pt;margin:12px 0 6px}.pcons{font-size:7.5pt;color:#444}' +
				'.pfoot{position:absolute;bottom:0;left:0;right:0;display:flex;justify-content:space-between;font-size:7pt;color:#666;border-top:1px solid #ddd;padding-top:3px}';
			w.document.open();
			w.document.write( '<!doctype html><html lang="it"><head><meta charset="utf-8"><title>' + esc( tpl.title + ( name ? ' – ' + name : '' ) ) + '</title><style>' + css + '</style></head><body>' + html + '<script>window.onload=function(){setTimeout(function(){window.print();},200)}<\/script></body></html>' );
			w.document.close();
		} );
	}

	/* ================= Candidati e colloqui (sezione di Operatrici e personale) ================= */

	var HR = { tab: 'staff', tpl: null, cq: '', cstatus: 'aperti', itype: '', people: [] };
	var HR_STATUS = { nuovo: [ 'Nuovo', '' ], colloquio: [ 'Colloquio', 'bhc-pill--warn' ], valutazione: [ 'Da decidere', 'bhc-pill--warn' ], assunto: [ 'Assunto', 'bhc-pill--ok' ], archiviato: [ 'Archiviato', 'bhc-pill--off' ] };
	var HR_CHANNELS = [ 'Passaparola', 'Annuncio online', 'Social', 'Candidatura spontanea', 'Scuola / accademia', 'Tablet in centro', 'Altro' ];

	function hrLoad() {
		return HR.tpl ? Promise.resolve( HR.tpl ) : api( 'hr/templates' ).then( function ( t ) {
			HR.tpl = t;
			return t;
		} );
	}

	function hrStars( n ) {
		n = +n || 0;
		return n ? '<span class="bhc-stars" title="Valutazione ' + n + '/5">' + '★★★★★'.slice( 0, n ) + '<i>' + '★★★★★'.slice( n ) + '</i></span>' : '';
	}

	function hrTabsHtml() {
		return '<div class="bhc-tabs bhc-hrtabs">' + [ [ 'staff', 'Personale' ], [ 'cand', 'Candidati' ], [ 'coll', 'Colloqui' ] ].map( function ( t ) {
			return '<button type="button" data-hrtab="' + t[ 0 ] + '"' + ( HR.tab === t[ 0 ] ? ' class="is-active"' : '' ) + '>' + t[ 1 ] + '</button>';
		} ).join( '' ) + '</div>';
	}
	function hrBindTabs( main ) {
		main.querySelectorAll( '[data-hrtab]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				HR.tab = b.dataset.hrtab;
				renderPeople();
			} );
		} );
	}

	/** Opzioni dell'editor delle schede per i colloqui. */
	function hrOpts( type, subj, onClose ) {
		var tpl = HR.tpl[ type ];
		return {
			tpl: tpl,
			base: 'hr/interviews',
			create: 'hr/interviews',
			createBody: { type: type, candidate_id: subj.candidate_id || 0, person_id: subj.person_id || 0 },
			noCopy: true,
			who: tpl.subject === 'candidato' ? 'del candidato' : 'del dipendente',
			staffLabel: 'del responsabile (valutazioni, proposta, firme)',
			staffNote: 'a cura del responsabile',
			giveBack: 'alla responsabile',
			onClose: onClose,
			extraFoot: function ( f ) {
				return type === 'uscita' && f && subj.person_id ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-hr-close>Chiudi il rapporto</button>' : '';
			},
			bindExtra: function ( m, f, collect, save ) {
				var b = m.querySelector( '[data-hr-close]' );
				if ( b ) {
					b.addEventListener( 'click', function () {
						var last = collect().last_day;
						if ( ! window.confirm( 'Segnare ' + subj.first_name + ' come cessata' + ( last ? ' dal ' + cardDate( last ) : '' ) + ' e disattivare l\'accesso al gestionale?' ) ) {
							return;
						}
						save( function () {
							api( 'hr/interviews/' + f.id + '/close-employment', { method: 'POST', body: {} } ).then( function () {
								toast( 'Rapporto chiuso: scheda segnata come cessata' );
								closeModal();
								if ( typeof loadPeople === 'function' ) {
									loadPeople();
								}
							} ).catch( function ( e ) {
								toast( e.message, true );
							} );
						} );
					} );
				}
			}
		};
	}

	function hrOpenInterview( id, onClose ) {
		Promise.all( [ hrLoad(), api( 'hr/interviews/' + id ) ] ).then( function ( r ) {
			var iv = r[ 1 ];
			var parts = ( iv.subject || '' ).split( ' ' );
			var subj = { first_name: parts.shift() || '', last_name: parts.join( ' ' ), candidate_id: iv.candidate_id, person_id: iv.person_id };
			formEditor( subj, iv.type, iv, hrOpts( iv.type, subj, onClose ) );
		} ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	function hrNewInterview( type, subj, onClose, tablet ) {
		hrLoad().then( function () {
			if ( tablet ) {
				formKiosk( subj, type, null, hrOpts( type, subj, onClose ) );
			} else {
				formEditor( subj, type, null, hrOpts( type, subj, onClose ) );
			}
		} );
	}

	function hrPrintBlank( type ) {
		hrLoad().then( function () {
			printForm( null, type, null, HR.tpl[ type ] );
		} );
	}

	/* ---------- Candidati ---------- */

	function renderCandidates( main ) {
		main.innerHTML = '<div class="bhc-top"><h2>Operatrici e personale</h2><div class="bhc-top__actions">' +
			'<input type="search" data-cq placeholder="Cerca candidato, posizione…" value="' + esc( HR.cq ) + '" style="min-width:200px">' +
			'<select data-cst><option value="aperti">In selezione</option><option value="assunto">Assunti</option><option value="archiviato">Archiviati</option><option value="">Tutti</option></select>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cblank>' + ICONS.print + ' Scheda vuota</button>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-ctablet>Candidato su tablet</button>' +
			'<button type="button" class="bhc-btn bhc-btn--sm" data-cnew>+ Nuovo candidato</button></div></div>' + hrTabsHtml() +
			'<div data-ckpi></div><div data-clist><div class="bhc-loading">Caricamento…</div></div>';
		hrBindTabs( main );
		main.querySelector( '[data-cst]' ).value = HR.cstatus;
		main.querySelector( '[data-cq]' ).addEventListener( 'input', debounce( function ( e ) {
			HR.cq = e.target.value;
			loadCandidates();
		}, 250 ) );
		main.querySelector( '[data-cst]' ).addEventListener( 'change', function ( e ) {
			HR.cstatus = e.target.value;
			loadCandidates();
		} );
		main.querySelector( '[data-cnew]' ).addEventListener( 'click', function () {
			candidateModal( null );
		} );
		main.querySelector( '[data-cblank]' ).addEventListener( 'click', function () {
			hrPrintBlank( 'assunzione' );
		} );
		main.querySelector( '[data-ctablet]' ).addEventListener( 'click', function () {
			hrLoad().then( function () {
				formKiosk( { first_name: '', last_name: '' }, 'assunzione', null, {
					tpl: HR.tpl.assunzione,
					base: 'hr/interviews',
					kioskCreate: 'hr/kiosk-candidate',
					giveBack: 'alla responsabile',
					onClose: renderPeople,
					onDone: function ( iv ) {
						renderPeople();
						openCandidate( iv.candidate_id );
					}
				} );
			} );
		} );
		loadCandidates();
	}

	function loadCandidates() {
		var box = document.querySelector( '[data-clist]' );
		if ( ! box ) {
			return;
		}
		api( 'hr/candidates?q=' + encodeURIComponent( HR.cq ) + '&status=' + HR.cstatus ).then( function ( d ) {
			var k = d.counts;
			document.querySelector( '[data-ckpi]' ).innerHTML = '<div class="bhc-kpis">' + kpi( 'Nuovi', k.nuovo ) + kpi( 'In colloquio', k.colloquio ) + kpi( 'Da decidere', k.valutazione ) + kpi( 'Assunti', k.assunto ) + kpi( 'Archiviati', k.archiviato ) + '</div>';
			box.innerHTML = '<div class="bhc-people">' + d.items.map( function ( c ) {
				var st = HR_STATUS[ c.status ] || [ c.status, '' ];
				return '<button type="button" class="bhc-person" data-cand="' + c.id + '"><span class="bhc-person__avatar" style="background:#8b9a7d">' + esc( nameInitials( c.name ) ) + '</span>' +
					'<span class="bhc-person__body"><strong>' + esc( c.name ) + '</strong><span class="bhc-muted">' + esc( c.position || 'Posizione da definire' ) + '</span>' +
					'<span class="bhc-person__meta"><span class="bhc-pill ' + st[ 1 ] + '">' + st[ 0 ] + '</span>' + hrStars( c.rating ) + ( c.channel ? '<span class="bhc-pill">' + esc( c.channel ) + '</span>' : '' ) + '</span>' +
					'<span class="bhc-muted" style="font-size:.78rem">' + esc( [ c.phone, c.email ].filter( Boolean ).join( ' · ' ) ) + ( c.interview_at ? '<br>Colloquio: ' + esc( cardDate( c.interview_at ) + ( c.interview_at.substring( 11, 16 ) !== '00:00' ? ' ' + c.interview_at.substring( 11, 16 ) : '' ) ) : '' ) + '</span></span></button>';
			} ).join( '' ) + '<button type="button" class="bhc-person bhc-person--add" data-cnew2><span class="bhc-person__avatar">' + ICONS.people + '<b>+</b></span><span class="bhc-person__body"><strong>Aggiungi candidato</strong><span class="bhc-muted">Oppure fallo compilare sul tablet</span></span></button></div>';
			box.querySelectorAll( '[data-cand]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					openCandidate( b.dataset.cand );
				} );
			} );
			box.querySelector( '[data-cnew2]' ).addEventListener( 'click', function () {
				candidateModal( null );
			} );
		} ).catch( function ( e ) {
			box.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function openCandidate( id ) {
		Promise.all( [ hrLoad(), api( 'hr/candidates/' + id ) ] ).then( function ( r ) {
			candidateModal( r[ 1 ] );
		} ).catch( function ( e ) {
			toast( e.message, true );
		} );
	}

	function candidateModal( c ) {
		var isNew = ! c;
		c = c || { first_name: '', last_name: '', phone: '', email: '', position: '', channel: '', interview_at: '', notes: '', status: 'nuovo', interviews: [] };
		var sel = ( c.interviews || [] ).filter( function ( i ) {
			return i.type === 'assunzione';
		} )[ 0 ];
		var st = HR_STATUS[ c.status ] || [ c.status, '' ];
		var fld = function ( k, label, type, extra ) {
			return '<div class="bhc-field"><label>' + label + '</label><input type="' + ( type || 'text' ) + '" data-cf="' + k + '" value="' + esc( k === 'interview_at' && c[ k ] ? c[ k ].substring( 0, 16 ).replace( ' ', 'T' ) : ( c[ k ] || '' ) ) + '"' + ( extra || '' ) + '></div>';
		};
		var body = ( isNew ? '' : '<div class="bhc-person-head"><span class="bhc-person__avatar bhc-person__avatar--lg" style="background:#8b9a7d">' + esc( nameInitials( c.name ) ) + '</span><div><strong style="font-size:1rem">' + esc( c.name ) + '</strong><br><span class="bhc-pill ' + st[ 1 ] + '">' + st[ 0 ] + '</span> ' + hrStars( c.rating ) + '</div></div>' ) +
			'<div class="bhc-row">' + fld( 'first_name', 'Nome *' ) + fld( 'last_name', 'Cognome *' ) + '</div>' +
			'<div class="bhc-row">' + fld( 'phone', 'Cellulare', 'tel' ) + fld( 'email', 'Email', 'email' ) + '</div>' +
			'<div class="bhc-row">' + fld( 'position', 'Posizione', 'text', ' list="bhc-hr-pos"' ) + '<div class="bhc-field"><label>Come ci ha conosciuto</label><select data-cf="channel"><option value="">—</option>' + HR_CHANNELS.map( function ( o ) {
				return '<option' + ( c.channel === o ? ' selected' : '' ) + '>' + esc( o ) + '</option>';
			} ).join( '' ) + '</select></div></div>' +
			'<datalist id="bhc-hr-pos">' + [ 'Estetista', 'Onicotecnica', 'Massaggiatrice / massoterapista', 'Receptionist', 'Apprendista estetista', 'Responsabile di centro' ].map( function ( o ) {
				return '<option value="' + esc( o ) + '">';
			} ).join( '' ) + '</datalist>' +
			'<div class="bhc-row">' + fld( 'interview_at', 'Data e ora del colloquio', 'datetime-local' ) + '<div></div></div>' +
			'<div class="bhc-field"><label>Note</label><textarea rows="2" data-cf="notes">' + esc( c.notes || '' ) + '</textarea></div>';
		if ( ! isNew ) {
			body += '<h4 class="bhc-fsec">Colloquio di selezione e assunzione</h4>' + ( sel ? '<div class="bhc-ivrow"><span><b class="bhc-mono">' + esc( sel.code ) + '</b> · ' + ( sel.signed ? '<span class="bhc-pill bhc-pill--ok">Firmato dal candidato ' + esc( cardDate( sel.signed_at ) ) + '</span>' : '<span class="bhc-pill">Bozza</span>' ) + ( sel.source === 'tablet' ? ' <span class="bhc-pill">tablet</span>' : '' ) + ' ' + hrStars( sel.rating ) + '</span><span><button type="button" class="bhc-btn bhc-btn--sm" data-ivopen="' + sel.id + '">Apri e valuta</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-ivprint="' + sel.id + '">' + ICONS.print + '</button></span></div>' :
				'<div class="bhc-ivrow"><span class="bhc-muted">Non ancora compilato.</span><span><button type="button" class="bhc-btn bhc-btn--sm" data-ivnew>Compila</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-ivtab>Su tablet</button></span></div>' );
			body += '<h4 class="bhc-fsec">Esito</h4>';
			if ( c.status === 'assunto' ) {
				body += '<div class="bhc-alert bhc-alert--ok">' + ICONS.check + '<span>Assunta il ' + esc( cardDate( c.decided_at ) ) + '. <a href="#" data-goperson="' + c.person_id + '">Apri la scheda del personale</a></span></div>';
			} else if ( c.status === 'archiviato' ) {
				body += '<div class="bhc-ivrow"><span class="bhc-muted">Candidatura archiviata il ' + esc( cardDate( c.decided_at ) ) + '.</span><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-reopen>Riapri</button></div>';
			} else {
				body += '<p class="bhc-muted bhc-note">Con «Assumi» viene creata la scheda del nuovo personale con i dati del colloquio (anagrafica, ruolo, mansione, contratto, livello, data di assunzione, ore, corsi) e la candidatura passa tra gli assunti.</p><div class="bhc-ivrow"><span></span><span><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-archive>Non assunto · archivia</button><button type="button" class="bhc-btn bhc-btn--sm" data-hire>' + ICONS.check + ' Assumi</button></span></div>';
			}
		}
		body += '<p class="bhc-msg" data-msg></p>';
		var foot = '<div>' + ( isNew ? '' : '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-cdel>Elimina</button>' ) + '</div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-x>Chiudi</button><button type="button" class="bhc-btn" data-csave>Salva</button></div>';
		var m = modal( isNew ? 'Nuovo candidato' : 'Candidato', body, foot );
		var msg = m.querySelector( '[data-msg]' );
		var back = function () {
			loadCandidates();
			openCandidate( c.id );
		};
		function payload() {
			var p = {};
			m.querySelectorAll( '[data-cf]' ).forEach( function ( i ) {
				p[ i.dataset.cf ] = i.value;
			} );
			return p;
		}
		function saveC() {
			return api( isNew ? 'hr/candidates' : 'hr/candidates/' + c.id, { method: isNew ? 'POST' : 'PUT', body: payload() } );
		}
		m.querySelector( '[data-x]' ).addEventListener( 'click', closeModal );
		m.querySelector( '[data-csave]' ).addEventListener( 'click', function () {
			saveC().then( function ( saved ) {
				toast( 'Candidato salvato' );
				loadCandidates();
				candidateModal( saved );
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
		var subj = { first_name: c.first_name, last_name: c.last_name, candidate_id: c.id };
		var on = function ( sel2, fn ) {
			var el = m.querySelector( sel2 );
			if ( el ) {
				el.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					fn( el );
				} );
			}
		};
		on( '[data-ivnew]', function () {
			hrNewInterview( 'assunzione', subj, back, false );
		} );
		on( '[data-ivtab]', function () {
			hrNewInterview( 'assunzione', subj, back, true );
		} );
		on( '[data-ivopen]', function ( el ) {
			hrOpenInterview( el.dataset.ivopen, back );
		} );
		on( '[data-ivprint]', function ( el ) {
			api( 'hr/interviews/' + el.dataset.ivprint ).then( function ( iv ) {
				printForm( { first_name: c.first_name, last_name: c.last_name }, 'assunzione', iv, HR.tpl.assunzione );
			} );
		} );
		on( '[data-hire]', function () {
			if ( ! sel || ! sel.rating ) {
				if ( ! window.confirm( 'Il colloquio non ha ancora una valutazione. Assumere comunque ' + c.name + '?' ) ) {
					return;
				}
			} else if ( ! window.confirm( 'Assumere ' + c.name + '? Verrà creata la scheda del nuovo personale con i dati del colloquio.' ) ) {
				return;
			}
			api( 'hr/candidates/' + c.id + '/outcome', { method: 'POST', body: { outcome: 'assunto' } } ).then( function ( r ) {
				toast( c.name + ' è stata aggiunta al personale' );
				closeModal();
				HR.tab = 'staff';
				renderPeople();
				personForm( r.person );
			} ).catch( function ( e ) {
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		} );
		on( '[data-archive]', function () {
			api( 'hr/candidates/' + c.id + '/outcome', { method: 'POST', body: { outcome: 'archiviato' } } ).then( function () {
				toast( 'Candidatura archiviata' );
				back();
			} );
		} );
		on( '[data-reopen]', function () {
			api( 'hr/candidates/' + c.id + '/outcome', { method: 'POST', body: { outcome: 'valutazione' } } ).then( back );
		} );
		on( '[data-goperson]', function ( el ) {
			api( 'people/' + el.dataset.goperson ).then( function ( p ) {
				HR.tab = 'staff';
				renderPeople();
				personForm( p );
			} );
		} );
		on( '[data-cdel]', function () {
			if ( ! window.confirm( 'Eliminare il candidato e il suo colloquio di selezione?' ) ) {
				return;
			}
			api( 'hr/candidates/' + c.id, { method: 'DELETE' } ).then( function () {
				closeModal();
				toast( 'Candidato eliminato' );
				loadCandidates();
			} );
		} );
	}

	/* ---------- Colloqui ---------- */

	function renderInterviews( main ) {
		hrLoad().then( function ( T ) {
			main.innerHTML = '<div class="bhc-top"><h2>Operatrici e personale</h2><div class="bhc-top__actions"><select data-itype><option value="">Tutti i colloqui</option>' + Object.keys( T ).map( function ( k ) {
				return '<option value="' + k + '">' + esc( T[ k ].title ) + '</option>';
			} ).join( '' ) + '</select></div></div>' + hrTabsHtml() +
				'<div class="bhc-hrmodels">' + Object.keys( T ).map( function ( k ) {
					var t = T[ k ];
					return '<div class="bhc-formcard" style="--fc:' + esc( t.color ) + '"><strong>' + esc( t.title ) + '</strong><small class="bhc-muted">' + ( t.subject === 'candidato' ? 'Per i candidati' : 'Per il personale' ) + '</small><div class="bhc-formcard__act">' +
						( t.subject === 'candidato' ? '<button type="button" class="bhc-btn bhc-btn--sm" data-gocand>Candidati</button>' : '<button type="button" class="bhc-btn bhc-btn--sm" data-inew="' + k + '">Nuovo</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-itab="' + k + '">Tablet</button>' ) +
						'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-iblank="' + k + '" title="Stampa vuota">' + ICONS.print + '</button></div></div>';
				} ).join( '' ) + '</div><div data-ilist><div class="bhc-loading">Caricamento…</div></div>';
			hrBindTabs( main );
			var it = main.querySelector( '[data-itype]' );
			it.value = HR.itype;
			it.addEventListener( 'change', function () {
				HR.itype = it.value;
				loadInterviews();
			} );
			main.querySelectorAll( '[data-iblank]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					hrPrintBlank( b.dataset.iblank );
				} );
			} );
			main.querySelectorAll( '[data-gocand]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					HR.tab = 'cand';
					renderPeople();
				} );
			} );
			main.querySelectorAll( '[data-inew],[data-itab]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					hrPickPerson( b.dataset.inew || b.dataset.itab, !! b.dataset.itab );
				} );
			} );
			loadInterviews();
		} );
	}

	function loadInterviews() {
		var box = document.querySelector( '[data-ilist]' );
		if ( ! box ) {
			return;
		}
		api( 'hr/interviews?type=' + HR.itype ).then( function ( d ) {
			box.innerHTML = d.items.length ? '<table class="bhc-table"><thead><tr><th>Aggiornato</th><th>Colloquio</th><th>Persona</th><th>Stato</th><th>Valutazione</th><th>Esito</th><th>Da</th><th></th></tr></thead><tbody>' + d.items.map( function ( i ) {
				var t = HR.tpl[ i.type ] || {};
				return '<tr class="is-click" data-iv="' + i.id + '"><td>' + esc( cardDate( i.updated_at ) ) + '</td><td><span class="bhc-card-dot" style="background:' + esc( t.color || '#999' ) + '"></span>' + esc( i.title ) + '<br><small class="bhc-muted bhc-mono">' + esc( i.code ) + '</small></td><td><b>' + esc( i.subject ) + '</b><br><small class="bhc-muted">' + ( i.person_id ? 'personale' : 'candidato' ) + '</small></td>' +
					'<td>' + ( i.signed ? '<span class="bhc-pill bhc-pill--ok">Firmato</span>' : '<span class="bhc-pill">Bozza</span>' ) + ( i.source === 'tablet' ? ' <span class="bhc-pill">tablet</span>' : '' ) + '</td><td>' + hrStars( i.rating ) + '</td><td>' + esc( i.outcome ) + '</td><td>' + esc( i.user ) + '</td><td><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-ivp="' + i.id + '">' + ICONS.print + '</button></td></tr>';
			} ).join( '' ) + '</tbody></table>' : '<div class="bhc-card"><p class="bhc-muted" style="margin:0">Nessun colloquio registrato.</p></div>';
			box.querySelectorAll( '[data-iv]' ).forEach( function ( r ) {
				r.addEventListener( 'click', function ( e ) {
					if ( e.target.closest( '[data-ivp]' ) ) {
						return;
					}
					hrOpenInterview( r.dataset.iv, function () {
						loadInterviews();
					} );
				} );
			} );
			box.querySelectorAll( '[data-ivp]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					api( 'hr/interviews/' + b.dataset.ivp ).then( function ( iv ) {
						var parts = ( iv.subject || '' ).split( ' ' );
						printForm( { first_name: parts.shift() || '', last_name: parts.join( ' ' ) }, iv.type, iv, HR.tpl[ iv.type ] );
					} );
				} );
			} );
		} );
	}

	/** Sceglie la persona del personale per un nuovo colloquio. */
	function hrPickPerson( type, tablet ) {
		api( 'people?status=' ).then( function ( d ) {
			var list = d.items.filter( function ( p ) {
				return type === 'uscita' || p.status !== 'cessato';
			} );
			var body = '<div class="bhc-field"><label>Persona</label><select data-pp><option value="">— scegli —</option>' + list.map( function ( p ) {
				return '<option value="' + p.id + '">' + esc( p.last_name + ' ' + p.first_name ) + ( p.job_title ? ' · ' + esc( p.job_title ) : '' ) + ( p.status !== 'attivo' ? ' (' + esc( p.status ) + ')' : '' ) + '</option>';
			} ).join( '' ) + '</select></div>';
			var m = modal( HR.tpl[ type ].title + ( tablet ? ' su tablet' : '' ), body, '<div></div><div><button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn" data-go>' + ( tablet ? 'Apri sul tablet' : 'Compila' ) + '</button></div>' );
			m.querySelector( '[data-x]' ).addEventListener( 'click', closeModal );
			m.querySelector( '[data-go]' ).addEventListener( 'click', function () {
				var pid = +m.querySelector( '[data-pp]' ).value;
				var p = list.filter( function ( x ) {
					return x.id === pid;
				} )[ 0 ];
				if ( ! p ) {
					return;
				}
				hrNewInterview( type, { first_name: p.first_name, last_name: p.last_name, person_id: p.id }, function () {
					if ( HR.tab === 'coll' ) {
						loadInterviews();
					}
				}, tablet );
			} );
		} );
	}

	/** Scheda del personale › Colloqui. */
	function hrPersonPane( m, p ) {
		var box = m.querySelector( '[data-hr-person]' );
		if ( ! box ) {
			return;
		}
		Promise.all( [ hrLoad(), api( 'hr/interviews?person_id=' + p.id ) ] ).then( function ( r ) {
			var T = r[ 0 ], list = r[ 1 ].items;
			var subj = { first_name: p.first_name, last_name: p.last_name, person_id: p.id };
			var reopen = function () {
				api( 'people/' + p.id ).then( function ( pp ) {
					personForm( pp );
					var t = document.querySelector( '.bhc-modal [data-ptab="coll"]' );
					if ( t ) {
						t.click();
					}
				} );
			};
			box.innerHTML = '<div class="bhc-hrmodels">' + [ 'periodica', 'fine_prova', 'uscita' ].map( function ( k ) {
				return '<div class="bhc-formcard" style="--fc:' + esc( T[ k ].color ) + '"><strong>' + esc( T[ k ].title ) + '</strong><div class="bhc-formcard__act"><button type="button" class="bhc-btn bhc-btn--sm" data-pnew="' + k + '">Nuovo</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-ptab2="' + k + '">Tablet</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pblank="' + k + '">' + ICONS.print + '</button></div></div>';
			} ).join( '' ) + '</div>' +
				( list.length ? '<table class="bhc-table" style="margin-top:10px"><thead><tr><th>Data</th><th>Colloquio</th><th>Stato</th><th>Valutazione</th><th>Esito</th></tr></thead><tbody>' + list.map( function ( i ) {
					return '<tr class="is-click" data-piv="' + i.id + '"><td>' + esc( cardDate( i.updated_at ) ) + '</td><td>' + esc( i.title ) + ' <small class="bhc-muted bhc-mono">' + esc( i.code ) + '</small></td><td>' + ( i.signed ? '<span class="bhc-pill bhc-pill--ok">Firmato</span>' : '<span class="bhc-pill">Bozza</span>' ) + '</td><td>' + hrStars( i.rating ) + '</td><td>' + esc( i.outcome ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table>' : '<p class="bhc-muted" style="margin-top:10px">Nessun colloquio registrato.</p>' );
			box.querySelectorAll( '[data-pnew],[data-ptab2]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					hrNewInterview( b.dataset.pnew || b.dataset.ptab2, subj, reopen, !! b.dataset.ptab2 );
				} );
			} );
			box.querySelectorAll( '[data-pblank]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					printForm( { first_name: p.first_name, last_name: p.last_name }, b.dataset.pblank, null, T[ b.dataset.pblank ] );
				} );
			} );
			box.querySelectorAll( '[data-piv]' ).forEach( function ( r2 ) {
				r2.addEventListener( 'click', function () {
					hrOpenInterview( r2.dataset.piv, reopen );
				} );
			} );
			var tb = m.querySelector( '[data-ptab="coll"]' );
			if ( tb ) {
				tb.textContent = 'Colloqui (' + list.length + ')';
			}
		} );
	}

	/* ================= Orari e presenze (timbrature) ================= */

	var TC = { tab: 'week', date: '', month: '', person: 0, year: 0, an: 'open', meta: null };
	var TC_DOW = [ 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom' ];

	function tcHM( m ) {
		m = Math.round( m || 0 );
		var s = m < 0 ? '−' : '';
		m = Math.abs( m );
		return s + Math.floor( m / 60 ) + ':' + pad( m % 60 );
	}
	function tcMeta( force ) {
		if ( TC.meta && ! force ) {
			return Promise.resolve( TC.meta );
		}
		return api( 'tc/meta' ).then( function ( m ) {
			TC.meta = m;
			return m;
		} );
	}
	function tcChip( c ) {
		return '<span class="bhc-tcchip" style="--c:' + esc( c.color ) + '" data-chg="' + c.id + '" title="' + esc( c.label + ( c.ranges ? ' ' + c.ranges : '' ) + ( c.note ? ' – ' + c.note : '' ) ) + '">' + esc( c.label ) + ( c.ranges ? ' <small>' + esc( c.ranges ) + '</small>' : '' ) + '</span>';
	}
	function tcPeopleOptions( sel, withAll ) {
		return ( withAll ? '<option value="0">' + withAll + '</option>' : '' ) + TC.meta.people.map( function ( p ) {
			return '<option value="' + p.id + '"' + ( +sel === p.id ? ' selected' : '' ) + '>' + esc( p.name ) + '</option>';
		} ).join( '' );
	}

	function renderTimeclock() {
		var main = document.getElementById( 'bhc-main' );
		var now = new Date();
		TC.date = TC.date || ymd( now );
		TC.month = TC.month || TC.date.substring( 0, 7 );
		TC.year = TC.year || now.getFullYear();
		var tabs = [ [ 'week', 'Orari settimana' ], [ 'punch', 'Timbrature e cartellino' ], [ 'an', 'Anomalie' ], [ 'leave', 'Ferie e permessi' ], [ 'kiosk', 'Timbratrice e PIN' ] ];
		main.innerHTML = '<div class="bhc-top"><h2>Orari e presenze</h2><div class="bhc-top__actions" data-tcact></div></div><div class="bhc-tabs">' + tabs.map( function ( t ) {
			return '<button type="button" data-tctab="' + t[ 0 ] + '"' + ( TC.tab === t[ 0 ] ? ' class="is-active"' : '' ) + '>' + t[ 1 ] + '</button>';
		} ).join( '' ) + '</div><div data-tcbody><div class="bhc-loading">Caricamento…</div></div>';
		main.querySelectorAll( '[data-tctab]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				TC.tab = b.dataset.tctab;
				renderTimeclock();
			} );
		} );
		tcMeta( true ).then( function () {
			( { week: tcWeek, punch: tcPunches, an: tcAnomalies, leave: tcLeaves, kiosk: tcKiosk } )[ TC.tab ]();
		} ).catch( function ( e ) {
			main.querySelector( '[data-tcbody]' ).innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}
	function tcEls() {
		return { act: document.querySelector( '[data-tcact]' ), body: document.querySelector( '[data-tcbody]' ) };
	}

	/* ---------- Settimana ---------- */

	function tcWeek() {
		var el = tcEls();
		el.act.innerHTML = '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-wprev>‹</button><input type="date" data-wdate value="' + esc( TC.date ) + '"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-wnext>›</button>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-wtoday>Oggi</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-wprint>' + ICONS.print + ' Stampa</button>' +
			'<button type="button" class="bhc-btn bhc-btn--sm" data-wadd>+ Ferie, permesso, variazione</button>';
		var go = function ( d ) {
			TC.date = d;
			tcWeek();
		};
		el.act.querySelector( '[data-wprev]' ).onclick = function () {
			go( addDays( TC.date, -7 ) );
		};
		el.act.querySelector( '[data-wnext]' ).onclick = function () {
			go( addDays( TC.date, 7 ) );
		};
		el.act.querySelector( '[data-wtoday]' ).onclick = function () {
			go( ymd( new Date() ) );
		};
		el.act.querySelector( '[data-wdate]' ).onchange = function ( e ) {
			if ( e.target.value ) {
				go( e.target.value );
			}
		};
		el.act.querySelector( '[data-wadd]' ).onclick = function () {
			tcChangeModal( {} );
		};
		api( 'tc/week?date=' + TC.date ).then( function ( w ) {
			el.act.querySelector( '[data-wprint]' ).onclick = function () {
				tcPrintWeek( w );
			};
			var today = ymd( new Date() );
			if ( ! w.rows.length ) {
				el.body.innerHTML = '<div class="bhc-card bhc-empty">Nessuna persona attiva. Aggiungi il personale da Operatrici.</div>';
				return;
			}
			var head = '<tr><th>Persona</th>' + w.rows[ 0 ].days.map( function ( d, i ) {
				return '<th class="' + ( d.date === today ? 'is-today' : '' ) + '">' + TC_DOW[ i ] + ' ' + esc( d.date.substring( 8 ) ) + '/' + esc( d.date.substring( 5, 7 ) ) + '</th>';
			} ).join( '' ) + '<th class="num">Ore</th></tr>';
			el.body.innerHTML = '<p class="bhc-muted bhc-note">Settimana dal ' + esc( cardDate( w.from ) ) + ' al ' + esc( cardDate( w.to ) ) + '. Clicca una casella per inserire ferie, permessi, malattia o un cambio turno; clicca il nome per modificare l\'orario di base.</p>' +
				'<div class="bhc-tcwrap"><table class="bhc-table bhc-tcweek"><thead>' + head + '</thead><tbody>' + w.rows.map( function ( r ) {
					var contract = r.person.weekly_hours ? r.person.weekly_hours * 60 : 0;
					return '<tr><th><button type="button" class="bhc-tcname" data-base="' + r.person.id + '"><span class="bhc-dot" style="background:' + esc( r.person.color ) + '"></span>' + esc( r.person.name ) + '<small>' + esc( r.person.job_title || '' ) + '</small></button></th>' + r.days.map( function ( d ) {
						var off = ! d.employed;
						return '<td class="bhc-tccell' + ( d.date === today ? ' is-today' : '' ) + ( off ? ' is-off' : '' ) + '" data-cell="' + r.person.id + '|' + d.date + '">' +
							( off ? '<span class="bhc-muted">—</span>' : ( d.sched ? '<span class="bhc-tcsched' + ( d.shift ? ' is-shift' : '' ) + ( d.absences.some( function ( a ) {
								return a.full;
							} ) ? ' is-struck' : '' ) + '">' + esc( d.sched ).replace( /, /g, '<br>' ) + '</span>' : '<span class="bhc-muted">riposo</span>' ) ) +
							d.changes.map( tcChip ).join( '' ) + '</td>';
					} ).join( '' ) + '<td class="num"><b>' + tcHM( r.total ) + '</b>' + ( contract ? '<br><small class="' + ( Math.abs( contract - r.total ) > 1 ? 'bhc-tcwarn' : 'bhc-muted' ) + '">contratto ' + tcHM( contract ) + '</small>' : '' ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table></div><div class="bhc-tclegend">' + Object.keys( TC.meta.types ).map( function ( k ) {
					return '<span class="bhc-tcchip" style="--c:' + TC.meta.types[ k ].color + '">' + esc( TC.meta.types[ k ].label ) + '</span>';
				} ).join( '' ) + '</div>';
			el.body.querySelectorAll( '[data-cell]' ).forEach( function ( td ) {
				td.addEventListener( 'click', function ( e ) {
					var chip = e.target.closest( '[data-chg]' );
					var pd = td.dataset.cell.split( '|' );
					if ( chip ) {
						var row = w.rows.filter( function ( r ) {
							return r.person.id === +pd[ 0 ];
						} )[ 0 ];
						var c = row.days.filter( function ( d ) {
							return d.date === pd[ 1 ];
						} )[ 0 ].changes.filter( function ( x ) {
							return x.id === +chip.dataset.chg;
						} )[ 0 ];
						tcChangeView( row.person, pd[ 1 ], c, tcWeek );
						return;
					}
					tcChangeModal( { person_id: +pd[ 0 ], from: pd[ 1 ], to: pd[ 1 ] } );
				} );
			} );
			el.body.querySelectorAll( '[data-base]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () {
					tcBaseModal( w.rows.filter( function ( r ) {
						return r.person.id === +b.dataset.base;
					} )[ 0 ].person );
				} );
			} );
		} ).catch( function ( e ) {
			el.body.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function tcChangeModal( pre ) {
		var t = TC.meta.types;
		var m = modal( 'Ferie, permessi e variazioni', '<div class="bhc-field"><label>Persona</label><select data-v="person_id">' + tcPeopleOptions( pre.person_id || 0, '' ) + '<option value="all">Tutto il personale (chiusura del centro)</option></select></div>' +
			'<div class="bhc-field"><label>Tipo</label><div class="bhc-tctypes">' + Object.keys( t ).map( function ( k, i ) {
				return '<label class="bhc-tctype" style="--c:' + t[ k ].color + '"><input type="radio" name="tct" value="' + k + '"' + ( ( pre.type || 'ferie' ) === k ? ' checked' : '' ) + '> ' + esc( t[ k ].label ) + '</label>';
			} ).join( '' ) + '</div></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Dal</label><input type="date" data-v="from" value="' + esc( pre.from || TC.date ) + '"></div><div class="bhc-field"><label>Al</label><input type="date" data-v="to" value="' + esc( pre.to || pre.from || TC.date ) + '"></div></div>' +
			'<div class="bhc-field"><label data-rlabel>Solo alcune ore (vuoto = giornata intera)</label><input type="text" data-v="ranges" placeholder="es. 09:00-11:00" value="' + esc( pre.ranges || '' ) + '"><small class="bhc-muted" data-rhint></small></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Note</label><input type="text" data-v="note" value=""></div><div class="bhc-field" data-protof><label>N. protocollo certificato</label><input type="text" data-v="protocol" value=""></div></div>' +
			'<div class="bhc-msg" data-msg hidden></div>',
		'<button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn" data-ok>Salva</button>' );
		var sync = function () {
			var k = m.querySelector( 'input[name=tct]:checked' ).value;
			m.querySelector( '[data-protof]' ).hidden = k !== 'malattia' && k !== 'infortunio';
			m.querySelector( '[data-rlabel]' ).textContent = k === 'turno' ? 'Nuovo orario per questi giorni *' : ( k === 'formazione' ? 'Ore di formazione (vuoto = giornata intera)' : 'Solo alcune ore (vuoto = giornata intera)' );
			m.querySelector( '[data-rhint]' ).textContent = k === 'turno' ? 'Sostituisce l\'orario di base, es. 12:00-20:00 oppure 09:00-13:00, 15:00-19:00.' : ( k === 'malattia' || k === 'infortunio' ? 'Conta a giorni di calendario e sostituisce le ferie già inserite.' : ( k === 'ferie' ? 'Su più giorni contano solo i giorni lavorativi della persona.' : '' ) );
		};
		m.querySelectorAll( 'input[name=tct]' ).forEach( function ( r ) {
			r.addEventListener( 'change', sync );
		} );
		sync();
		m.querySelector( '[data-v=from]' ).addEventListener( 'change', function ( e ) {
			var to = m.querySelector( '[data-v=to]' );
			if ( ! to.value || to.value < e.target.value ) {
				to.value = e.target.value;
			}
		} );
		m.querySelector( '[data-x]' ).onclick = closeModal;
		m.querySelector( '[data-ok]' ).onclick = function () {
			var d = {};
			m.querySelectorAll( '[data-v]' ).forEach( function ( i ) {
				d[ i.dataset.v ] = i.value;
			} );
			d.type = m.querySelector( 'input[name=tct]:checked' ).value;
			if ( d.person_id === 'all' ) {
				d.all = 1;
				d.person_id = 0;
			}
			var msg = m.querySelector( '[data-msg]' );
			if ( d.type === 'turno' && ! d.ranges.trim() ) {
				msg.hidden = false;
				msg.className = 'bhc-msg is-error';
				msg.textContent = 'Scrivi il nuovo orario.';
				return;
			}
			api( 'tc/changes', { method: 'POST', body: d } ).then( function ( r ) {
				closeModal();
				toast( r.added === 1 ? 'Inserito' : 'Inserite ' + r.added + ' giornate' + ( r.skipped ? ' (saltati ' + r.skipped + ' giorni non lavorativi)' : '' ) );
				TC.date = d.from;
				renderTimeclock();
			} ).catch( function ( e ) {
				msg.hidden = false;
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		};
	}

	function tcChangeView( person, date, c, after ) {
		var m = modal( c.label, '<p><b>' + esc( person.name ) + '</b> · ' + esc( fmtDate( date ) ) + '</p>' + ( c.ranges ? '<p>Orario: <b>' + esc( c.ranges ) + '</b></p>' : '<p>Giornata intera</p>' ) +
			( c.note ? '<p>Note: ' + esc( c.note ) + '</p>' : '' ) + ( c.protocol ? '<p>Protocollo: ' + esc( c.protocol ) + '</p>' : '' ),
		'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--danger" data-del>Elimina questo giorno</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--danger" data-delg>Elimina tutto il periodo</button><button type="button" class="bhc-btn" data-x>Chiudi</button>' );
		var del = function ( group ) {
			api( 'tc/changes/' + c.id + ( group ? '?group=1' : '' ), { method: 'DELETE' } ).then( function () {
				closeModal();
				toast( 'Eliminato' );
				after();
			} ).catch( function ( e ) {
				toast( e.message, true );
			} );
		};
		m.querySelector( '[data-del]' ).onclick = function () {
			del( false );
		};
		m.querySelector( '[data-delg]' ).onclick = function () {
			del( true );
		};
		m.querySelector( '[data-x]' ).onclick = closeModal;
	}

	function tcBaseModal( p ) {
		var days = [ 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica' ];
		var m = modal( 'Orario di base – ' + p.name, '<p class="bhc-muted bhc-note">Orario abituale di ogni giorno, es. <b>09:00-13:00, 14:00-18:00</b>. Lascia vuoto il giorno di riposo. È lo stesso orario della scheda personale e vale per tutte le settimane: per i cambi occasionali usa «Cambio turno».</p>' +
			days.map( function ( d, i ) {
				return '<div class="bhc-row" style="grid-template-columns:100px 1fr 60px;align-items:center;margin-bottom:6px"><span>' + d + '</span><input type="text" data-sc="' + ( i + 1 ) + '" value="' + esc( ( p.schedule || {} )[ i + 1 ] || '' ) + '" placeholder="riposo"><span class="bhc-muted" data-sch="' + ( i + 1 ) + '"></span></div>';
			} ).join( '' ) + '<div class="bhc-row"><div class="bhc-field"><label>Ore settimanali da contratto</label><input type="number" step="0.5" data-wh value="' + esc( p.weekly_hours || '' ) + '"></div><div class="bhc-field"><label>Totale orario</label><div data-tot style="padding:8px 0;font-weight:600"></div></div></div><div class="bhc-msg" data-msg hidden></div>',
		'<button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn" data-ok>Salva</button>' );
		var calc = function () {
			var tot = 0;
			m.querySelectorAll( '[data-sc]' ).forEach( function ( i ) {
				var t = 0;
				i.value.split( /[,;]/ ).forEach( function ( part ) {
					var x = /(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})/.exec( part );
					if ( x && toMin( x[ 2 ] ) > toMin( x[ 1 ] ) ) {
						t += toMin( x[ 2 ] ) - toMin( x[ 1 ] );
					}
				} );
				tot += t;
				m.querySelector( '[data-sch="' + i.dataset.sc + '"]' ).textContent = t ? tcHM( t ) : '';
			} );
			m.querySelector( '[data-tot]' ).textContent = tcHM( tot ) + ' ore';
		};
		m.querySelectorAll( '[data-sc]' ).forEach( function ( i ) {
			i.addEventListener( 'input', calc );
		} );
		calc();
		m.querySelector( '[data-x]' ).onclick = closeModal;
		m.querySelector( '[data-ok]' ).onclick = function () {
			var sc = {};
			m.querySelectorAll( '[data-sc]' ).forEach( function ( i ) {
				sc[ i.dataset.sc ] = i.value.trim();
			} );
			api( 'tc/schedule/' + p.id, { method: 'PUT', body: { schedule: sc, weekly_hours: m.querySelector( '[data-wh]' ).value } } ).then( function () {
				closeModal();
				toast( 'Orario salvato' );
				tcWeek();
			} ).catch( function ( e ) {
				var msg = m.querySelector( '[data-msg]' );
				msg.hidden = false;
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		};
	}

	function tcPrintWeek( w ) {
		var win = window.open( '', '_blank' );
		if ( ! win ) {
			toast( 'Consenti le finestre popup per stampare.', true );
			return;
		}
		var html = '<h1>Orari del personale</h1><p>Settimana dal ' + esc( cardDate( w.from ) ) + ' al ' + esc( cardDate( w.to ) ) + ' · ' + esc( B.center || '' ) + '</p><table><thead><tr><th>Persona</th>' + w.rows[ 0 ].days.map( function ( d, i ) {
			return '<th>' + TC_DOW[ i ] + ' ' + d.date.substring( 8 ) + '/' + d.date.substring( 5, 7 ) + '</th>';
		} ).join( '' ) + '<th>Ore</th></tr></thead><tbody>' + w.rows.map( function ( r ) {
			return '<tr><th>' + esc( r.person.name ) + '</th>' + r.days.map( function ( d ) {
				var full = d.absences.filter( function ( a ) {
					return a.full;
				} )[ 0 ];
				return '<td>' + ( ! d.employed ? '—' : ( full ? '<b>' + esc( full.label ) + '</b>' : ( d.sched ? esc( d.sched ).replace( /, /g, '<br>' ) : '<i>riposo</i>' ) + d.changes.filter( function ( c ) {
					return c.type !== 'turno';
				} ).map( function ( c ) {
					return '<br><b>' + esc( c.label ) + '</b> ' + esc( c.ranges );
				} ).join( '' ) ) ) + '</td>';
			} ).join( '' ) + '<td>' + tcHM( r.total ) + '</td></tr>';
		} ).join( '' ) + '</tbody></table>';
		win.document.write( '<!doctype html><html lang="it"><head><meta charset="utf-8"><title>Orari settimana</title><style>@page{size:A4 landscape;margin:10mm}body{font-family:Helvetica,Arial,sans-serif;font-size:9pt;color:#222}h1{font-size:15pt;margin:0}p{margin:2px 0 10px;color:#555}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:5px;vertical-align:top;text-align:left}thead th{background:#f2efe8;font-size:8pt}tbody th{width:16%}td:last-child{text-align:right;width:6%}</style></head><body>' + html + '<script>window.onload=function(){setTimeout(function(){window.print()},200)}<\/script></body></html>' );
		win.document.close();
	}

	/* ---------- Timbrature, riepilogo mensile e cartellino ---------- */

	function tcPunches() {
		var el = tcEls();
		el.act.innerHTML = '<input type="month" data-pm value="' + esc( TC.month ) + '"><select data-pp>' + tcPeopleOptions( TC.person, 'Riepilogo di tutto il personale' ) + '</select>' +
			'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pcsv>Esporta CSV</button>' + ( TC.person ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pprint>' + ICONS.print + ' Cartellino</button><button type="button" class="bhc-btn bhc-btn--sm" data-padd>+ Timbratura</button>' : '' );
		el.act.querySelector( '[data-pm]' ).onchange = function ( e ) {
			if ( e.target.value ) {
				TC.month = e.target.value;
				tcPunches();
			}
		};
		el.act.querySelector( '[data-pp]' ).onchange = function ( e ) {
			TC.person = +e.target.value;
			tcPunches();
		};
		el.body.innerHTML = '<div class="bhc-loading">Caricamento…</div>';
		api( 'tc/month?month=' + TC.month + ( TC.person ? '&person=' + TC.person : '' ) ).then( function ( d ) {
			var present = '<div class="bhc-card bhc-tcpresent"><b>Presenti adesso</b> ' + ( d.present.length ? d.present.map( function ( p ) {
				return '<span class="bhc-tcin"><span class="bhc-dot" style="background:' + esc( p.color ) + '"></span>' + esc( p.name ) + ' <small>dalle ' + esc( p.since ) + '</small></span>';
			} ).join( '' ) : '<span class="bhc-muted">nessuno ha timbrato l\'entrata</span>' ) + '</div>';
			el.act.querySelector( '[data-pcsv]' ).onclick = function () {
				tcCsv( d );
			};
			if ( ! TC.person ) {
				el.body.innerHTML = present + '<table class="bhc-table"><thead><tr><th>Persona</th><th class="num">Ore previste nel mese</th><th class="num">Previste fino a ieri</th><th class="num">Lavorate fino a ieri</th><th class="num">Saldo</th><th>Assenze</th><th>Anomalie</th></tr></thead><tbody>' + d.rows.map( function ( r ) {
					var s = r.sum;
					return '<tr class="is-click" data-prow="' + r.person.id + '"><td><span class="bhc-dot" style="background:' + esc( r.person.color ) + '"></span> <b>' + esc( r.person.name ) + '</b></td><td class="num">' + tcHM( s.expected ) + '</td>' + ( s.tracking ? '<td class="num">' + tcHM( s.expected_to_date ) + '</td><td class="num"><b>' + tcHM( s.worked_to_date ) + '</b></td>' +
						'<td class="num ' + ( s.diff < -15 ? 'bhc-tcneg' : ( s.diff > 15 ? 'bhc-tcpos' : '' ) ) + '">' + ( s.diff > 0 ? '+' : '' ) + tcHM( s.diff ) + '</td>' : '<td colspan="3" class="num bhc-muted">non ha ancora timbrato</td>' ) + '<td>' + Object.keys( s.absences ).map( function ( k ) {
							var a = s.absences[ k ];
							return '<span class="bhc-tcchip" style="--c:' + esc( TC.meta.types[ k ] ? TC.meta.types[ k ].color : '#999' ) + '">' + esc( a.label ) + ' ' + ( a.days ? a.days + ' gg' : tcHM( a.minutes ) + ' h' ) + '</span>';
						} ).join( '' ) + '</td><td>' + ( s.open ? '<span class="bhc-pill bhc-pill--warn">' + s.open + ' da giustificare</span>' : ( s.anomalies ? '<span class="bhc-pill bhc-pill--ok">giustificate</span>' : '<span class="bhc-muted">—</span>' ) ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table><p class="bhc-muted bhc-note">Clicca una persona per vedere il foglio presenze giorno per giorno, correggere le timbrature e stampare il cartellino.</p>';
				el.body.querySelectorAll( '[data-prow]' ).forEach( function ( tr ) {
					tr.onclick = function () {
						TC.person = +tr.dataset.prow;
						tcPunches();
					};
				} );
				return;
			}
			var r = d.rows[ 0 ];
			if ( ! r ) {
				el.body.innerHTML = present + '<div class="bhc-card bhc-empty">Nessun dato.</div>';
				return;
			}
			el.act.querySelector( '[data-pprint]' ).onclick = function () {
				tcPrintCard( d );
			};
			el.act.querySelector( '[data-padd]' ).onclick = function () {
				tcPunchModal( r.person, ymd( new Date() ) );
			};
			var s = r.sum;
			el.body.innerHTML = present + '<div class="bhc-kpis">' + kpi( 'Ore previste nel mese', tcHM( s.expected ) ) + kpi( 'Ore lavorate', tcHM( s.worked ) ) + kpi( 'Saldo fino a ieri', ( s.diff > 0 ? '+' : '' ) + tcHM( s.diff ) ) + kpi( 'Anomalie da giustificare', s.open ) + '</div>' +
				'<table class="bhc-table bhc-tcdays"><thead><tr><th>Giorno</th><th>Orario previsto</th><th>Timbrature</th><th>Variazioni</th><th class="num">Previste</th><th class="num">Lavorate</th><th>Anomalie</th><th></th></tr></thead><tbody>' + r.days.map( function ( x ) {
					var dw = TC_DOW[ ( parseDate( x.date ).getDay() + 6 ) % 7 ];
					var future = x.date > TC.meta.today;
					return '<tr class="' + ( dw === 'Dom' ? 'is-sun' : '' ) + ( x.date === TC.meta.today ? ' is-today' : '' ) + '"><td><b>' + dw + ' ' + x.date.substring( 8 ) + '</b></td><td>' + ( x.sched ? esc( x.sched ) : '<span class="bhc-muted">riposo</span>' ) + '</td>' +
						'<td>' + x.pairs.map( function ( pr ) {
							return '<span class="bhc-tcpair">' + [ pr[ 0 ], pr[ 1 ] ].map( function ( pu, k ) {
								return pu ? '<span class="bhc-tcpunch' + ( pu.manual ? ' is-manual' : '' ) + '" title="' + ( pu.manual ? 'Inserita a mano' + ( pu.note ? ': ' + esc( pu.note ) : '' ) : 'Da timbratrice' ) + '">' + esc( pu.time ) + ( pu.manual ? '*' : '' ) + '<button type="button" data-pdel="' + pu.id + '" title="Elimina">×</button></span>' : '<span class="bhc-tcpunch is-miss">' + ( k ? 'uscita?' : 'entrata?' ) + '</span>';
							} ).join( '–' ) + '</span>';
						} ).join( ' ' ) + ( x.inside ? ' <span class="bhc-pill bhc-pill--ok">in servizio</span>' : '' ) + '</td>' +
						'<td>' + x.changes.map( tcChip ).join( '' ) + '</td><td class="num">' + ( x.expected ? tcHM( x.expected ) : '' ) + '</td><td class="num">' + ( x.worked ? '<b>' + tcHM( x.worked ) + '</b>' : '' ) + '</td>' +
						'<td>' + x.anomalies.map( function ( a ) {
							return '<span class="bhc-pill ' + ( a.open ? 'bhc-pill--warn' : 'bhc-pill--ok' ) + '" title="' + esc( a.detail || '' ) + ( a.note ? ' – ' + esc( a.note.reason ) : '' ) + '">' + esc( a.label ) + ( a.minutes ? ' ' + a.minutes + '′' : '' ) + '</span>';
						} ).join( ' ' ) + '</td><td>' + ( future ? '' : '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-padd2="' + x.date + '">+</button>' ) + '</td></tr>';
				} ).join( '' ) + '</tbody></table><p class="bhc-muted bhc-note">* timbratura inserita o corretta a mano dalla responsabile. Le timbrature eliminate restano registrate nello storico.</p>';
			el.body.querySelectorAll( '[data-padd2]' ).forEach( function ( b ) {
				b.onclick = function () {
					tcPunchModal( r.person, b.dataset.padd2 );
				};
			} );
			el.body.querySelectorAll( '[data-pdel]' ).forEach( function ( b ) {
				b.onclick = function () {
					if ( ! window.confirm( 'Eliminare questa timbratura?' ) ) {
						return;
					}
					api( 'tc/punches/' + b.dataset.pdel, { method: 'DELETE' } ).then( function () {
						toast( 'Timbratura eliminata' );
						tcPunches();
					} ).catch( function ( e ) {
						toast( e.message, true );
					} );
				};
			} );
		} ).catch( function ( e ) {
			el.body.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	function tcPunchModal( person, date, after ) {
		var m = modal( 'Timbratura manuale – ' + person.name, '<div class="bhc-row"><div class="bhc-field"><label>Giorno</label><input type="date" data-v="date" value="' + esc( date ) + '" max="' + esc( TC.meta.today ) + '"></div><div class="bhc-field"><label>Ora</label><input type="time" data-v="time" value=""></div></div>' +
			'<div class="bhc-field"><label>Tipo</label><div class="bhc-tcseg"><label><input type="radio" name="pk" value="in" checked> Entrata</label><label><input type="radio" name="pk" value="out"> Uscita</label></div></div>' +
			'<div class="bhc-field"><label>Motivo</label><input type="text" data-v="note" placeholder="es. dimenticata timbratura"></div><div class="bhc-msg" data-msg hidden></div>',
		'<button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn" data-ok>Salva</button>' );
		m.querySelector( '[data-x]' ).onclick = closeModal;
		m.querySelector( '[data-ok]' ).onclick = function () {
			var d = { person_id: person.id, kind: m.querySelector( 'input[name=pk]:checked' ).value };
			m.querySelectorAll( '[data-v]' ).forEach( function ( i ) {
				d[ i.dataset.v ] = i.value;
			} );
			api( 'tc/punches', { method: 'POST', body: d } ).then( function () {
				closeModal();
				toast( 'Timbratura inserita' );
				( after || tcPunches )();
			} ).catch( function ( e ) {
				var msg = m.querySelector( '[data-msg]' );
				msg.hidden = false;
				msg.className = 'bhc-msg is-error';
				msg.textContent = e.message;
			} );
		};
	}

	function tcCsv( d ) {
		var rows = [];
		var q = function ( v ) {
			v = String( v === null || v === undefined ? '' : v );
			return /[";\n]/.test( v ) ? '"' + v.replace( /"/g, '""' ) + '"' : v;
		};
		var h = function ( m ) {
			return ( Math.round( ( m || 0 ) / 60 * 100 ) / 100 ).toString().replace( '.', ',' );
		};
		if ( ! TC.person ) {
			rows.push( [ 'Persona', 'Ore previste mese', 'Ore previste fino a ieri', 'Ore lavorate', 'Saldo fino a ieri', 'Ferie (gg)', 'Permessi (h)', 'Malattia (gg)', 'Anomalie aperte' ] );
			d.rows.forEach( function ( r ) {
				var a = r.sum.absences;
				rows.push( [ r.person.name, h( r.sum.expected ), h( r.sum.expected_to_date ), h( r.sum.worked ), h( r.sum.diff ), a.ferie ? a.ferie.days : 0, a.permesso ? h( a.permesso.minutes ) : 0, a.malattia ? a.malattia.days : 0, r.sum.open ] );
			} );
		} else {
			rows.push( [ 'Persona', 'Data', 'Orario previsto', 'Timbrature', 'Variazioni', 'Ore previste', 'Ore lavorate', 'Anomalie' ] );
			d.rows[ 0 ].days.forEach( function ( x ) {
				rows.push( [ d.rows[ 0 ].person.name, cardDate( x.date ), x.sched, x.pairs.map( function ( p ) {
					return ( p[ 0 ] ? p[ 0 ].time + ( p[ 0 ].manual ? '*' : '' ) : '?' ) + '-' + ( p[ 1 ] ? p[ 1 ].time + ( p[ 1 ].manual ? '*' : '' ) : '?' );
				} ).join( ' ' ), x.changes.map( function ( c ) {
					return c.label + ( c.ranges ? ' ' + c.ranges : '' );
				} ).join( '; ' ), h( x.expected ), h( x.worked ), x.anomalies.map( function ( a ) {
					return a.label;
				} ).join( '; ' ) ] );
			} );
		}
		var blob = new Blob( [ '﻿' + rows.map( function ( r ) {
			return r.map( q ).join( ';' );
		} ).join( '\r\n' ) ], { type: 'text/csv;charset=utf-8' } );
		var a = document.createElement( 'a' );
		a.href = URL.createObjectURL( blob );
		a.download = 'presenze-' + TC.month + ( TC.person ? '-' + d.rows[ 0 ].person.name.replace( /\W+/g, '-' ).toLowerCase() : '' ) + '.csv';
		document.body.appendChild( a );
		a.click();
		a.remove();
	}

	function tcPrintCard( d ) {
		var r = d.rows[ 0 ];
		var win = window.open( '', '_blank' );
		if ( ! win ) {
			toast( 'Consenti le finestre popup per stampare.', true );
			return;
		}
		var mName = parseDate( d.from ).toLocaleDateString( 'it-IT', { month: 'long', year: 'numeric' } );
		var html = '<h1>Cartellino presenze</h1><p><b>' + esc( r.person.name ) + '</b>' + ( r.person.job_title ? ' · ' + esc( r.person.job_title ) : '' ) + ' · ' + esc( mName ) + ' · ' + esc( B.center || '' ) + '</p><table><thead><tr><th>Giorno</th><th>Orario previsto</th><th>Entrata</th><th>Uscita</th><th>Entrata</th><th>Uscita</th><th>Variazioni</th><th>Previste</th><th>Lavorate</th><th>Note</th></tr></thead><tbody>' + r.days.map( function ( x ) {
			var cells = [];
			x.pairs.slice( 0, 2 ).forEach( function ( p ) {
				cells.push( p[ 0 ] ? p[ 0 ].time + ( p[ 0 ].manual ? '*' : '' ) : '' );
				cells.push( p[ 1 ] ? p[ 1 ].time + ( p[ 1 ].manual ? '*' : '' ) : '' );
			} );
			while ( cells.length < 4 ) {
				cells.push( '' );
			}
			return '<tr><td>' + TC_DOW[ ( parseDate( x.date ).getDay() + 6 ) % 7 ] + ' ' + x.date.substring( 8 ) + '</td><td>' + esc( x.sched ) + '</td>' + cells.map( function ( c ) {
				return '<td>' + esc( c ) + '</td>';
			} ).join( '' ) + '<td>' + esc( x.changes.map( function ( c ) {
				return c.label + ( c.ranges ? ' ' + c.ranges : '' );
			} ).join( ', ' ) ) + '</td><td>' + ( x.expected ? tcHM( x.expected ) : '' ) + '</td><td>' + ( x.worked ? tcHM( x.worked ) : '' ) + '</td><td>' + esc( x.anomalies.map( function ( a ) {
				return a.label + ( a.note ? ' (' + a.note.reason + ')' : '' );
			} ).join( '; ' ) ) + '</td></tr>';
		} ).join( '' ) + '</tbody><tfoot><tr><td colspan="7">Totali del mese</td><td>' + tcHM( r.sum.expected ) + '</td><td>' + tcHM( r.sum.worked ) + '</td><td>Saldo fino a ieri ' + ( r.sum.diff > 0 ? '+' : '' ) + tcHM( r.sum.diff ) + '</td></tr></tfoot></table>' +
			'<p class="small">* timbratura inserita o corretta a mano.</p><div class="sign"><div>Firma del dipendente<span></span></div><div>Firma della responsabile<span></span></div></div>';
		win.document.write( '<!doctype html><html lang="it"><head><meta charset="utf-8"><title>Cartellino ' + esc( r.person.name ) + '</title><style>@page{size:A4 landscape;margin:9mm}body{font-family:Helvetica,Arial,sans-serif;font-size:8.5pt;color:#222}h1{font-size:14pt;margin:0}p{margin:2px 0 8px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:3px 5px;text-align:left}thead th{background:#f2efe8;font-size:7.5pt}tfoot td{font-weight:bold;background:#faf8f4}.small{font-size:7.5pt;color:#555}.sign{display:flex;gap:40px;margin-top:16px}.sign div{flex:1}.sign span{display:block;border-bottom:1px solid #999;height:12mm}</style></head><body>' + html + '<script>window.onload=function(){setTimeout(function(){window.print()},200)}<\/script></body></html>' );
		win.document.close();
	}

	/* ---------- Anomalie ---------- */

	function tcAnomalies() {
		var el = tcEls();
		el.act.innerHTML = '<input type="month" data-am value="' + esc( TC.month ) + '"><select data-as><option value="open">Da giustificare</option><option value="done">Gestite</option><option value="all">Tutte</option></select>';
		el.act.querySelector( '[data-as]' ).value = TC.an;
		el.act.querySelector( '[data-am]' ).onchange = function ( e ) {
			if ( e.target.value ) {
				TC.month = e.target.value;
				tcAnomalies();
			}
		};
		el.act.querySelector( '[data-as]' ).onchange = function ( e ) {
			TC.an = e.target.value;
			tcAnomalies();
		};
		el.body.innerHTML = '<div class="bhc-loading">Caricamento…</div>';
		api( 'tc/anomalies?month=' + TC.month + '&status=' + TC.an ).then( function ( d ) {
			if ( ! d.items.length ) {
				el.body.innerHTML = '<div class="bhc-card bhc-empty">' + ( TC.an === 'open' ? 'Nessuna anomalia da giustificare in questo mese.' : 'Nessuna anomalia.' ) + '</div><p class="bhc-muted bhc-note">Il controllo parte dalla prima timbratura di ogni persona e confronta le timbrature con l\'orario previsto (tolleranza ' + TC.meta.settings.tolerance + ' minuti).</p>';
				return;
			}
			el.body.innerHTML = '<table class="bhc-table"><thead><tr><th>Giorno</th><th>Persona</th><th>Anomalia</th><th>Dettaglio</th><th>Stato</th><th></th></tr></thead><tbody>' + d.items.map( function ( a, i ) {
				return '<tr><td>' + esc( fmtDate( a.date, { weekday: 'short', day: 'numeric', month: 'short' } ) ) + '</td><td><span class="bhc-dot" style="background:' + esc( a.person.color ) + '"></span> ' + esc( a.person.name ) + '</td><td><b>' + esc( a.label ) + '</b>' + ( a.minutes ? ' <span class="bhc-muted">' + a.minutes + ' min</span>' : '' ) + '</td>' +
					'<td class="bhc-muted" style="font-size:.8rem">' + ( a.sched ? 'Previsto ' + esc( a.sched ) + '<br>' : '' ) + ( a.pairs.length ? 'Timbrature ' + esc( a.pairs.join( ' ' ) ) : 'Nessuna timbratura' ) + '</td>' +
					'<td>' + ( a.note ? '<span class="bhc-pill ' + ( a.note.status === 'respinta' ? 'bhc-pill--warn' : 'bhc-pill--ok' ) + '">' + ( a.note.status === 'respinta' ? 'Respinta' : 'Giustificata' ) + '</span> <small>' + esc( a.note.reason + ( a.note.note ? ' – ' + a.note.note : '' ) ) + '</small>' : '<span class="bhc-pill bhc-pill--warn">Da giustificare</span>' ) + '</td>' +
					'<td class="bhc-nowrap"><button type="button" class="bhc-btn bhc-btn--sm" data-aj="' + i + '">Giustifica</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-afix="' + i + '" title="Apri il foglio presenze per correggere le timbrature">Correggi</button>' + ( a.note ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-aro="' + i + '">Riapri</button>' : '' ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table>';
			var send = function ( a, body ) {
				body.person_id = a.person.id;
				body.day = a.date;
				body.code = a.code;
				return api( 'tc/anomalies', { method: 'POST', body: body } ).then( function () {
					closeModal();
					tcAnomalies();
				} ).catch( function ( e ) {
					toast( e.message, true );
				} );
			};
			el.body.querySelectorAll( '[data-aj]' ).forEach( function ( b ) {
				b.onclick = function () {
					var a = d.items[ +b.dataset.aj ];
					var m = modal( a.label + ' – ' + a.person.name, '<p class="bhc-muted">' + esc( fmtDate( a.date ) ) + ( a.detail ? ' · ' + esc( a.detail ) : '' ) + '</p><div class="bhc-field"><label>Motivo</label><select data-r>' + TC.meta.reasons.map( function ( r ) {
						return '<option' + ( a.note && a.note.reason === r ? ' selected' : '' ) + '>' + esc( r ) + '</option>';
					} ).join( '' ) + '</select></div><div class="bhc-field"><label>Note</label><input type="text" data-n value="' + esc( a.note ? a.note.note : '' ) + '"></div>' +
						( a.code === 'absent' ? '<p class="bhc-muted bhc-note">Se era ferie, permesso o malattia, inseriscilo da «Orari settimana»: l\'anomalia sparisce da sola.</p>' : '' ),
					'<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--danger" data-no>Respingi</button><button type="button" class="bhc-btn" data-ok>' + ICONS.check + ' Approva giustificazione</button>' );
					var go = function ( st ) {
						send( a, { status: st, reason: m.querySelector( '[data-r]' ).value, note: m.querySelector( '[data-n]' ).value } );
					};
					m.querySelector( '[data-ok]' ).onclick = function () {
						go( 'approvata' );
					};
					m.querySelector( '[data-no]' ).onclick = function () {
						go( 'respinta' );
					};
				};
			} );
			el.body.querySelectorAll( '[data-aro]' ).forEach( function ( b ) {
				b.onclick = function () {
					send( d.items[ +b.dataset.aro ], { status: 'reopen' } );
				};
			} );
			el.body.querySelectorAll( '[data-afix]' ).forEach( function ( b ) {
				b.onclick = function () {
					var a = d.items[ +b.dataset.afix ];
					TC.person = a.person.id;
					TC.month = a.date.substring( 0, 7 );
					TC.tab = 'punch';
					renderTimeclock();
				};
			} );
		} ).catch( function ( e ) {
			el.body.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	/* ---------- Ferie e permessi ---------- */

	function tcLeaves() {
		var el = tcEls();
		var y = new Date().getFullYear();
		el.act.innerHTML = '<select data-ly>' + [ y - 1, y, y + 1 ].map( function ( v ) {
			return '<option' + ( v === TC.year ? ' selected' : '' ) + '>' + v + '</option>';
		} ).join( '' ) + '</select><button type="button" class="bhc-btn bhc-btn--sm" data-ladd>+ Ferie o permesso</button>';
		el.act.querySelector( '[data-ly]' ).onchange = function ( e ) {
			TC.year = +e.target.value;
			tcLeaves();
		};
		el.act.querySelector( '[data-ladd]' ).onclick = function () {
			tcChangeModal( {} );
		};
		el.body.innerHTML = '<div class="bhc-loading">Caricamento…</div>';
		api( 'tc/leaves?year=' + TC.year ).then( function ( d ) {
			var n = function ( v ) {
				return ( Math.round( v * 100 ) / 100 ).toLocaleString( 'it-IT' );
			};
			el.body.innerHTML = '<table class="bhc-table bhc-tcleave"><thead><tr><th rowspan="2">Persona</th><th colspan="4" class="grp">Ferie (giorni)</th><th colspan="4" class="grp">Permessi / ROL (ore)</th><th rowspan="2" class="num">Malattia<br>(gg)</th><th rowspan="2"></th></tr>' +
				'<tr><th class="num">Spettanti</th><th class="num">Godute</th><th class="num">Programmate</th><th class="num">Residuo</th><th class="num">Spettanti</th><th class="num">Usate</th><th class="num">Programmate</th><th class="num">Residuo</th></tr></thead><tbody>' + d.rows.map( function ( r, i ) {
					return '<tr><td><span class="bhc-dot" style="background:' + esc( r.person.color ) + '"></span> <b>' + esc( r.person.name ) + '</b></td>' +
						'<td class="num">' + n( r.vac_prev + r.vac_days ) + ( r.vac_prev ? '<br><small class="bhc-muted">di cui ' + n( r.vac_prev ) + ' anno prec.</small>' : '' ) + '</td><td class="num">' + n( r.vac_used ) + '</td><td class="num">' + n( r.vac_plan ) + '</td><td class="num"><b class="' + ( r.vac_left < 0 ? 'bhc-tcneg' : '' ) + '">' + n( r.vac_left ) + '</b></td>' +
						'<td class="num">' + n( r.rol_prev + r.rol_hours ) + '</td><td class="num">' + n( r.rol_used ) + '</td><td class="num">' + n( r.rol_plan ) + '</td><td class="num"><b class="' + ( r.rol_left < 0 ? 'bhc-tcneg' : '' ) + '">' + n( r.rol_left ) + '</b></td>' +
						'<td class="num">' + ( r.sick + r.injury ) + '</td><td><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-led="' + i + '">Modifica</button></td></tr>';
				} ).join( '' ) + '</tbody></table><p class="bhc-muted bhc-note">Spettanze predefinite: ' + TC.meta.settings.vac_days + ' giorni di ferie e ' + TC.meta.settings.rol_hours + ' ore di permessi l\'anno, in proporzione ai mesi di servizio per chi è assunto o cessa durante l\'anno (si cambiano in «Timbratrice e PIN»). Le ferie si contano a giorni lavorativi secondo l\'orario della persona; i permessi a ore. Verifica sempre le spettanze del tuo CCNL con il consulente del lavoro.</p>';
			el.body.querySelectorAll( '[data-led]' ).forEach( function ( b ) {
				b.onclick = function () {
					var r = d.rows[ +b.dataset.led ];
					var m = modal( 'Ferie e permessi ' + d.year + ' – ' + r.person.name, '<div class="bhc-row"><div class="bhc-field"><label>Ferie residue anno precedente (gg)</label><input type="number" step="0.5" data-l="vac_prev" value="' + r.vac_prev + '"></div><div class="bhc-field"><label>Ferie spettanti ' + d.year + ' (gg)</label><input type="number" step="0.5" data-l="vac_days" value="' + r.vac_days + '"></div></div>' +
						'<div class="bhc-row"><div class="bhc-field"><label>Permessi residui anno precedente (h)</label><input type="number" step="0.5" data-l="rol_prev" value="' + r.rol_prev + '"></div><div class="bhc-field"><label>Permessi spettanti ' + d.year + ' (h)</label><input type="number" step="0.5" data-l="rol_hours" value="' + r.rol_hours + '"></div></div>',
					'<button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn" data-ok>Salva</button>' );
					m.querySelector( '[data-x]' ).onclick = closeModal;
					m.querySelector( '[data-ok]' ).onclick = function () {
						var body = { year: d.year };
						m.querySelectorAll( '[data-l]' ).forEach( function ( i ) {
							body[ i.dataset.l ] = i.value;
						} );
						api( 'tc/leaves/' + r.person.id, { method: 'PUT', body: body } ).then( function () {
							closeModal();
							toast( 'Salvato' );
							tcLeaves();
						} ).catch( function ( e ) {
							toast( e.message, true );
						} );
					};
				};
			} );
		} ).catch( function ( e ) {
			el.body.innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	/* ---------- Timbratrice, PIN e impostazioni ---------- */

	function tcLoadQr( cb ) {
		if ( typeof window.qrcode === 'function' ) {
			cb();
			return;
		}
		var s = document.createElement( 'script' );
		s.src = String( cfg.data || '' ).replace( /data\/?$/, 'vendor/' ) + 'qrcode.js?v=1';
		s.onload = cb;
		document.head.appendChild( s );
	}

	function tcKiosk() {
		var el = tcEls();
		el.act.innerHTML = '';
		var st = TC.meta.settings;
		el.body.innerHTML = '<div class="bhc-tcgrid"><div class="bhc-card"><h3>Timbratrice su tablet</h3>' +
			( st.enabled ? '<p class="bhc-muted">Apri questo indirizzo sul tablet della reception (meglio a schermo intero o aggiunto alla schermata Home). Ognuna timbra con il suo PIN: il tablet non dà accesso al gestionale.</p>' +
				'<div class="bhc-tclink"><input type="text" readonly value="' + esc( st.url ) + '" data-url><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-copy>Copia</button><a class="bhc-btn bhc-btn--ghost bhc-btn--sm" href="' + esc( st.url ) + '" target="_blank" rel="noopener">Apri</a></div>' +
				'<div class="bhc-tcqr" data-qr></div><p class="bhc-muted bhc-note">Inquadra il QR con il tablet per aprire la timbratrice. Se il link finisce in mani sbagliate generane uno nuovo: quello vecchio smette subito di funzionare.</p>' +
				'<div class="bhc-btnrow"><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-newtok>Genera nuovo link</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm bhc-btn--danger" data-off>Disattiva timbratrice</button></div>' :
				'<p class="bhc-muted">La timbratrice è spenta. Attivandola ottieni un link segreto (e il QR) da aprire sul tablet della sede: il personale timbra entrata e uscita con un PIN personale di 4–6 cifre.</p><button type="button" class="bhc-btn" data-on>Attiva timbratrice</button>' ) +
			'</div><div class="bhc-card"><h3>Impostazioni</h3><div class="bhc-field"><label>Tolleranza su ritardi e uscite (minuti)</label><input type="number" min="0" max="60" data-s="tolerance" value="' + st.tolerance + '"></div>' +
			'<div class="bhc-row"><div class="bhc-field"><label>Ferie annue (giorni)</label><input type="number" step="0.5" data-s="vac_days" value="' + st.vac_days + '"></div><div class="bhc-field"><label>Permessi / ROL annui (ore)</label><input type="number" step="0.5" data-s="rol_hours" value="' + st.rol_hours + '"></div></div>' +
			'<button type="button" class="bhc-btn bhc-btn--sm" data-ssave>Salva impostazioni</button></div></div>' +
			'<h3 class="bhc-fsec">PIN del personale</h3><p class="bhc-muted bhc-note">Il PIN si vede una volta sola quando lo generi: comunicalo alla persona. Nel gestionale resta salvata solo un\'impronta cifrata, quindi se lo dimentica ne generi uno nuovo.</p>' +
			'<table class="bhc-table"><thead><tr><th>Persona</th><th>Mansione</th><th>PIN</th><th></th></tr></thead><tbody>' + TC.meta.people.filter( function ( p ) {
				return p.status === 'attivo';
			} ).map( function ( p ) {
				return '<tr><td><span class="bhc-dot" style="background:' + esc( p.color ) + '"></span> <b>' + esc( p.name ) + '</b></td><td>' + esc( p.job_title || '' ) + '</td><td>' + ( p.has_pin ? '<span class="bhc-pill bhc-pill--ok">Impostato</span>' : '<span class="bhc-pill">Non impostato</span>' ) + '</td>' +
					'<td class="bhc-nowrap"><button type="button" class="bhc-btn bhc-btn--sm" data-pgen="' + p.id + '">' + ( p.has_pin ? 'Nuovo PIN' : 'Genera PIN' ) + '</button><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-pset="' + p.id + '">Scegli PIN</button>' + ( p.has_pin ? '<button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm bhc-btn--danger" data-prm="' + p.id + '">Rimuovi</button>' : '' ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table>';
		var save = function ( body, msg ) {
			return api( 'tc/settings', { method: 'PUT', body: body } ).then( function ( m ) {
				TC.meta = m;
				toast( msg );
				tcKiosk();
			} ).catch( function ( e ) {
				toast( e.message, true );
			} );
		};
		var q = function ( s ) {
			return el.body.querySelector( s );
		};
		if ( q( '[data-on]' ) ) {
			q( '[data-on]' ).onclick = function () {
				save( { enabled: 1 }, 'Timbratrice attivata' );
			};
		}
		if ( q( '[data-off]' ) ) {
			q( '[data-off]' ).onclick = function () {
				save( { enabled: 0 }, 'Timbratrice disattivata' );
			};
			q( '[data-newtok]' ).onclick = function () {
				if ( window.confirm( 'Il link attuale smetterà di funzionare: dovrai aprire quello nuovo sul tablet. Continuare?' ) ) {
					save( { new_token: 1 }, 'Nuovo link generato' );
				}
			};
			q( '[data-copy]' ).onclick = function () {
				var i = q( '[data-url]' );
				i.select();
				( navigator.clipboard ? navigator.clipboard.writeText( i.value ) : Promise.reject() ).then( function () {
					toast( 'Link copiato' );
				}, function () {
					document.execCommand( 'copy' );
					toast( 'Link copiato' );
				} );
			};
			tcLoadQr( function () {
				var box = q( '[data-qr]' );
				if ( box && typeof window.qrcode === 'function' ) {
					var qr = window.qrcode( 0, 'M' );
					qr.addData( st.url );
					qr.make();
					box.innerHTML = qr.createSvgTag( { cellSize: 4, margin: 2, scalable: true } );
				}
			} );
		}
		q( '[data-ssave]' ).onclick = function () {
			var body = {};
			el.body.querySelectorAll( '[data-s]' ).forEach( function ( i ) {
				body[ i.dataset.s ] = i.value;
			} );
			save( body, 'Impostazioni salvate' );
		};
		var person = function ( id ) {
			return TC.meta.people.filter( function ( p ) {
				return p.id === +id;
			} )[ 0 ];
		};
		var showPin = function ( p, pin ) {
			var m = modal( 'PIN di ' + p.name, '<div class="bhc-tcpin">' + esc( pin ) + '</div><p class="bhc-muted" style="text-align:center">Comunica il PIN a ' + esc( p.first_name ) + ': non sarà più visibile.</p>', '<button type="button" class="bhc-btn" data-x>Fatto</button>' );
			m.querySelector( '[data-x]' ).onclick = function () {
				closeModal();
				tcMeta( true ).then( tcKiosk );
			};
		};
		el.body.querySelectorAll( '[data-pgen]' ).forEach( function ( b ) {
			b.onclick = function () {
				var p = person( b.dataset.pgen );
				if ( p.has_pin && ! window.confirm( 'Il PIN attuale di ' + p.name + ' smetterà di funzionare. Continuare?' ) ) {
					return;
				}
				api( 'tc/pin/' + p.id, { method: 'POST', body: {} } ).then( function ( r ) {
					showPin( p, r.pin );
				} ).catch( function ( e ) {
					toast( e.message, true );
				} );
			};
		} );
		el.body.querySelectorAll( '[data-pset]' ).forEach( function ( b ) {
			b.onclick = function () {
				var p = person( b.dataset.pset );
				var m = modal( 'Scegli il PIN di ' + p.name, '<div class="bhc-field"><label>PIN (da 4 a 6 cifre)</label><input type="text" inputmode="numeric" maxlength="6" autocomplete="off" data-pin></div><div class="bhc-msg" data-msg hidden></div>', '<button type="button" class="bhc-btn bhc-btn--ghost" data-x>Annulla</button><button type="button" class="bhc-btn" data-ok>Salva</button>' );
				m.querySelector( '[data-x]' ).onclick = closeModal;
				m.querySelector( '[data-ok]' ).onclick = function () {
					var v = m.querySelector( '[data-pin]' ).value.trim();
					api( 'tc/pin/' + p.id, { method: 'POST', body: { pin: v } } ).then( function () {
						closeModal();
						toast( 'PIN salvato' );
						tcMeta( true ).then( tcKiosk );
					} ).catch( function ( e ) {
						var msg = m.querySelector( '[data-msg]' );
						msg.hidden = false;
						msg.className = 'bhc-msg is-error';
						msg.textContent = e.message;
					} );
				};
			};
		} );
		el.body.querySelectorAll( '[data-prm]' ).forEach( function ( b ) {
			b.onclick = function () {
				var p = person( b.dataset.prm );
				if ( window.confirm( 'Rimuovere il PIN di ' + p.name + '? Non potrà più timbrare finché non ne generi uno.' ) ) {
					api( 'tc/pin/' + p.id, { method: 'DELETE' } ).then( function () {
						toast( 'PIN rimosso' );
						tcMeta( true ).then( tcKiosk );
					} );
				}
			};
		} );
	}

	/* ================= Report ================= */

	function rangeDates( r ) {
		var t = parseDate( B.today );
		var from, to;
		if ( r === 'today' ) {
			from = to = B.today;
		} else if ( r === 'week' ) {
			from = weekStart( B.today );
			to = addDays( from, 6 );
		} else if ( r === 'month' ) {
			from = ymd( new Date( t.getFullYear(), t.getMonth(), 1 ) );
			to = ymd( new Date( t.getFullYear(), t.getMonth() + 1, 0 ) );
		} else if ( r === 'lastmonth' ) {
			from = ymd( new Date( t.getFullYear(), t.getMonth() - 1, 1 ) );
			to = ymd( new Date( t.getFullYear(), t.getMonth(), 0 ) );
		} else {
			from = ymd( new Date( t.getFullYear(), 0, 1 ) );
			to = ymd( new Date( t.getFullYear(), 11, 31 ) );
		}
		return [ from, to ];
	}

	function renderReport() {
		var main = document.getElementById( 'bhc-main' );
		var opts = [ [ 'today', 'Oggi' ], [ 'week', 'Questa settimana' ], [ 'month', 'Questo mese' ], [ 'lastmonth', 'Mese scorso' ], [ 'year', 'Quest\'anno' ] ];
		main.innerHTML = '<div class="bhc-top"><h2>Report</h2><div class="bhc-top__actions"><select data-range>' + opts.map( function ( o ) {
			return '<option value="' + o[ 0 ] + '"' + ( S.reportRange === o[ 0 ] ? ' selected' : '' ) + '>' + o[ 1 ] + '</option>';
		} ).join( '' ) + '</select><button type="button" class="bhc-btn bhc-btn--ghost bhc-btn--sm" data-print-report>Stampa</button></div></div><div data-report><div class="bhc-loading">Caricamento…</div></div>';
		main.querySelector( '[data-range]' ).addEventListener( 'change', function ( e ) {
			S.reportRange = e.target.value;
			renderReport();
		} );
		main.querySelector( '[data-print-report]' ).addEventListener( 'click', function () {
			window.print();
		} );
		var r = rangeDates( S.reportRange );
		api( 'stats?from=' + r[ 0 ] + '&to=' + r[ 1 ] ).then( function ( d ) {
			var maxT = Math.max.apply( null, d.by_treatment.map( function ( x ) {
				return x.n;
			} ).concat( [ 1 ] ) );
			var html = '<div class="bhc-kpis">' +
				kpi( 'Incassato', euro( d.revenue ) ) +
				kpi( 'Appuntamenti', d.appointments ) +
				kpi( 'No-show', d.noshow_rate + '%' ) +
				kpi( 'Nuove clienti', d.new_clients ) +
				kpi( 'Prenotazioni online', d.online_bookings ) + '</div>';
			html += '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px">';
			html += '<div class="bhc-card"><h3>Trattamenti più richiesti</h3>' + ( d.by_treatment.length ? d.by_treatment.map( function ( t ) {
				return '<div style="margin:10px 0"><div style="display:flex;justify-content:space-between"><span>' + esc( t.name ) + '</span><span class="bhc-muted">' + t.n + ' · ' + euro( t.value ) + '</span></div><div class="bhc-bar"><span style="width:' + Math.round( t.n / maxT * 100 ) + '%"></span></div></div>';
			} ).join( '' ) : '<p class="bhc-muted">Nessun dato.</p>' ) + '</div>';
			html += '<div class="bhc-card"><h3>Occupazione cabine</h3>' + ( d.by_staff.length ? '<table class="bhc-table" style="box-shadow:none"><thead><tr><th>Cabina</th><th>Appunt.</th><th>Ore occupate</th><th>Valore</th></tr></thead><tbody>' + d.by_staff.map( function ( s ) {
				return '<tr><td><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:' + esc( s.color ) + ';margin-right:6px"></span>' + esc( s.name ) + '</td><td>' + s.n + '</td><td>' + s.hours + '</td><td>' + euro( s.value ) + '</td></tr>';
			} ).join( '' ) + '</tbody></table>' : '<p class="bhc-muted">Nessun dato.</p>' ) + '</div>';
			html += '<div class="bhc-card"><h3>Incassi per metodo</h3>' + ( d.by_method.length ? d.by_method.map( function ( p ) {
				return '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #eee"><span>' + esc( B.methods[ p.method ] || p.method ) + '</span><strong>' + euro( p.total ) + '</strong></div>';
			} ).join( '' ) : '<p class="bhc-muted">Nessun incasso.</p>' ) + '</div>';
			html += '<div class="bhc-card"><h3>Stato appuntamenti</h3>' + Object.keys( d.status ).map( function ( k ) {
				return '<div style="display:flex;justify-content:space-between;padding:6px 0"><span class="bhc-badge bhc-badge--' + k + '">' + esc( B.statuses[ k ] ) + '</span><strong>' + d.status[ k ] + '</strong></div>';
			} ).join( '' ) + '</div>';
			html += '</div>';
			document.querySelector( '[data-report]' ).innerHTML = html;
		} ).catch( function ( e ) {
			document.querySelector( '[data-report]' ).innerHTML = '<div class="bhc-card bhc-msg is-error">' + esc( e.message ) + '</div>';
		} );
	}

	/* ================= Avvio ================= */

	api( 'bootstrap' ).then( function ( data ) {
		B = data;
		B.hours = B.hours || {};
		S.date = B.today;
		var first = navItems()[ 0 ];
		if ( ! first ) {
			root.innerHTML = '<div class="bhc-box" style="margin:40px auto">Il tuo ruolo non ha ancora permessi nel gestionale. Chiedi all\'amministratore.</div>';
			return;
		}
		if ( ! navItems().some( function ( n ) {
			return n[ 0 ] === S.view;
		} ) ) {
			S.view = first[ 0 ];
		}
		shell();
		render();
		// Aggiorna l'agenda ogni 2 minuti (per vedere le prenotazioni online).
		setInterval( function () {
			if ( S.view === 'agenda' && ! document.querySelector( '.bhc-modal' ) && ! document.hidden ) {
				loadAgenda();
			}
		}, 120000 );
	} ).catch( function ( e ) {
		root.innerHTML = '<div class="bhc-box bhc-msg is-error" style="margin:40px auto">' + esc( e.message ) + '</div>';
	} );
} )();
